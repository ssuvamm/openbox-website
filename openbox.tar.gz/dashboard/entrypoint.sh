#!/bin/sh
# Runtime GID alignment for docker socket access.
#
# The dashboard container runs as the unprivileged `node` user, but needs
# to talk to the docker daemon via /var/run/docker.sock. The socket's GID
# varies by host (121 on UGREEN UGOS, 999 on most Debian/Ubuntu, different
# on Rocky/Alma). We can't hardcode it in the Dockerfile. Detect at runtime
# and add the `node` user to whatever group owns the socket.

set -e

if [ -S /var/run/docker.sock ]; then
  SOCK_GID=$(stat -c '%g' /var/run/docker.sock 2>/dev/null || echo '')
  if [ -n "$SOCK_GID" ] && [ "$SOCK_GID" != "0" ]; then
    # Does a group with this GID already exist in the container?
    if ! getent group "$SOCK_GID" >/dev/null 2>&1; then
      addgroup -g "$SOCK_GID" dockerhost 2>/dev/null || true
    fi
    GROUP_NAME=$(getent group "$SOCK_GID" | cut -d: -f1)
    if [ -n "$GROUP_NAME" ]; then
      addgroup node "$GROUP_NAME" 2>/dev/null || true
    fi
  fi
fi

# Self-heal install-dir permissions on every startup.
#
# UGREEN UGOS reapplies its own ACLs at boot and sometimes clamps
# bind-mounted directories to mode 000 — most painfully /app/public,
# which makes the dashboard return HTTP 500 on every request because
# even the static index.html can't be opened. Same thing can happen
# with /app/state/sessions which leaves users unable to log in.
#
# The fix is to chmod the install-relevant paths back to sane values
# every time the container starts. We're root here (haven't dropped
# to `node` yet) so chmod works against the host filesystem via the
# bind mount. Idempotent — does nothing on installs where perms are
# already correct.
for p in /app/state /app/state/sessions /app/backups /app/data /app/.env /app/public /app/lib /app/openbox /app/VERSION; do
  if [ -e "$p" ]; then
    chmod -R u+rwX,g+rwX,o+rX "$p" 2>/dev/null || true
  fi
done

# Drop to node user and run the server.
exec su-exec node "$@"
