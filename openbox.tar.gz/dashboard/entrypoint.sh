#!/bin/sh
# Runtime GID alignment for docker socket access.
#
# The dashboard container runs as the unprivileged `node` user, but needs
# to talk to the docker daemon via /var/run/docker.sock. The socket's GID
# varies by host (121 on UGREEN UGOS, 999 on most Debian/Ubuntu, different
# on Rocky/Alma). We can't hardcode it in the Dockerfile. Detect at runtime
# and add the `node` user to whatever group owns the socket.

set -e

if [ -S /var/run/docker.sock ]; then
  SOCK_GID=$(stat -c '%g' /var/run/docker.sock 2>/dev/null || echo '')
  if [ -n "$SOCK_GID" ] && [ "$SOCK_GID" != "0" ]; then
    # Does a group with this GID already exist in the container?
    if ! getent group "$SOCK_GID" >/dev/null 2>&1; then
      addgroup -g "$SOCK_GID" dockerhost 2>/dev/null || true
    fi
    GROUP_NAME=$(getent group "$SOCK_GID" | cut -d: -f1)
    if [ -n "$GROUP_NAME" ]; then
      addgroup node "$GROUP_NAME" 2>/dev/null || true
    fi
  fi
fi

# Self-heal install-dir permissions on every startup.
#
# UGREEN UGOS reapplies its own ACLs at boot and sometimes clamps
# bind-mounted directories to mode 000 — most painfully /app/public,
# which makes the dashboard return HTTP 500 on every request because
# even the static index.html can't be opened. Same thing can happen
# with /app/state/sessions which leaves users unable to log in.
#
# The fix is to chmod the install-relevant paths back to sane values
# every time the container starts. We're root here (haven't dropped
# to `node` yet) so chmod works against the host filesystem via the
# bind mount. Idempotent — does nothing on installs where perms are
# already correct.
for p in /app/state /app/state/sessions /app/backups /app/data /app/.env /app/public /app/lib /app/openbox /app/VERSION; do
  if [ -e "$p" ]; then
    chmod -R u+rwX,g+rwX,o+rX "$p" 2>/dev/null || true
  fi
done

# Heal module config-dir permissions while still root.
#
# Non-linuxserver images (seerr, n8n, etc.) run as a fixed non-root user
# and crash on startup if their bind-mounted config dir is owned by root.
# This happens on re-installs: a prior failed compose-up may have let
# Docker auto-create the dirs as root before the service errored out.
# prepareModuleConfigDirs() in modules.js creates them before compose,
# but can't chown root-owned dirs from the unprivileged node user.
# Running chown here (as root, before su-exec) heals stale ownership
# on every dashboard restart. Idempotent — no-op when already correct.
PUID_VAL=$(grep -m1 '^PUID=' /app/.env 2>/dev/null | cut -d= -f2 | tr -d '[:space:]' || echo '1000')
PGID_VAL=$(grep -m1 '^PGID=' /app/.env 2>/dev/null | cut -d= -f2 | tr -d '[:space:]' || echo '1000')
PUID_VAL=${PUID_VAL:-1000}
PGID_VAL=${PGID_VAL:-1000}
for config_dir in /app/modules/*/config; do
  [ -d "$config_dir" ] && chown -R "${PUID_VAL}:${PGID_VAL}" "$config_dir" 2>/dev/null || true
done

# Drop to node user and run the server.
exec su-exec node "$@"
