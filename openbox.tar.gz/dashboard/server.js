const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const session = require('express-session');
const crypto = require('crypto');
const path = require('path');
const fsSync = require('fs');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const compression = require('compression');

const docker = require('./lib/docker');
const hostMetrics = require('./lib/host-metrics');
const stateStore = require('./lib/state-store');
const statsStream = require('./lib/stats-stream');
const modules = require('./lib/modules');
const wizard = require('./lib/wizard');
const config = require('./lib/config');
const backup = require('./lib/backup');
const license = require('./lib/license');
const support = require('./lib/support');
const updates = require('./lib/updates');
const scheduler = require('./lib/scheduler');
const chat = require('./lib/chat');
const knowledge = require('./lib/knowledge');
const knowledgeMiner = require('./lib/knowledge-miner');
const telemetry = require('./lib/telemetry');
const migrate = require('./lib/migrate');
const selfUpdate = require('./lib/self-update');
const vpnStatus = require('./lib/vpn-status');
const alerts = require('./lib/alerts');
const healthReport = require('./lib/health-report');
const remoteAccess = require('./lib/remote-access');
const domainWizard = require('./lib/domain-wizard');
const { writeFileAtomic, writeFileAtomicSync } = require('./lib/atomic-write');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = 8443;
const OB_ROOT = process.env.OB_ROOT || '/opt/openbox';

// Defense-in-depth path validation. Codex command-injection audit
// (2026-05-01) caught 6 sites where OB_ROOT/OB_HOST_ROOT get
// interpolated into `bash -c` / `sh -c` strings unquoted. The
// realistic attack surface is small (only install.sh --install-dir
// or hand-edited .env can set OB_ROOT, and both already require
// sudo), but the strict path allowlist below makes those sites safe
// by construction. Reject install paths with shell metacharacters
// before any spawn/exec ever sees them.
const _SB_PATH_RE = /^\/[a-zA-Z0-9_./-]+$/;
if (!_SB_PATH_RE.test(OB_ROOT)) {
  console.error(`[FATAL] OB_ROOT contains disallowed characters: ${JSON.stringify(OB_ROOT)}`);
  console.error('        OpenBox install paths must match /[a-zA-Z0-9_./-]+ — no spaces, no shell metacharacters.');
  process.exit(1);
}
const LOCK_FILE = path.join(OB_ROOT, 'state', 'operation.lock');
let activeOperation = null;
// Boot ID: a unique token per dashboard process. Embedded in every
// operation.lock we write so a stale lock left by a previous dashboard
// instance (with the same PID namespace inside the container — the
// Node process is always PID 1) can't be mistaken for "still running"
// by the PID-alive check. If lock.bootId !== OB_BOOT_ID, the lock is
// from a previous process no matter what PID it records.
const OB_BOOT_ID = require('crypto').randomBytes(8).toString('hex');

// Conditionally clear a leftover lock from a previous process at
// startup. The old unconditional delete had a real hazard: detached
// `openbox up` helpers (setsid nohup) write rm -f on their own exit
// path, so the lock IS live while the helper is still running. A
// dashboard restart mid-helper (a crash, a docker recreate, or the
// self-update helper's own restart of ob-dashboard) would wipe the
// live lock and let a second destructive operation start in parallel
// with the first. Codex 2026-04-24 round 2 finding #3.
//
// Instead: parse the lock, look up its PID, and only clear if the
// PID is dead OR the lock is past its 10-minute TTL. Ambiguous cases
// (unparseable, missing PID) are cleared defensively — we'd rather
// drop a lock than deadlock into "forever busy." The risk with the
// defensive clear is limited because the operations that use the
// lock are themselves idempotent-ish (openbox up is a no-op on
// already-running containers).
try {
  if (fsSync.existsSync(LOCK_FILE)) {
    let clear = true;
    let reason = 'no pid/bootId recorded';
    try {
      const lock = JSON.parse(fsSync.readFileSync(LOCK_FILE, 'utf8'));
      const age = Date.now() - (lock.startedAt || 0);
      // A lock written by THIS process would have our bootId. Any
      // other bootId — including "no bootId at all" on locks from
      // pre-v1.5.88 dashboards — is from a prior instance, so the
      // PID-alive check is meaningless (container PID namespaces
      // recycle 1 on each start). v1.5.87 bug: pid=1 survived forever.
      const fromThisProcess = lock.bootId === OB_BOOT_ID;
      if (!fromThisProcess) {
        reason = `lock from previous dashboard instance (bootId mismatch)`;
      } else if (lock.pid && age < 600000) {
        try {
          process.kill(lock.pid, 0);
          clear = false;
          console.log(`[startup] Preserving operation lock: pid ${lock.pid} (${lock.name}) still alive, ${Math.floor(age / 1000)}s old`);
        } catch {
          reason = `pid ${lock.pid} not alive`;
        }
      } else if (age >= 600000) {
        reason = `TTL expired (${Math.floor(age / 1000)}s > 600s)`;
      }
    } catch (err) {
      reason = `unparseable (${err.message})`;
    }
    if (clear) {
      fsSync.unlinkSync(LOCK_FILE);
      console.log(`[startup] Cleared stale operation lock: ${reason}`);
    }
  }
} catch {}

function acquireOperationLock(opName) {
  if (activeOperation) return false;
  try {
    try {
      const lock = JSON.parse(fsSync.readFileSync(LOCK_FILE, 'utf8'));
      const age = Date.now() - (lock.startedAt || 0);
      const fromThisProcess = lock.bootId === OB_BOOT_ID;
      if (age > 600000) {
        fsSync.unlinkSync(LOCK_FILE);
      } else if (!fromThisProcess) {
        // Lock is from a previous dashboard instance OR a detached
        // helper. If it's a detached helper (which overwrites bootId
        // in its cmd) it also overwrote pid to its own $$, so the
        // PID-alive check tells the truth. If it's a dead previous
        // dashboard instance, PID 1 is meaningless — reclaim.
        let helperAlive = false;
        if (lock.pid && lock.pid > 1 && lock.bootId !== undefined) {
          try { process.kill(lock.pid, 0); helperAlive = true; } catch {}
        }
        if (helperAlive) return false;
        fsSync.unlinkSync(LOCK_FILE);
      } else if (lock.pid) {
        // Same process — check it's still active.
        try {
          process.kill(lock.pid, 0);
          return false; // someone is really running
        } catch {
          fsSync.unlinkSync(LOCK_FILE);
        }
      } else {
        return false;
      }
    } catch {}
    // Record pid + bootId so stale locks from previous dashboard
    // instances can be distinguished from live ones.
    activeOperation = {
      name: opName,
      startedAt: Date.now(),
      pid: process.pid,
      bootId: OB_BOOT_ID,
    };
    writeFileAtomicSync(LOCK_FILE, JSON.stringify(activeOperation));
    return true;
  } catch { return false; }
}

function releaseOperationLock() {
  activeOperation = null;
  try { fsSync.unlinkSync(LOCK_FILE); } catch {}
}

// Build a shell command for a detached helper that:
//  1. Overwrites operation.lock with ITS OWN pid ($$) so the
//     dashboard's startup PID-alive check stays accurate even after
//     a dashboard restart (the acquireOperationLock write records the
//     dashboard's pid, which becomes stale the instant the dashboard
//     is recreated mid-operation).
//  2. Runs the actual work redirected to the given log file.
//  3. Releases the lock on exit.
// Codex 2026-04-24 round 2 finding #3.
function buildDetachedLockedCmd(opName, logFile, work) {
  const escapedOp = String(opName).replace(/[^a-zA-Z0-9_.-]/g, '_');
  // Include bootId (= `detached:${OB_BOOT_ID}`) so a dashboard restart
  // AFTER the helper starts can tell "this lock is from a helper that
  // survived me" apart from "this lock is from an old instance of me."
  // The detached helper is a separate process tree from the dashboard,
  // so its $$ is a real PID the next dashboard's kill(pid,0) can check.
  const helperBootId = `detached:${OB_BOOT_ID}`;
  return (
    `printf '{"name":"%s","startedAt":%d,"pid":%d,"bootId":"%s"}' '${escapedOp}' ` +
    `$(date +%s)000 $$ '${helperBootId}' > '${LOCK_FILE}'; ` +
    `${work} >>'${logFile}' 2>&1; ` +
    `rm -f '${LOCK_FILE}'`
  );
}

// Load .env from disk at startup and OVERRIDE anything compose forwarded.
//
// Why: docker compose forwards variables from .env into the container's
// environment at container-creation time, but on `docker restart` the
// container reuses its ORIGINAL baked env from docker run. Any value
// that server.js itself wrote back to .env AFTER the container started
// (OB_ADMIN_PASSWORD_HASH from a first-run claim, OB_LICENSE_KEY from
// Pro activation, etc.) does NOT make it into process.env on restart —
// the running Node process ends up with a stale view of the world and
// dashboards that were claimed before reboot end up prompting for a
// bootstrap token again. Disk is the source of truth; compose is just
// a convenience for container-creation-time seeding.
//
// We can't use dotenv directly because .env values are stored with
// docker-compose `$$` escaping (bcrypt hashes like $2b$12$... are
// written as $$2b$$12$$... to prevent compose from eating them as
// variable references). config.js owns the escape/unescape logic.
//
// Caught by QA: restarted ob-dashboard post-claim, tried to log in,
// got "This server has not been claimed yet. Paste the bootstrap
// token." — every real user rebooting their host would hit this.
(function loadEnvFromDisk() {
  try {
    const envPath = path.join(OB_ROOT, '.env');
    if (!fsSync.existsSync(envPath)) return;
    const content = fsSync.readFileSync(envPath, 'utf8');
    const { unescapeEnvValue } = require('./lib/config');
    for (const line of content.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eq = trimmed.indexOf('=');
      if (eq === -1) continue;
      const key = trimmed.substring(0, eq);
      const value = unescapeEnvValue(trimmed.substring(eq + 1));
      // Path vars that differ between host and container: the host
      // install.sh writes OB_ROOT=/opt/openbox into .env so the bash
      // CLI on the host can find the install, but inside the dashboard
      // container OB_ROOT is /app (from docker-compose's environment
      // block). Blindly overwriting here would point every later
      // process.env.OB_ROOT read at /opt/openbox — which doesn't
      // exist in the container — and silently break license cache
      // reads, state file writes, and every other path derived from
      // OB_ROOT. Keep the compose-forwarded value.
      if (key === 'OB_ROOT') continue;
      // Only set if non-empty. An empty value in .env shouldn't
      // overwrite a non-empty value compose forwarded (e.g. if .env
      // has OB_BOOTSTRAP_TOKEN= blank after a claim but the compose
      // still carries the original — actually in that case we WANT
      // to clear the token, which is what the claim intends). Use
      // override-always semantics: disk is truth.
      process.env[key] = value;
    }
  } catch (err) {
    console.warn(`[startup] Failed to load ${OB_ROOT}/.env: ${err.message}`);
  }
})();

// --- Logging ---
function log(level, msg, err) {
  const ts = new Date().toISOString();
  const line = `[${ts}] [${level}] ${msg}`;
  if (level === 'ERROR') {
    console.error(line, err ? err.stack || err : '');
  } else {
    console.log(line);
  }
}

// Use a dedicated session secret, never reuse the password hash
const SESSION_SECRET = process.env.OB_SESSION_SECRET || crypto.randomBytes(32).toString('hex');

// --- Security Middleware ---

app.set('trust proxy', 1);

// gzip /api/* JSON responses. Default compression threshold is 1KB —
// below that the overhead costs more than it saves.
//
// v1.6.63: compression bypass for /js/, /css/, /icons/, /sw.js,
// /manifest.json, /logo.png. Beta-tester reports (Cammo92, fwaygo,
// wartbump on Demox 2026-05-08) all hit "dashboard renders but every
// button is dead" — root cause: compression middleware's chunked-encoding
// finalization races with express.static's stream end on large static
// files, producing ERR_INCOMPLETE_CHUNKED_ENCODING (Chromium/Edge) or
// NS_ERROR_NET_PARTIAL_TRANSFER (Firefox). Curl tolerates the missing
// 0-length chunk terminator; browsers reject it.
//
// v1.6.71: widen the bypass to ALL non-/api/ paths after notrike (#8929)
// hit the same class of bug on `/` (the catch-all index.html route) and
// `/favicon.ico` — paths the v1.6.63 list missed. Symptom on those paths
// is "blank white screen, no JS errors, doctor green, containers
// healthy" because index.html arrives truncated and the SPA never mounts.
// The clean fix isn't to keep adding paths to a denylist — it's to flip
// the model: only compress /api/* JSON (where compression matters most
// and the race doesn't reproduce because handlers buffer their JSON
// fully before send). Static HTML/CSS/images skip compression entirely;
// LAN bandwidth cost is negligible, correctness is absolute.
app.use(compression({
  filter: (req, res) => {
    const p = req.path || '';
    if (!p.startsWith('/api/')) return false;
    return compression.filter(req, res);
  }
}));

app.use(helmet({
  contentSecurityPolicy: {
    // Replace (not extend) defaults so we don't inherit
    // `upgrade-insecure-requests`. Helmet includes that by default, which
    // forces browsers to upgrade every HTTP request to HTTPS — and that
    // completely breaks OpenBox on first install, since the dashboard is
    // served over plain HTTP until the user sets up a reverse proxy.
    // Every form submit and API call would get upgraded to https:// and
    // fail with ERR_SSL_PROTOCOL_ERROR.
    useDefaults: false,
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      fontSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'", "ws:", "wss:"],
      formAction: ["'self'"],
      baseUri: ["'self'"],
      frameAncestors: ["'self'"],
      objectSrc: ["'none'"],
    }
  },
  crossOriginEmbedderPolicy: false,
  // Enable HSTS only when the user has opted into secure cookies (meaning
  // they're behind a TLS terminator). On plain HTTP LAN installs, HSTS
  // would permanently break the browser's ability to reach the dashboard.
  strictTransportSecurity: process.env.OB_COOKIE_SECURE === 'true'
    ? { maxAge: 31536000, includeSubDomains: true }
    : false,
}));

app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// Catch malformed JSON bodies before they hit route handlers. Without
// this, Express's default error handler returns an HTML 400 page (or
// in development NODE_ENV, a stack trace). Codex round-3 audit
// (Phase 19, 2026-05-01) flagged this as the only remaining
// information-disclosure surface. Returns a clean JSON 400 matching
// the rest of our API contract.
app.use((err, req, res, next) => {
  if (err && (err.type === 'entity.parse.failed' || err.type === 'entity.too.large')) {
    return res.status(400).json({ error: 'Invalid JSON body.', code: err.type });
  }
  next(err);
});

// Cookie security: auto-detect when behind a TLS terminator (NPM, Caddy,
// Cloudflare). When the request arrives via HTTPS (or via a proxy that
// sets X-Forwarded-Proto: https), the cookie gets the Secure flag. On
// plain HTTP LAN installs, it stays non-Secure so login works. Users can
// also force it via OB_COOKIE_SECURE=true.
const forceSecureCookie = process.env.OB_COOKIE_SECURE === 'true';
app.set('trust proxy', 1); // trust X-Forwarded-Proto from reverse proxy

// Minimal file-backed session store. Writes each session as a JSON
// file under state/sessions/<sid>.json and reads on demand. Without
// this the default MemoryStore (a) prints a loud production warning
// at every boot, (b) leaks memory for every abandoned session, and
// (c) vaporizes every logged-in session on dashboard restart — so
// the watchdog auto-restart cycle would log everyone out. Writing
// to disk is cheap (low write volume: one write per login, a touch
// per page load at most) and survives restarts.
//
// We don't pull in connect-sqlite3 or session-file-store because
// hot-swapping server.js onto an existing install would require a
// container rebuild to get new deps, which kills the zero-downtime
// upgrade path. 30 lines of inline code is better than a dep.
const SessionFileStore = (function () {
  const fs = require('fs');
  const fsp = fs.promises;
  function Store(opts) {
    const session = require('express-session');
    session.Store.call(this);
    this.dir = opts.dir;
    try { fs.mkdirSync(this.dir, { recursive: true, mode: 0o700 }); } catch {}
  }
  const session = require('express-session');
  Store.prototype = Object.create(session.Store.prototype);
  Store.prototype.constructor = Store;
  function safeSid(sid) {
    const clean = String(sid).replace(/[^A-Za-z0-9_-]/g, '');
    if (!clean) return '_empty_sid';
    return clean;
  }
  Store.prototype._path = function (sid) {
    return path.join(this.dir, safeSid(sid) + '.json');
  };
  Store.prototype.get = function (sid, cb) {
    fsp.readFile(this._path(sid), 'utf8')
      .then(raw => {
        try {
          const data = JSON.parse(raw);
          if (data.__expires && Date.now() > data.__expires) {
            this.destroy(sid, () => cb(null, null));
            return;
          }
          cb(null, data);
        } catch (e) { cb(null, null); }
      })
      .catch(err => (err && err.code === 'ENOENT') ? cb(null, null) : cb(err));
  };
  Store.prototype.set = function (sid, sess, cb) {
    const data = Object.assign({}, sess);
    if (sess.cookie && sess.cookie.expires) {
      data.__expires = new Date(sess.cookie.expires).getTime();
    } else if (sess.cookie && sess.cookie.maxAge) {
      data.__expires = Date.now() + sess.cookie.maxAge;
    }
    const p = this._path(sid);
    const tmp = p + '.' + process.pid + '.' + Date.now() + '.tmp';
    fsp.writeFile(tmp, JSON.stringify(data), { mode: 0o600 })
      .then(() => fsp.rename(tmp, p))
      .then(() => cb && cb(null))
      .catch(err => cb && cb(err));
  };
  Store.prototype.destroy = function (sid, cb) {
    fsp.unlink(this._path(sid))
      .then(() => cb && cb(null))
      .catch(err => (err && err.code === 'ENOENT') ? (cb && cb(null)) : (cb && cb(err)));
  };
  Store.prototype.touch = function (sid, sess, cb) {
    this.set(sid, sess, cb);
  };
  // Reap expired session files every 30 minutes. Without this, session
  // files accumulate forever (1,961 after one day of testing). The
  // __expires field is set on every write; files older than that are
  // stale and safe to delete.
  Store.prototype.startReaper = function (intervalMs) {
    const dir = this.dir;
    setInterval(async () => {
      try {
        const files = await fsp.readdir(dir);
        const now = Date.now();
        let reaped = 0;
        for (const f of files) {
          if (!f.endsWith('.json')) continue;
          try {
            const raw = await fsp.readFile(path.join(dir, f), 'utf8');
            const data = JSON.parse(raw);
            if (data.__expires && now > data.__expires) {
              await fsp.unlink(path.join(dir, f));
              reaped++;
            }
          } catch {}
        }
        if (reaped > 0) console.log(`[sessions] Reaped ${reaped} expired session files`);
      } catch {}
    }, intervalMs || 1800000);
  };
  return Store;
})();

const sessionStore = new SessionFileStore({ dir: path.join(OB_ROOT, 'state', 'sessions') });
sessionStore.startReaper(1800000); // every 30 min
const sessionMiddleware = session({
  store: sessionStore,
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 24 * 60 * 60 * 1000,
    httpOnly: true,
    sameSite: 'lax',
    secure: forceSecureCookie ? true : 'auto'
  }
});

app.use(sessionMiddleware);

// CSRF protection for state-changing requests. Generate a token per
// session and require it on all POST/PUT/DELETE requests. The frontend
// reads it from a cookie and sends it back in the X-CSRF-Token header.
// GET/HEAD/OPTIONS and the Stripe webhook callback are exempt.
app.use((req, res, next) => {
  // Generate CSRF token if session exists but token doesn't
  if (req.session && !req.session.csrfToken) {
    req.session.csrfToken = require('crypto').randomBytes(32).toString('hex');
  }
  // Set the token as a readable (non-httpOnly) cookie so frontend JS can read it
  if (req.session && req.session.csrfToken) {
    res.cookie('_csrf', req.session.csrfToken, { sameSite: 'lax', httpOnly: false });
  }
  // Exempt safe methods and specific webhook/auth paths
  const exempt = ['GET', 'HEAD', 'OPTIONS'];
  if (exempt.includes(req.method)) return next();
  if (req.path === '/api/login') return next(); // login creates the session

  // Verify the token
  const headerToken = req.headers['x-csrf-token'];
  if (req.session && req.session.csrfToken && headerToken === req.session.csrfToken) {
    return next();
  }
  // If no session yet (first request), allow — the session middleware
  // hasn't created a token yet. Once logged in, CSRF is enforced.
  if (!req.session || !req.session.csrfToken) return next();

  res.status(403).json({ error: 'CSRF token mismatch. Refresh the page and try again.' });
});

// Defense in depth (v1.6.59 audit): refuse to serve any markdown file
// out of the static dir. claude-mem auto-generates `CLAUDE.md` /
// `*/CLAUDE.md` files into source-tree subdirectories including
// dashboard/public/, dashboard/public/css/, dashboard/public/js/. They
// contain internal session-summary context (recent bug titles, file
// paths, internal version timeline) that would help an attacker
// fingerprint patches.
//
// release.sh already excludes them from the shipped tarball via
// `--exclude='**/CLAUDE.md'` so curl-bash customer installs don't
// leak. But a developer running `npm start` from a source checkout, OR
// a future typo in the rsync excludes, would expose them. There is NO
// legitimate reason to serve a `.md` file from the dashboard's static
// dir — block them at the request layer regardless of what's on disk.
app.use((req, res, next) => {
  const p = (req.path || '').toLowerCase();
  if (p.endsWith('.md')) {
    return res.status(404).send('Not Found');
  }
  next();
});

// Static files with aggressive caching for icons/images. SVG icons are
// tiny and never change — cache them for a year so the browser doesn't
// re-fetch 30+ icons on every page load.
app.use('/icons', express.static(path.join(__dirname, 'public', 'icons'), {
  maxAge: '365d',
  immutable: true,
}));
app.use(express.static(path.join(__dirname, 'public'), {
  // maxAge:0 + etag:true → browsers re-validate every request via
  // If-None-Match. If the file is unchanged the server returns 304 Not
  // Modified (cheap), but if a release shipped new JS the customer's
  // browser picks it up on the very next page load. Was '1h' until
  // 2026-05-04 — Tom hit a confusing repro where v1.6.31 shipped a JS
  // fix to the cities-dropdown but his browser kept serving the v1.6.30
  // version from disk cache for the next hour. Single-NAS dashboard
  // doesn't need aggressive caching; correctness > a few KB saved.
  maxAge: 0,
  etag: true,
  lastModified: true,
}));

// Share session with Socket.IO
io.engine.use(sessionMiddleware);

// Rate limiting for login. Use the socket remote address (not
// X-Forwarded-For) so attackers can't bypass the limit by rotating
// the header. We trust the proxy for cookie Secure detection but NOT
// for rate-limit identity — those are different trust decisions.
//
// IPv6 safety: express-rate-limit refuses to run a custom keyGenerator
// that returns a raw IP string without collapsing IPv6 addresses into
// /64 subnets, because otherwise an attacker on IPv6 can rotate the
// lower 64 bits of their address and bypass per-IP limits. ipKeyGenerator
// (exported from express-rate-limit) handles this: IPv4 stays as-is,
// IPv6 is collapsed to /64. Without this wrapper the process boots
// with a ValidationError stack trace AND the limiter never fires on
// IPv6 clients.
const { ipKeyGenerator } = require('express-rate-limit');
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 15,
  keyGenerator: (req) => ipKeyGenerator(req.socket.remoteAddress || req.ip),
  message: { error: 'Too many login attempts. Try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// General API rate limiter. Sized for a single authenticated user
// actively using the dashboard: normal page loads fire 10-20 parallel
// /api/* requests, plus background polling (status, containers, alerts)
// and the setup wizard polls /api/status every 5s. 60/min was way too
// tight and caused the wizard to 429 itself mid-install.
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 600,
  standardHeaders: true,
  legacyHeaders: false,
  // Skip rate limiting for the read-only polling endpoints the UI calls
  // every few seconds. Abuse of these is low-impact.
  skip: (req) => {
    const p = req.path;
    return p === '/status' || p === '/containers' || p === '/auth/status';
  },
});

app.use('/api/', apiLimiter);

// --- Auth Middleware ---

function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated) {
    return next();
  }
  if (req.path.startsWith('/api/')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  res.redirect('/');
}

// (NOTE: an earlier 15-minute version of this function used to live
// here; it was duplicated below and the second definition won. Removed
// 2026-05-01 by Codex round-2 audit cleanup. The active 10-minute
// version is below — see comment block + function at the next
// definition.)

// --- License Required Middleware ---
//
// v1.6.0 free pivot: OpenBox is free for personal use. The license
// gate now honors EITHER an activated license OR the
// state/license-skipped marker (set when the user clicks "Open
// dashboard" on the welcome screen). Skipped users get full local
// feature access: wizard, modules, VPN config, container ops,
// settings, etc. Auto-updates and AI chat stay gated separately
// via `requireWorkerKey` because they require a worker-validated
// license key for telemetry/abuse-revoke ability.
//
// Codex audit 2026-05-02 found that pre-skip-marker `requireLicense`
// was 403'ing skipped installs on every write route — `/api/setup/
// complete`, `/api/modules/*/enable`, `/api/containers/*`,
// `/api/vpn/config`, `/api/config`, `/api/server/*` — making the
// "Open dashboard" button lead to a half-broken UI. This relaxes
// the gate so the customer's choice actually unlocks the product.
const _LICENSE_SKIP_MARKER = path.join(OB_ROOT, 'state', 'license-skipped');
function _hasSkipMarker() {
  try { return fsSync.existsSync(_LICENSE_SKIP_MARKER); }
  catch { return false; }
}
// Same gate as requireLicense middleware, exposed for code paths that aren't
// Express routes (Socket.IO handlers). Free-personal-use means a skip marker
// is as good as a real key for everything except worker-validated operations.
function isLicensedOrSkipped() {
  return license.hasValidLicense() || _hasSkipMarker();
}
function requireLicense(req, res, next) {
  if (license.hasValidLicense()) return next();
  if (_hasSkipMarker()) return next();
  res.status(403).json({
    error: 'license_required',
    message: 'Activate from Settings → License (free for personal use).',
    licensed: false,
  });
}

// requireWorkerKey — strict license gate, used on routes that hit the
// license worker (auto-updates, AI chat, remote support). Skipping
// activation can't unlock these because the underlying operation
// itself needs a key the worker can validate.
function requireWorkerKey(req, res, next) {
  if (license.hasValidLicense()) return next();
  res.status(403).json({
    error: 'license_required',
    message: 'This action requires an activated license — free for personal use, activate from Settings → License.',
    licensed: false,
  });
}

// `requirePro` is the legacy alias used on /api/updates/*, /api/chat/*,
// /api/support/*, /api/alerts/* etc. v1.6.x re-routes it to the
// strict requireWorkerKey gate so worker-dependent operations stay
// license-gated even after skip — the underlying worker call would
// fail anyway with "no OB_LICENSE_KEY", better to fail fast at the
// edge with a clear message.
const requirePro = requireWorkerKey;

// requireRecentReauth — session must have authenticated within the
// last N seconds (default 10 minutes). Used on endpoints that serve
// raw secrets or perform destructive rollbacks: backup download/
// restore (attacker with a stolen cookie could exfiltrate every
// secret or wipe the box) and first-login-creds (plaintext passwords
// for every app). Claude-adversarial-review P0 finding. Forces the
// user to retype their admin password before the operation
// continues — a session cookie alone is not enough.
// Window resolution: explicit arg → OB_REAUTH_WINDOW_SEC env var → 600s default.
// The env override exists so test runs can drop the window to a few seconds and
// exercise the >window codepath without sleeping 10 real minutes per assertion
// (used by scripts/test-reauth-long-session.js). Production never sets the env.
function requireRecentReauth(windowSeconds) {
  const win = (typeof windowSeconds === 'number' && windowSeconds > 0)
    ? windowSeconds
    : (parseInt(process.env.OB_REAUTH_WINDOW_SEC, 10) || 600);
  return function (req, res, next) {
    const reauthAt = (req.session && req.session.reauthAt) || 0;
    if (Date.now() - reauthAt <= win * 1000) return next();
    // 401 with error: 'reauth_required' matches the client-side
    // convention in dashboard/public/js/app.js (see the api() helper
    // at line ~244 — it intercepts this shape and calls
    // promptRecentReauth() before retrying the request once).
    res.status(401).json({
      error: 'reauth_required',
      message: 'Re-enter your admin password to continue. This action requires a recent reauthentication.',
      reauthRequired: true,
      reauthWindowSeconds: win,
    });
  };
}

// v1.6.59 audit fix (Codex pre-beta round): the credential-dump and
// self-update endpoints (/api/passwords, /api/wizard/backup-key,
// /api/containers/:id/first-login-creds, /api/self-update/apply) had
// reauth dropped in v1.6.53-56 for UX on home-NAS installs — Tom's call
// after extended customer-feel testing was that retyping the admin
// password every 10 minutes during a Settings session outweighed the
// stolen-cookie defense for a single-operator LAN-only box.
//
// On a public-IP VPS the threat model flips: a session cookie leaked
// via XSS, a malicious browser extension, MITM on plain HTTP, or any
// shared-machine slip becomes an immediate dump of every app's plaintext
// password and the OB_BACKUP_KEY. v1.6.58's network profile detector
// gives us the missing axis — we can keep the dropped-reauth UX for
// nas/private profiles and re-impose reauth only when the host has a
// publicly-routable IP.
//
// Profile is cached at startup. Pre-1.6.58 installs (no OB_PROFILE in
// install-meta.conf) read as 'unknown' and DO NOT prompt — that
// preserves the v1.6.57 UX exactly for any user who hasn't yet upgraded
// through a fresh install.
let _cachedNetworkProfile = 'unknown';
(function loadNetworkProfileSync() {
  try {
    const raw = fsSync.readFileSync(path.join(OB_ROOT, 'state', 'install-meta.conf'), 'utf8');
    for (const line of raw.split('\n')) {
      const m = line.match(/^OB_PROFILE=(.*)$/);
      if (m) {
        const v = m[1].trim();
        if (['nas', 'private', 'public'].includes(v)) {
          _cachedNetworkProfile = v;
        }
        break;
      }
    }
  } catch { /* file missing/unreadable — stay 'unknown', no reauth */ }
})();

function requireRecentReauthIfPublic(windowSeconds) {
  const inner = requireRecentReauth(windowSeconds);
  return function (req, res, next) {
    if (_cachedNetworkProfile === 'public') return inner(req, res, next);
    return next();
  };
}

// --- Auth Routes ---

app.post('/api/login', loginLimiter, async (req, res) => {
  const { password, bootstrapToken } = req.body;
  const storedHash = process.env.OB_ADMIN_PASSWORD_HASH || '';

  if (!storedHash) {
    // Serialize concurrent first-run claims. Without this, two callers
    // racing the one-time bootstrap token (e.g., a LAN attacker who
    // intercepted it sniffing the install.sh stdout) can both pass
    // the constant-time compare and both mint admin sessions — the
    // last admin-password-write wins but both hold valid session
    // cookies. Codex-review P0 finding. Lock is released in each
    // return path below.
    if (!acquireOperationLock('first-run-claim')) {
      return res.status(409).json({ error: 'Another first-run claim is in progress. Retry in a few seconds.' });
    }
    // Release the lock on any response — covers every branch below
    // without having to thread try/finally around session.regenerate's
    // callback or duplicate release calls at every return.
    res.on('finish', () => { releaseOperationLock(); });
    res.on('close', () => { releaseOperationLock(); });
    // First-run password creation. Require the one-time bootstrap token
    // printed by install.sh so the first unauthenticated caller on the
    // network cannot claim the box. The token is generated during install
    // and written to .env; only whoever ran the installer sees it.
    const expectedToken = process.env.OB_BOOTSTRAP_TOKEN || '';
    if (!expectedToken) {
      // No token configured — fail closed. The install is broken; the user
      // must re-run install.sh or add OB_BOOTSTRAP_TOKEN manually.
      return res.status(500).json({
        error: 'First-run setup is missing the bootstrap token. Re-run install.sh or add OB_BOOTSTRAP_TOKEN to your .env and restart the dashboard.',
      });
    }
    if (!bootstrapToken || typeof bootstrapToken !== 'string') {
      return res.status(400).json({
        error: 'This server has not been claimed yet. Paste the bootstrap token printed by install.sh to set your admin password.',
        firstRun: true,
        bootstrapRequired: true,
      });
    }
    // Constant-time compare to avoid timing oracles.
    const a = Buffer.from(bootstrapToken);
    const b = Buffer.from(expectedToken);
    const tokenOk = a.length === b.length && crypto.timingSafeEqual(a, b);
    if (!tokenOk) {
      return res.status(401).json({
        error: 'Bootstrap token is incorrect. Check the installer output.',
        firstRun: true,
        bootstrapRequired: true,
      });
    }
    if (!password || password.length < 8) {
      return res.status(400).json({
        error: 'Please set a password (minimum 8 characters).',
        firstRun: true,
        bootstrapRequired: true,
      });
    }
    // Hash and save the new password, then burn the bootstrap token so it
    // can never be reused.
    try {
      const hash = await bcrypt.hash(password, 12);
      await config.update(OB_ROOT, {
        OB_ADMIN_PASSWORD_HASH: hash,
        OB_BOOTSTRAP_TOKEN: '',
      });
      process.env.OB_ADMIN_PASSWORD_HASH = hash;
      process.env.OB_BOOTSTRAP_TOKEN = '';
      return req.session.regenerate((err) => {
        if (err) { log('WARN', 'Session regenerate failed', err); }
        req.session.authenticated = true;
        req.session.reauthAt = Date.now();
        req.session.csrfToken = require('crypto').randomBytes(32).toString('hex');
        res.cookie('_csrf', req.session.csrfToken, { sameSite: 'lax', httpOnly: false });
        req.session.save(() => res.json({ success: true, firstRun: true }));
      });
    } catch (err) {
      log('ERROR', 'Failed to save password', err);
      return res.status(500).json({ error: 'Failed to save password. Try again.' });
    }
  }

  // Compare password - support both bcrypt hashes and legacy SHA-256
  try {
    let valid = false;
    if (storedHash.startsWith('$2')) {
      // bcrypt hash
      valid = await bcrypt.compare(password || '', storedHash);
    } else {
      // Legacy SHA-256 hash - compare and upgrade
      const inputHash = crypto.createHash('sha256').update(password || '').digest('hex');
      valid = inputHash === storedHash;
      if (valid) {
        // Auto-upgrade to bcrypt. A failure here (e.g. .env is read-only)
        // must NOT block the login, or the user gets 401s forever on a
        // correct password.
        try {
          const newHash = await bcrypt.hash(password, 12);
          await config.update(OB_ROOT, { OB_ADMIN_PASSWORD_HASH: newHash });
          process.env.OB_ADMIN_PASSWORD_HASH = newHash;
        } catch (upgradeErr) {
          log('WARN', 'Could not upgrade password hash to bcrypt', upgradeErr.message);
        }
      }
    }

    if (valid) {
      // Regenerate session ID to prevent session fixation. The pre-auth
      // session ID is discarded and a new one is issued, so an attacker
      // who captured the pre-login cookie can't replay it.
      return req.session.regenerate((err) => {
        if (err) { log('WARN', 'Session regenerate failed', err); }
        req.session.authenticated = true;
        req.session.reauthAt = Date.now();
        req.session.csrfToken = require('crypto').randomBytes(32).toString('hex');
        res.cookie('_csrf', req.session.csrfToken, { sameSite: 'lax', httpOnly: false });
        req.session.save(() => res.json({ success: true }));
      });
    }
  } catch (err) {
    log('ERROR', 'Login comparison failed', err);
  }

  res.status(401).json({ error: 'Wrong password. Try again?' });
});

app.post('/api/logout', requireAuth, (req, res) => {
  // Disconnect any Socket.IO connections using this session before
  // destroying it, so authenticated WebSockets don't survive logout.
  const sessionId = req.session.id;
  if (io) {
    for (const [, socket] of io.sockets.sockets) {
      if (socket.request.session && socket.request.session.id === sessionId) {
        socket.disconnect(true);
      }
    }
  }
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/auth/status', async (req, res) => {
  const isAuthenticated = !!(req.session && req.session.authenticated);
  const hasPassword = !!process.env.OB_ADMIN_PASSWORD_HASH;
  if (!isAuthenticated) {
    // firstRun must be visible pre-auth — the claim screen depends on it to
    // distinguish "set your initial password" from "log in." An unclaimed
    // dashboard already renders "Claim your OpenBox" in plaintext HTML, so
    // exposing the same bit via JSON is not new info to a scanner. needsSetup
    // is still withheld.
    return res.json({ authenticated: false, firstRun: !hasPassword });
  }

  // Only reveal setup state to authenticated users. An unauthenticated
  // caller learns whether a password exists (needed for the login UI to
  // show "create password" vs "enter password") but NOT whether setup is
  // complete — that info lets an attacker identify unclaimed instances.
  //
  // needsSetup reflects whether the dashboard should auto-open the new
  // setup wizard on home-page load. The new wizard endpoints write to
  // state/wizard.json (done/skipped flags). An older /api/setup/complete
  // path wrote a legacy state/setup-complete file — we still honor that
  // marker for backward compatibility with old installs, but wizard.json
  // is the authoritative source going forward. If either says the user
  // has finished or explicitly skipped, needsSetup is false.
  //
  // Pre-1.3.10 this check only looked at setup-complete, so every new
  // wizard completion or skip was ignored and the wizard reopened on
  // every page load forever. Caught by headless QA.
  let needsSetup = false;
  if (isAuthenticated && hasPassword) {
    try {
      const wizardStatus = await wizard.getStatus(OB_ROOT);
      if (wizardStatus.done || wizardStatus.skipped) {
        needsSetup = false;
      } else {
        // Fall back to the legacy setup-complete marker for installs
        // that used the old /api/setup/complete endpoint before
        // wizard.json was introduced.
        try {
          const fsp = require('fs').promises;
          await fsp.access(path.join(OB_ROOT, 'state', 'setup-complete'));
          needsSetup = false;
        } catch {
          needsSetup = true;
        }
      }
    } catch (err) {
      // Anything we can't read = assume setup is done. Defaulting to true
      // here was the cause of the recurring-wizard bug: any transient
      // read error reopened the wizard on the user's next page load even
      // though they'd completed it days ago. The user can manually
      // re-open from Settings if they really want to see it again.
      log('WARN', 'wizard status read failed; assuming setup complete', err);
      needsSetup = false;
    }
  }
  res.json({
    authenticated: true,
    firstRun: !hasPassword,
    needsSetup
  });
});

// Aggregate bootstrap endpoint for the homepage. Codex round 6 #3/#4:
// dashboard fires ~15-19 independent GETs on page load (auth-status
// × 2, license × 3, wizard-status, modules/store, containers,
// network, backup/status, vpn/status, last-upgrade, etc.). Most of
// those can be served from a single response — auth + license +
// wizard + modules + containers + system + network + activity.
//
// Unauthenticated callers get only {authenticated:false,firstRun}
// — same shape as /auth/status — so the frontend can still gate the
// login screen without revealing internal state. Authenticated
// callers get the full bundle. Endpoint is idempotent + cheap (all
// reads, all cached); safe to poll if useful.
app.get('/api/bootstrap', async (req, res) => {
  const isAuthenticated = !!(req.session && req.session.authenticated);
  const hasPassword = !!process.env.OB_ADMIN_PASSWORD_HASH;
  if (!isAuthenticated) {
    return res.json({ authenticated: false, firstRun: !hasPassword });
  }
  // All bundled reads are independent. Parallelize.
  const [wizardStatus, modulesList, containers, activity, vpnStatus] = await Promise.all([
    wizard.getStatus(OB_ROOT).catch(() => ({})),
    modules.listRich(OB_ROOT).catch(() => []),
    docker.listContainers().catch(() => []),
    Promise.resolve({ events: stateStore.getActivity() }),
    // VPN status is only relevant when media is enabled, but cheap enough
    // to always include — consumers can ignore media_enabled:false.
    require('./lib/vpn-status').getStatus(OB_ROOT).catch(() => ({ media_enabled: false })),
  ]);
  // needsSetup mirrors the /auth/status logic.
  let needsSetup = false;
  try {
    if (hasPassword) {
      if (wizardStatus.done || wizardStatus.skipped) {
        needsSetup = false;
      } else {
        try {
          const fsp = require('fs').promises;
          await fsp.access(path.join(OB_ROOT, 'state', 'setup-complete'));
          needsSetup = false;
        } catch {
          needsSetup = true;
        }
      }
    }
  } catch {}
  // v1.6.3: no license screen at all. The dashboard just opens. License
  // activation is purely optional from Settings (for Founding Member
  // badge and opt-in telemetry). On first /api/bootstrap call, if there
  // is neither a valid license nor a skip marker, auto-create the skip
  // marker silently — guarantees the activation gate is never shown to
  // a fresh-install user. Auto-updates work via the relaxed
  // requireLicense middleware which honors the skip marker.
  const fsp = require('fs').promises;
  const skipMarker = path.join(OB_ROOT, 'state', 'license-skipped');
  let licenseSkipped = false;
  try {
    await fsp.access(skipMarker);
    licenseSkipped = true;
  } catch {
    // Marker absent. If no license either, auto-create so the customer
    // never sees an activation prompt.
    if (!license.hasValidLicense()) {
      try {
        await fsp.writeFile(skipMarker, new Date().toISOString(), { mode: 0o600 });
        licenseSkipped = true;
      } catch (e) {
        // Permission issue writing the marker is non-fatal — the boot
        // flow will still render the dashboard via license.valid:false
        // landing on a now-orphaned activation route that no longer
        // shows a screen. Log and move on.
        log('WARN', 'Could not auto-create license-skipped marker', e);
      }
    }
  }
  res.json({
    authenticated: true,
    firstRun: !hasPassword,
    needsSetup,
    license: {
      valid: true,  // Always true for the boot flow — license is optional, no gate.
      tier: license.getTier ? license.getTier() : 'unlicensed',
      activated: license.hasValidLicense(),
      skipped: licenseSkipped && !license.hasValidLicense(),
    },
    wizard: wizardStatus,
    modules: modulesList,
    containers,
    activity,
    vpn: vpnStatus,
  });
});

// Deeper health probe for the self-update helper. /api/auth/status only
// tells you Express is answering — it passes even if config.json won't
// load, modules can't be listed, or the filesystem is degraded. Codex
// adversarial 2026-04-24 finding #7: the self-update helper's 180s
// health window was deleting the rollback dir after /api/auth/status
// alone, which means a release that boots Express but leaves any
// dashboard subsystem broken still "looked healthy" and got promoted
// past the rollback safety net.
//
// This endpoint intentionally touches the things a dashboard must be
// able to do to function at all: read its own config, list modules,
// read wizard state, and (if a license is configured) parse it. Any
// subsystem that throws flips the overall result to 503 so the helper
// keeps the rollback dir around.
app.get('/api/health/deep', async (req, res) => {
  const results = { process: 'ok' };
  let allOk = true;
  try {
    const cfg = await config.read(OB_ROOT);
    results.config = cfg && typeof cfg === 'object' ? 'ok' : 'missing';
    if (results.config !== 'ok') allOk = false;
  } catch (err) {
    results.config = `error: ${err.message}`;
    allOk = false;
  }
  try {
    const fsp = require('fs').promises;
    const modulesRoot = path.join(OB_ROOT, 'modules');
    const entries = await fsp.readdir(modulesRoot);
    const modulesFound = entries.filter(e => !e.startsWith('.')).length;
    results.modules = modulesFound > 0 ? `ok (${modulesFound})` : 'empty';
    if (modulesFound === 0) allOk = false;
  } catch (err) {
    results.modules = `error: ${err.message}`;
    allOk = false;
  }
  try {
    await wizard.getStatus(OB_ROOT);
    results.wizard = 'ok';
  } catch (err) {
    results.wizard = `error: ${err.message}`;
    allOk = false;
  }
  // License is optional — missing/invalid is fine for health, but a
  // throw from the parser means the license module itself is broken
  // and the dashboard would fail login flows.
  try {
    if (typeof license !== 'undefined' && license.hasValidLicense) {
      license.hasValidLicense();
      results.license = 'ok';
    } else {
      results.license = 'n/a';
    }
  } catch (err) {
    results.license = `error: ${err.message}`;
    allOk = false;
  }
  res.status(allOk ? 200 : 503).json({ ok: allOk, checks: results });
});

// Network profile (v1.6.58+). Reads state/install-meta.conf and surfaces
// the OB_PROFILE classification (nas / private / public) plus the reasons
// it was chosen. Pre-1.6.58 installs lack the keys; we derive a best-guess
// from IS_NAS so callers always get a usable value.
app.get('/api/environment', requireAuth, async (req, res) => {
  const fsp = require('fs').promises;
  const metaPath = path.join(OB_ROOT, 'state', 'install-meta.conf');
  const result = {
    profile: 'unknown',
    isNas: false,
    nasType: '',
    reasons: [],
    legacy: false,
  };
  try {
    const raw = await fsp.readFile(metaPath, 'utf8');
    const meta = {};
    for (const line of raw.split('\n')) {
      const m = line.match(/^([A-Z_][A-Z0-9_]*)=(.*)$/);
      if (m) meta[m[1]] = m[2];
    }
    result.isNas = meta.IS_NAS === 'true';
    result.nasType = meta.NAS_TYPE || '';
    if (meta.OB_PROFILE && ['nas', 'private', 'public'].includes(meta.OB_PROFILE)) {
      result.profile = meta.OB_PROFILE;
    } else {
      result.legacy = true;
      result.profile = result.isNas ? 'nas' : 'unknown';
    }
    if (meta.OB_PROFILE_REASONS) {
      result.reasons = meta.OB_PROFILE_REASONS.split(';').map(s => s.trim()).filter(Boolean);
    }
    res.json(result);
  } catch (err) {
    if (err.code === 'ENOENT') {
      res.json(result);
    } else {
      log('ERROR', 'environment read failed', err);
      res.status(500).json({ error: 'Failed to read install metadata.' });
    }
  }
});

app.post('/api/auth/reauth', requireAuth, loginLimiter, async (req, res) => {
  const { password } = req.body || {};
  const storedHash = process.env.OB_ADMIN_PASSWORD_HASH || '';
  if (!storedHash) {
    return res.status(400).json({ error: 'invalid_password' });
  }
  try {
    let valid = false;
    if (storedHash.startsWith('$2')) {
      valid = await bcrypt.compare(password || '', storedHash);
    } else {
      const inputHash = crypto.createHash('sha256').update(password || '').digest('hex');
      valid = inputHash === storedHash;
    }
    if (!valid) {
      return res.status(401).json({ error: 'invalid_password' });
    }
    req.session.reauthAt = Date.now();
    req.session.save(() => res.json({ ok: true }));
  } catch (err) {
    log('ERROR', 'Reauth failed', err);
    res.status(500).json({ error: 'Failed to confirm password.' });
  }
});

// Password change
app.post('/api/auth/change-password', requireAuth, loginLimiter, async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!newPassword || newPassword.length < 8) {
    return res.status(400).json({ error: 'New password must be at least 8 characters.' });
  }
  const storedHash = process.env.OB_ADMIN_PASSWORD_HASH || '';
  if (!storedHash) {
    return res.status(400).json({ error: 'No password set. Use the login page to set one.' });
  }
  try {
    let valid = false;
    if (storedHash.startsWith('$2')) {
      valid = await bcrypt.compare(currentPassword || '', storedHash);
    } else {
      const inputHash = crypto.createHash('sha256').update(currentPassword || '').digest('hex');
      valid = inputHash === storedHash;
    }
    if (!valid) {
      return res.status(401).json({ error: 'Current password is incorrect.' });
    }
    const hash = await bcrypt.hash(newPassword, 12);
    await config.update(OB_ROOT, { OB_ADMIN_PASSWORD_HASH: hash });
    process.env.OB_ADMIN_PASSWORD_HASH = hash;
    res.json({ success: true });
  } catch (err) {
    log('ERROR', 'Failed to change password', err);
    res.status(500).json({ error: 'Failed to change password.' });
  }
});

// Setup wizard completion
app.post('/api/setup/complete', requireAuth, requireLicense, requireRecentReauth(), async (req, res) => {
  try {
    const { domain, timezone, profile, vpnProvider, vpnType, vpnUser, vpnPass, vpnWgKey, vpnWgAddr } = req.body;
    const updates = {};
    if (domain) updates.OB_DOMAIN = domain;
    if (timezone) updates.TZ = timezone;
    // VPN env var names must match what the media module reads from
    // .env — VPN_PROVIDER / VPN_TYPE / VPN_USER / VPN_PASSWORD /
    // WIREGUARD_PRIVATE_KEY / WIREGUARD_ADDRESSES. The compose file
    // remaps them to gluetun's VPN_SERVICE_PROVIDER etc at runtime.
    if (vpnProvider) updates.VPN_PROVIDER = vpnProvider;
    if (vpnType === 'openvpn' || vpnType === 'wireguard') updates.VPN_TYPE = vpnType;
    if (vpnUser) updates.VPN_USER = vpnUser;
    if (vpnPass) updates.VPN_PASSWORD = vpnPass;
    if (vpnWgKey) updates.WIREGUARD_PRIVATE_KEY = vpnWgKey;
    if (vpnWgAddr) updates.WIREGUARD_ADDRESSES = vpnWgAddr;
    if (Object.keys(updates).length > 0) {
      await config.update(OB_ROOT, updates);
    }
    // Apply profile if specified. Before writing modules.conf, run
    // the wizard constraint pass — drops VPN-gated modules when VPN
    // isn't configured, enforces conflicts_with between overlapping
    // modules (media's jellyfin vs standalone jellyfin, etc). Without
    // this the cold-click-through wizard produces a broken state:
    // 35 modules enabled, media stuck without VPN, three competing
    // Jellyfin-likes. Warnings are returned to the client so the
    // post-wizard toast can explain what was skipped and why.
    let wizardWarnings = [];
    // Track whether modules.conf actually CHANGED. If it didn't (and no
    // env values were updated either), the welcome splash had nothing
    // to do — modules already match what install.sh set up. Spawning a
    // 15s+ `openbox up` for a no-op operation holds the operation lock
    // and blocks the next thing the user clicks ("Apply" on a media
    // module → 'Another operation is already running'). Caught by Tom's
    // v1.6.21 cold-install test.
    let modulesChanged = false;
    if (profile && profile !== 'custom') {
      const available = await modules.getAvailableModuleDirs(OB_ROOT);
      let targetModules;
      if (profile === 'full') {
        targetModules = available;
      } else if (MODULE_PROFILES[profile]) {
        targetModules = MODULE_PROFILES[profile].filter(m => available.includes(m));
      }
      if (targetModules) {
        const vpnConfigured = await isVpnConfigured();
        const constrained = await applyWizardConstraints(targetModules, vpnConfigured);
        targetModules = constrained.modules;
        wizardWarnings = constrained.warnings;

        const fsp = require('fs').promises;
        const confPath = path.join(OB_ROOT, 'state', 'modules.conf');
        let existingModules = [];
        try {
          const raw = await fsp.readFile(confPath, 'utf8');
          existingModules = raw.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
        } catch { /* file missing, treat as changed */ }
        const sortedNew = [...targetModules].sort().join(',');
        const sortedOld = [...existingModules].sort().join(',');
        modulesChanged = sortedNew !== sortedOld;
        if (modulesChanged) {
          await writeFileAtomic(confPath, targetModules.join('\n') + '\n');
          log('INFO', `Wizard wrote modules.conf (${targetModules.length} modules; ${wizardWarnings.length} skipped)`);
        } else {
          log('INFO', `Wizard: modules.conf already matches profile=${profile}, skipping write + openbox up`);
        }
      }
    }
    // Mark setup as complete
    const fsp = require('fs').promises;
    await fsp.mkdir(path.join(OB_ROOT, 'state'), { recursive: true });
    await writeFileAtomic(path.join(OB_ROOT, 'state', 'setup-complete'), new Date().toISOString());
    await wizard.markDone(OB_ROOT, { domain, timezone, profile });

    // No-op fast path: nothing in modules.conf changed AND no .env updates
    // were applied. Skip the heavy detached `openbox up` (which would
    // hold the operation lock for 10–15s while it recreates already-
    // running containers for no reason). Welcome-splash + essentials
    // profile lands here every time.
    const envChanged = Object.keys(updates).length > 0;
    if (!modulesChanged && !envChanged) {
      log('INFO', 'Setup complete — no module/env changes; skipping openbox up');
      return res.json({ success: true, applying: false, warnings: wizardWarnings });
    }

    // Kick off `openbox up` as a fully-detached background process.
    // This has to survive the dashboard container being recreated mid-up,
    // so we use setsid + nohup + stdio: 'ignore' + unref so the child
    // outlives the Node process and has its own session.
    if (!acquireOperationLock('setup-complete')) {
      return res.status(409).json({ error: 'Another operation is already running. Please wait.' });
    }
    try {
      const { spawn: sp } = require('child_process');
      const logFile = path.join(OB_ROOT, 'state', 'setup-apply.log');
      // The openbox CLI itself is a bash script (uses #!/usr/bin/env bash),
      // so the image MUST have bash. `sh` here just starts the pipeline.
      // No `exec` — anything after `; rm` was unreachable, so the dashboard
      // lock leaked. OB_SKIP_LOCK=1 prevents the CLI from fighting the
      // dashboard for the lock it already holds.
      const cmd = buildDetachedLockedCmd(activeOperation && activeOperation.name || 'detached-up', logFile, `${OB_ROOT}/openbox up`);
      const child = sp('setsid', ['nohup', 'sh', '-c', cmd], {
        cwd: OB_ROOT,
        env: { ...process.env, OB_ROOT, OB_SKIP_LOCK: '1' },
        detached: true,
        stdio: 'ignore',
      });
      child.unref();
      activeOperation = null;
      log('INFO', 'Setup complete — detached openbox up (pid=' + child.pid + ')');
    } catch (err) {
      releaseOperationLock();
      log('ERROR', 'Failed to spawn openbox up', err);
    }

    res.json({ success: true, applying: true, warnings: wizardWarnings });
  } catch (err) {
    log('ERROR', 'Setup failed', err);
    res.status(500).json({ error: "OpenBox couldn't finish setup — it couldn't save your settings or start the selected apps. Check that Docker is running and that /opt/openbox has enough disk space, then run setup again." });
  }
});

// --- First-Time Setup Wizard ---
// Lightweight companion to /api/setup/complete above. The wizard is a
// guided UX walkthrough (5 steps) that auto-opens on first home-page
// visit and teaches the user how OpenBox works. It persists its state
// in state/wizard.json so it never reopens after completion or dismissal.

app.get('/api/wizard/status', requireAuth, async (req, res) => {
  try {
    const status = await wizard.getStatus(OB_ROOT);
    // Legacy fallback: installs that ran the pre-wizard.json flow never
    // write wizard.json — they only have state/setup-complete. Without
    // this fallback, wizard.js maybeAutoOpen() reopens the wizard on
    // every page load forever for those users. Same fallback logic as
    // /api/auth/status's needsSetup calculation.
    if (!status.done && !status.skipped) {
      try {
        const fsp = require('fs').promises;
        await fsp.access(path.join(OB_ROOT, 'state', 'setup-complete'));
        status.done = true;
      } catch {}
    }
    res.json(status);
  } catch (err) {
    log('ERROR', 'wizard status failed', err);
    res.status(500).json({ error: 'Failed to read wizard status.' });
  }
});

app.post('/api/wizard/complete', requireAuth, async (req, res) => {
  try {
    // Schema filter: the wizard persists these fields and nothing else.
    // Without the filter, a malicious JSON body could plant arbitrary
    // nested data in state/wizard.json that would be surfaced back via
    // /api/wizard/status.
    const body = (req.body && typeof req.body === 'object' && !Array.isArray(req.body)) ? req.body : {};
    const WIZARD_SELECTION_KEYS = ['profile', 'domain', 'vpnProvider'];
    const selections = {};
    for (const k of WIZARD_SELECTION_KEYS) {
      const v = body[k];
      if (typeof v === 'string' && v.length > 0 && v.length <= 253) {
        selections[k] = v;
      }
    }
    // Persist optional user choices into .env. Env var names must match
    // what the module compose files read — VPN_PROVIDER (not
    // VPN_SERVICE_PROVIDER), which is the key the media module's gluetun
    // config actually looks up from .env.
    const updates = {};
    if (selections.domain) updates.OB_DOMAIN = selections.domain;
    if (selections.vpnProvider) updates.VPN_PROVIDER = selections.vpnProvider.slice(0, 64);
    if (Object.keys(updates).length) {
      await config.update(OB_ROOT, updates);
    }
    const status = await wizard.markDone(OB_ROOT, selections);
    res.json(status);
  } catch (err) {
    log('ERROR', 'wizard complete failed', err);
    res.status(500).json({ error: 'Failed to save wizard completion.' });
  }
});

app.post('/api/wizard/skip', requireAuth, async (req, res) => {
  try {
    const status = await wizard.markSkipped(OB_ROOT);
    res.json(status);
  } catch (err) {
    log('ERROR', 'wizard skip failed', err);
    res.status(500).json({ error: 'Failed to save wizard skip.' });
  }
});

app.post('/api/wizard/reopen', requireAuth, requireLicense, async (req, res) => {
  try {
    const status = await wizard.reopen(OB_ROOT);
    res.json(status);
  } catch (err) {
    log('ERROR', 'wizard reopen failed', err);
    res.status(500).json({ error: 'Failed to reopen wizard.' });
  }
});

// --- Telemetry (Settings → Privacy) ---
//
// Three endpoints back the Settings → Privacy section:
//   GET  /api/telemetry/settings  → { enabled, source }
//   POST /api/telemetry/settings  → { enabled, source: 'settings-toggle' }
//   GET  /api/telemetry/history   → last 50 sanitized events we've sent
//
// All require auth — telemetry settings are admin-controlled, and the
// history is a transparency tool for the box owner. Nobody else should
// see what crashes have been reported.
app.get('/api/telemetry/settings', requireAuth, async (req, res) => {
  try {
    const settings = await telemetry.loadSettings();
    res.json(settings);
  } catch (err) {
    log('ERROR', 'telemetry settings get failed', err);
    res.status(500).json({ error: 'Failed to load telemetry settings.' });
  }
});

app.post('/api/telemetry/settings', requireAuth, async (req, res) => {
  try {
    const enabled = !!(req.body && req.body.enabled);
    const saved = await telemetry.saveSettings({ enabled, source: 'settings-toggle' });
    res.json(saved);
  } catch (err) {
    log('ERROR', 'telemetry settings save failed', err);
    res.status(500).json({ error: 'Failed to save telemetry settings.' });
  }
});

app.get('/api/telemetry/history', requireAuth, async (req, res) => {
  try {
    const history = await telemetry.getHistory();
    res.json({ history });
  } catch (err) {
    log('ERROR', 'telemetry history failed', err);
    res.status(500).json({ error: 'Failed to load telemetry history.' });
  }
});

// Returns the plaintext OB_BACKUP_KEY so the wizard's backup-key step can
// show it. /api/config strips anything containing KEY to asterisks for
// safety, but the wizard is the one place where the user is expected to
// see and record this value — it is the whole point of the step. Same
// requireAuth gate as /api/config, so only the logged-in admin sees it.
// v1.6.56: dropped requireRecentReauth(). Same reasoning as /api/passwords.
app.get('/api/wizard/backup-key', requireAuth, requireRecentReauthIfPublic(), async (req, res) => {
  try {
    const cfg = await config.read(OB_ROOT);
    res.json({ key: cfg.OB_BACKUP_KEY || '' });
  } catch (err) {
    log('ERROR', 'wizard backup-key read failed', err);
    res.status(500).json({ error: 'Failed to read backup key.' });
  }
});

// Apply the profile the user picked in the wizard — enables the right
// set of modules and kicks off a detached `openbox up` so the install
// proceeds in the background while the wizard keeps going. Same logic
// as /api/setup/complete, minus the password/session side effects
// (since the wizard runs AFTER login). Enforces the freemium tier limit.
app.post('/api/wizard/apply-profile', requireAuth, requireLicense, async (req, res) => {
  try {
    const { profile } = req.body || {};
    if (!profile || profile === 'custom') {
      return res.json({ applied: false, reason: 'no profile selected or custom — user will pick apps from the store' });
    }
    const available = await modules.getAvailableModuleDirs(OB_ROOT);
    let targetModules;
    if (profile === 'full') {
      targetModules = available;
    } else if (MODULE_PROFILES[profile]) {
      targetModules = MODULE_PROFILES[profile].filter(m => available.includes(m));
    } else {
      return res.status(400).json({ error: 'Unknown profile.' });
    }
    // Apply the same VPN/conflict constraints as /api/setup/complete and
    // /api/wizard/save. Without these, a stale frontend or future reuse
    // could re-enable the old "Media without VPN" broken state — Codex
    // audit finding #11 (2026-05-01).
    const vpnConfigured = await isVpnConfigured();
    const constrained = await applyWizardConstraints(targetModules, vpnConfigured);
    targetModules = constrained.modules;
    const wizardWarnings = constrained.warnings || [];

    // Acquire the lock BEFORE persisting modules.conf. Previously the
    // wizard wrote the profile to disk first, then checked the lock —
    // which meant a concurrent op (cold-install rehearsal, batch apply)
    // could make first-run return 409 with the chosen apps already
    // committed but no `openbox up` ever started, wedging the install.
    if (!acquireOperationLock('wizard-apply-profile')) {
      return res.status(409).json({ error: 'Another operation is already running. Please wait.' });
    }

    try {
      const fsp = require('fs').promises;
      const confPath = path.join(OB_ROOT, 'state', 'modules.conf');
      await fsp.mkdir(path.dirname(confPath), { recursive: true });
      await writeFileAtomic(confPath, targetModules.join('\n') + '\n');
      if (wizardWarnings.length) {
        log('INFO', `Wizard apply-profile: ${wizardWarnings.length} module(s) skipped by constraints — ${wizardWarnings.map(w => w.module).join(', ')}`);
      }
    } catch (err) {
      releaseOperationLock();
      log('ERROR', 'wizard apply-profile: failed to persist modules.conf', err);
      return res.status(500).json({ error: 'Failed to apply profile.' });
    }

    // Kick off `openbox up` detached so the wizard UX doesn't block.
    // Same setsid/nohup/unref pattern as /api/setup/complete so the
    // child survives a dashboard container recreate.
    try {
      const { spawn: sp } = require('child_process');
      const logFile = path.join(OB_ROOT, 'state', 'wizard-apply.log');
      // No `exec` — anything after `; rm` was unreachable, so the dashboard
      // lock leaked forever. OB_SKIP_LOCK=1 tells the CLI not to fight the
      // dashboard for the lock it already holds. The trailing rm releases
      // the lock the dashboard took, regardless of whether openbox up
      // succeeded or failed.
      const cmd = buildDetachedLockedCmd(activeOperation && activeOperation.name || 'detached-up', logFile, `${OB_ROOT}/openbox up`);
      const child = sp('setsid', ['nohup', 'sh', '-c', cmd], {
        cwd: OB_ROOT,
        env: { ...process.env, OB_ROOT, OB_SKIP_LOCK: '1' },
        detached: true,
        stdio: 'ignore',
      });
      child.unref();
      activeOperation = null;
      log('INFO', 'Wizard apply-profile — detached openbox up (pid=' + child.pid + ')');
    } catch (err) {
      releaseOperationLock();
      log('ERROR', 'wizard openbox up spawn failed', err);
    }

    res.json({ applied: true, profile, count: targetModules.length, modules: targetModules });
  } catch (err) {
    log('ERROR', 'wizard apply-profile failed', err);
    res.status(500).json({ error: 'Failed to apply profile.' });
  }
});

// --- Module Routes ---

app.get('/api/modules', requireAuth, async (req, res) => {
  try {
    const mods = await modules.list(OB_ROOT);
    res.json(mods);
  } catch (err) {
    log('ERROR', 'Failed to load modules', err);
    res.status(500).json({ error: 'Failed to load modules.' });
  }
});

// Rich metadata from x-openbox compose extensions (for App Store UI)
app.get('/api/modules/store', requireAuth, async (req, res) => {
  try {
    const mods = await modules.listRich(OB_ROOT);
    res.json(mods);
  } catch (err) {
    log('ERROR', 'Failed to load store data', err);
    res.status(500).json({ error: 'Failed to load app store data.' });
  }
});

// Modules whose enable flow depends on a configured VPN provider.
// Gluetun is the critical piece — every *arr service in the media
// bundle routes through it via `network_mode: service:gluetun`, so
// without VPN credentials the whole stack stays in "Created" state
// with no visible error. Block the enable and ask for the config
// upfront instead.
const VPN_REQUIRED_MODULES = new Set(['media']);

async function isVpnConfigured() {
  try {
    const cfg = await config.read(OB_ROOT);
    if (!cfg.VPN_PROVIDER || !cfg.VPN_PROVIDER.trim()) return false;
    const type = (cfg.VPN_TYPE || 'wireguard').toLowerCase();
    if (type === 'wireguard') {
      return !!(cfg.WIREGUARD_PRIVATE_KEY && cfg.WIREGUARD_PRIVATE_KEY.trim());
    }
    return !!(cfg.VPN_USER && cfg.VPN_USER.trim() && cfg.VPN_PASSWORD && cfg.VPN_PASSWORD.trim());
  } catch { return false; }
}

app.post('/api/modules/:name/enable', requireAuth, requireLicense, async (req, res) => {
  try {
    // 2026-04-21 beta review P1: block VPN-dependent module enables
    // until the user has actually configured a VPN provider. Without
    // this guard, enabling Media on a fresh install left sonarr/
    // radarr/prowlarr/qbittorrent in Created state forever with no
    // UI-visible error — the helper-less failure mode that made
    // every first-time user think OpenBox was broken.
    if (VPN_REQUIRED_MODULES.has(req.params.name) && !(await isVpnConfigured())) {
      return res.status(409).json({
        error: 'vpn_required',
        vpn_required: true,
        message: `The ${req.params.name} module routes traffic through a VPN tunnel. Configure your VPN provider before enabling.`,
        module: req.params.name,
        configure_url: '/settings#vpn',
      });
    }
    // 1.4.0: single-tier. requireLicense gates this route; licensed
    // users have unlimited apps, there is no free-tier cap to check.
    // Use the streaming variant so the response returns immediately.
    // The synchronous version blocked for minutes on fresh boxes that
    // had to pull large images (immich ~1.5GB, jellyfin ~500MB), causing
    // both browsers and API clients to time out at 30s. The streaming
    // variant writes modules.conf, kicks off `openbox up` in a child
    // process, and returns the operationId before the docker pull runs.
    // Progress is emitted to all connected Socket.IO clients via
    // operation:progress / operation:complete events; pure-API callers
    // can poll /api/containers to see when the container appears.
    const operationId = await modules.enableStreaming(
      OB_ROOT,
      req.params.name,
      io.emit.bind(io)
    );
    res.status(202).json({
      success: true,
      operationId,
      message: 'Enable started. Listen for operation:progress events or poll /api/containers.'
    });
  } catch (err) {
    log('ERROR', `Failed to enable module: ${req.params.name}`, err);
    res.status(400).json({ error: err.message || 'Failed to enable module.' });
  }
});

// --- VPN provider configuration ---
//
// Read-side returns the current VPN config with secrets masked (the
// dashboard UI only needs to know what's set, not the private key
// itself). Write-side accepts an updated config and persists to .env.
// Restart of gluetun is the user's next action — the Media module
// picks up the new env on its next `openbox up`.
app.get('/api/vpn/config', requireAuth, async (req, res) => {
  try {
    const cfg = await config.read(OB_ROOT);
    res.json({
      provider: cfg.VPN_PROVIDER || '',
      type: cfg.VPN_TYPE || 'wireguard',
      user: cfg.VPN_USER || '',
      server_countries: cfg.SERVER_COUNTRIES || '',
      server_cities: cfg.SERVER_CITIES || '',
      server_hostnames: cfg.SERVER_HOSTNAMES || '',
      hasPassword: !!(cfg.VPN_PASSWORD && cfg.VPN_PASSWORD.trim()),
      hasPrivateKey: !!(cfg.WIREGUARD_PRIVATE_KEY && cfg.WIREGUARD_PRIVATE_KEY.trim()),
      hasAddresses: !!(cfg.WIREGUARD_ADDRESSES && cfg.WIREGUARD_ADDRESSES.trim()),
      configured: await isVpnConfigured(),
    });
  } catch (err) {
    log('ERROR', 'Read VPN config failed', err);
    res.status(500).json({ error: 'Failed to read VPN configuration.' });
  }
});

// No requireRecentReauth here on purpose: the wizard saves the same VPN config
// on first run without prompting for the password, so gating the edit-after path
// behind reauth was asymmetric and silently broke (the client didn't have
// /vpn/config in its needsRecentReauth whitelist, so 401 became a dead end).
// VPN creds are not a privilege escalation surface — the user already has admin
// to reach this route at all. requireLicense (skip-marker-aware) is sufficient.
app.post('/api/vpn/config', requireAuth, requireLicense, async (req, res) => {
  try {
    const body = req.body || {};
    const updates = {};
    const allowedProviders = new Set([
      'airvpn','cyberghost','expressvpn','fastestvpn','giganews','hidemyass','ipvanish',
      'ivpn','mullvad','nordvpn','perfectprivacy','privado','privateinternetaccess',
      'privatevpn','protonvpn','purevpn','slickvpn','surfshark','torguard','vpnunlimited',
      'vyprvpn','windscribe','custom',
    ]);
    if (typeof body.provider === 'string' && allowedProviders.has(body.provider)) {
      updates.VPN_PROVIDER = body.provider;
    } else if (body.provider) {
      return res.status(400).json({ error: `Unsupported VPN provider: ${String(body.provider).slice(0, 30)}` });
    }
    const allowedTypes = new Set(['wireguard', 'openvpn']);
    if (typeof body.type === 'string' && allowedTypes.has(body.type)) {
      updates.VPN_TYPE = body.type;
    }
    if (typeof body.user === 'string') updates.VPN_USER = body.user.slice(0, 256);
    if (typeof body.password === 'string' && body.password.length > 0) {
      updates.VPN_PASSWORD = body.password.slice(0, 512);
    }
    if (typeof body.wireguard_private_key === 'string' && body.wireguard_private_key.length > 0) {
      updates.WIREGUARD_PRIVATE_KEY = body.wireguard_private_key.trim().slice(0, 512);
    }
    if (typeof body.wireguard_addresses === 'string') {
      updates.WIREGUARD_ADDRESSES = body.wireguard_addresses.trim().slice(0, 256);
    }
    if (typeof body.server_countries === 'string') {
      updates.SERVER_COUNTRIES = body.server_countries.trim().slice(0, 256);
    }
    if (typeof body.server_cities === 'string') {
      updates.SERVER_CITIES = body.server_cities.trim().slice(0, 512);
    }
    if (typeof body.server_hostnames === 'string') {
      updates.SERVER_HOSTNAMES = body.server_hostnames.trim().slice(0, 512);
    }
    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ error: 'No VPN fields provided.' });
    }
    await config.update(OB_ROOT, updates);

    // If media is already enabled, force-recreate its containers so
    // the freshly-saved VPN creds actually take effect. Without this
    // the gluetun container keeps running with whatever .env it was
    // created with — the classic "docker compose up doesn't recreate
    // on env change" gotcha. This made the VPN modal's Save button
    // silently no-op on any install where media was enabled first
    // (via wizard) and VPN creds set later. The HTTP response returns
    // immediately; we surface the restart's final outcome via a
    // socket.io event ('vpn:restart-complete') so the UI can show a
    // success or failure toast tied to THIS Save click instead of the
    // user being told "VPN configured" while compose actually choked.
    let restarting = false;
    try {
      const enabled = await modules.getEnabledModules(OB_ROOT);
      if (enabled.includes('media')) {
        restarting = true;
        const { spawn: sp } = require('child_process');
        const child = sp('sh', ['-c', `"${OB_ROOT}/openbox" restart media`], {
          cwd: OB_ROOT,
          env: { ...process.env, OB_ROOT, OB_SKIP_LOCK: '1' },
          detached: true,
          stdio: ['ignore', 'pipe', 'pipe'],
        });
        // Buffer a bit of stderr so we can include it in the failure
        // event — without this, the UI would just see "restart failed"
        // with no actionable detail. Cap at 4KB; anything larger is
        // already in /opt/openbox/state/setup-apply.log.
        let stderrBuf = '';
        if (child.stderr) {
          child.stderr.on('data', (chunk) => {
            if (stderrBuf.length < 4096) stderrBuf += chunk.toString().slice(0, 4096 - stderrBuf.length);
          });
        }
        if (child.stdout) child.stdout.on('data', () => {});
        child.on('exit', (code) => {
          if (code === 0) {
            log('INFO', 'VPN restart complete (media containers recreated with new env)');
            io.emit('vpn:restart-complete', { success: true });
          } else {
            log('ERROR', `VPN restart failed (openbox restart media exited ${code})`, stderrBuf);
            io.emit('vpn:restart-complete', {
              success: false,
              code,
              error: 'Restart failed — VPN settings were saved, but the media stack did not come back up cleanly. Check Apps page for container status.',
            });
          }
        });
        child.on('error', (err) => {
          log('ERROR', 'VPN restart spawn error', err);
          io.emit('vpn:restart-complete', { success: false, error: err.message });
        });
        child.unref();
        log('INFO', 'VPN config saved; recreating media containers to pick up new env');
        // Invalidate the IP-probe cache. The recreate above gives gluetun
        // (and qBit-via-gluetun) new public IPs; without clearing the cache
        // the VPN banner would keep showing the OLD pre-recreate state for
        // up to 5 minutes — looks like "tunnel down / at risk" even though
        // the tunnel is healthy. Caught by Tom's v1.6.20 cold-install test.
        if (vpnStatus && typeof vpnStatus.invalidateCache === 'function') {
          vpnStatus.invalidateCache();
        }
      }
    } catch (err) {
      log('WARN', 'VPN config saved but background media-restart failed', err);
      // Non-fatal — config was saved, user can retry by clicking restart.
    }

    res.json({ success: true, configured: await isVpnConfigured(), restarting });
  } catch (err) {
    log('ERROR', 'Write VPN config failed', err);
    res.status(500).json({ error: 'Failed to save VPN configuration.' });
  }
});

app.post('/api/modules/:name/disable', requireAuth, requireLicense, async (req, res) => {
  try {
    // Validate module name strictly. Codex round-2 audit finding #5:
    // without this, `core%2F..%2Fdashboard` (encoded `core/../dashboard`)
    // normalizes through path.join inside modules.disable to
    // `modules/dashboard/docker-compose.yml`, bypassing the core-module
    // protection (which only string-matches the raw `req.params.name`).
    // Stops/removes core containers — high-impact DoS via authenticated
    // session.
    const name = req.params.name;
    if (!/^[a-z0-9_-]+$/i.test(name)) {
      return res.status(400).json({ error: 'Invalid module name.' });
    }
    const available = await modules.getAvailableModuleDirs(OB_ROOT);
    if (!available.includes(name)) {
      return res.status(404).json({ error: 'Unknown module.' });
    }
    await modules.disable(OB_ROOT, name);
    res.json({ success: true });
  } catch (err) {
    log('ERROR', `Failed to disable module: ${req.params.name}`, err);
    res.status(400).json({ error: 'Failed to disable module.' });
  }
});

// Batch enable/disable: the user picks multiple apps in selection mode
// and hits Apply. One endpoint, one modules.conf write, one detached
// `openbox up` run. Much faster than toggling apps individually.
//
// Body: { enable: ['gitea', 'mealie'], disable: ['adguard'] }
// Either key is optional. Empty arrays are fine.
app.post('/api/modules/batch', requireAuth, requireLicense, async (req, res) => {
  try {
    const { enable = [], disable = [] } = req.body || {};
    if (!Array.isArray(enable) || !Array.isArray(disable)) {
      return res.status(400).json({ error: 'enable and disable must be arrays of module ids' });
    }
    if (enable.length === 0 && disable.length === 0) {
      return res.status(400).json({ error: 'Nothing to apply.' });
    }

    // 1.4.0: single-tier, unlimited apps for licensed users.
    // requireLicense gates this route. No cap check needed.

    // Take the operation lock BEFORE batchUpdate. batchUpdate writes
    // modules.conf and stops/removes disabled containers — if we did
    // that before grabbing the lock and another op was already
    // holding it, we'd return a busy error AFTER having already torn
    // down the user's containers and rewritten state. Lock first so a
    // busy reply is a true no-op.
    if (!acquireOperationLock('batch-module-update')) {
      return res.status(409).json({ error: 'Another operation is already running. Please wait.' });
    }

    let result;
    try {
      result = await modules.batchUpdate(OB_ROOT, { enable, disable });
    } catch (err) {
      releaseOperationLock();
      throw err;
    }

    // Kick off `openbox up` as a fully-detached process so it survives
    // even if the dashboard container itself is recreated during the up
    // sweep. Same pattern as /api/setup/complete.
    try {
      const { spawn: sp } = require('child_process');
      const logFile = path.join(OB_ROOT, 'state', 'batch-apply.log');
      const cmd = buildDetachedLockedCmd(activeOperation && activeOperation.name || 'detached-up', logFile, `${OB_ROOT}/openbox up`);
      const child = sp('setsid', ['nohup', 'sh', '-c', cmd], {
        cwd: OB_ROOT,
        env: { ...process.env, OB_ROOT, OB_SKIP_LOCK: '1' },
        detached: true,
        stdio: 'ignore',
      });
      child.unref();
      activeOperation = null;
      log('INFO', `Batch module update — enable=[${result.enable.join(',')}] disable=[${result.disable.join(',')}] — detached openbox up (pid=${child.pid})`);
    } catch (err) {
      releaseOperationLock();
      log('ERROR', 'Failed to spawn openbox up after batch update', err);
    }

    res.json({
      success: true,
      applying: true,
      enabled: result.enable,
      disabled: result.disable,
      finalEnabled: result.finalEnabled,
    });
  } catch (err) {
    log('ERROR', 'Batch module update failed', err);
    res.status(400).json({ error: err.message || 'Batch update failed.' });
  }
});

// Get required config vars before enabling a module
app.get('/api/modules/:name/config-required', requireAuth, async (req, res) => {
  try {
    const missing = await modules.getRequiredConfig(OB_ROOT, req.params.name);
    const deps = await modules.getDependencies(OB_ROOT, req.params.name);
    res.json({ configRequired: missing, missingDependencies: deps });
  } catch (err) {
    log('ERROR', `Failed to check module config: ${req.params.name}`, err);
    res.status(400).json({ error: 'Failed to check module requirements.' });
  }
});

// --- Container Routes ---

app.get('/api/containers', requireAuth, async (req, res) => {
  try {
    const containers = await docker.listContainers();
    res.json(containers);
  } catch (err) {
    log('ERROR', 'Failed to load containers', err);
    res.status(500).json({ error: 'Failed to load containers.' });
  }
});

app.get('/api/containers/:id/stats', requireAuth, async (req, res) => {
  // Codex round 3 finding #4: require the target is a OpenBox-managed
  // container. Without this, an authenticated user could query stats
  // for any container on the Docker socket, including host-side
  // workloads sharing the dashboard's socket. Same class of fix as the
  // round-2 logs:subscribe patch.
  const id = req.params.id;
  if (!/^sb-[a-z0-9][a-z0-9_-]{0,63}$/.test(id)) {
    return res.status(400).json({ error: 'Invalid container name.' });
  }
  try {
    const ok = await docker.validateOpenBoxContainer(id);
    if (!ok) return res.status(404).json({ error: 'Container not found.' });
    const stats = await docker.getContainerStats(id);
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: "OpenBox couldn't read container stats. Refresh the page; if it repeats, check that Docker is running." });
  }
});

// Scan a container's logs for first-run credential printouts.
//
// Used by the launcher's first-login modal so users don't have to SSH
// in and grep logs themselves to learn their Frigate password (or any
// other app that prints its admin credentials to stdout on first
// boot). Runs server-side so the logs never leave the OpenBox host
// — we return only the matched lines, not the whole log stream.
//
// Security: name is validated against the sb-<alphanumeric+dash>
// pattern so a malicious query string can't be used to reach non-
// OpenBox containers on the same Docker socket, and we only hit
// dockerode's API (no shell, no injection surface). Still gated on
// requireAuth because the matched lines may contain secrets.
// Known state-file → container mappings. Some services print their
// admin credentials to stdout (Frigate, Portainer etc. — handled by
// the log-scrape below), but some are auto-generated by OpenBox
// scripts and saved to a state file instead. We surface both paths
// through the same endpoint so the launcher's first-login modal
// "just works" regardless of where the creds came from.
//
// Jellyfin + Seerr share the same creds because media-autoseed
// signs Seerr in using the Jellyfin admin it just created.
const STATE_FILE_CREDS = {
  'ob-jellyfin-media': 'jellyfin-admin-password.txt',
  'sb-seerr':          'jellyfin-admin-password.txt',
  'ob-portainer':      'portainer-admin-password.txt',
  'ob-qbittorrent':    'qbittorrent-admin-password.txt',
  'ob-linkding':       'linkding-admin-password.txt',
  // v1.6.35: Pi-hole password is generated by install.sh into .env
  // but until now never surfaced anywhere the user could find it.
  // Now persisted to state/ following the same pattern as the others.
  'ob-pihole':         'pihole-admin-password.txt',
  // v1.6.35: Vaultwarden's "creds" file is actually an access guide
  // (the web vault won't load over HTTP from a non-localhost browser
  // due to the SubtleCrypto/secure-context requirement, so the user
  // needs to know about the browser-extension path + admin panel +
  // optional NPM HTTPS setup). Same modal flow surfaces it.
  'ob-vaultwarden':    'vaultwarden-admin-password.txt',
  // v1.6.42: arr-bootstrap.sh seeds an admin user directly into each
  // *arr's Users SQLite table (PBKDF2-HMAC-SHA512). v1.6.40's
  // Forms+Enabled lockdown left Sonarr/Radarr/Prowlarr with no self-
  // service account-creation UI, so beta testers couldn't get past
  // the login form. Same launcher-modal flow now surfaces the seeded
  // creds on first click.
  'ob-sonarr':         'sonarr-admin-password.txt',
  'ob-radarr':         'radarr-admin-password.txt',
  'ob-prowlarr':       'prowlarr-admin-password.txt',
};

// Containers where the static first_login hint is the complete answer
// (no creds in logs to find). Skip the log scrape entirely — it just
// surfaces framework noise that looks like creds because of loose
// keyword matches. Immich logs every NestJS route mapping at boot,
// including paths like /api/admin/users which match the `admin`
// keyword and dump 20+ lines of router-explorer junk into the modal.
const SKIP_LOG_SCRAPE = new Set([
  'ob-immich-server',
]);

// v1.6.37: dropped requireRecentReauth() here. The 10-minute reauth gate
// fired EVERY time a user opened an app from the dashboard's launcher
// (the credentials modal calls this endpoint to show the auto-generated
// password) — so a customer using their NAS daily got hit with a
// password-retype prompt every 10 minutes. The original P0 review added
// this on the theory that an attacker with a stolen session cookie
// could exfiltrate every app's plaintext password. That's a real risk
// trade-off, but for a single-operator home NAS the friction outweighed
// it. The dedicated `/api/passwords` Settings page below STILL has the
// reauth gate — that's a deliberate "dump all secrets" action and worth
// the friction, whereas this endpoint surfaces one app's cred at a time
// in the natural launch flow. requireAuth (logged-in session) is still
// enforced.
app.get('/api/containers/:id/first-login-creds', requireAuth, requireRecentReauthIfPublic(), async (req, res) => {
  const name = req.params.id;
  if (!/^sb-[a-z0-9][a-z0-9_-]{0,63}$/.test(name)) {
    return res.status(400).json({ error: 'Invalid container name.' });
  }

  // Try the state-file path first — covers autoseed-generated creds
  // (Jellyfin/Seerr) and install.sh pre-seeded creds (Portainer,
  // qBittorrent). These are more reliable than scraping logs.
  if (STATE_FILE_CREDS[name]) {
    try {
      const fsSync = require('fs');
      const path = require('path');
      const stateFile = path.join(OB_ROOT, 'state', STATE_FILE_CREDS[name]);
      const content = fsSync.readFileSync(stateFile, 'utf8').trim();
      if (content) {
        // The file is either:
        //   - "username: openbox\npassword: xxx\napi_key: yyy" (autoseed)
        //   - Just a bare password on one line (install.sh)
        // Normalize both into 1-N matches the UI already handles.
        const matches = content.split('\n').map(l => l.trim()).filter(Boolean);
        return res.json({ matches, truncated: false, source: 'state-file' });
      }
    } catch {
      // State file missing is fine — fall through to log scrape.
    }
  }

  if (SKIP_LOG_SCRAPE.has(name)) {
    return res.json({ matches: [], truncated: false, source: 'skip' });
  }

  try {
    const raw = await docker.getContainerLogSnapshot(name, 1000);
    if (!raw) {
      return res.json({
        matches: [],
        truncated: true,
        hint: `OpenBox couldn't find credentials in this container's logs. Try the Restart button in the app launcher — some services print their password only when they first boot.`,
      });
    }
    // Keep lines that look like a credential printout. The pattern
    // is intentionally loose — if an app uses a phrase we miss the
    // user just falls back to the YAML first_login hint.
    const KEEP = /\b(password|pass(?:word)?:|passphrase|admin(?:\s+user)?|credential|api[- ]?key|token|secret)\b/i;
    // Drop lines that are obviously about migrations, schema, hash
    // columns, or hash-of-blank-password test values — those are the
    // noisy false positives Frigate/BookStack produce on boot. Also
    // drops NestJS framework noise (Immich, Vikunja, etc. print every
    // route at boot, and paths like /api/admin/users match the `admin`
    // keyword above).
    const DROP = /migrat|CREATE TABLE|ALTER TABLE|password_hash|password_changed_at|password column|REFERENCES|INDEX|RouterExplorer|RoutesResolver|InstanceLoader|Mapped\s+\{/i;
    // Clean a raw log line down to just the credential payload.
    // Container log lines look like (real Frigate example):
    //   "2026-05-04 20:15:55.884199120  [2026-05-04 20:15:55] frigate.app    INFO    : ***    User: admin    ***"
    // The user only cares about "User: admin". Strip:
    //   1. Docker stream timestamp (RFC3339 with optional fractional secs).
    //   2. App-level bracket timestamp `[YYYY-MM-DD HH:MM:SS]` or `[ISO8601]`.
    //   3. Common logger header — `<dotted.name>  LEVEL  :` (Python/Java style).
    //   4. ASCII-art decoration: surrounding `***` runs and excess whitespace.
    //   5. Collapse runs of whitespace to single spaces, trim.
    // v1.6.38: was previously dumping the raw line into the modal,
    // which made Frigate / BookStack / etc. credential displays look
    // like a wall of timestamps and asterisks. Customer feedback.
    const cleanLine = (line) => {
      let s = line;
      // Docker stream prefix
      s = s.replace(/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?\s+/, '');
      // App bracket timestamp
      s = s.replace(/^\[[^\]]{8,40}\]\s+/, '');
      // Repeat once: some apps emit the bracket timestamp AFTER the
      // docker stream prefix (Frigate does), so a second strip pass
      // catches the inner one.
      s = s.replace(/^\[[^\]]{8,40}\]\s+/, '');
      // Logger header: "logger.name   LEVEL   : ..." — match a dotted
      // identifier followed by whitespace, an upper-case level word,
      // whitespace and a colon.
      s = s.replace(/^[\w.\-]+\s+(?:DEBUG|INFO|WARN|WARNING|ERROR|CRITICAL|FATAL|TRACE|NOTICE)\s*:\s*/i, '');
      // Strip leading and trailing `***` decoration with whitespace.
      s = s.replace(/^\*+\s+/, '').replace(/\s+\*+$/, '');
      // Collapse runs of whitespace.
      s = s.replace(/\s+/g, ' ').trim();
      return s;
    };
    const seen = new Set();
    const matches = [];
    for (const raw_line of raw.split('\n')) {
      const stripped = raw_line.replace(/\s+$/, '');
      if (!stripped || !KEEP.test(stripped) || DROP.test(stripped)) continue;
      const cleaned = cleanLine(stripped);
      // Drop empties, drop dupes (chatty boot logs print the same line
      // 5+ times). Preserve order.
      if (!cleaned || seen.has(cleaned)) continue;
      seen.add(cleaned);
      matches.push(cleaned);
    }
    // Cap to the last 20 matches so a chatty first boot doesn't
    // flood the UI.
    matches.splice(0, Math.max(0, matches.length - 20));
    if (matches.length === 0) {
      return res.json({
        matches: [],
        truncated: true,
        hint: `OpenBox couldn't find credentials in this container's logs. Try the Restart button in the app launcher — some services print their password only when they first boot.`,
      });
    }
    res.json({ matches, truncated: false });
  } catch (err) {
    if (err.statusCode === 404 || /no such container/i.test(err.message || '')) {
      return res.status(404).json({ error: 'Container not found.' });
    }
    log('ERROR', `first-login-creds failed for ${name}`, err);
    res.status(500).json({ error: 'Failed to read container logs.' });
  }
});

app.post('/api/containers/:id/restart', requireAuth, requireLicense, async (req, res) => {
  try {
    await docker.restartContainer(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(err.message === 'Container not found' ? 404 : 500)
       .json({ error: err.message === 'Container not found' ? err.message : 'Failed to restart container.' });
  }
});

app.post('/api/containers/:id/stop', requireAuth, requireLicense, async (req, res) => {
  try {
    await docker.stopContainer(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(err.message === 'Container not found' ? 404 : 500)
       .json({ error: err.message === 'Container not found' ? err.message : 'Failed to stop container.' });
  }
});

app.post('/api/containers/:id/start', requireAuth, requireLicense, async (req, res) => {
  try {
    await docker.startContainer(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(err.message === 'Container not found' ? 404 : 500)
       .json({ error: err.message === 'Container not found' ? err.message : 'Failed to start container.' });
  }
});

// --- Restart All OpenBox Containers ---

app.post('/api/containers/restart-all', requireAuth, requireLicense, async (req, res) => {
  try {
    // Codex round 6 #13: skip re-validating each container. We just
    // got the canonical list from docker.listContainers() (which
    // already filters to sb-* names), so every c.id is known-valid.
    // restartContainer() re-calls listContainers internally for
    // validation, turning N restarts into N+1 list calls on a 30-
    // container install. Use the Dockerode handle directly here.
    const containers = await docker.listContainers();
    const running = containers.filter(c => c.state === 'running');
    const Dockerode = require('dockerode');
    const d = new Dockerode({ socketPath: '/var/run/docker.sock' });
    // Run restarts in parallel with a small concurrency cap so we
    // don't pin the docker daemon on a 30-container NAS. Containers
    // are independent from Docker's POV — the only serializing
    // thing is the compose "depends_on" chain, which this path
    // intentionally ignores (it's a simple restart, not an up).
    const CONCURRENCY = 5;
    const results = new Array(running.length);
    let i = 0;
    async function worker() {
      while (true) {
        const idx = i++;
        if (idx >= running.length) return;
        const c = running[idx];
        try {
          await d.getContainer(c.id).restart();
          results[idx] = { id: c.id, name: c.name, success: true };
        } catch (err) {
          results[idx] = { id: c.id, name: c.name, success: false, error: err.message };
        }
      }
    }
    await Promise.all(Array.from({ length: CONCURRENCY }, worker));
    res.json({ success: true, results });
  } catch (err) {
    log('ERROR', 'Failed to restart all containers', err);
    res.status(500).json({ error: 'Failed to restart containers.' });
  }
});

// Run a host-side command that will take ob-dashboard down (reset,
// factory-reset, etc.) from INSIDE a short-lived privileged helper
// container. Mirrors the self-update pattern. The helper mounts the
// docker socket and the host OB_ROOT parent, so it can keep running
// even after `docker compose down` kills ob-dashboard.
//
// IMPORTANT: the dashboard's own OB_ROOT is /app (bind-mount target
// inside the container), but the helper container's filesystem only
// has the HOST path mounted. We read OB_ROOT from the bind-mounted
// .env to recover the real host path (e.g. /opt/openbox) and use
// that for the volume mount, the bash invocation, and the env vars
// inside the helper. Getting this wrong silently breaks the helper
// (`bash /app/openbox` fails because /app doesn't exist in the helper)
// which is exactly what bit us on 2026-04-20's Factory Reset attempt.
function spawnHostHelper(label, innerScript) {
  const { execSync, spawn: sp } = require('child_process');
  const fs = require('fs');
  const image = execSync(`docker inspect --format '{{.Config.Image}}' ob-dashboard`, { timeout: 10000 })
    .toString().trim();

  // Resolve the HOST OB_ROOT from .env. Falls back to our own OB_ROOT
  // only if .env lookup fails and we're apparently running on the host
  // (not in a container). Never use the container path inside the helper.
  // Codex cmd-injection audit caught hostRoot getting interpolated into
  // `bash -c` strings unquoted at multiple sites; the strict regex below
  // hardens against shell metacharacters in the .env value (defense-in-
  // depth — even though only sudo can write .env on the host).
  let hostRoot = OB_ROOT;
  try {
    const raw = fs.readFileSync(path.join(OB_ROOT, '.env'), 'utf8');
    for (const line of raw.split(/\r?\n/)) {
      const m = line.match(/^OB_ROOT=(.+)$/);
      if (m) {
        const v = m[1].trim().replace(/^["']|["']$/g, '');
        if (v && path.isAbsolute(v) && /^\/[a-zA-Z0-9_./-]+$/.test(v)) {
          hostRoot = v;
          break;
        }
      }
    }
  } catch { /* stay on OB_ROOT fallback */ }
  // Final defense: block any hostRoot that snuck through (won't normally
  // happen, but if OB_ROOT itself is malicious from process.env, the
  // top-of-file _SB_PATH_RE check would have already exited; this is
  // belt-and-suspenders for the .env-derived path).
  if (!/^\/[a-zA-Z0-9_./-]+$/.test(hostRoot)) {
    throw new Error(`spawnHostHelper: hostRoot ${JSON.stringify(hostRoot)} contains disallowed characters`);
  }

  const hostParent = path.dirname(hostRoot);
  const logFile = `${hostRoot}/state/${label}.log`;
  const script = `
set -uo pipefail
LOG="${logFile}"
mkdir -p "$(dirname "$LOG")"
exec > >(tee -a "$LOG") 2>&1
echo "[helper $(date -Iseconds)] starting ${label} (hostRoot=${hostRoot})"
export OB_SKIP_LOCK=1 OB_ROOT="${hostRoot}"
${innerScript}
RC=$?
echo "[helper $(date -Iseconds)] ${label} exit code: $RC"
rm -f "${LOCK_FILE}"
exit $RC
`;
  const child = sp('docker', [
    'run', '--rm', '-d',
    '--user', '0:0',
    '--entrypoint', '/bin/bash',
    '-v', '/var/run/docker.sock:/var/run/docker.sock',
    '-v', `${hostParent}:${hostParent}`,
    image,
    '-c', script,
  ], { stdio: 'ignore', detached: true });
  child.unref();
}

// --- Soft Reset: stop all, remove containers, bring everything back up ---

app.post('/api/server/soft-reset', requireAuth, requireLicense, requireRecentReauth(), async (req, res) => {
  if (!acquireOperationLock('soft-reset')) {
    return res.status(409).json({ error: 'Another operation is already running. Please wait.' });
  }
  try {
    log('INFO', 'Soft reset initiated from dashboard');
    res.json({ success: true, message: 'Soft reset started. Services will restart momentarily.' });

    // `;` not `&&` so up runs even if reset exited non-zero. Runs
    // inside a host helper container so ob-dashboard dying mid-reset
    // doesn't orphan the script.
    spawnHostHelper('soft-reset',
      'bash "$OB_ROOT/openbox" reset --soft --yes; sleep 2; bash "$OB_ROOT/openbox" up');
    activeOperation = null;
  } catch (err) {
    releaseOperationLock();
    log('ERROR', 'Soft reset failed', err);
    if (!res.headersSent) res.status(500).json({ error: "OpenBox couldn't start the soft-reset helper, so nothing was reset. Make sure Docker is running and the dashboard can reach the Docker socket, then try Soft Reset again." });
  }
});

// --- Reset to Defaults: disable all optional modules, keep only core ---

app.post('/api/server/reset-defaults', requireAuth, requireLicense, requireRecentReauth(), async (req, res) => {
  if (!acquireOperationLock('reset-defaults')) {
    return res.status(409).json({ error: 'Another operation is already running. Please wait.' });
  }
  try {
    log('INFO', 'Reset to defaults initiated from dashboard');

    // Narrow modules.conf to core BEFORE the helper runs, so the later
    // `openbox up` inside the helper sees only the core set.
    const CORE = modules.CORE_MODULES || ['core', 'dashboard'];
    const confPath = path.join(OB_ROOT, 'state', 'modules.conf');
    await writeFileAtomic(confPath, CORE.join('\n') + '\n');

    res.json({ success: true, message: 'Reset to defaults started. Optional apps are being removed.' });

    spawnHostHelper('reset-defaults',
      'bash "$OB_ROOT/openbox" reset --soft --yes; sleep 2; bash "$OB_ROOT/openbox" up');
    activeOperation = null;
  } catch (err) {
    releaseOperationLock();
    log('ERROR', 'Reset to defaults failed', err);
    if (!res.headersSent) res.status(500).json({ error: "OpenBox couldn't run reset-to-defaults. Make sure Docker is running, then try again from Settings → System." });
  }
});

// --- Factory Reset: wipe module configs/data + state, keep .env/backups/data ---
// Boots the dashboard into the first-run wizard. License key and admin
// password in .env stay — the user logs in with the same credentials and
// walks the wizard again for a fresh setup.
//
// Runs in a short-lived privileged helper container (same pattern as
// self-update) so the factory-reset script survives ob-dashboard being
// stopped mid-run by `docker compose down`. A previous implementation
// ran `setsid nohup openbox factory-reset` directly inside ob-dashboard,
// which died with the container — leaving the wipe half-done at the
// "Stopping all OpenBox services..." step. Caught live 2026-04-20.
app.post('/api/server/factory-reset', requireAuth, requireLicense, requireRecentReauth(), async (req, res) => {
  // Body-level confirmation: client must send { confirm: "DELETE" }.
  if (!req.body || req.body.confirm !== 'DELETE') {
    return res.status(400).json({ error: 'Confirmation required. Send { confirm: "DELETE" }.' });
  }
  if (!acquireOperationLock('factory-reset')) {
    return res.status(409).json({ error: 'Another operation is already running. Please wait.' });
  }
  try {
    log('INFO', 'Factory reset initiated from dashboard');
    res.json({ success: true, message: 'Factory reset started. Page will reload into setup wizard.' });

    spawnHostHelper('factory-reset',
      'bash "$OB_ROOT/openbox" factory-reset --yes');
    activeOperation = null;
  } catch (err) {
    releaseOperationLock();
    log('ERROR', 'Factory reset failed', err);
    if (!res.headersSent) {
      res.status(500).json({ error: "OpenBox couldn't start the factory-reset helper. No data was wiped. Make sure Docker is running and retry from Settings." });
    }
  }
});

// --- Remote support session ---
//
// Customer flow: Settings → "Allow Tom to help" button →
//   POST /api/support/enable → spawns `openbox support enable` in
//   a host helper, which mints a Tailscale auth key from the worker,
//   joins our tailnet ephemerally, and adds Tom's pubkey to
//   /root/.ssh/authorized_keys for 4 hours. The customer never
//   touches a terminal.
//
// Tom's flow: he sees the new node appear in his tailnet under name
//   openbox-<id8>, ssh root@openbox-<id8>, debug, then either
//   wait for auto-disable or have the customer click "Revoke now".

app.get('/api/support/status', requireAuth, async (req, res) => {
  try {
    const sj = path.join(OB_ROOT, 'state', 'support.json');
    if (!fsSync.existsSync(sj)) {
      return res.json({ enabled: false });
    }
    const raw = await fs.readFile(sj, 'utf8');
    let parsed;
    try { parsed = JSON.parse(raw); } catch { return res.json({ enabled: false }); }
    if (parsed.enabled && parsed.expires_at && parsed.expires_at < (Date.now() / 1000)) {
      // Stale — auto-disable on the host side will catch up; meanwhile
      // surface as not-active so the UI doesn't claim a session is open
      // when its window has lapsed.
      parsed.enabled = false;
    }
    res.json(parsed);
  } catch (err) {
    log('ERROR', 'support status read failed', err);
    res.status(500).json({ error: 'Could not read support state.' });
  }
});

// requireRecentReauth: support enable opens a 4h+ root SSH session via
// Tailscale and writes root authorized_keys (openbox:1353-1397). A
// stolen / unattended authenticated dashboard session must NOT be able
// to grant external root access without password re-entry — same modal
// flow as backup downloads + first-login creds. Caught 2026-05-01 deep
// audit phase 9 (Codex finding #7).
app.post('/api/support/enable', requireAuth, requireWorkerKey, requireRecentReauth(), async (req, res) => {
  if (!acquireOperationLock('support-enable')) {
    return res.status(409).json({ error: 'Another operation is already running. Please wait.' });
  }
  try {
    const hours = Math.max(1, Math.min(8, Number(req.body?.hours) || 4));
    log('INFO', `Support session enable requested (${hours}h)`);
    // Spawn the host helper FIRST so a Docker / permission failure
    // surfaces synchronously as 500, rather than 202 followed by a
    // mute UI poll-timeout. spawnHostHelper itself uses execSync to
    // resolve the dashboard image — if Docker is unreachable from the
    // dashboard container, that throws here and we fall into catch.
    spawnHostHelper(
      'support-enable',
      `bash "$OB_ROOT/openbox" support enable --hours ${hours}`
    );
    res.status(202).json({ status: 'enabling', hours });
    activeOperation = null;
  } catch (err) {
    releaseOperationLock();
    log('ERROR', 'support enable failed', err);
    if (!res.headersSent) res.status(500).json({ error: "Couldn't start support session helper. Make sure the dashboard can reach the Docker socket, then try again. Details: " + (err && err.message ? err.message : 'unknown') });
  }
});

app.post('/api/support/disable', requireAuth, async (req, res) => {
  // Intentionally NOT requireLicense: even an expired-license customer
  // should be able to revoke a previously-granted support session.
  if (!acquireOperationLock('support-disable')) {
    return res.status(409).json({ error: 'Another operation is already running. Please wait.' });
  }
  try {
    log('INFO', 'Support session disable requested');
    spawnHostHelper(
      'support-disable',
      `bash "$OB_ROOT/openbox" support disable`
    );
    res.status(202).json({ status: 'disabling' });
    activeOperation = null;
  } catch (err) {
    releaseOperationLock();
    log('ERROR', 'support disable failed', err);
    if (!res.headersSent) res.status(500).json({ error: "Couldn't close support session helper. Details: " + (err && err.message ? err.message : 'unknown') });
  }
});

// --- Clean Slate: uninstall a module and delete all its data ---

// Restart all containers for a given module. Safe for any module
// except `core`/`dashboard` (those would kill the dashboard itself —
// use /api/server/restart-all for those).
app.post('/api/modules/:id/restart', requireAuth, requireLicense, async (req, res) => {
  const moduleId = req.params.id;
  if (!/^[a-z0-9_-]+$/.test(moduleId)) {
    return res.status(400).json({ error: 'Invalid module ID.' });
  }
  const CORE = modules.CORE_MODULES || ['core', 'dashboard'];
  if (CORE.includes(moduleId)) {
    return res.status(400).json({ error: `Restart the whole stack instead — ${moduleId} is a core module.` });
  }
  try {
    const { spawn: sp } = require('child_process');
    // Detach so the HTTP response returns immediately; the restart
    // itself takes 20-40s and we don't want the user's browser to hang.
    const child = sp('sh', ['-c', `"${OB_ROOT}/openbox" restart ${moduleId} 2>&1`], {
      cwd: OB_ROOT,
      env: { ...process.env, OB_ROOT, OB_SKIP_LOCK: '1' },
      detached: true,
      stdio: 'ignore',
    });
    child.unref();
    log('INFO', `Restarting module ${moduleId}`);
    res.json({ success: true, message: `Restarting ${moduleId}...` });
  } catch (err) {
    log('ERROR', `Failed to restart ${moduleId}`, err);
    res.status(500).json({ error: err.message || 'Restart failed.' });
  }
});

app.post('/api/modules/:id/clean-slate', requireAuth, requireLicense, requireRecentReauth(), async (req, res) => {
  const moduleId = req.params.id;
  if (!/^[a-z0-9_-]+$/.test(moduleId)) {
    return res.status(400).json({ error: 'Invalid module ID.' });
  }
  const CORE = modules.CORE_MODULES || ['core', 'dashboard'];
  if (CORE.includes(moduleId)) {
    return res.status(400).json({ error: 'Cannot clean-slate a core module.' });
  }

  try {
    // 1. Disable the module (removes from modules.conf + stops containers)
    const failures = [];
    try {
      await modules.disable(OB_ROOT, moduleId);
    } catch (err) {
      failures.push(`stop/disable: ${err.message}`);
    }

    // 2. Delete the module's config and data directories. Codex 2026-04-24
    // round 5 silent-failure finding: prior code silently swallowed
    // rm failures and returned success, so a user who saw "cleanly
    // removed" might still have stale state left behind (permission
    // denied on root-owned bind mounts is the common case).
    const fsp = require('fs').promises;
    const configDir = path.join(OB_ROOT, 'modules', moduleId, 'config');
    const dataDir = path.join(OB_ROOT, 'modules', moduleId, 'data');
    try { await fsp.rm(configDir, { recursive: true, force: true }); }
    catch (err) { failures.push(`config/: ${err.code || err.message}`); }
    try { await fsp.rm(dataDir, { recursive: true, force: true }); }
    catch (err) { failures.push(`data/: ${err.code || err.message}`); }

    if (failures.length > 0) {
      log('WARN', `Clean slate: ${moduleId} — partial: ${failures.join('; ')}`);
      return res.status(500).json({
        error: `OpenBox could not fully remove ${moduleId}. Some parts failed (${failures.join('; ')}). Check file permissions on modules/${moduleId}/, then try Clean Slate again.`,
      });
    }

    log('INFO', `Clean slate: ${moduleId} — disabled + config/data deleted`);
    res.json({ success: true, message: `${moduleId} has been completely removed. Re-enable it for a fresh start.` });
  } catch (err) {
    log('ERROR', `Clean slate failed for ${moduleId}`, err);
    res.status(500).json({ error: `OpenBox could not remove ${moduleId}'s containers or data. Stop the app, check file permissions on its config/data folders, then try Clean Slate again.` });
  }
});

// --- Maintenance: prune unused Docker images ---

app.post('/api/maintenance/prune-images', requireAuth, requireLicense, async (req, res) => {
  try {
    const result = await docker.pruneImages();
    log('INFO', `Pruned ${result.imagesDeleted} images, reclaimed ${result.spaceReclaimed} bytes`);
    res.json({ success: true, ...result });
  } catch (err) {
    log('ERROR', 'Failed to prune images', err);
    res.status(500).json({ error: "Docker couldn't remove unused images right now. Make sure no install or update is running, then try Prune Images again." });
  }
});

// --- Module Profile Presets ---

// Essentials ≡ core + dashboard only. The safest default for a new
// install — the customer picks what they actually want from Apps
// page, nothing silently spun up in the background. Before v1.5.47
// the default profile in the wizard was `full`, which enabled 35+
// modules and torched low-RAM NAS boxes on first boot.
const MODULE_PROFILES = {
  essentials: ['core', 'dashboard'],
  privacy: ['core', 'dashboard', 'privacy', 'vpn', 'cloud', 'files', 'monitoring'],
  media: ['core', 'dashboard', 'media'],
  full: null, // null = enable all available modules (minus wizard-time dedup)
};

app.get('/api/profiles', requireAuth, (req, res) => {
  res.json({
    profiles: [
      { id: 'essentials', name: 'Essentials', description: 'Core + dashboard only. Pick what you want from the Apps tab.' },
      { id: 'privacy', name: 'Privacy', description: 'Privacy tools: ad-blocking, passwords, VPN, cloud storage, file browser, monitoring' },
      { id: 'media', name: 'Media', description: 'Media center with auto-downloads (Jellyfin, Sonarr, Radarr). Requires VPN creds on the VPN step.' },
      { id: 'full', name: 'Full', description: 'Everything (35+ modules, ~5-6GB RAM). Not recommended for 4GB NAS boxes.' },
      { id: 'custom', name: 'Custom', description: 'Start minimal, pick your own modules.' },
    ]
  });
});

// Wizard-time conflict dedup + VPN-required filter. Applied before
// writing modules.conf in /api/setup/complete so the final state
// is always coherent:
//
//   - conflicts_with pairs keep only the first-listed module
//     (`media` wins over standalone `jellyfin`; `adguard` vs
//     `privacy`'s pi-hole decided by listed order)
//   - VPN-gated modules (media) are dropped unless VPN creds are set
//
// Returns {modules, warnings} so the handler can include warnings
// in its response for the client to surface.
async function applyWizardConstraints(targetModules, vpnConfigured) {
  const warnings = [];
  const set = new Set(targetModules);

  // Drop VPN-gated modules if no VPN configured. The v1.5.32 VPN
  // gate blocks the module-enable API path, but the wizard writes
  // modules.conf directly -- so without this, cold-click-through
  // wizard enables `media` with empty creds and gluetun crashloops.
  const VPN_GATED = new Set(['media']);
  for (const m of [...set]) {
    if (VPN_GATED.has(m) && !vpnConfigured) {
      set.delete(m);
      warnings.push(`${m}: VPN credentials were not provided, so this module was skipped. Add VPN creds in Settings → Network → VPN, then enable it from Apps.`);
    }
  }

  // Enforce conflicts_with from module compose metadata. Before
  // v1.5.47 the wizard's full profile happily enabled both
  // standalone `jellyfin` AND the `media` bundle (which includes
  // Jellyfin) — three Jellyfin-like containers fighting for the
  // same port. Same for `emby` vs either.
  const toCheck = [...set];
  for (const m of toCheck) {
    if (!set.has(m)) continue; // may have been removed by an earlier conflict
    const meta = await modules.readComposeMetadata(OB_ROOT, m);
    if (!meta || !Array.isArray(meta.conflicts_with)) continue;
    for (const other of meta.conflicts_with) {
      if (set.has(other) && other !== m) {
        set.delete(other);
        warnings.push(`${other}: skipped because it conflicts with ${m} (both provide overlapping services).`);
      }
    }
  }

  return { modules: [...set], warnings };
}

app.post('/api/profiles/:id/apply', requireAuth, requireLicense, async (req, res) => {
  try {
    const profileId = req.params.id;
    if (profileId === 'custom') {
      return res.json({ success: true, message: 'Custom profile - no changes made.' });
    }
    const available = await modules.getAvailableModuleDirs(OB_ROOT);
    let targetModules;
    if (profileId === 'full' || !MODULE_PROFILES[profileId]) {
      targetModules = available;
    } else {
      targetModules = MODULE_PROFILES[profileId].filter(m => available.includes(m));
    }

    // Run the same wizard-time constraint pass so a profile apply
    // from the Apps page behaves identically to a wizard apply:
    // VPN-gated modules dropped without creds, conflicts_with
    // enforced. Without this, applying "Full" from Apps enabled
    // media + standalone jellyfin + emby simultaneously (three
    // Jellyfin-likes fighting for the same port) and rewrote
    // modules.conf without starting anything.
    const vpnConfigured = await isVpnConfigured();
    const constrained = await applyWizardConstraints(targetModules, vpnConfigured);
    targetModules = constrained.modules;

    // Acquire the operation lock BEFORE persisting modules.conf or
    // spawning the up. Previously we wrote modules.conf first and then
    // checked the lock — if another op (cold-install rehearsal, batch
    // apply, wizard) held it, the route returned success: true even
    // though no `openbox up` was started, leaving disk state changed
    // and running state stale.
    if (!acquireOperationLock('profile-apply')) {
      return res.status(409).json({
        error: 'Another operation is already in progress. Wait for it to finish, then retry.',
        busy: true,
      });
    }

    try {
      const confPath = path.join(OB_ROOT, 'state', 'modules.conf');
      await writeFileAtomic(confPath, targetModules.join('\n') + '\n');

      // Kick off `openbox up` detached so the profile change actually
      // brings the new modules online. Same setsid/nohup pattern as
      // /api/setup/complete so the child survives a dashboard container
      // recreate mid-up.
      const { spawn: sp } = require('child_process');
      const logFile = path.join(OB_ROOT, 'state', 'profile-apply.log');
      const cmd = buildDetachedLockedCmd(activeOperation && activeOperation.name || 'detached-up', logFile, `${OB_ROOT}/openbox up`);
      const child = sp('setsid', ['nohup', 'sh', '-c', cmd], {
        cwd: OB_ROOT,
        env: { ...process.env, OB_ROOT, OB_SKIP_LOCK: '1' },
        detached: true,
        stdio: 'ignore',
      });
      child.unref();
      activeOperation = null;
      log('INFO', `Profile "${profileId}" applied; detached openbox up (pid=${child.pid})`);
    } catch (err) {
      releaseOperationLock();
      log('ERROR', 'profile-apply failed', err);
      return res.status(500).json({ error: 'Failed to apply profile.' });
    }

    res.json({
      success: true,
      modules: targetModules,
      warnings: constrained.warnings,
      applying: true,
    });
  } catch (err) {
    log('ERROR', `Failed to apply profile: ${req.params.id}`, err);
    res.status(500).json({ error: 'Failed to apply profile.' });
  }
});

// --- Config Routes ---

// Always-allowed system config keys
// Keys that can be updated via PUT /api/config. Security-sensitive keys
// (password hash, session secret, bootstrap token) are deliberately
// excluded — they have dedicated endpoints with proper verification.
const SYSTEM_CONFIG_KEYS = new Set([
  'OB_DOMAIN', 'TZ',
  'PUID', 'PGID', 'HTTP_PORT', 'HTTPS_PORT',
  'PIHOLE_DNS_PORT', 'PORTAINER_PORT', 'MEDIA_ROOT',
  'JELLYFIN_HW_ACCEL', 'OB_LICENSE_KEY',
  'OB_AI_CHAT_ENABLED',
  'OB_UPDATE_CHANNEL',
]);

// Keys whose value is a filesystem path used as a bind-mount source.
// Any update to these goes through validatePathValue() to prevent a
// logged-in attacker from repointing a module at /etc, /root, etc.
const PATH_VALUED_KEYS = new Set([
  'MEDIA_ROOT', 'PHOTOS_PATH', 'BOOKS_PATH', 'MANGA_PATH', 'OB_DATA_DIR',
]);

// Allowed host-path prefixes for module data bind mounts. Anything
// outside these is rejected. /opt/openbox covers the install dir,
// /mnt and /media are standard Linux mount points, /home/<user>/
// covers per-user data, /srv and /data are common server layouts.
const SAFE_PATH_PREFIXES = ['/opt/openbox', '/mnt', '/media', '/srv', '/data', '/home'];

function validatePathValue(value) {
  if (typeof value !== 'string' || value.length === 0) {
    return { ok: false, reason: 'must be a non-empty string' };
  }
  if (value.length > 4096) return { ok: false, reason: 'path too long' };
  if (!value.startsWith('/')) return { ok: false, reason: 'must be an absolute path' };
  // Normalize and refuse if the normalized form escapes via ..
  const normalized = path.posix.normalize(value);
  if (normalized.includes('/..') || normalized === '..') {
    return { ok: false, reason: 'path traversal rejected' };
  }
  // Must start with one of the safe prefixes.
  const ok = SAFE_PATH_PREFIXES.some(p => normalized === p || normalized.startsWith(p + '/'));
  if (!ok) {
    return { ok: false, reason: `path must start with one of: ${SAFE_PATH_PREFIXES.join(', ')}` };
  }
  return { ok: true };
}

// Build allowed config keys dynamically from module env_vars metadata
async function getAllowedConfigKeys() {
  const allowed = new Set(SYSTEM_CONFIG_KEYS);
  try {
    const mods = await modules.listRich(OB_ROOT);
    for (const mod of mods) {
      if (mod.env_vars) {
        for (const [key, def] of Object.entries(mod.env_vars)) {
          if (def.config_editable) {
            allowed.add(key);
          }
        }
      }
    }
  } catch {
    // If metadata fails, fall back to system keys only
  }
  return allowed;
}

// Build config schema dynamically from module env_vars metadata
async function buildConfigSchema() {
  const groups = [
    { title: 'General', keys: [
      { key: 'TZ', label: 'Timezone', tip: 'Your timezone (e.g., America/New_York)', dangerous: false, type: 'text' },
      { key: 'OB_DOMAIN', label: 'Domain', tip: "Your server's domain name or IP address", dangerous: false, type: 'text' },
      { key: 'OB_ROOT', label: 'Install Path', tip: "Where OpenBox is installed (don't change this)", dangerous: true, type: 'text' },
      { key: 'PUID', label: 'User ID (PUID)', tip: 'Linux user ID that owns files your apps create. Installer sets this automatically — only change if you know you need a different UID for existing data.', dangerous: false, advanced: true, type: 'text' },
      { key: 'PGID', label: 'Group ID (PGID)', tip: 'Linux group ID for files your apps create. Installer sets this automatically — matches PUID.', dangerous: false, advanced: true, type: 'text' },
    ]},
    { title: 'Ports', keys: [
      { key: 'HTTP_PORT', label: 'HTTP Port', tip: 'HTTP port for reverse proxy (default: 80)', dangerous: false, type: 'text' },
      { key: 'HTTPS_PORT', label: 'HTTPS Port', tip: 'HTTPS port for reverse proxy (default: 443)', dangerous: false, type: 'text' },
      { key: 'PIHOLE_DNS_PORT', label: 'DNS Port', tip: 'Pi-hole DNS port (default: 53)', dangerous: false, type: 'text' },
      { key: 'PORTAINER_PORT', label: 'Portainer Port', tip: 'Portainer web UI port (default: 9000)', dangerous: false, type: 'text' },
    ]},
    { title: 'Media', keys: [
      { key: 'MEDIA_ROOT', label: 'Media Root', tip: 'Root directory for media storage (movies, tv, music, downloads)', dangerous: false, type: 'text' },
      { key: 'JELLYFIN_HW_ACCEL', label: 'Hardware Transcoding', tip: 'Jellyfin hardware acceleration (none, intel, auto)', dangerous: false, type: 'text' },
    ]}
  ];

  try {
    const mods = await modules.listRich(OB_ROOT);
    for (const mod of mods) {
      if (!mod.env_vars) continue;
      const keys = [];
      for (const [key, def] of Object.entries(mod.env_vars)) {
        keys.push({
          key,
          label: def.label || key,
          tip: def.prompt || '',
          dangerous: def.dangerous || false,
          type: def.type || 'text',
          config_editable: def.config_editable !== false,
        });
      }
      if (keys.length) {
        groups.push({ title: mod.name, moduleId: mod.id, keys });
      }
    }
  } catch {
    // If metadata fails, return just system keys
  }

  return groups;
}

app.get('/api/config', requireAuth, async (req, res) => {
  try {
    const cfg = await config.read(OB_ROOT);
    // Strip sensitive values
    const safe = {};
    for (const [key, value] of Object.entries(cfg)) {
      if (key.includes('PASSWORD') || key.includes('SECRET') || key.includes('TOKEN') || key.includes('KEY')) {
        safe[key] = value ? '********' : '';
      } else {
        safe[key] = value;
      }
    }
    res.json(safe);
  } catch (err) {
    res.status(500).json({ error: 'Failed to load configuration.' });
  }
});

app.get('/api/config/schema', requireAuth, async (req, res) => {
  try {
    const schema = await buildConfigSchema();
    res.json(schema);
  } catch (err) {
    log('ERROR', 'Failed to build config schema', err);
    res.status(500).json({ error: 'Failed to load config schema.' });
  }
});

// Env keys whose values gluetun (or other media-stack containers) read
// at container-creation time. ANY change to one of these requires a
// FORCE-RECREATE — `docker restart` reuses the existing container's
// frozen env, so the new value sits in .env but never reaches the
// running tunnel. Caught 2026-05-05 on the v1.6.43 test box: customer
// picked San Jose in the city dropdown, .env said `SERVER_CITIES=San
// Jose`, but `docker inspect ob-gluetun` had `SERVER_CITIES=` empty
// because the container had been created earlier with whatever was in
// .env at that moment. Tunnel exit stayed in Charlotte.
const MEDIA_RECREATE_ENV_KEYS = new Set([
  'VPN_PROVIDER', 'VPN_TYPE', 'VPN_USER', 'VPN_PASSWORD',
  'WIREGUARD_PRIVATE_KEY', 'WIREGUARD_ADDRESSES',
  'WIREGUARD_PUBLIC_KEY', 'WIREGUARD_PRESHARED_KEY',
  'SERVER_COUNTRIES', 'SERVER_CITIES', 'SERVER_HOSTNAMES', 'SERVER_REGIONS',
  'VPN_PORT_FORWARDING', 'FIREWALL_VPN_INPUT_PORTS',
]);

// Spawn `openbox restart media` if the media module is enabled.
// HTTP response gets `mediaRestarting: true` immediately (we only
// check eligibility synchronously); the actual `openbox restart media`
// runs in the background and emits `vpn:restart-complete` on the
// socket when done. Used by both /api/vpn/config and PUT /api/config.
//
// v1.6.50: serialize the actual restart EXECUTION via a promise chain
// where each segment awaits the spawned child's exit before the next
// can start. Two concurrent saves (e.g. /api/vpn/config burst + a PUT
// /api/config with SERVER_CITIES) used to fire two `openbox restart
// media` processes simultaneously. Both run with OB_SKIP_LOCK=1 so
// neither blocks the other; they fight over compose state and leave
// gluetun in whichever-wins-last. Now: dashboard-internal mutex
// queues subsequent restarts behind any in-flight one. Codex audit.
let _mediaRestartChain = Promise.resolve();
async function maybeRestartMediaForEnvChange(reason) {
  try {
    const enabled = await modules.getEnabledModules(OB_ROOT);
    if (!enabled.includes('media')) return false;
    // Queue (don't await) — caller's HTTP response shouldn't block.
    // Chain segments swallow errors so one failure doesn't poison the queue.
    _mediaRestartChain = _mediaRestartChain
      .then(() => _runMediaRestartSerial(reason))
      .catch((err) => log('ERROR', `media restart chain segment failed (${reason})`, err));
    return true;
  } catch (err) {
    log('WARN', `maybeRestartMediaForEnvChange (${reason}) failed`, err);
    return false;
  }
}
async function _runMediaRestartSerial(reason) {
  try {
    const { spawn: sp } = require('child_process');
    const child = sp('sh', ['-c', `"${OB_ROOT}/openbox" restart media`], {
      cwd: OB_ROOT,
      env: { ...process.env, OB_ROOT, OB_SKIP_LOCK: '1' },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stderrBuf = '';
    if (child.stderr) {
      child.stderr.on('data', (chunk) => {
        if (stderrBuf.length < 4096) stderrBuf += chunk.toString().slice(0, 4096 - stderrBuf.length);
      });
    }
    if (child.stdout) child.stdout.on('data', () => {});
    log('INFO', `media restart triggered: ${reason}`);
    if (vpnStatus && typeof vpnStatus.invalidateCache === 'function') {
      vpnStatus.invalidateCache();
    }
    // Block the chain until this restart finishes. The next queued
    // restart only starts after this child exits, so concurrent
    // edits don't fight over compose state.
    const code = await new Promise((resolve) => {
      child.on('exit', (c) => resolve(c));
      child.on('error', () => resolve(-1));
    });
    if (code === 0) {
      log('INFO', `media restart complete (${reason})`);
      io.emit('vpn:restart-complete', { success: true, reason });
    } else {
      log('ERROR', `media restart failed (${reason}, exit ${code})`, stderrBuf);
      io.emit('vpn:restart-complete', {
        success: false, code, reason,
        error: 'Restart failed — settings were saved, but the media stack did not come back up cleanly. Check Apps page for container status.',
      });
    }
  } catch (err) {
    log('WARN', `_runMediaRestartSerial (${reason}) failed`, err);
    return false;
  }
}

// v1.6.53: dropped requireRecentReauth() here. Same reasoning as v1.6.37
// when we dropped it on /api/containers/:id/first-login-creds: every
// Settings edit (VPN provider tweak, AI chat toggle, update channel,
// theme save indirectly, Trust-LAN toggle, module config) hit this
// route and the 10-minute window meant a user editing settings for
// more than ten minutes got a password prompt on every save. The gate
// was added on the theory that an attacker with a stolen session cookie
// could rewrite VPN creds; for a single-operator home NAS the daily
// friction outweighs that thin defense (httponly + samesite=lax cookie
// already mitigates CSRF, requireAuth still gates active session).
// requireRecentReauth() stays on the genuinely-destructive ops:
// factory-reset, license delete, backup restore, password dumps,
// module clean-slate, support-tunnel enable, license activate. See
// the gate at server.js:634+ for the list of routes that retained it.
app.put('/api/config', requireAuth, requireLicense, async (req, res) => {
  try {
    const allowedKeys = await getAllowedConfigKeys();
    // Validate keys against dynamic allowlist
    const updates = {};
    for (const [key, value] of Object.entries(req.body)) {
      if (!allowedKeys.has(key)) {
        return res.status(400).json({ error: `Configuration key "${key}" is not allowed.` });
      }
      // Reject values with newlines or shell metacharacters
      if (typeof value === 'string' && /[\n\r`$]/.test(value)) {
        return res.status(400).json({ error: `Invalid characters in value for "${key}".` });
      }
      // Path-valued keys must resolve inside one of the safe host-path
      // prefixes. Without this, a logged-in attacker could set
      // MEDIA_ROOT=/etc and have subsequent module restarts bind-mount
      // system directories into containers.
      if (PATH_VALUED_KEYS.has(key) && typeof value === 'string' && value.length > 0) {
        const check = validatePathValue(value);
        if (!check.ok) {
          return res.status(400).json({ error: `Invalid path for "${key}": ${check.reason}` });
        }
      }
      // Trim leading/trailing whitespace on every string value. Before
      // v1.5.52, a customer pasting a VPN private key with a stray
      // leading space saved ` eEWFJhKsEMV8Fn2h...` to .env — the
      // dashboard's isVpnConfigured() check stripped the space when
      // deciding to allow Media enable, but gluetun inside the
      // container saw the literal leading space and errored with
      // "Wireguard settings: private key is not set". Caught by a
      // real customer test on 2026-04-22.
      updates[key] = typeof value === 'string' ? value.trim() : value;
    }
    await config.update(OB_ROOT, updates);

    // v1.6.50: mirror updates into process.env so the dashboard's view
    // stays in sync with .env on disk. Without this, the next time the
    // dashboard spawns `openbox up` (or any compose command), the
    // spawned process inherits process.env where these values are still
    // whatever they were at dashboard startup — and compose's variable
    // substitution gives shell env priority over --env-file, silently
    // shadowing the user's just-saved value. Same root cause as the
    // SERVER_CITIES regression chased through v1.6.39 → v1.6.47, but
    // generalized: it would re-emerge for any of the 60+ module env
    // vars (BOOKSTACK_APP_KEY, IMMICH_DB_PASSWORD, FRIGATE_RTSP_PASSWORD,
    // PIHOLE_PASSWORD, etc.) the moment a user edited one via PUT
    // /api/config after install. Existing pattern at lines 721, 754:
    // bootstrap-claim and password-change already do this for OB_ADMIN_*.
    // Codex audit P0 (2026-05-06).
    for (const [k, v] of Object.entries(updates)) {
      process.env[k] = (v === null || v === undefined) ? '' : String(v);
    }

    // v1.6.44: if any of the updated keys are gluetun-relevant, force-
    // recreate media so the new values actually take effect. Without
    // this, the customer-config flow (PUT /api/config from the wizard's
    // module-config modal AND from Settings → Network VPN edit) wrote
    // SERVER_CITIES=San Jose to .env but left the running gluetun
    // container with whatever empty value it was created with — exit
    // node stayed wherever the cold-install picked. Caught on the
    // v1.6.43 test box.
    let mediaRestarting = false;
    const mediaEnvTouched = Object.keys(updates).some(k => MEDIA_RECREATE_ENV_KEYS.has(k));
    if (mediaEnvTouched) {
      mediaRestarting = await maybeRestartMediaForEnvChange(`PUT /api/config touched: ${Object.keys(updates).filter(k => MEDIA_RECREATE_ENV_KEYS.has(k)).join(',')}`);
    }
    res.json({ success: true, mediaRestarting });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save configuration.' });
  }
});

// --- License Routes ---

// License read — open to any authenticated user (licensed or not),
// because the activation screen needs to read the current state.
// Returns { licensed, hasKey, keyPreview, activations, maxActivations,
// purchaseDate, revoked, features }.
app.get('/api/license', requireAuth, (req, res) => {
  res.json(license.getLicenseInfo());
});

// License activation — the canonical path for the new model. Validates
// the key against the worker, persists to .env, returns the new state.
// Both /api/license/activate (new) and /api/license POST (legacy) point
// at the same handler so old callers keep working.
async function handleLicenseActivate(req, res) {
  const { key, purchaseEmail } = req.body || {};
  if (!license.isValidKeyFormat(key)) {
    return res.status(400).json({
      ok: false,
      error: 'Invalid key format. Expected: SB-PRO-XXXXXXXX-XXXXXXXX',
    });
  }
  let result;
  try {
    result = await license.activateKey(OB_ROOT, key, purchaseEmail);
  } catch (err) {
    log('ERROR', 'License activation call failed', err);
    return res.status(502).json({
      ok: false,
      error: 'Could not reach license server. Try again in a moment.',
    });
  }
  if (!result.ok) {
    return res.status(400).json({
      ...result,
      message: result.message || result.error,
    });
  }
  // Re-init Pro-gated background services now that we have a license.
  // scheduler, alerts, health-report all check license at init time.
  try { scheduler.init(OB_ROOT, io, () => activeOperation); } catch {}
  try { backup.initScheduler(OB_ROOT); } catch {}
  try { alerts.init(OB_ROOT, io); } catch {}
  res.json({
    ...result,
    ok: true,
    success: true, // legacy callers expect this field
    license: license.getLicenseInfo(),
  });
}
// Rate limit license activation. Adversarial review 2026-04-21: without
// this limiter, an authenticated (but misbehaving) client could flood
// the webhook's /validate with bad keys, consuming the KV budget and
// burning per-install-ID rate-limit slots for everyone. 5 per 5 min is
// plenty for legitimate users (typing a 16-char key with typos, hitting
// Activate a couple of times).
const licenseActivateLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Too many license activation attempts. Wait a few minutes and try again.' },
});
app.post('/api/license/activate', requireAuth, requireRecentReauth(), licenseActivateLimiter, handleLicenseActivate);
app.post('/api/license', requireAuth, requireRecentReauth(), licenseActivateLimiter, handleLicenseActivate);

// v1.6.0 free pivot. Mint a free personal-use license key from an email.
// Proxies to the webhook worker's /issue-free endpoint. Caller is the
// dashboard's license-screen form when the user hits Activate without
// pasting an existing key — the form submits an email-only payload.
app.post('/api/license/issue-free', requireAuth, licenseActivateLimiter, async (req, res) => {
  try {
    const email = ((req.body && req.body.email) || '').trim().toLowerCase();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: 'Valid email required.' });
    }
    const validateUrl = process.env.OB_LICENSE_VALIDATE_URL
      || 'https://webhook.crushcodeworks.com/validate';
    const issueUrl = validateUrl.replace(/\/validate$/, '/issue-free');
    const r = await fetch(issueUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.key) {
      return res.status(r.status || 500).json({ error: j.error || 'Could not mint a free key.' });
    }
    res.json({ key: j.key, email });
  } catch (err) {
    log('ERROR', 'Issue-free license proxy failed', err);
    res.status(500).json({ error: 'Network error while minting key.' });
  }
});

// v1.6.0 free pivot. Mark dashboard "skipped license" so the boot
// flow stops showing the activation screen. Auto-updates stay off
// (hasValidLicense() returns false). Customer can activate later
// from Settings → License.
app.post('/api/license/skip', requireAuth, async (req, res) => {
  try {
    const fsp = require('fs').promises;
    const markerPath = path.join(OB_ROOT, 'state', 'license-skipped');
    await fsp.writeFile(markerPath, new Date().toISOString(), { mode: 0o600 });
    res.json({ success: true });
  } catch (err) {
    log('ERROR', 'License skip marker write failed', err);
    res.status(500).json({ error: 'Could not save skip preference.' });
  }
});

app.delete('/api/license', requireAuth, requireRecentReauth(), async (req, res) => {
  try {
    await config.update(OB_ROOT, { OB_LICENSE_KEY: '' });
    process.env.OB_LICENSE_KEY = '';
    // Clear the cached validation so the next read falls back to free.
    try {
      const fsp = require('fs').promises;
      await fsp.unlink(path.join(OB_ROOT, 'state', 'license.json'));
    } catch {}
    scheduler.stopJob();
    res.json({ success: true, ...license.getLicenseInfo() });
  } catch (err) {
    log('ERROR', 'Failed to remove license key', err);
    res.status(500).json({ error: 'Failed to remove license key.' });
  }
});

// --- Update Routes ---

// Keep expensive update-style operations throttled, but do NOT make
// unrelated update flows share a single bucket. The Updates page can
// auto-trigger an app-update check on load; if self-update apply shares
// that limiter, simply opening the page can burn the only slot and make
// "Update OpenBox" fail immediately with a 429.
const appUpdateCheckLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 1,
  message: { error: 'App update checks are limited to once per 5 minutes.' },
});

const appUpdateApplyLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 1,
  message: { error: 'App updates are limited to once per 5 minutes.' },
});

const selfUpdateApplyLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 1,
  message: { error: 'OpenBox self-updates are limited to once per 5 minutes.' },
});

// Legacy manual update endpoint (free tier)
app.post('/api/update', requireAuth, requireWorkerKey, requireRecentReauth(), appUpdateApplyLimiter, async (req, res) => {
  try {
    const result = await docker.pullAndRecreate(OB_ROOT);
    res.json({ success: true, result });
  } catch (err) {
    log('ERROR', 'Update failed', err);
    res.status(500).json({ error: 'Update failed. Check logs for details.' });
  }
});

// Pro update endpoints
app.get('/api/updates/available', requireAuth, async (req, res) => {
  try {
    const state = await updates.getState(OB_ROOT);
    res.json({
      lastCheck: state.lastCheck,
      available: state.available,
      tier: license.getTier(),
    });
  } catch (err) {
    log('ERROR', 'Failed to get available updates', err);
    res.status(500).json({ error: 'Failed to get available updates.' });
  }
});

app.get('/api/updates/check', requireAuth, requirePro, appUpdateCheckLimiter, async (req, res) => {
  try {
    // Pass io.emit so the check streams `updates:progress` events to
    // any listening client (the Updates page modal/log). Without this
    // the user clicked Check and saw a frozen button for the entire
    // duration with zero feedback. Same fix pattern as /updates/apply.
    const available = await updates.checkForUpdates(OB_ROOT, io.emit.bind(io));
    res.json({ success: true, available });
  } catch (err) {
    log('ERROR', 'Update check failed', err);
    res.status(500).json({ error: 'Failed to check for updates.' });
  }
});

app.post('/api/updates/apply', requireAuth, requirePro, requireRecentReauth(), appUpdateApplyLimiter, async (req, res) => {
  const { module: moduleId } = req.body;
  if (moduleId && moduleId !== 'all' && !/^[a-z0-9_-]+$/.test(moduleId)) {
    return res.status(400).json({ error: 'Invalid module name.' });
  }
  try {
    // Pass io.emit so updates.js can stream `updates:progress` events to
    // the browser. Without this the frontend modal stays empty for the
    // entire pull/recreate cycle and looks frozen — cause of the
    // "empty Updating budget..." bug from the v1.4.5 audit.
    const result = await updates.performUpdate(OB_ROOT, moduleId || 'all', io.emit.bind(io));
    res.json(result);
  } catch (err) {
    log('ERROR', 'Update apply failed', err);
    res.status(500).json({ error: 'Failed to apply updates.' });
  }
});

app.post('/api/updates/rollback', requireAuth, requirePro, requireRecentReauth(), async (req, res) => {
  const { module: moduleId, snapshot } = req.body;
  if (moduleId && moduleId !== 'all' && !/^[a-z0-9_-]+$/.test(moduleId)) {
    return res.status(400).json({ error: 'Invalid module name.' });
  }
  if (!snapshot || !/^\d{4}-\d{2}-\d{2}T/.test(snapshot)) {
    return res.status(400).json({ error: 'Valid snapshot timestamp required.' });
  }
  try {
    const success = await updates.rollback(OB_ROOT, moduleId, snapshot);
    res.json({ success });
  } catch (err) {
    log('ERROR', 'Rollback failed', err);
    res.status(500).json({ error: 'Failed to rollback.' });
  }
});

app.get('/api/updates/schedule', requireAuth, requirePro, async (req, res) => {
  try {
    const schedule = await updates.getSchedule(OB_ROOT);
    res.json(schedule);
  } catch (err) {
    res.status(500).json({ error: 'Failed to get schedule.' });
  }
});

app.put('/api/updates/schedule', requireAuth, requirePro, async (req, res) => {
  const { cron: cronExpr, enabled } = req.body;
  if (cronExpr && typeof cronExpr !== 'string') {
    return res.status(400).json({ error: 'Cron expression must be a string (e.g. "0 2 * * 0" for every Sunday at 2am).' });
  }
  try {
    const schedule = await updates.getSchedule(OB_ROOT);
    const newCron = cronExpr || schedule.cron;
    const newEnabled = typeof enabled === 'boolean' ? enabled : schedule.enabled;
    await scheduler.reschedule(OB_ROOT, newCron, newEnabled);
    const updated = await updates.getSchedule(OB_ROOT);
    res.json(updated);
  } catch (err) {
    if (err && err.code === 'INVALID_CRON') {
      // User-input error, not a server fault. Codex round 5.
      return res.status(400).json({
        error: `That cron schedule isn't valid. Use the format "minute hour day-of-month month day-of-week" (e.g. "0 2 * * 0" = every Sunday at 2am). Fix it and save again.`,
      });
    }
    log('ERROR', 'Failed to update schedule', err);
    res.status(500).json({ error: 'OpenBox could not save your update schedule. Check that the scheduler service is running, then try again.' });
  }
});

app.get('/api/updates/history', requireAuth, async (req, res) => {
  try {
    const state = await updates.getState(OB_ROOT);
    res.json(state.history || []);
  } catch (err) {
    res.status(500).json({ error: 'Failed to get update history.' });
  }
});

// --- Chat Routes (Pro Feature) ---

app.post('/api/chat/session', requireAuth, requirePro, (req, res) => {
  const sessionId = chat.createSession();
  res.json({ sessionId });
});

app.get('/api/chat/history/:sessionId', requireAuth, requirePro, async (req, res) => {
  try {
    const session = await chat.getSessionHistory(OB_ROOT, req.params.sessionId);
    res.json(session);
  } catch (err) {
    res.status(500).json({ error: 'Failed to load chat history.' });
  }
});

// AI Troubleshooting is included with Pro (50/mo) and Ultimate (unlimited).
// Chat requests are routed through the OpenBox proxy at api.crushcodeworks.com/chat
// which authenticates via the user's Pro license key.

app.get('/api/chat/available', requireAuth, async (req, res) => {
  res.json({
    available: await chat.isChatAvailable(OB_ROOT),
    tier: license.getTier(),
  });
});

app.get('/api/chat/usage', requireAuth, requirePro, async (req, res) => {
  try {
    const status = await chat.getUsageStatus(OB_ROOT);
    res.json(status);
  } catch (err) {
    res.status(500).json({ error: 'Failed to get chat usage.' });
  }
});

// --- Backup Routes ---

const backupLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 1,
  message: { error: 'Backups are limited to one per minute.' },
});

app.post('/api/backup', requireAuth, requireLicense, backupLimiter, async (req, res) => {
  try {
    const file = await backup.create(OB_ROOT);
    res.json({ success: true, file });
  } catch (err) {
    log('ERROR', 'Failed to create backup', err);
    res.status(500).json({ error: 'Failed to create backup.' });
  }
});

app.get('/api/backups', requireAuth, async (req, res) => {
  try {
    const backups = await backup.list(OB_ROOT);
    res.json(backups);
  } catch (err) {
    res.status(500).json({ error: 'Failed to list backups.' });
  }
});

app.get('/api/backups/:filename', requireAuth, requireRecentReauth(), async (req, res) => {
  try {
    const filename = req.params.filename;
    let filePath;

    if (filename.endsWith('.enc')) {
      // Decrypt before download
      filePath = await backup.decrypt(OB_ROOT, filename);
      const downloadName = filename.replace('.enc', '');
      // Unlink the plaintext as soon as the response is done streaming
      // (or aborts). The 60s setTimeout in backup.decrypt is the safety
      // net for the abort case; this is the fast path.
      const cleanup = () => { require('fs').promises.unlink(filePath).catch(() => {}); };
      res.on('close', cleanup);
      res.on('finish', cleanup);
      res.download(filePath, downloadName);
    } else {
      filePath = await backup.getPath(OB_ROOT, filename);
      res.download(filePath);
    }
  } catch (err) {
    res.status(404).json({ error: 'Backup not found.' });
  }
});

// Restore from a backup archive. Overwrites state/, .env, and module
// configs (and data if the archive is a full backup) with the archived
// versions, then signals the caller to run `openbox up` to restart
// services with the restored configuration.
app.post('/api/backup/restore', requireAuth, requireRecentReauth(), requireLicense, async (req, res) => {
  const { filename } = req.body || {};
  if (!filename || typeof filename !== 'string') {
    return res.status(400).json({ error: 'Missing filename.' });
  }
  // Use the shared validator from backup.js so dashboard restore accepts
  // the same filenames that listing + CLI restore accept (current
  // 8d_6t format AND legacy ISO-like format). Codex audit finding #6:
  // before this, GET /api/backups would list legacy files but
  // POST /api/backup/restore returned 400. Caught 2026-05-01.
  if (!backup.isSupportedBackupFilename(filename)) {
    return res.status(400).json({ error: 'Invalid backup filename.' });
  }
  try {
    log('WARN', `Restoring from backup: ${filename}`);
    const result = await backup.restore(OB_ROOT, filename);
    log('INFO', `Restore complete: ${filename}`);
    res.json(result);
  } catch (err) {
    // Codex round 5: differentiate user-recoverable errors (bad input,
    // missing file, wrong key) from genuine server faults. Don't leak
    // raw err.message — it can include host paths, archive entry
    // names, or internal command output.
    log('ERROR', `Restore failed: ${filename}`, err);
    const code = err && err.code;
    if (code === 'ENOENT' || code === 'BACKUP_NOT_FOUND') {
      return res.status(404).json({ error: `OpenBox couldn't find backup "${filename}". It may have been deleted. Refresh your backups list.` });
    }
    if (code === 'BACKUP_DECRYPT_FAILED' || code === 'BACKUP_KEY_MISMATCH') {
      return res.status(422).json({ error: `OpenBox couldn't decrypt "${filename}" with the current backup key. The backup may have been created on a different install. Restore it with the matching key or pick another backup.` });
    }
    if (code === 'BACKUP_INVALID' || code === 'BACKUP_UNSAFE_PATH') {
      return res.status(422).json({ error: `"${filename}" doesn't look like a valid OpenBox backup. Choose a different backup.` });
    }
    res.status(500).json({ error: 'OpenBox could not restore the backup. Your current install was not modified. Try another backup or contact support.' });
  }
});

// View auto-generated passwords from state/ files. These are created
// at install time for services like Portainer and Authelia — the user
// needs to see them to log in but shouldn't have to SSH in and cat
// files. Gated on requireAuth so only logged-in dashboard admins can
// read them.
// v1.6.56: dropped requireRecentReauth(). The Service Passwords panel
// in Settings auto-loads this on mount, so navigating to Settings →
// Monitoring fired a password prompt every time the reauth window
// expired. requireAuth still gates an active session. Stolen-cookie
// risk is real but the same exposure exists for every other
// state-file-backed cred via the launcher modal (which dropped reauth
// in v1.6.37); centralizing the dump-view here doesn't change the
// blast radius for that attacker class.
app.get('/api/passwords', requireAuth, requireRecentReauthIfPublic(), async (req, res) => {
  const stateDir = path.join(OB_ROOT, 'state');
  const passwords = {};
  // Codex round 4 finding #8: this used to list only Portainer and
  // Authelia. Customers looking for their Jellyfin, Seerr, qBit, or
  // Linkding auto-generated password hit the launcher modal but
  // Settings → Passwords pretended those credentials didn't exist.
  // Surface every state-file-backed cred the launcher modal knows
  // about, plus Authelia which is only reachable via this page.
  const files = [
    { key: 'portainer',  file: 'portainer-admin-password.txt',  label: 'Portainer admin' },
    { key: 'authelia',   file: 'authelia-admin-password.txt',   label: 'Authelia admin' },
    { key: 'jellyfin',   file: 'jellyfin-admin-password.txt',   label: 'Jellyfin admin (shared with Seerr)' },
    { key: 'qbittorrent',file: 'qbittorrent-admin-password.txt',label: 'qBittorrent admin' },
    { key: 'linkding',   file: 'linkding-admin-password.txt',   label: 'Linkding admin' },
    // v1.6.35: Pi-hole + Vaultwarden surfacing — see STATE_FILE_CREDS comment.
    { key: 'pihole',     file: 'pihole-admin-password.txt',     label: 'Pi-hole admin' },
    { key: 'vaultwarden',file: 'vaultwarden-admin-password.txt',label: 'Vaultwarden access guide (web vault needs HTTPS — see file)' },
    // v1.6.42: *arr admin users seeded by arr-bootstrap.sh — see STATE_FILE_CREDS comment.
    { key: 'sonarr',     file: 'sonarr-admin-password.txt',     label: 'Sonarr admin' },
    { key: 'radarr',     file: 'radarr-admin-password.txt',     label: 'Radarr admin' },
    { key: 'prowlarr',   file: 'prowlarr-admin-password.txt',   label: 'Prowlarr admin' },
  ];
  for (const { key, file, label } of files) {
    try {
      const fsp = require('fs').promises;
      const val = (await fsp.readFile(path.join(stateDir, file), 'utf8')).trim();
      if (val) passwords[key] = { label, password: val };
    } catch {}
  }
  res.json(passwords);
});

// --- LAN-trust toggle for the *arr stack ---
//
// v1.6.43: lets the operator opt out of v1.6.40's Forms+Enabled lockdown
// for Sonarr/Radarr/Prowlarr if they trust their LAN (single-operator
// home NAS, no port forwarding, router is the trust boundary). Flipping
// to "external" reverts to pre-v1.6.40 behavior:
//   <AuthenticationMethod>External</AuthenticationMethod>
//   <AuthenticationRequired>DisabledForLocalAddresses</AuthenticationRequired>
// which means: anyone on the LAN walks straight in (auto-login feel),
// auth is only enforced for non-LAN if an upstream proxy provides it.
//
// The default stays Forms+Enabled because shipping External-by-default
// means a beta tester with roommates / IoT / guest devices on the same
// subnet has no auth between any of them and Sonarr. This toggle is the
// power-user escape hatch, not a recommended default.
//
// Scope is the three *arrs only. Pi-hole / Vaultwarden / Authelia / the
// dashboard itself are unaffected.
const ARR_APPS_FOR_AUTH = ['sonarr', 'radarr', 'prowlarr'];
const arrConfigPath = (app) =>
  path.join(OB_ROOT, 'modules', 'media', 'config', app, 'config.xml');

async function readArrAuthMode() {
  // Read from whichever *arr's config.xml exists; arr-bootstrap and
  // this endpoint always set them in lockstep, so the first hit wins.
  const fsp = require('fs').promises;
  for (const app of ARR_APPS_FOR_AUTH) {
    try {
      const xml = await fsp.readFile(arrConfigPath(app), 'utf8');
      const m = xml.match(/<AuthenticationMethod>([^<]+)<\/AuthenticationMethod>/);
      if (m) {
        return m[1].trim().toLowerCase().startsWith('external') ? 'external' : 'forms';
      }
    } catch { /* try next */ }
  }
  return null; // media stack not installed
}

async function applyArrAuthMode(mode) {
  const fsp = require('fs').promises;
  const method = mode === 'external' ? 'External' : 'Forms';
  const required = mode === 'external' ? 'DisabledForLocalAddresses' : 'Enabled';
  const touched = [];
  for (const app of ARR_APPS_FOR_AUTH) {
    const p = arrConfigPath(app);
    let xml;
    try { xml = await fsp.readFile(p, 'utf8'); } catch { continue; }
    const orig = xml;
    xml = xml.replace(/<AuthenticationMethod>[^<]+<\/AuthenticationMethod>/,
                      `<AuthenticationMethod>${method}</AuthenticationMethod>`);
    xml = xml.replace(/<AuthenticationRequired>[^<]+<\/AuthenticationRequired>/,
                      `<AuthenticationRequired>${required}</AuthenticationRequired>`);
    if (xml !== orig) {
      await fsp.writeFile(p, xml, { mode: 0o600 });
      touched.push(app);
    }
  }
  // Restart so the *arrs reload config.xml. dockerode swallows missing-
  // container errors loudly — wrap each so one disabled app doesn't
  // abort the others.
  for (const app of touched) {
    try { await docker.restartContainer(`sb-${app}`); }
    catch (err) { log('WARN', `arr-auth restart sb-${app} failed: ${err.message}`); }
  }
  return { applied: mode, touched };
}

app.get('/api/arr-auth/state', requireAuth, async (req, res) => {
  try {
    const mode = await readArrAuthMode();
    res.json({ mode: mode || 'forms', mediaInstalled: mode !== null });
  } catch (err) {
    log('ERROR', `arr-auth/state read: ${err.message}`);
    res.status(500).json({ error: 'Could not read auth mode.' });
  }
});

// v1.6.53: dropped requireRecentReauth() — Trust-LAN is a settings
// toggle, not a destructive op. Same reasoning as PUT /api/config
// above. requireAuth still gates an active session.
app.post('/api/arr-auth/state', requireAuth, async (req, res) => {
  const mode = String((req.body && req.body.mode) || '').toLowerCase();
  if (mode !== 'forms' && mode !== 'external') {
    return res.status(400).json({ error: 'mode must be "forms" or "external"' });
  }
  try {
    const result = await applyArrAuthMode(mode);
    res.json({ ok: true, ...result });
  } catch (err) {
    log('ERROR', `arr-auth/state write: ${err.message}`);
    res.status(500).json({ error: 'Could not apply auth mode.' });
  }
});

// v1.6.65: re-run scripts/media-finish.sh in the background.
// Surfaced primarily to support the Moonfin opt-in toggle: when a
// user flips MOONFIN_ENABLED on, we PUT /api/config to update .env,
// then call this endpoint to re-fire media-finish so the new env is
// picked up and the plugin gets installed without waiting for the
// next openbox up. Same pattern as how arr-bootstrap auto-fires.
app.post('/api/media-finish/run', requireAuth, requireLicense, async (req, res) => {
  try {
    const { spawn: sp } = require('child_process');
    const logFile = path.join(OB_ROOT, 'state', 'media-finish.log');
    const child = sp('bash', ['-c', `"${OB_ROOT}/scripts/media-finish.sh" >>"${logFile}" 2>&1`], {
      cwd: OB_ROOT,
      env: { ...process.env, OB_ROOT },
      detached: true,
      stdio: 'ignore',
    });
    child.unref();
    log('INFO', `media-finish re-fired in background (pid=${child.pid})`);
    res.json({ success: true, message: 'media-finish started; tail state/media-finish.log to follow.' });
  } catch (err) {
    log('ERROR', 'media-finish spawn failed', err);
    res.status(500).json({ error: 'Failed to start media-finish.' });
  }
});

// v1.6.86: status of the most recent media-finish run.
//
// Surfaced 2026-05-10 by notrike — they flipped the Moonfin toggle and
// the dashboard status text stayed stuck on "Installing Moonfin
// plugin in Jellyfin (downloading from GitHub + restarting Jellyfin)…"
// indefinitely, even after media-finish.log wrote "Media finish
// complete" and Moonfin was actually installed on disk. Bug was that
// the toggle handler set the status text once after POST and never
// polled for completion.
//
// Read the last ~100 lines of media-finish.log, look for:
//   - "Media finish complete" → run is done
//   - "Moonfin: extracted version X" or "Moonfin: ... already installed" → installed
//   - "Moonfin: ERROR" / "Moonfin: ... failed" → failed
//
// Returns shape: { running, completed_at, moonfin_status, last_lines }.
// Frontend polls this every 5s after a flip-on; stops polling once
// `completed_at` is present AND newer than the post-time.
app.get('/api/media-finish/status', requireAuth, async (req, res) => {
  try {
    const fs = require('fs');
    const logFile = path.join(OB_ROOT, 'state', 'media-finish.log');
    if (!fs.existsSync(logFile)) {
      return res.json({ running: false, completed_at: null, moonfin_status: 'unknown', last_lines: [] });
    }
    // Read last 8KB of log — enough for the recent run, bounded for cost.
    const stat = fs.statSync(logFile);
    const readLen = Math.min(stat.size, 8192);
    const fd = fs.openSync(logFile, 'r');
    const buf = Buffer.alloc(readLen);
    fs.readSync(fd, buf, 0, readLen, Math.max(0, stat.size - readLen));
    fs.closeSync(fd);
    const tail = buf.toString('utf8');
    const lines = tail.split('\n').filter(Boolean);
    // The script writes a stable "Media finish complete" line at the end.
    const lastCompleteIdx = lines.map((l, i) => l.includes('Media finish complete') ? i : -1).filter(i => i >= 0).pop();
    const lastStartIdx = lines.map((l, i) => l.includes('Moonfin: opt-in enabled') || l.includes('Starting media-finish') ? i : -1).filter(i => i >= 0).pop();
    // Running = a start marker exists later than the last complete marker.
    const running = lastStartIdx != null && (lastCompleteIdx == null || lastStartIdx > lastCompleteIdx);
    let moonfinStatus = 'unknown';
    // Scan ALL Moonfin lines in the tail to determine outcome.
    const moonfinLines = lines.filter(l => /\bMoonfin\b/i.test(l));
    if (moonfinLines.some(l => /Moonfin:.*(failed|ERROR)/i.test(l))) {
      moonfinStatus = 'failed';
    } else if (moonfinLines.some(l => /Moonfin:.*(extracted version|already installed)/i.test(l))) {
      moonfinStatus = 'installed';
    } else if (moonfinLines.some(l => /Moonfin:.*opt-in enabled/i.test(l))) {
      moonfinStatus = 'installing';
    } else if (moonfinLines.some(l => /Moonfin:.*opt-in disabled/i.test(l))) {
      moonfinStatus = 'disabled';
    }
    res.json({
      running,
      completed_at: lastCompleteIdx != null ? new Date(stat.mtimeMs).toISOString() : null,
      moonfin_status: moonfinStatus,
      last_lines: lines.slice(-15),
    });
  } catch (err) {
    log('ERROR', 'media-finish status read failed', err);
    res.status(500).json({ error: 'Failed to read media-finish status.' });
  }
});

// --- Support Ticket ---
//
// Private channel for refund/license/billing/security matters.
// Troubleshooting belongs on the forum (Help modal's primary CTA).
// The dashboard holds the Bearer license key + install ID so the
// customer never has to paste them; we just relay their subject +
// message to the webhook worker, which rate-limits + emails Tom
// via Resend. Gate on requireAuth so only logged-in dashboard
// admins can submit — not on requireLicense, because a customer
// whose license validation is temporarily failing (rate-limit,
// revocation dispute) should STILL be able to reach support.

// Light per-install rate limit as a first line — prevents a
// runaway client from hammering even before the worker's
// 3/day/license cap fires.
const ticketSubmitLimiter = require('express-rate-limit').rateLimit({
  windowMs: 60 * 1000,
  max: 2, // 2/min/IP — legit customers submit maybe 1 ticket per session
  standardHeaders: true,
  legacyHeaders: false,
});

app.post('/api/support/ticket', requireAuth, ticketSubmitLimiter, async (req, res) => {
  const { subject, message, diagnostics, replyTo, includeServerInfo } = req.body || {};
  if (!subject || typeof subject !== 'string' || !subject.trim()) {
    return res.status(400).json({ error: 'subject is required' });
  }
  if (!message || typeof message !== 'string' || !message.trim()) {
    return res.status(400).json({ error: 'message is required' });
  }
  // Customer can opt in to server info. Build it server-side so the
  // client can't fabricate or omit sensitive bits.
  let finalDiagnostics = String(diagnostics || '').slice(0, 4000);
  if (includeServerInfo) {
    try {
      const info = await docker.getSystemInfo();
      const version = require('fs').readFileSync(path.join(OB_ROOT, 'VERSION'), 'utf8').trim();
      finalDiagnostics = [
        `OpenBox version: ${version}`,
        `Host: ${info.hostname || 'unknown'}`,
        `OS: ${info.os || 'unknown'} (${info.arch || 'unknown'})`,
        `Docker: ${info.dockerVersion || 'unknown'}`,
        `CPU cores: ${info.cpus || 'unknown'}`,
        `Memory: ${info.memory ? Math.round(info.memory / 1024 / 1024 / 1024) + ' GB' : 'unknown'}`,
        `Containers: ${info.containersRunning || 0} running / ${info.containers || 0} total`,
        finalDiagnostics ? '\n' + finalDiagnostics : '',
      ].filter(Boolean).join('\n');
    } catch {
      // Best effort — don't fail the ticket if diagnostics can't be built.
    }
  }

  try {
    const result = await support.submitTicket({
      sbRoot: OB_ROOT,
      subject: subject.trim(),
      message: message.trim(),
      diagnostics: finalDiagnostics,
      replyTo: typeof replyTo === 'string' ? replyTo.trim() : '',
    });
    log('INFO', `Support ticket submitted: ${result.ticketId || 'unknown'}`);
    res.json({ success: true, ticketId: result.ticketId || null, emailed: result.emailed !== false });
  } catch (err) {
    log('WARN', `Support ticket submission failed: ${err.message}`);
    if (err.status === 429) {
      return res.status(429).json({
        error: err.message,
        retryAfter: err.retryAfter,
      });
    }
    res.status(err.status || 502).json({
      error: err.message || 'Could not submit ticket. Your message was not sent. Try again in a minute.',
    });
  }
});

// --- Alerts Routes (Pro Feature) ---

app.get('/api/alerts', requireAuth, async (req, res) => {
  try {
    const alertList = await alerts.getAlerts(OB_ROOT);
    res.json(alertList);
  } catch (err) {
    log('ERROR', 'Failed to get alerts', err);
    res.status(500).json({ error: 'Failed to get alerts.' });
  }
});

app.get('/api/alerts/settings', requireAuth, requirePro, async (req, res) => {
  try {
    const settings = await alerts.getSettings(OB_ROOT);
    res.json(settings);
  } catch (err) {
    res.status(500).json({ error: 'Failed to get alert settings.' });
  }
});

app.put('/api/alerts/settings', requireAuth, requirePro, async (req, res) => {
  try {
    const { autoRestart, webhookUrl } = req.body;
    const settings = await alerts.updateSettings(OB_ROOT, { autoRestart, webhookUrl });
    res.json(settings);
  } catch (err) {
    log('ERROR', 'Failed to update alert settings', err);
    res.status(500).json({ error: 'Failed to update alert settings.' });
  }
});

// --- Health Reports Routes (Pro Feature) ---

app.get('/api/reports', requireAuth, requirePro, async (req, res) => {
  try {
    const reports = await healthReport.listReports(OB_ROOT);
    res.json(reports);
  } catch (err) {
    res.status(500).json({ error: 'Failed to list reports.' });
  }
});

app.get('/api/reports/latest', requireAuth, requirePro, async (req, res) => {
  try {
    const report = await healthReport.getLatestReport(OB_ROOT);
    if (!report) {
      return res.json(null);
    }
    res.json(report);
  } catch (err) {
    res.status(500).json({ error: 'Failed to get latest report.' });
  }
});

// --- System Info ---

app.get('/api/system', requireAuth, async (req, res) => {
  try {
    const info = await docker.getSystemInfo();
    res.json(info);
  } catch (err) {
    res.status(500).json({ error: 'Failed to load system info.' });
  }
});

app.get('/api/system/stats', requireAuth, async (req, res) => {
  // Served from the in-memory host-metrics cache. Zero Docker calls,
  // zero shell-outs, zero blocking sleeps. ensureSample() primes the
  // cache on the first cold request so REST callers don't see the
  // zero-filled bootstrap object before any socket subscriber has
  // warmed the sampler.
  await hostMetrics.ensureSample();
  res.json(hostMetrics.getSnapshot());
});

// Recyclarr / TRaSH-Guides status — surfaces what's actually applied
// to the customer's *arr stack. Without this, customer has no idea
// they got 34 custom formats + a curated quality profile out of the
// box (Phase 15 ship). Phase 23 of 2026-05-01 deep audit.
app.get('/api/recyclarr/status', requireAuth, async (req, res) => {
  try {
    const fsp = require('fs').promises;
    const fs = require('fs');
    const result = {
      enabled: false,
      lastSyncedAt: null,
      configPresent: false,
      sonarr: null,
      radarr: null,
    };
    // Marker presence + mtime tells us when Recyclarr last ran clean.
    const marker = path.join(OB_ROOT, 'state', 'recyclarr-synced');
    if (fs.existsSync(marker)) {
      const st = await fsp.stat(marker);
      result.enabled = true;
      result.lastSyncedAt = st.mtime.toISOString();
    }
    const yml = path.join(OB_ROOT, 'modules', 'media', 'config', 'recyclarr', 'recyclarr.yml');
    if (fs.existsSync(yml)) {
      result.configPresent = true;
    }
    // Live counts from Sonarr/Radarr. Skip on auth-key-not-yet-issued
    // (early in install before arr-bootstrap completes).
    const keysFile = path.join(OB_ROOT, 'state', 'arr-api-keys.json');
    if (fs.existsSync(keysFile)) {
      try {
        const keys = JSON.parse(await fsp.readFile(keysFile, 'utf8'));
        const fetch = require('http');
        const probe = (host, port, key) => new Promise((resolve) => {
          const req = fetch.request({
            host, port, path: '/api/v3/customformat',
            headers: { 'X-Api-Key': key },
            timeout: 4000,
          }, (resp) => {
            let body = '';
            resp.on('data', (c) => body += c);
            resp.on('end', () => {
              try {
                const arr = JSON.parse(body);
                resolve({ count: Array.isArray(arr) ? arr.length : 0 });
              } catch { resolve({ count: 0 }); }
            });
          });
          req.on('error', () => resolve({ count: 0 }));
          req.on('timeout', () => { req.destroy(); resolve({ count: 0 }); });
          req.end();
        });
        // *arrs share gluetun's netns; reachable via published host ports
        if (keys.sonarr) result.sonarr = await probe('localhost', 8989, keys.sonarr);
        if (keys.radarr) result.radarr = await probe('localhost', 7878, keys.radarr);
      } catch { /* keys file unreadable, leave counts null */ }
    }
    res.json(result);
  } catch (err) {
    log('ERROR', 'recyclarr status failed', err);
    res.status(500).json({ error: 'Could not read Recyclarr state.' });
  }
});

// Prowlarr indexer count — surfaces the "you need to add an indexer
// before downloads work" gap to the customer. v1.6.x removed default
// indexer auto-seeding for Terms §6 compliance (OpenBox does not
// pre-configure indexers, trackers, or sources). The flip side is
// that a fresh install has zero indexers and Sonarr/Radarr requests
// queue forever with no feedback. The Home banner uses this endpoint
// to detect the empty state and surface a clear next-step.
app.get('/api/media/indexer-count', requireAuth, async (req, res) => {
  try {
    const fsp = require('fs').promises;
    const fs = require('fs');
    const result = { count: null, prowlarrReachable: false };
    const keysFile = path.join(OB_ROOT, 'state', 'arr-api-keys.json');
    if (!fs.existsSync(keysFile)) return res.json(result);
    let keys;
    try {
      keys = JSON.parse(await fsp.readFile(keysFile, 'utf8'));
    } catch { return res.json(result); }
    if (!keys.prowlarr) return res.json(result);
    const httpMod = require('http');
    const body = await new Promise((resolve) => {
      const r = httpMod.request({
        host: 'localhost', port: 9696, path: '/api/v1/indexer',
        headers: { 'X-Api-Key': keys.prowlarr },
        timeout: 4000,
      }, (resp) => {
        let buf = '';
        resp.on('data', (c) => buf += c);
        resp.on('end', () => resolve(buf));
      });
      r.on('error', () => resolve(null));
      r.on('timeout', () => { r.destroy(); resolve(null); });
      r.end();
    });
    if (body == null) return res.json(result);
    result.prowlarrReachable = true;
    try {
      const arr = JSON.parse(body);
      result.count = Array.isArray(arr) ? arr.length : 0;
    } catch { result.count = 0; }
    res.json(result);
  } catch (err) {
    log('ERROR', 'indexer-count failed', err);
    res.status(500).json({ error: 'Could not check Prowlarr indexer count.' });
  }
});

// Activity feed — most recent lifecycle events for sb-* containers.
// Served from the state-store ring buffer (last 20 events). Zero
// polling cost — populated from the same Docker /events stream that
// drives the state store.
app.get('/api/activity', requireAuth, async (req, res) => {
  res.json({ events: stateStore.getActivity() });
});

// Network info — LAN hostname, domain, port summary. Read from
// OB_DOMAIN in .env plus os.hostname() and os.networkInterfaces().
app.get('/api/network', requireAuth, async (req, res) => {
  try {
    const cfg = await config.read(OB_ROOT);
    // Tom 2026-04-24 live review: previously this returned
    // os.hostname() and os.networkInterfaces(), which inside a Docker
    // container are the CONTAINER's identity (c2fdfdadf413, 172.20.0.5)
    // — not what a user wants to see on their "Network" card. The top
    // host pill gets the right info via docker.info().Name; use the
    // same source here.
    let hostname = 'unknown';
    try {
      const info = await docker.getSystemInfo();
      if (info && info.hostname) hostname = info.hostname;
    } catch {}

    // For LAN IPs, use the host header on the incoming request — that
    // IS a valid address the client used to reach us. Full iface
    // enumeration from inside a container is misleading (always
    // reports the docker bridge). This is best-effort; if users want
    // the complete LAN IP list they can see it on the NAS dashboard.
    const addresses = [];
    const hostHeader = (req.get('host') || '').split(':')[0];
    if (hostHeader && hostHeader !== 'localhost' && !hostHeader.startsWith('127.')) {
      addresses.push({ iface: 'connected via', address: hostHeader });
    }

    res.json({
      hostname,
      domain: cfg.OB_DOMAIN || '',
      addresses,
      httpPort: cfg.HTTP_PORT || '80',
      httpsPort: cfg.HTTPS_PORT || '443',
      dashboardPort: '8443',
    });
  } catch (err) {
    log('ERROR', 'Failed to load network info', err);
    res.status(500).json({ error: 'Failed to load network info.' });
  }
});

// Backup status — last backup file timestamp + size, count of
// backups, whether encryption is configured. Does NOT return the
// backup key itself.
app.get('/api/backup/status', requireAuth, async (req, res) => {
  try {
    const fsp = require('fs').promises;
    const backupDir = path.join(OB_ROOT, 'backups');
    let files = [];
    try {
      const entries = await fsp.readdir(backupDir);
      // Match the actual names createUnlocked() writes:
      //   openbox-backup-${ts}.tar.gz.enc   (encrypted, default)
      //   openbox-full-${ts}.tar.gz         (plaintext, opt-in)
      // Codex 2026-04-24 round 2 finding #6: prior filter was
      // "openbox-backup-*.tar.gz" (without .enc), which matched
      // nothing the backup module actually writes — /api/backup/status
      // always reported zero backups even after a successful backup.
      const stats = await Promise.all(
        entries
          .filter(e => (
            (e.startsWith('openbox-backup-') && e.endsWith('.tar.gz.enc')) ||
            (e.startsWith('openbox-full-') && e.endsWith('.tar.gz'))
          ))
          .map(async (e) => {
            const st = await fsp.stat(path.join(backupDir, e)).catch(() => null);
            return st ? { name: e, size: st.size, mtime: st.mtimeMs } : null;
          })
      );
      files = stats.filter(Boolean).sort((a, b) => b.mtime - a.mtime);
    } catch { /* backup dir doesn't exist yet */ }
    const last = files[0] || null;
    res.json({
      count: files.length,
      lastBackupName: last ? last.name : null,
      lastBackupSize: last ? last.size : 0,
      lastBackupAt: last ? last.mtime : null,
      encrypted: !!process.env.OB_BACKUP_KEY,
    });
  } catch (err) {
    log('ERROR', 'Failed to load backup status', err);
    res.status(500).json({ error: 'Failed to load backup status.' });
  }
});

app.get('/api/backup/schedule', requireAuth, async (req, res) => {
  try {
    const schedule = await backup.getSchedule(OB_ROOT);
    res.json(schedule);
  } catch (err) {
    res.status(500).json({ error: 'Failed to get backup schedule.' });
  }
});

app.put('/api/backup/schedule', requireAuth, requireLicense, async (req, res) => {
  const { cron: cronExpr, enabled, retentionCount } = req.body;
  if (cronExpr !== undefined && typeof cronExpr !== 'string') {
    return res.status(400).json({ error: 'Cron expression must be a string (e.g. "0 2 * * 0" for every Sunday at 2am).' });
  }
  // Validate cron up front — Codex round 5 flagged that the old flow
  // returned HTTP 500 when the cron expression was bad (a user-input
  // error). 400 with an actionable message is correct.
  if (cronExpr !== undefined) {
    const cronLib = require('node-cron');
    if (!cronLib.validate(cronExpr)) {
      return res.status(400).json({
        error: `That cron schedule isn't valid. Use the format "minute hour day-of-month month day-of-week" (e.g. "0 2 * * 0" = every Sunday at 2am). Fix it and save again.`,
      });
    }
  }
  if (retentionCount !== undefined) {
    const n = parseInt(retentionCount, 10);
    if (isNaN(n) || n < 1 || n > 100) {
      return res.status(400).json({ error: 'Backup retention count must be a whole number between 1 and 100.' });
    }
  }
  try {
    const config = {};
    if (cronExpr !== undefined) config.cron = cronExpr;
    if (typeof enabled === 'boolean') config.enabled = enabled;
    if (retentionCount !== undefined) config.retentionCount = retentionCount;
    const updated = await backup.rescheduleBackups(OB_ROOT, config);
    const schedule = await backup.getSchedule(OB_ROOT);
    res.json(schedule);
  } catch (err) {
    log('ERROR', 'Failed to update backup schedule', err);
    res.status(500).json({ error: 'OpenBox could not save your backup schedule. Check that the backups folder is writable and retry.' });
  }
});

// --- Socket.IO: Real-time Logs + Status ---

// Shared operation lock across all socket connections — prevents concurrent destructive ops

io.on('connection', (socket) => {
  const sess = socket.request.session;
  if (!sess || !sess.authenticated) {
    socket.disconnect();
    return;
  }

  // Input validation for socket events
  const isValidName = (name) => typeof name === 'string' && /^[a-z0-9_-]+$/.test(name);
  socket.on('module:enable', async (moduleName) => {
    if (!isValidName(moduleName)) { socket.emit('operation:error', { error: 'Invalid module name.' }); return; }
    // Mirror the REST endpoint's gate. Free-personal-use: skip marker counts.
    if (!isLicensedOrSkipped()) {
      socket.emit('operation:error', { error: 'license_required' });
      return;
    }
    if (!acquireOperationLock('module-enable-' + moduleName)) {
      socket.emit('operation:busy', { message: 'Another operation is in progress.' });
      return;
    }
    try {
      const emitFn = (event, data) => socket.emit(event, data);
      socket.emit('operation:started', { module: moduleName, action: 'enable' });
      await modules.enableStreaming(OB_ROOT, moduleName, emitFn);
    } catch (err) {
      socket.emit('operation:error', { module: moduleName, error: err.message });
    }
    releaseOperationLock();
  });

  socket.on('module:disable', async (moduleName) => {
    if (!isValidName(moduleName)) { socket.emit('operation:error', { error: 'Invalid module name.' }); return; }
    // Mirror the REST endpoint's gate. Free-personal-use: skip marker counts.
    if (!isLicensedOrSkipped()) {
      socket.emit('operation:error', { error: 'license_required' });
      return;
    }
    if (!acquireOperationLock('module-disable-' + moduleName)) {
      socket.emit('operation:busy', { message: 'Another operation is in progress.' });
      return;
    }
    try {
      const emitFn = (event, data) => socket.emit(event, data);
      socket.emit('operation:started', { module: moduleName, action: 'disable' });
      await modules.disableStreaming(OB_ROOT, moduleName, emitFn);
    } catch (err) {
      socket.emit('operation:error', { module: moduleName, error: err.message });
    }
    releaseOperationLock();
  });

  // Batch module install/remove with live streaming output.
  // Mirrors /api/modules/batch but pipes stdout/stderr back to the browser
  // via Socket.IO so the user sees every line of `openbox up` output.
  socket.on('modules:install-stream', async (payload) => {
    const { enable = [], disable = [] } = payload || {};
    if (!Array.isArray(enable) || !Array.isArray(disable)) {
      socket.emit('install:error', { error: 'Invalid payload.' });
      return;
    }
    if (enable.length === 0 && disable.length === 0) {
      socket.emit('install:error', { error: 'Nothing to apply.' });
      return;
    }
    if (!enable.every(isValidName) || !disable.every(isValidName)) {
      socket.emit('install:error', { error: 'Invalid module name.' });
      return;
    }
    // v1.6.49: setup wizard's `Get started` fires /api/setup/complete
    // which spawns a detached `openbox up` for the chosen profile and
    // holds the operation lock until that detached process finishes
    // (~30-60s for an essentials-profile no-op recreate). If the user
    // clicks Apply on Media inside that window — which is exactly the
    // tutorial / video flow — they hit a flat "Another operation is
    // already running" error and have to refresh + try again. Instead,
    // wait politely for the lock to release and surface progress to the
    // live install log so the user sees what's happening.
    {
      socket.emit('install:started', { enable, disable });
      const acquireDeadline = Date.now() + 90 * 1000;
      let acquired = false;
      let waitedOnce = false;
      while (Date.now() < acquireDeadline) {
        if (acquireOperationLock('modules-install')) { acquired = true; break; }
        if (!waitedOnce) {
          socket.emit('install:line', {
            line: '[OpenBox] Waiting for the previous operation (setup wizard) to finish before installing media...',
            stream: 'stdout',
          });
          waitedOnce = true;
        }
        await new Promise(r => setTimeout(r, 4000));
      }
      if (!acquired) {
        socket.emit('install:error', {
          error: 'A previous operation is still running after 90 seconds. Try again in a moment.',
        });
        return;
      }
      if (waitedOnce) {
        socket.emit('install:line', { line: '[OpenBox] Previous operation finished; starting media install.', stream: 'stdout' });
      }
    }

    try {
      // Mirror the REST /api/modules/batch gate. Free-personal-use: skip marker counts.
      if (!isLicensedOrSkipped()) {
        socket.emit('install:error', {
          error: 'license_required',
          message: 'This action needs an activated license. Free for personal use — activate from Settings → License.',
        });
        releaseOperationLock();
        return;
      }

      // VPN-gated modules (Media) need a configured VPN provider before
      // enable — otherwise gluetun never gets healthy and the *arr stack
      // silently stays in Created state. Matches the REST pre-flight on
      // /api/modules/:name/enable.
      const vpnGatedInEnable = enable.filter(m => VPN_REQUIRED_MODULES.has(m));
      if (vpnGatedInEnable.length > 0 && !(await isVpnConfigured())) {
        socket.emit('install:error', {
          error: 'vpn_required',
          vpn_required: true,
          modules: vpnGatedInEnable,
          message: `The ${vpnGatedInEnable.join(', ')} module${vpnGatedInEnable.length === 1 ? '' : 's'} route through a VPN tunnel. Configure your VPN provider first in Settings → VPN.`,
          configure_url: '/settings#vpn',
        });
        releaseOperationLock();
        return;
      }

      // v1.6.49: install:started already emitted above before lock-wait.

      // Apply the diff first (writes modules.conf, stops removed containers).
      await modules.batchUpdate(OB_ROOT, { enable, disable });

      // Now run `openbox up` with stdio piped so we can stream it.
      // v1.6.46 also passed --force-recreate, but that recreated all
      // enabled modules including the dashboard itself (ob-dashboard),
      // killing the in-progress streaming install. Reverted: the real
      // root cause for "VPN city not applying" was not a recreate gap
      // but cmd_up's unset list missing SERVER_CITIES — see v1.6.47.
      const { spawn: sp } = require('child_process');
      const proc = sp('bash', ['-c', `${OB_ROOT}/openbox up`], {
        cwd: OB_ROOT,
        env: { ...process.env, OB_ROOT, OB_SKIP_LOCK: '1' },
      });

      const emitLines = (buf, stream) => {
        buf.toString().split('\n').forEach(line => {
          if (line.trim().length) socket.emit('install:line', { line, stream });
        });
      };
      proc.stdout.on('data', (d) => emitLines(d, 'stdout'));
      proc.stderr.on('data', (d) => emitLines(d, 'stderr'));

      proc.on('close', (code) => {
        socket.emit('install:done', { success: code === 0, code });
        // If Media was just enabled, invalidate the VPN status probe
        // cache. Media install brings up gluetun + qBit + new public IPs,
        // and pre-VPN-handshake probes may have left poisoned cache
        // entries (host IP showing as gluetun IP). Without this, the
        // VPN banner shows red leak warnings for up to 5 minutes after
        // a successful Media install — Tom hit this on 2026-05-04.
        if (code === 0 && enable.includes('media')) {
          if (vpnStatus && typeof vpnStatus.invalidateCache === 'function') {
            vpnStatus.invalidateCache();
            log('INFO', 'Media enabled — invalidated VPN status cache');
          }
        }
        releaseOperationLock();
      });
      proc.on('error', (err) => {
        socket.emit('install:error', { error: err.message });
        releaseOperationLock();
      });
    } catch (err) {
      log('ERROR', 'Streaming install failed', err);
      socket.emit('install:error', { error: err.message || 'Install failed.' });
      releaseOperationLock();
    }
  });

  // Update all services via streaming
  socket.on('system:update', async () => {
    // Match the REST endpoint's requireLicense — this socket handler
    // was unguarded (Codex P0). An unlicensed user emitting this could
    // force a openbox-update on the host; malicious releases could
    // brick the NAS.
    if (!license.hasValidLicense()) {
      socket.emit('operation:error', { error: 'license_required' });
      return;
    }
    if (!acquireOperationLock('system-update')) {
      socket.emit('operation:busy', { message: 'Another operation is in progress.' });
      return;
    }
    try {
      const emitFn = (event, data) => socket.emit(event, data);
      socket.emit('operation:started', { module: 'system', action: 'update' });
      const { spawn: sp } = require('child_process');
      const proc = sp('bash', ['-c', `${OB_ROOT}/openbox update`], { cwd: OB_ROOT, env: { ...process.env, OB_ROOT, OB_SKIP_LOCK: '1' } });
      proc.stdout.on('data', (data) => {
        data.toString().split('\n').filter(Boolean).forEach(line => {
          emitFn('operation:progress', { operationId: 'update', line, stream: 'stdout' });
        });
      });
      proc.stderr.on('data', (data) => {
        data.toString().split('\n').filter(Boolean).forEach(line => {
          emitFn('operation:progress', { operationId: 'update', line, stream: 'stderr' });
        });
      });
      proc.on('close', (code) => {
        emitFn('operation:complete', { operationId: 'update', success: code === 0 });
        releaseOperationLock();
      });
    } catch (err) {
      socket.emit('operation:error', { module: 'system', error: err.message });
      releaseOperationLock();
    }
  });

  // Update operations via streaming. Auto-updates require a valid
  // license (any tier) so the worker can revoke abusers.
  socket.on('updates:check', async () => {
    if (!license.hasValidLicense()) {
      socket.emit('updates:error', { error: 'License required. Activate to unlock auto-updates.' });
      return;
    }
    if (!acquireOperationLock('updates-check')) {
      socket.emit('operation:busy', { message: 'Another operation is in progress.' });
      return;
    }
    try {
      const emitFn = (event, data) => socket.emit(event, data);
      socket.emit('operation:started', { module: 'updates', action: 'check' });
      const available = await updates.checkForUpdates(OB_ROOT, emitFn);
      socket.emit('updates:check-complete', { available });
      socket.emit('operation:complete', { operationId: 'updates-check', success: true });
    } catch (err) {
      socket.emit('updates:error', { error: err.message });
      socket.emit('operation:complete', { operationId: 'updates-check', success: false });
    }
    releaseOperationLock();
  });

  socket.on('updates:apply', async (data) => {
    const moduleId = (data && data.module) || 'all';
    if (!license.hasValidLicense()) {
      socket.emit('updates:error', { error: 'License required. Activate to unlock auto-updates.' });
      return;
    }
    if (!acquireOperationLock('updates-apply')) {
      socket.emit('operation:busy', { message: 'Another operation is in progress.' });
      return;
    }
    try {
      const emitFn = (event, data) => socket.emit(event, data);
      socket.emit('operation:started', { module: moduleId, action: 'update' });
      const result = await updates.performUpdate(OB_ROOT, moduleId, emitFn);
      socket.emit('updates:apply-complete', result);
      socket.emit('operation:complete', { operationId: 'updates-apply', success: result.success });
    } catch (err) {
      socket.emit('updates:error', { error: err.message });
      socket.emit('operation:complete', { operationId: 'updates-apply', success: false });
    }
    releaseOperationLock();
  });

  // AI Troubleshooting streaming (Pro / Ultimate)
  socket.on('chat:send', async ({ sessionId, message }) => {
    if (!license.isPro()) {
      socket.emit('chat:error', { error: 'AI Troubleshooting requires a valid license. Activate from Settings → License.' });
      return;
    }
    if (!(await chat.isChatAvailable(OB_ROOT))) {
      socket.emit('chat:error', { error: 'AI Troubleshooting is disabled in Settings or requires a valid license.' });
      return;
    }
    try {
      const emitToken = (token) => socket.emit('chat:token', { sessionId, token });
      socket.emit('chat:start', { sessionId });
      const response = await chat.sendMessage(OB_ROOT, sessionId, message, emitToken);
      socket.emit('chat:done', { sessionId, response });
    } catch (err) {
      socket.emit('chat:error', { error: err.message || 'Chat failed.' });
    }
  });

  socket.on('chat:session', () => {
    if (!license.isPro()) {
      socket.emit('chat:error', { error: 'AI Troubleshooting requires a valid license. Activate from Settings → License.' });
      return;
    }
    const sessionId = chat.createSession();
    socket.emit('chat:session-created', { sessionId });
  });

  // Log streaming - limit to one subscription at a time
  let activeLogStream = null;
  socket.on('logs:subscribe', async (containerId) => {
    // Clean up previous stream
    if (activeLogStream) { activeLogStream.destroy(); activeLogStream = null; }
    // Codex 2026-04-24 round 2 finding #1: validate the container is
    // actually a OpenBox-managed one. Without this, any authenticated
    // user could logs:subscribe to any container on the Docker socket
    // — including the host's own workloads if the socket is shared —
    // and receive whatever secrets those containers print. REST callers
    // (startContainer, stopContainer, etc.) already gate on
    // validateOpenBoxContainer; mirror that here.
    try {
      const ok = await docker.validateOpenBoxContainer(containerId);
      if (!ok) {
        socket.emit('logs:error', { containerId, error: 'Container not managed by OpenBox.' });
        return;
      }
    } catch {
      socket.emit('logs:error', { containerId, error: 'Container lookup failed.' });
      return;
    }
    try {
      const stream = await docker.streamLogs(containerId);
      activeLogStream = stream;
      // Codex round 6 #8: a chatty container (Jellyfin streaming,
      // qBittorrent torrent churn) can emit hundreds of log lines
      // per second. Emitting a socket message per line jankifies
      // the browser's main thread (every message fires a JS event +
      // a DOM append). Batch every 100ms and emit one logs:batch
      // event with an array of lines. Client concats once, appends
      // once. Also enforces a per-flush byte cap so a runaway
      // container can't grow the batch unboundedly.
      let pending = [];
      let pendingBytes = 0;
      let flushTimer = null;
      const MAX_BATCH_BYTES = 32 * 1024;
      const FLUSH_MS = 100;
      const flush = () => {
        if (pending.length === 0) return;
        const lines = pending;
        pending = [];
        pendingBytes = 0;
        socket.emit('logs:data', { containerId, line: lines.join('') });
      };
      const handler = (data) => {
        const text = data.toString('utf8').replace(/[\x00-\x08]/g, '');
        pending.push(text);
        pendingBytes += text.length;
        if (pendingBytes >= MAX_BATCH_BYTES) {
          if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }
          flush();
        } else if (!flushTimer) {
          flushTimer = setTimeout(() => { flushTimer = null; flush(); }, FLUSH_MS);
        }
      };
      stream.on('data', handler);
      const cleanup = () => {
        if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }
        flush(); // drain before tearing down
        stream.destroy();
        activeLogStream = null;
      };
      socket.on('logs:unsubscribe', cleanup);
      socket.on('disconnect', cleanup);
    } catch (err) {
      socket.emit('logs:error', { containerId, error: 'Failed to stream logs.' });
    }
  });

  // Container state — push, not poll. Subscribes to the shared
  // state-store (which is fed by Docker /events), fans snapshot +
  // deltas to this socket, tears down on disconnect.
  //
  // Backward compat: we still emit status:update with a full array
  // on every change so existing 1.1.x clients keep working during
  // the 1.2 rollout. New clients should listen to state:snapshot +
  // state:delta and reduce locally.
  // Codex round 6 #10: previously every state change fired both
  // state:delta AND a full status:update snapshot to every subscriber.
  // On a 38-container install with N tabs open, that's 38 containers
  // × N tabs × every change twice = a lot of bytes for no reason.
  // Clients that subscribed via the legacy status:subscribe name
  // still get the full snapshots (compat); clients that used the
  // new state:subscribe only get state:delta. A legacy flag is set
  // per-socket on subscribe.
  let stateUnsub = null;
  let sendLegacySnapshots = false;
  const subscribeState = (isLegacy) => {
    if (isLegacy) sendLegacySnapshots = true;
    if (stateUnsub) return;
    stateUnsub = stateStore.subscribe((delta) => {
      if (delta.type === 'snapshot') {
        socket.emit('state:snapshot', delta.containers);
        if (sendLegacySnapshots) {
          socket.emit('status:update', delta.containers);
        }
      } else {
        socket.emit('state:delta', delta);
        if (sendLegacySnapshots) {
          socket.emit('status:update', stateStore.getSnapshot());
        }
      }
    });
  };
  socket.on('status:subscribe', () => subscribeState(true));   // legacy 1.1.x client
  socket.on('state:subscribe', () => subscribeState(false));   // modern client

  // Host stats — push from a shared sampler that only runs while
  // at least one client is subscribed. Tears down globally when the
  // last subscriber disconnects.
  let hostUnsub = null;
  const subscribeHost = () => {
    if (hostUnsub) return;
    hostUnsub = hostMetrics.subscribe((stats) => {
      socket.emit('hoststats:update', stats);
      socket.emit('host:state', stats); // new name
    });
  };
  socket.on('hoststats:subscribe', subscribeHost);
  socket.on('host:subscribe', subscribeHost);

  // Per-container streaming stats. Client sends stats:subscribe with
  // an array of container ids (only the cards currently visible on
  // screen). Each id gets one shared Docker stream regardless of how
  // many clients are watching it. Unsubscribe on visibilitychange.
  const statsUnsubs = new Map(); // id -> unsubscribe fn
  // Cap concurrent subscriptions per socket. Codex round 3 finding #4:
  // an authenticated user could emit an unbounded ids array and open
  // a stats stream per container on the Docker socket, including
  // non-OpenBox workloads. Require sb-* naming and cap at 50 (more
  // than the visible cards even on a maximized dashboard).
  const MAX_STATS_SUBSCRIPTIONS = 50;
  socket.on('stats:subscribe', (ids) => {
    if (!Array.isArray(ids)) return;
    let accepted = 0;
    for (const id of ids) {
      if (typeof id !== 'string') continue;
      if (!/^sb-[a-z0-9][a-z0-9_-]{0,63}$/.test(id)) continue;
      if (statsUnsubs.has(id)) continue;
      if (statsUnsubs.size >= MAX_STATS_SUBSCRIPTIONS) break;
      const unsub = statsStream.subscribe(id, (containerId, stats) => {
        socket.emit('stats:update', { id: containerId, ...stats });
      });
      statsUnsubs.set(id, unsub);
      accepted += 1;
    }
    if (accepted === 0 && ids.length > 0) {
      socket.emit('stats:error', { error: 'No valid OpenBox containers in subscription list.' });
    }
  });
  socket.on('stats:unsubscribe', (ids) => {
    if (!Array.isArray(ids)) return;
    for (const id of ids) {
      const unsub = statsUnsubs.get(id);
      if (unsub) { unsub(); statsUnsubs.delete(id); }
    }
  });
  socket.on('stats:unsubscribe-all', () => {
    for (const unsub of statsUnsubs.values()) unsub();
    statsUnsubs.clear();
  });

  socket.on('disconnect', () => {
    if (stateUnsub) { stateUnsub(); stateUnsub = null; }
    if (hostUnsub) { hostUnsub(); hostUnsub = null; }
    for (const unsub of statsUnsubs.values()) unsub();
    statsUnsubs.clear();
    if (activeLogStream) { activeLogStream.destroy(); activeLogStream = null; }
  });
});

// Recover from an interrupted self-update swap before doing anything
// else. If the dashboard crashed between `rename(sbRoot, rollbackRoot)`
// and `rename(stagedRoot, sbRoot)`, the parent dir has a
// `openbox.rollback-*` but no sbRoot. This restores the rollback copy
// so the install is usable on the next boot. Called synchronously at
// startup — no requests can land before it finishes.
(async () => {
  try {
    const result = await selfUpdate.recoverInterruptedSwap(OB_ROOT);
    if (result.recovered) {
      log('INFO', `self-update recovery: restored from ${result.from}`);
    }
  } catch (err) {
    log('ERROR', 'self-update recovery check failed', err);
  }
})();

// Boot the state store so it starts listening to /events immediately,
// before any client connects. getSnapshot() is populated by the time
// the first subscribe comes in.
stateStore.init().catch((err) => {
  log('ERROR', 'state-store init failed', err);
});

// --- Migration Routes (Pro Feature) ---

app.get('/api/migrate/info', requireAuth, requirePro, async (req, res) => {
  try {
    const info = await migrate.getMigrationInfo(OB_ROOT);
    res.json(info);
  } catch (err) {
    res.status(500).json({ error: 'Failed to get migration info.' });
  }
});

app.get('/api/migrate/export', requireAuth, requirePro, requireRecentReauth(), async (req, res) => {
  try {
    const bundle = await migrate.exportBundle(OB_ROOT);
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', 'attachment; filename="openbox-migration.json"');
    res.json(bundle);
  } catch (err) {
    log('ERROR', 'Migration export failed', err);
    res.status(500).json({ error: 'Failed to export migration bundle.' });
  }
});

app.post('/api/migrate/import', requireAuth, requirePro, requireRecentReauth(), async (req, res) => {
  try {
    const bundle = req.body;
    if (!bundle || !bundle.version) {
      return res.status(400).json({ error: 'Invalid migration bundle.' });
    }
    const results = await migrate.importBundle(OB_ROOT, bundle);
    if (results && results.error) {
      return res.status(400).json({ error: results.error });
    }
    res.json({ success: true, ...results });
  } catch (err) {
    log('ERROR', 'Migration import failed', err);
    res.status(500).json({ error: 'Failed to import migration bundle.' });
  }
});

// --- OpenBox Self-Update (Pro Feature) ---

// One-shot endpoint: returns the last-upgrade flag and DELETES it.
// Set by the helper container after a successful self-update upgrade.
// The dashboard's frontend hits this on login and shows a welcome
// modal summarizing what's new in the new version.
app.get('/api/last-upgrade', requireAuth, async (req, res) => {
  const fsp = require('fs').promises;
  const flagPath = path.join(OB_ROOT, 'state', 'last-upgrade.json');
  try {
    const raw = await fsp.readFile(flagPath, 'utf8');
    const data = JSON.parse(raw);
    // Delete after read so the modal only shows once.
    await fsp.unlink(flagPath).catch(() => {});
    res.json(data);
  } catch {
    res.json({ none: true });
  }
});

// Read the user's chosen update channel from .env — defaults to
// 'stable'. Set 'canary' to get early access to releases ~3 days
// before they promote to stable. Opt-in via Settings → Updates.
async function readUpdateChannel() {
  try {
    const cfg = await config.read(OB_ROOT);
    const v = String(cfg.OB_UPDATE_CHANNEL || '').toLowerCase().trim();
    if (v === 'canary') return 'canary';
  } catch {}
  return 'stable';
}

app.get('/api/self-update/check', requireAuth, async (req, res) => {
  try {
    const channel = await readUpdateChannel();
    const result = await selfUpdate.checkForUpdate(OB_ROOT, { canary: channel === 'canary' });
    res.json({ ...result, channel });
  } catch (err) {
    log('ERROR', 'Self-update check failed', err);
    res.status(500).json({ error: 'Failed to check for OpenBox updates.' });
  }
});

// v1.6.54: free users can manually install Core updates. The actual
// self-update flow pulls from the public CDN (get.crushcodeworks.com)
// and verifies the baked ed25519 signature — no worker validation
// needed. requirePro was a pre-v1.6.3-pivot paid-tier gate. Pro tier
// still gets auto-updates / scheduling / rollback (those routes are
// /api/update + /api/updates/* and stay requireWorkerKey'd). Manual
// click-to-update goes free, gated on requireLicense (skip-marker-
// aware) so the user just needs the install completed, not an
// activated license. requireRecentReauth() stays — overwriting your
// OpenBox install IS destructive enough to warrant a fresh prompt.
// v1.6.55: dropped requireRecentReauth() here. Same reasoning as
// v1.6.53's drop on Settings saves — for a single-operator home NAS
// the friction outweighs the defense. The update path is already
// belt-and-suspenders gated: requireAuth (active session) + the
// confirm modal in the UI + signature verification (ed25519 against
// the baked public key) + selfUpdateApplyLimiter (rate limit). A
// password prompt on top of all of that just makes Tom retype his
// password every time he clicks Update.
app.post('/api/self-update/apply', requireAuth, requireLicense, requireRecentReauthIfPublic(), selfUpdateApplyLimiter, async (req, res) => {
  log('INFO', 'Self-update apply requested');
  if (!acquireOperationLock('self-update')) {
    log('WARN', 'Self-update apply rejected: operation lock busy');
    return res.status(409).json({ error: 'Another operation is already running. Please wait.' });
  }
  try {
    // Emit a synthetic kickoff event so the client log isn't empty even
    // if the first real progress event from performSelfUpdate is delayed.
    io.emit('self-update:progress', { step: 'Self-update started — checking for new release...' });
    const channel = await readUpdateChannel();
    const result = await selfUpdate.performSelfUpdate(OB_ROOT, (event, data) => {
      io.emit(event, data);
    }, { canary: channel === 'canary' });
    log('INFO', `Self-update result: ${JSON.stringify({ ok: result.success, msg: result.message, from: result.fromVersion, to: result.toVersion, blocked: result.blocked })}`);
    // Structured blockers (e.g. too-old stepped-upgrade path, Codex P2)
    // are not 500s — they're expected outcomes the UI renders as a CTA.
    // 409 gets the apply button to stop spinning AND lets the dashboard
    // distinguish "genuinely failed" from "you have a pre-req to do".
    if (result && result.success === false && result.blocked) {
      return res.status(409).json(result);
    }
    res.json(result);
  } catch (err) {
    // Codex round 5: don't leak raw err.message to the client — it can
    // expose host paths, internal command output, or node stack trace
    // fragments. The progress log still shows the raw message so the
    // user has a forensic trail.
    log('ERROR', 'Self-update failed', err);
    io.emit('self-update:progress', { step: `ERROR: ${err.message || 'Self-update failed.'}` });
    res.status(500).json({ error: 'OpenBox could not install the update. Your current install was left in place. Try again; if it repeats, open Settings → Updates and try the stepped update option.' });
  } finally {
    releaseOperationLock();
  }
});

// --- Remote Access Routes (Pro Feature) ---

app.get('/api/remote-access', requireAuth, requirePro, async (req, res) => {
  try {
    const result = await remoteAccess.getAccessMethods(OB_ROOT);
    res.json(result);
  } catch (err) {
    log('ERROR', 'Failed to get remote access info', err);
    res.status(500).json({ error: 'Failed to get remote access information.' });
  }
});

// Live VPN health for the Media Center. Pulls public-IP lookups from
// inside ob-gluetun and ob-qbittorrent so users can verify the tunnel
// is actually routing their download traffic — the single highest-stakes
// check for anyone using the *arr stack.
app.get('/api/vpn/status', requireAuth, async (req, res) => {
  try {
    const status = await vpnStatus.getStatus(OB_ROOT);
    res.json(status);
  } catch (err) {
    log('ERROR', 'Failed to query VPN status', err);
    res.status(500).json({ error: err.message || 'Failed to query VPN status.' });
  }
});

app.post('/api/remote-access/wireguard/client', requireAuth, requirePro, requireRecentReauth(), async (req, res) => {
  try {
    const result = await remoteAccess.generateWireGuardConfig(OB_ROOT);
    res.json(result);
  } catch (err) {
    // Codex round 5: don't leak wg-easy internals to the client.
    log('ERROR', 'Failed to create WireGuard client', err);
    res.status(503).json({ error: 'OpenBox could not create a new WireGuard client. Make sure the WireGuard app is enabled and healthy (Settings → Apps), then try again.' });
  }
});

app.get('/api/remote-access/tailscale/status', requireAuth, requirePro, async (req, res) => {
  try {
    const status = await remoteAccess.getTailscaleStatus(OB_ROOT);
    res.json(status);
  } catch (err) {
    log('ERROR', 'Failed to get Tailscale status', err);
    res.status(500).json({ error: 'Failed to get Tailscale status.' });
  }
});

// --- Domain Wizard Routes (Pro Feature) ---

// 2026-05-11 (v1.6.94): switched from requirePro (worker-validated
// license required) to requireLicense (license OR skip-marker OK).
// Domain wizard talks to local NPM only — no license worker call
// involved, so the strict gate was wrong from the v1.6.3 free pivot.
// Reported by GamerX06 #9519: clicked "DNS is ready, continue" in
// the Custom Domain modal and got "This action requires an
// activated license" — same shape as the v1.6.51 theme-picker bug.
app.get('/api/domains', requireAuth, requireLicense, async (req, res) => {
  try {
    const token = await domainWizard.getNpmToken(OB_ROOT);
    const hosts = await domainWizard.listProxyHosts(token);
    res.json(hosts);
  } catch (err) {
    // Codex round 5: don't leak NPM credential / network errors.
    log('ERROR', 'Failed to list proxy hosts', err);
    res.status(503).json({ error: "OpenBox can't read your domain entries. Make sure Nginx Proxy Manager is enabled and healthy, then check its admin email and password in Settings → Apps → NPM." });
  }
});

app.get('/api/domains/suggestions', requireAuth, requireLicense, async (req, res) => {
  try {
    const baseDomain = req.query.domain;
    if (!baseDomain) {
      return res.status(400).json({ error: 'Base domain is required. Pass ?domain=example.com' });
    }
    const suggestions = await domainWizard.suggestSubdomains(OB_ROOT, baseDomain);
    res.json(suggestions);
  } catch (err) {
    log('ERROR', 'Failed to get domain suggestions', err);
    res.status(500).json({ error: 'Failed to get domain suggestions.' });
  }
});

app.post('/api/domains/setup', requireAuth, requireLicense, requireRecentReauth(), async (req, res) => {
  const { domain, service, ssl } = req.body;
  if (!domain || !service) {
    return res.status(400).json({ error: 'Domain and service are required.' });
  }

  try {
    const token = await domainWizard.getNpmToken(OB_ROOT);

    // Look up the service in our subdomain map to get container and port
    const services = await domainWizard.getServicePorts(OB_ROOT);
    const svc = services.find(s => s.id === service);
    if (!svc) {
      return res.status(400).json({ error: `Unknown service: ${service}` });
    }

    const result = await domainWizard.createProxyHost(
      token,
      domain,
      svc.container,
      svc.port,
      ssl !== false
    );

    res.json({
      success: true,
      proxyHost: {
        id: result.id,
        domain,
        forwardHost: svc.container,
        forwardPort: svc.port,
        ssl: ssl !== false,
      }
    });
  } catch (err) {
    // Codex round 5: distinguish user-recoverable causes from server
    // faults, and don't leak NPM internals to the client.
    log('ERROR', 'Failed to set up domain', err);
    const msg = String(err && err.message || '').toLowerCase();
    if (msg.includes('already exists') || msg.includes('duplicate')) {
      return res.status(409).json({ error: `"${domain}" is already set up in Nginx Proxy Manager. Edit the existing entry or pick a different domain.` });
    }
    if (msg.includes('invalid') || msg.includes('malformed')) {
      return res.status(400).json({ error: `"${domain}" is not a valid domain. Use the format app.example.com and try again.` });
    }
    res.status(502).json({ error: `OpenBox couldn't add "${domain}". Make sure Nginx Proxy Manager is running, DNS for the domain points to this server, then try again.` });
  }
});

// --- SPA Fallback ---

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// --- Start ---

// Detect env-forwarding drift: any SB_* key that appears in the on-disk
// .env but is missing/empty in process.env. The dashboard container
// bind-mounts the host .env at /app/.env, but server.js does not call
// dotenv.config() — so the only way a var reaches process.env is if
// modules/dashboard/docker-compose.yml forwards it explicitly. When the
// two files drift (new var added to install.sh's .env heredoc without
// a matching line in the compose environment block), reads return
// undefined and features silently no-op. The 1.3.4 bootstrap-token
// bug was exactly this pattern. This check logs a WARN at startup for
// each drifted key so the next incident shows up in `docker logs
// ob-dashboard` instead of waiting for a user to click a broken flow.
function checkEnvForwardingDrift() {
  try {
    const envPath = path.join(OB_ROOT, '.env');
    if (!fsSync.existsSync(envPath)) return;
    const content = fsSync.readFileSync(envPath, 'utf8');
    const drifted = [];
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*(SB_[A-Z0-9_]+)\s*=\s*(.+?)\s*$/);
      if (!m) continue;
      const key = m[1];
      const envValue = m[2].replace(/^['"]|['"]$/g, '');
      // A key with an empty value in .env is just "unset" — not drift.
      if (!envValue) continue;
      // Drift is when .env has a non-empty value but process.env doesn't.
      if (!process.env[key]) {
        drifted.push(key);
      }
    }
    if (drifted.length > 0) {
      log('WARN', `Env-forwarding drift detected — these SB_* vars are set in ${envPath} but NOT visible in process.env:`);
      for (const key of drifted) {
        log('WARN', `  - ${key} (add to modules/dashboard/docker-compose.yml's environment block)`);
      }
      log('WARN', 'Features that read these vars will silently no-op until fixed.');
    }
  } catch (err) {
    log('WARN', `Env-drift check failed: ${err.message}`);
  }
}

// v1.5.29 pentest finding: v1.5.28 fixed atomic-write.js to create new
// state files at 0o600, but applyExistingMetadata preserves prior mode
// on subsequent writes — so files created before v1.5.28 stay
// world-readable forever. One-shot startup fixup: walk state/*.json
// (and a few known non-.json sensitive files) and chmod 0o600 when
// group/other have ANY bits set. Logs each file it fixes so the
// operator sees the migration happen.
function migrateStatePermissions() {
  try {
    const stateDir = path.join(OB_ROOT, 'state');
    const entries = require('fs').readdirSync(stateDir);
    // Any regular file directly in state/ — these are all written by the
    // dashboard and may carry secrets (license key, session fingerprints,
    // wizard logs that echo .env values, etc.). Directories (sessions/,
    // chat-sessions/, knowledge/) are walked one level deep too.
    let fixed = 0;
    for (const name of entries) {
      const full = path.join(stateDir, name);
      let stat;
      try { stat = require('fs').statSync(full); } catch { continue; }
      if (!stat.isFile()) continue;
      const mode = stat.mode & 0o777;
      if ((mode & 0o077) === 0) continue; // already locked down
      try {
        require('fs').chmodSync(full, 0o600);
        fixed++;
        log('INFO', `[perms] migrated ${name} from ${mode.toString(8)} to 600`);
      } catch (err) {
        log('WARN', `[perms] could not chmod ${name}: ${err.message}`);
      }
    }
    if (fixed > 0) log('INFO', `[perms] state/ permission migration: ${fixed} file(s) locked to 0600`);
  } catch (err) {
    log('WARN', `[perms] migration skipped: ${err.message}`);
  }
}

server.listen(PORT, '0.0.0.0', () => {
  log('INFO', `OpenBox Dashboard running on port ${PORT}`);
  log('INFO', `OB_ROOT: ${OB_ROOT}`);
  log('INFO', `License tier (cached): ${license.getTier()}`);

  // Codex round 6 #2: defer background schedulers via setImmediate
  // so the first customer request doesn't compete with boot-time
  // work (permission migrations, license remote-refresh, alerts
  // init, etc.). The listener is ready to answer requests NOW;
  // these housekeeping tasks fire on the next tick.
  setImmediate(() => {
    migrateStatePermissions();
    checkEnvForwardingDrift();
  });

  // Detect an interrupted backup restore. If state/restore.lock
  // exists, the previous dashboard process died mid-swap and the
  // install may be in an inconsistent state. Log LOUDLY so the
  // operator sees it. v1.5.71 fix for Claude-review finding #5.
  backup.checkForInterruptedRestore(OB_ROOT).then(res => {
    if (res.interrupted) {
      log('WARN', '========================================');
      log('WARN', 'INTERRUPTED BACKUP RESTORE DETECTED');
      log('WARN', `A prior restore was in progress: ${JSON.stringify(res.details)}`);
      log('WARN', 'Review state/restore.lock, check sbRoot is intact, then delete the lock to acknowledge.');
      log('WARN', '========================================');
    }
  }).catch(() => {});

  // Sweep stale restore artifacts (.restore-snapshot-*, .restore-rollback-*,
  // .restore-staging-*) older than 7 days. These were leaking on every
  // restore — UGREEN's 19GB root partition runs out of space after a
  // few cycles. Caught by the 2026-05-04 full-app audit when the
  // dashboard crashed with ENOSPC mid-test.
  backup.cleanupOldRestoreArtifacts(OB_ROOT, 7).catch(() => {});

  // Refresh the license cache against the server on startup so a key
  // revoked (or newly activated) since the last check gets picked up.
  // Best-effort — the cached value keeps working if the network is down.
  //
  // Also schedule a background re-check every 5 minutes. Without this,
  // the dashboard's 1-hour local cache kept refunded keys "valid" for
  // up to an hour after the webhook flipped them to revoked, letting
  // a refunded user enjoy Pro features (AI chat, updates) for up to
  // 60 minutes past cancellation. Claude-review finding #4. force:true
  // bypasses the cache for this specific call — regular callers still
  // use the cached value so this doesn't blow up quota.
  if (process.env.OB_LICENSE_KEY) {
    const refreshLicenseCache = () => license
      .validateKeyRemote(process.env.OB_LICENSE_KEY, OB_ROOT, { force: true })
      .then(v => {
        // Bust the process-local hasValidLicense() cache so the next
        // call observes the refreshed state immediately (v1.5.100).
        license.invalidateLicenseCache();
        log('INFO', `License cache refreshed: ${v.valid ? 'licensed (Pro)' : 'unlicensed'}${v.revoked ? ' REVOKED' : ''}${v.stale ? ' (stale fallback)' : ''}`);
      })
      .catch(err => log('WARN', `License refresh failed: ${err.message}`));
    // Initial remote check fires after a short delay so it doesn't
    // race the first dashboard request on boot. The cached value is
    // correct for steady-state usage; this re-check only catches
    // revocations or new activations since the last boot.
    setTimeout(refreshLicenseCache, 3000).unref();
    setInterval(refreshLicenseCache, 5 * 60 * 1000).unref();
  }
  log('INFO', `Backup encryption: ${process.env.OB_BACKUP_KEY ? 'dedicated key' : process.env.OB_SESSION_SECRET ? 'session secret' : 'disabled'}`);

  // Initialize update scheduler (Pro feature)
  scheduler.init(OB_ROOT, io, () => activeOperation).catch(err => {
    log('ERROR', 'Failed to initialize scheduler', err);
  });

  // Initialize backup scheduler (Pro feature)
  backup.initScheduler(OB_ROOT).catch(err => {
    log('ERROR', 'Failed to initialize backup scheduler', err);
  });

  // Initialize service health alerts monitor (Pro feature)
  alerts.init(OB_ROOT, io).catch(err => {
    log('ERROR', 'Failed to initialize alerts monitor', err);
  });

  // Initialize weekly health report generator (Pro feature)
  healthReport.init(OB_ROOT).catch(err => {
    log('ERROR', 'Failed to initialize health reports', err);
  });

  // Initialize AI Troubleshooting knowledge base and mining agent
  chat.initChat(OB_ROOT).catch(err => {
    log('ERROR', 'Failed to initialize chat', err);
  });
  knowledgeMiner.init(OB_ROOT).catch(err => {
    log('ERROR', 'Failed to initialize knowledge miner', err);
  });

  // Telemetry — opt-in error reporting. init() creates the install_id
  // file + loads the on-disk settings; report() is a no-op when the
  // toggle is off, so wiring the process.on hooks is always safe.
  telemetry.init(OB_ROOT).catch(err => {
    log('ERROR', 'Failed to initialize telemetry', err);
  });

  // uncaughtException / unhandledRejection — best-effort report THEN
  // continue. We intentionally do NOT exit the process on these
  // because the dashboard's many cron jobs and socket handlers can
  // throw without the whole UI being unrecoverable. Express's per-
  // request error handler already protects the request lifecycle;
  // these hooks catch escapes from setImmediate / setTimeout / event
  // emitters where Express can't reach.
  process.on('uncaughtException', (err) => {
    log('ERROR', 'uncaughtException', err);
    telemetry.reportException(err).catch(() => {});
  });
  process.on('unhandledRejection', (reason) => {
    const err = reason instanceof Error ? reason : new Error(String(reason));
    log('ERROR', 'unhandledRejection', err);
    telemetry.reportException(err).catch(() => {});
  });
});
