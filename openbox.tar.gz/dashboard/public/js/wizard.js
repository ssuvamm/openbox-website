// First-time interactive tutorial.
//
// Walks the user through the actual dashboard UI — spotlights real
// elements, waits for them to click the right one, advances. Unlike
// a config wizard, it never blocks the app: the overlay is
// pointer-events: none so clicks pass through to the real page.
//
// The tooltip (with Skip / Next) is the only part that captures input.
// Tutorial state is persisted via state/wizard.json on the server so
// it doesn't auto-open after completion or skip.

(function () {
  const STEPS = [
    {
      id: 'welcome',
      kind: 'modal',
      title: 'Welcome to OpenBox',
      body: "You just spun up your own server. Let's take a 90-second tour so you know where everything is.",
    },
    {
      id: 'home',
      kind: 'spotlight',
      target: '.bento-system',
      placement: 'left',
      title: 'This is your home page',
      body: 'The gauges show live CPU, RAM, disk, and uptime. The quick actions below let you restart everything, jump into Portainer, or check Updates and Logs.',
    },
    {
      id: 'running',
      kind: 'spotlight',
      target: '.bento-card .running-list, #running-list',
      placement: 'top',
      title: 'Your running apps',
      body: 'Every container OpenBox manages lives here with its live status, CPU, and memory. Pause, restart, or view logs with one click.',
    },
    {
      id: 'nav-apps',
      kind: 'spotlight',
      target: 'a[data-page="apps"]',
      placement: 'bottom',
      title: 'The App Store',
      body: 'Go click Apps in the nav now — that\'s where you turn features on and off.',
      waitForClick: true,
    },
    {
      id: 'apps-page',
      kind: 'spotlight',
      target: '#profile-selector, .apps-grid',
      placement: 'top',
      title: 'Pick your apps',
      body: 'Each card is a module. Click to enable. The profile buttons up top apply a whole bundle in one go — Privacy, Media, or Everything.',
    },
    {
      id: 'nav-releases',
      kind: 'spotlight',
      target: 'a[data-page="releases"]',
      placement: 'bottom',
      title: 'Live product',
      body: 'Click Releases to see what\'s shipped. Every version of OpenBox, the day it lands on your box.',
      waitForClick: true,
    },
    {
      id: 'releases-page',
      kind: 'spotlight',
      target: '.changelog-section, #changelog-list',
      placement: 'top',
      title: "What's new",
      body: "Every release card shows its date, tag, and bullet list. OpenBox is actively developed — features land as soon as they're cut.",
    },
    {
      id: 'nav-settings',
      kind: 'spotlight',
      target: 'a[data-page="settings"]',
      placement: 'bottom',
      title: 'Settings',
      body: 'One more stop — click Settings to find where your backup key lives.',
      waitForClick: true,
    },
    {
      id: 'done',
      kind: 'modal',
      title: "You're in control",
      body: 'That\'s the tour. Everything else is self-explanatory — just click around. You can replay this tour any time from Settings → Setup Wizard.',
    },
  ];

  let step = 0;
  let overlayEl = null;
  let skipResolver = null;
  let tutorialActive = false;
  let reposRaf = null;
  let waitForClickCleanup = null;

  async function api(method, path, body) {
    const opts = { method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json' } };
    if (body !== undefined) opts.body = JSON.stringify(body);
    const res = await fetch('/api' + path, opts);
    if (!res.ok) throw new Error('http ' + res.status);
    return res.json();
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function buildShell() {
    overlayEl = document.createElement('div');
    overlayEl.className = 'tutorial-root';
    overlayEl.innerHTML = `
      <svg class="tutorial-mask" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <defs>
          <mask id="tutorial-mask-cutout">
            <rect width="100%" height="100%" fill="white"/>
            <rect class="tutorial-hole" x="0" y="0" width="0" height="0" rx="12" ry="12" fill="black"/>
          </mask>
        </defs>
        <rect class="tutorial-dim" width="100%" height="100%" fill="rgba(0,0,0,0.68)" mask="url(#tutorial-mask-cutout)"/>
      </svg>
      <div class="tutorial-ring"></div>
      <div class="tutorial-tooltip" role="dialog" aria-modal="true">
        <div class="tutorial-tooltip-inner">
          <div class="tutorial-header">
            <span class="tutorial-progress"></span>
            <button class="tutorial-skip" type="button">Skip tour</button>
          </div>
          <h3 class="tutorial-title"></h3>
          <p class="tutorial-body"></p>
          <div class="tutorial-footer">
            <button class="tutorial-back" type="button">← Back</button>
            <button class="tutorial-next" type="button">Next →</button>
          </div>
        </div>
        <div class="tutorial-arrow"></div>
      </div>
      <div class="tutorial-modal">
        <div class="tutorial-modal-inner">
          <img class="tutorial-logo" src="/logo.png" alt="OpenBox">
          <h1 class="tutorial-modal-title"></h1>
          <p class="tutorial-modal-body"></p>
          <div class="tutorial-modal-actions">
            <button class="tutorial-modal-skip" type="button">Skip tour</button>
            <button class="tutorial-modal-next primary" type="button">Start tour</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(overlayEl);

    // Skip / Next handlers (used by both modes).
    // Codex round 5 silent-failure finding: prior code swallowed API
    // failures and closed the wizard anyway, which meant a network
    // blip during the skip-request left the user seeing the tutorial
    // on every page load forever. We now surface the failure so they
    // know to try again.
    const skipHandler = async () => {
      try {
        await api('POST', '/wizard/skip');
      } catch (err) {
        console.error('[wizard] failed to record skip:', err);
        if (typeof toast === 'function') {
          toast("Couldn't save 'skip tour' — the setup wizard may reopen next visit. Try Skip again or refresh.", 'warn');
        }
      }
      destroy();
    };
    overlayEl.querySelector('.tutorial-skip').addEventListener('click', skipHandler);
    overlayEl.querySelector('.tutorial-modal-skip').addEventListener('click', skipHandler);

    overlayEl.querySelector('.tutorial-back').addEventListener('click', () => { if (step > 0) { step--; renderStep(); } });
    overlayEl.querySelector('.tutorial-next').addEventListener('click', () => advance());
    overlayEl.querySelector('.tutorial-modal-next').addEventListener('click', () => advance());

    window.addEventListener('resize', queueReposition, { passive: true });
    window.addEventListener('scroll', queueReposition, { passive: true, capture: true });
  }

  function destroy() {
    if (waitForClickCleanup) { waitForClickCleanup(); waitForClickCleanup = null; }
    if (overlayEl) { overlayEl.remove(); overlayEl = null; }
    tutorialActive = false;
    window.removeEventListener('resize', queueReposition);
    window.removeEventListener('scroll', queueReposition, true);
  }

  function queueReposition() {
    if (reposRaf) return;
    reposRaf = requestAnimationFrame(() => {
      reposRaf = null;
      const s = STEPS[step];
      if (s && s.kind === 'spotlight') positionSpotlight(s);
    });
  }

  // Query a target selector, retrying briefly for elements that render
  // after a nav click (e.g. the Apps page profile-selector).
  async function findTarget(selector, maxWaitMs = 1500) {
    const start = Date.now();
    while (Date.now() - start < maxWaitMs) {
      const el = document.querySelector(selector);
      if (el && el.offsetParent !== null) return el;
      await new Promise(r => setTimeout(r, 60));
    }
    return null;
  }

  function positionSpotlight(s) {
    const target = document.querySelector(s.target);
    if (!target) return;
    const rect = target.getBoundingClientRect();
    const pad = 8;
    const x = Math.max(4, rect.left - pad);
    const y = Math.max(4, rect.top - pad);
    const w = rect.width + pad * 2;
    const h = rect.height + pad * 2;

    const hole = overlayEl.querySelector('.tutorial-hole');
    hole.setAttribute('x', x);
    hole.setAttribute('y', y);
    hole.setAttribute('width', w);
    hole.setAttribute('height', h);

    const ring = overlayEl.querySelector('.tutorial-ring');
    ring.style.left = x + 'px';
    ring.style.top = y + 'px';
    ring.style.width = w + 'px';
    ring.style.height = h + 'px';

    positionTooltip(s, rect);
  }

  function positionTooltip(s, rect) {
    const tip = overlayEl.querySelector('.tutorial-tooltip');
    const arrow = overlayEl.querySelector('.tutorial-arrow');
    // Measure tooltip size
    tip.style.visibility = 'hidden';
    tip.style.display = 'block';
    const tipRect = tip.getBoundingClientRect();
    const tw = tipRect.width, th = tipRect.height;
    const vw = window.innerWidth, vh = window.innerHeight;

    const gap = 18;
    const candidates = [];
    // Preferred placement first, then auto fallbacks
    const order = [s.placement, 'bottom', 'top', 'right', 'left'].filter(Boolean);
    const seen = new Set();
    for (const p of order) {
      if (seen.has(p)) continue;
      seen.add(p);
      let x, y, arrowSide;
      if (p === 'bottom') {
        x = rect.left + rect.width / 2 - tw / 2;
        y = rect.bottom + gap;
        arrowSide = 'top';
      } else if (p === 'top') {
        x = rect.left + rect.width / 2 - tw / 2;
        y = rect.top - th - gap;
        arrowSide = 'bottom';
      } else if (p === 'right') {
        x = rect.right + gap;
        y = rect.top + rect.height / 2 - th / 2;
        arrowSide = 'left';
      } else if (p === 'left') {
        x = rect.left - tw - gap;
        y = rect.top + rect.height / 2 - th / 2;
        arrowSide = 'right';
      } else continue;
      const fits = x >= 10 && y >= 10 && x + tw <= vw - 10 && y + th <= vh - 10;
      candidates.push({ p, x, y, arrowSide, fits });
      if (fits) break;
    }
    const pick = candidates.find(c => c.fits) || candidates[0];
    const clampedX = Math.max(10, Math.min(vw - tw - 10, pick.x));
    const clampedY = Math.max(10, Math.min(vh - th - 10, pick.y));
    tip.style.left = clampedX + 'px';
    tip.style.top = clampedY + 'px';
    tip.style.visibility = 'visible';
    // Arrow position
    arrow.className = 'tutorial-arrow tutorial-arrow-' + pick.arrowSide;
  }

  async function renderStep() {
    if (waitForClickCleanup) { waitForClickCleanup(); waitForClickCleanup = null; }
    const s = STEPS[step];
    if (!s) { finish(); return; }
    const isModal = s.kind === 'modal';

    // Toggle modes
    overlayEl.classList.toggle('mode-modal', isModal);
    overlayEl.classList.toggle('mode-spotlight', !isModal);

    // Fill progress + back/next state
    overlayEl.querySelector('.tutorial-progress').textContent = `${step + 1} / ${STEPS.length}`;
    const back = overlayEl.querySelector('.tutorial-back');
    back.disabled = step === 0;
    const next = overlayEl.querySelector('.tutorial-next');
    next.textContent = step === STEPS.length - 1 ? 'Finish' : 'Next →';

    if (isModal) {
      const firstStep = step === 0;
      const lastStep = step === STEPS.length - 1;
      overlayEl.querySelector('.tutorial-modal-title').textContent = s.title;
      overlayEl.querySelector('.tutorial-modal-body').textContent = s.body;
      const modalNext = overlayEl.querySelector('.tutorial-modal-next');
      modalNext.textContent = firstStep ? 'Start tour →' : lastStep ? "Done — let's go" : 'Next →';
      overlayEl.querySelector('.tutorial-modal-skip').style.display = lastStep ? 'none' : '';
      return;
    }

    // Spotlight step: wait for the target to exist (handles post-nav rendering).
    const target = await findTarget(s.target);
    if (!target) {
      // Target missing — fall back to a centered tooltip without a hole.
      const hole = overlayEl.querySelector('.tutorial-hole');
      hole.setAttribute('x', 0); hole.setAttribute('y', 0);
      hole.setAttribute('width', 0); hole.setAttribute('height', 0);
      overlayEl.querySelector('.tutorial-ring').style.cssText = '';
    } else {
      target.scrollIntoView({ block: 'center', behavior: 'smooth' });
      // Wait a frame for smooth scroll start so rect is fresh
      await new Promise(r => setTimeout(r, 120));
      positionSpotlight(s);
    }

    overlayEl.querySelector('.tutorial-title').textContent = s.title;
    overlayEl.querySelector('.tutorial-body').textContent = s.body;

    // If the step asks us to wait for a click on the target, attach a
    // one-shot listener that auto-advances.
    if (s.waitForClick && target) {
      const clickHandler = () => { setTimeout(() => advance(), 200); };
      target.addEventListener('click', clickHandler, { once: true });
      waitForClickCleanup = () => { target.removeEventListener('click', clickHandler); };
      // Highlight the target with a subtle nudge.
      next.textContent = 'or click the highlighted element';
    }
  }

  function advance() {
    if (step < STEPS.length - 1) {
      step++;
      renderStep();
    } else {
      finish();
    }
  }

  async function finish() {
    try {
      await api('POST', '/wizard/complete', {});
    } catch (err) {
      console.error('[wizard] failed to record completion:', err);
      if (typeof toast === 'function') {
        toast("Couldn't mark the tour as done — it may reopen on your next visit. Refresh and it should save next time.", 'warn');
      }
    }
    destroy();
  }

  async function open() {
    if (tutorialActive) return;
    tutorialActive = true;
    step = 0;
    if (!overlayEl) buildShell();
    renderStep();
  }

  async function maybeAutoOpen() {
    // Local kill-switch so the wizard never re-opens on a browser that
    // already saw it once, even if server state somehow rolled back.
    // The user can re-open from Settings → Reopen wizard, which clears
    // this flag server-side AND we explicitly reset it on that path.
    if (localStorage.getItem('ob-wizard-dismissed') === '1') return;
    try {
      const status = await api('GET', '/wizard/status');
      if (!status.done && !status.skipped) {
        setTimeout(open, 500);
      } else {
        // Server says we're done — pin that locally so a future flicker
        // (transient read error, partial state) can't auto-open us.
        localStorage.setItem('ob-wizard-dismissed', '1');
      }
    } catch { /* silent — probably unauth */ }
  }

  window.SB = window.SB || {};
  window.SB.wizard = { open, close: destroy };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', maybeAutoOpen);
  } else {
    maybeAutoOpen();
  }
})();
