// Keyed list renderer — drop-in replacement for `parent.innerHTML = items.map(…).join('')`.
//
// Instead of nuking the whole parent and forcing a full browser reflow
// every tick, this:
//   - Keeps a Map<key, HTMLElement> between calls (stored on the parent)
//   - Adds new rows at the end
//   - Removes rows whose key no longer exists
//   - Updates rows in place via a user-supplied updateRow(el, item) fn
//     — only the fields that changed actually touch the DOM
//
// No framework, no vDOM, no deps. ~60 lines.
//
// Usage:
//   renderList(parent, items, {
//     key: item => item.id,
//     create: item => { const div = document.createElement('div'); ...; return div; },
//     update: (el, item) => { el.querySelector('.name').textContent = item.name; },
//   });

(function () {
  const KEY = '__sbRenderMap';

  function renderList(parent, items, { key, create, update }) {
    let map = parent[KEY];
    if (!map) { map = new Map(); parent[KEY] = map; }

    const nextKeys = new Set();
    let cursor = parent.firstChild;

    for (const item of items) {
      const k = key(item);
      nextKeys.add(k);
      let el = map.get(k);
      if (!el) {
        el = create(item);
        map.set(k, el);
        // Insert at the correct position (before the current cursor).
        parent.insertBefore(el, cursor);
      } else {
        // Move into position if not already there.
        if (el !== cursor) {
          parent.insertBefore(el, cursor);
        } else {
          cursor = cursor.nextSibling;
        }
        update(el, item);
      }
    }

    // Anything left in the map whose key isn't in nextKeys is stale.
    for (const [k, el] of map) {
      if (!nextKeys.has(k)) {
        try { el.remove(); } catch {}
        map.delete(k);
      }
    }
  }

  window.SB = window.SB || {};
  window.SB.renderList = renderList;
})();
