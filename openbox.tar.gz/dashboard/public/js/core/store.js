// Client-side state store.
//
// Mirrors the server's state-store: an in-memory Map of containers
// that's updated either from a full snapshot or from incremental
// deltas. Render code subscribes once and gets notified when
// something it cares about changes.
//
// Designed to survive reconnects: a new snapshot replaces the store
// atomically, a delta mutates it in place.

(function () {
  const containers = new Map(); // id -> row
  let subscribers = [];
  let version = 0; // bumps on every change — cheap change-detection

  function emit() {
    version++;
    for (const cb of subscribers) {
      try { cb(Array.from(containers.values()), version); } catch {}
    }
  }

  function applySnapshot(list) {
    containers.clear();
    for (const c of list) containers.set(c.id, c);
    emit();
  }

  function applyDelta(delta) {
    if (!delta || !delta.type) return;
    if (delta.type === 'container:add' || delta.type === 'container:update') {
      if (delta.container) containers.set(delta.container.id, delta.container);
      emit();
    } else if (delta.type === 'container:remove') {
      if (containers.delete(delta.id)) emit();
    } else if (delta.type === 'snapshot') {
      applySnapshot(delta.containers || []);
    }
  }

  function subscribe(cb) {
    subscribers.push(cb);
    cb(Array.from(containers.values()), version);
    return () => { subscribers = subscribers.filter(s => s !== cb); };
  }

  function list() { return Array.from(containers.values()); }
  function get(id) { return containers.get(id); }

  window.SB = window.SB || {};
  window.SB.store = { applySnapshot, applyDelta, subscribe, list, get };
})();
