(function () {
  'use strict';

  const OB_HELP = {
    'system-stats': {
      title: 'System stats',
      body: 'These gauges show live CPU, RAM, disk, and uptime for the host running OpenBox. **Watch for sustained spikes** over 80% on RAM or disk, because that is usually when installs, imports, or updates start feeling slow.',
      docs: 'https://crushcodeworks.com/docs.html#performance'
    },
    'container-row': {
      title: 'Running service row',
      body: 'Each row is one live container OpenBox is managing. **The launcher is your normal entry point**; the row controls are for quick pause, restart, and logs when something looks off.',
      docs: 'https://crushcodeworks.com/docs.html#post-install'
    },
    'recent-activity': {
      title: 'Recent activity',
      body: 'This feed records container lifecycle events like starts, stops, restarts, and health changes. **Use it after a change** to confirm OpenBox actually touched the service you expected.',
      docs: 'https://crushcodeworks.com/docs.html#dashboard-issues'
    },
    'apps-launcher': {
      title: 'Apps and launcher',
      body: 'The Apps page is where you enable modules, while the Home launcher is where you open the apps you already run. **Profiles are just shortcuts** that queue a sensible bundle for one-click install.',
      docs: 'https://crushcodeworks.com/docs.html#modules-enable-disable'
    },
    'app-first-login': {
      title: 'First login hint',
      body: 'Some apps ship with a temporary password, one-time setup wizard, or credentials OpenBox detects from logs. **This chip exists so you do not have to SSH in** just to find the first login.',
      docs: 'https://crushcodeworks.com/docs.html#service-passwords'
    },
    'module-enable': {
      title: 'Enable a module',
      body: 'Enabling downloads the images, writes any needed config, and starts the module containers. **First install can take a few minutes**, especially on a NAS or for larger apps like Immich or Nextcloud.',
      docs: 'https://crushcodeworks.com/docs.html#modules-enable-disable'
    },
    'module-disable': {
      title: 'Disable a module',
      body: 'Disabling stops and removes the containers, but **your data and module config stay on disk**. Re-enable it later and the app usually comes back exactly where you left it.',
      docs: 'https://crushcodeworks.com/docs.html#modules-enable-disable'
    },
    'install-profile': {
      title: 'Install profiles',
      body: 'Profiles pre-select a bundle of modules with different RAM expectations and setup goals. **Custom is the safest starting point** if you want to grow one app at a time.',
      docs: 'https://crushcodeworks.com/docs.html#profile-selection'
    },
    'updates-check': {
      title: 'Check for updates',
      body: 'This only asks registries whether newer container images exist. **Nothing is changed during the check**; it is safe to run any time to see what is available first.',
      docs: 'https://crushcodeworks.com/docs.html#updates-check'
    },
    'updates-apply': {
      title: 'Apply an update',
      body: 'Updating pulls the newer image, recreates the container, and restarts that service. **Expect a short interruption** while the old container exits and the new one becomes healthy.',
      docs: 'https://crushcodeworks.com/docs.html#updates-rollback'
    },
    'updates-schedule': {
      title: 'Update schedule',
      body: 'Pick a maintenance window when a short restart will not annoy anyone using the box. **Nighttime weekly windows** are usually the safest balance between freshness and stability.',
      docs: 'https://crushcodeworks.com/docs.html#updates-schedule'
    },
    'license-key': {
      title: 'License activations',
      body: 'Your license tracks how many installs have been activated with the key so you can move between machines without buying again. **Keep the purchase email** because that is the fastest recovery path if you ever need an activation reset.',
      docs: 'https://crushcodeworks.com/docs.html#license-activations'
    },
    'domain-settings': {
      title: 'Domain and timezone',
      body: 'The domain tells OpenBox what hostname to advertise for links and reverse proxy setup. **Timezone matters for backups, reports, and scheduled updates**, so set it to where the box actually lives.',
      docs: 'https://crushcodeworks.com/docs.html#domain-setup'
    },
    'env-vars': {
      title: 'Environment variables',
      body: 'These categories are the low-level settings OpenBox writes into `.env`. **Some values apply immediately, but many only take effect after a restart** because Docker only reads them when recreating containers.',
      docs: 'https://crushcodeworks.com/docs.html#cli-reference'
    },
    'config-save': {
      title: 'Saving server config',
      body: 'OpenBox writes config changes as one atomic update so half-written `.env` files do not strand the install. **Still double-check sensitive values** because a typo can stop the next container recreate from starting cleanly.',
      docs: 'https://crushcodeworks.com/docs.html#dashboard-issues'
    },
    'remote-access': {
      title: 'Remote access',
      body: 'A VPS already has a public IP, so remote access is mostly about hardening and convenience. A NAS lives on a private home IP, so **WireGuard or Tailscale is what makes it reachable from outside your Wi-Fi**.',
      docs: 'https://crushcodeworks.com/docs.html#remote-access'
    },
    'wireguard-setup': {
      title: 'WireGuard setup',
      body: 'OpenBox generates a client config you can scan as a QR code or import as a `.conf` file. **That file is the tunnel itself**, so treat it like a password when you move it onto your phone or laptop.',
      docs: 'https://crushcodeworks.com/docs.html#remote-access-wireguard'
    },
    'tailscale-check': {
      title: 'Tailscale check',
      body: 'This verifies whether `tailscaled` is installed, authenticated, and currently connected. **If it is missing or disconnected**, OpenBox cannot magically bring it online without the host-side Tailscale service.',
      docs: 'https://crushcodeworks.com/docs.html#remote-access-tailscale'
    },
    'custom-domains': {
      title: 'Custom domains',
      body: 'Custom domains only work after DNS already points your hostname at this server and Nginx Proxy Manager is available to terminate TLS. **Think of this as the final automation layer**, not the first step.',
      docs: 'https://crushcodeworks.com/docs.html#custom-domains'
    },
    'image-update': {
      title: 'Container image updates',
      body: 'This pulls newer images for the services you run and recreates their containers. **Running services will restart**, so use it when a short interruption is acceptable.',
      docs: 'https://crushcodeworks.com/docs.html#updates-rollback'
    },
    'backup-overview': {
      title: 'Backup strategy',
      body: 'The goal is simple: **3 copies of your data, on 2 kinds of storage, with 1 copy somewhere else**. Local backups help with mistakes; off-site backups help when the whole box or drive dies.',
      docs: 'https://crushcodeworks.com/docs.html#backup-create'
    },
    'backup-create': {
      title: 'Create Backup Now',
      body: 'Dashboard backups include your `.env`, module configs, and OpenBox data directories, then write an encrypted archive into `/backups/`. **Download a copy off the NAS** after it finishes, because a backup on the same drive does not save you from disk failure.',
      docs: 'https://crushcodeworks.com/docs.html#backup-create'
    },
    'backup-list': {
      title: 'Backup files',
      body: 'Backups use names like `openbox-backup-YYYYMMDD_HHMMSS.tar.gz.enc` so you can sort by timestamp at a glance. **Download keeps a copy elsewhere, Restore rolls back to that point, and Delete removes the local archive only**.',
      docs: 'https://crushcodeworks.com/docs.html#backup-create'
    },
    'backup-restore': {
      title: 'Restore a backup',
      body: 'Restore stops services, snapshots the current state, swaps the archived data in, and starts everything again. **If restore fails, OpenBox rolls back** to the snapshot instead of leaving you half-restored.',
      docs: 'https://crushcodeworks.com/docs.html#backup-restore'
    },
    'backup-encryption-key': {
      title: 'Backup encryption key',
      body: 'This key decrypts every encrypted dashboard backup for this install. **Save it in your password manager** because without it your backup files are uncrackable trash.',
      docs: 'https://crushcodeworks.com/docs.html#backup-encryption-key'
    },
    'backup-schedule': {
      title: 'Scheduled backups',
      body: 'Presets turn into cron jobs and retention controls how many old archives OpenBox keeps before pruning. **Daily for active boxes or weekly for quieter ones** is usually enough if you also copy backups off the machine.',
      docs: 'https://crushcodeworks.com/docs.html#backup-schedule'
    },
    'backup-offsite': {
      title: 'Off-site backups',
      body: 'Local backups protect you from bad updates and accidental deletes, but not from theft, fire, or a dead drive. **Use Duplicati or another off-site target** so at least one copy lives somewhere else.',
      docs: 'https://crushcodeworks.com/docs.html#backup-offsite'
    },
    'service-passwords': {
      title: 'Service passwords',
      body: 'OpenBox stores auto-generated credentials for apps like Portainer and Authelia so you do not need shell access to recover them. **This is the browser-safe replacement** for hunting through `state/*.txt` by hand.',
      docs: 'https://crushcodeworks.com/docs.html#service-passwords'
    },
    'health-reports': {
      title: 'Health reports',
      body: 'Health reports summarize uptime, alerts, updates, and disk pressure into a weekly snapshot. **They are meant for trend spotting**, not real-time debugging when something just broke.',
      docs: 'https://crushcodeworks.com/docs.html#health-reports'
    },
    'alerts': {
      title: 'Alert settings',
      body: 'Alerts can auto-restart unhealthy services and optionally send a webhook payload to Discord or Slack. **Webhook delivery is just notification**; the restart behavior is what keeps the box self-healing.',
      docs: 'https://crushcodeworks.com/docs.html#alerts-webhook'
    },
    'soft-reset': {
      title: 'Soft reset',
      body: 'Soft reset wipes the running containers and recreates them from the current config, but **it preserves your data, settings, and module state**. Use it when Docker gets weird and you want a clean recreate without starting over.',
      docs: 'https://crushcodeworks.com/docs.html#soft-reset-vs-clean-slate'
    },
    'reset-defaults': {
      title: 'Reset to defaults',
      body: 'This turns off optional modules and returns the stack to the core OpenBox services. **App data is preserved on disk**, so you can re-enable modules later and pick back up from there.',
      docs: 'https://crushcodeworks.com/docs.html#soft-reset-vs-clean-slate'
    },
    'factory-reset': {
      title: 'Factory reset',
      body: 'True clean slate — wipes every module config and data folder, clears dashboard state, resets modules.conf to core-only, and boots back into the first-run wizard. **Keeps** your license key, admin password, backups, and anything in /data (your media). **Does not** require reinstalling OpenBox. Use this when an install is broken beyond rescue or you want to redo setup from scratch.',
      docs: 'https://crushcodeworks.com/docs.html#soft-reset-vs-clean-slate'
    },
    'vpn-architecture': {
      title: 'How the VPN tunnel is wired',
      body: 'Your downloads run through a **gluetun** container that creates the VPN tunnel. qBittorrent, Sonarr, Radarr, Prowlarr, and Bazarr all run in `network_mode: service:gluetun` — they share gluetun\'s network namespace, so every packet they send leaves your box through the VPN. **If the tunnel drops, so does their internet** — that\'s the kill switch, enforced at the kernel level by Docker\'s network namespaces, not by application-level logic that can fail open. Gluetun also blocks any traffic that isn\'t destined for the VPN peer, so a misconfigured container can\'t accidentally leak. The dashboard checks this live by running a public-IP probe from inside qBittorrent and inside gluetun and confirming they match AND differ from your real home IP.',
      docs: 'https://crushcodeworks.com/docs.html#vpn-provider-setup'
    },
    'prune-images': {
      title: 'Prune images',
      body: 'Pruning removes old Docker images that no current container uses. **It is a disk cleanup**, not a data cleanup, so running services and their volumes stay untouched.',
      docs: 'https://crushcodeworks.com/docs.html#disk-space-issues'
    },
    'clean-slate': {
      title: 'Clean slate',
      body: 'Clean slate deletes that module’s saved data and config so the next enable acts like a brand-new install. **This is destructive by design**, which is why OpenBox makes you confirm it first.',
      docs: 'https://crushcodeworks.com/docs.html#modules-clean-slate'
    },
    'profile-privacy': {
      title: 'Privacy profile',
      body: 'Privacy installs the everyday self-hosting essentials like DNS blocking, password management, remote access, and monitoring. **It is the lightest preset** and a good fit for smaller VPS or NAS boxes.',
      docs: 'https://crushcodeworks.com/docs.html#profile-selection'
    },
    'profile-media': {
      title: 'Media profile',
      body: 'Media focuses on Jellyfin and the ARR stack, so it expects more RAM and a VPN-backed download path. **Choose this if the box is mainly a streaming server**.',
      docs: 'https://crushcodeworks.com/docs.html#profile-selection'
    },
    'profile-full': {
      title: 'Full profile',
      body: 'Full combines the privacy, media, and productivity pieces into one install. **It is the fastest way to demo everything**, but it also has the heaviest idle footprint.',
      docs: 'https://crushcodeworks.com/docs.html#profile-selection'
    },
    'profile-custom': {
      title: 'Custom profile',
      body: 'Custom starts lean and lets you add exactly what you want from the Apps page. **This is the safest option** if you are unsure what you will actually use day to day.',
      docs: 'https://crushcodeworks.com/docs.html#profile-selection'
    }
  };

  let active = null;

  function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
  }

  function renderBody(body) {
    return escapeHtml(body)
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\n/g, '<br>');
  }

  function closePopover() {
    if (!active) return;
    active.trigger.classList.remove('is-open');
    active.popover.remove();
    active = null;
  }

  function placePopover(trigger, popover) {
    const arrow = popover.querySelector('.sb-help-popover-arrow');
    const rect = trigger.getBoundingClientRect();
    const popRect = popover.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const gap = 12;

    let top = rect.bottom + gap;
    let left = rect.left + rect.width / 2 - popRect.width / 2;
    let side = 'top';

    if (top + popRect.height > vh - 12) {
      top = rect.top - popRect.height - gap;
      side = 'bottom';
    }
    if (top < 12) {
      top = Math.max(12, rect.bottom + gap);
      side = 'top';
    }

    left = Math.max(12, Math.min(left, vw - popRect.width - 12));

    popover.style.top = `${top}px`;
    popover.style.left = `${left}px`;
    arrow.dataset.side = side;
    arrow.style.left = `${Math.max(18, Math.min(popRect.width - 26, rect.left + rect.width / 2 - left - 7))}px`;
  }

  function openPopover(trigger) {
    const key = trigger.dataset.help;
    const entry = OB_HELP[key];
    if (!entry) return;

    if (active && active.trigger === trigger) {
      closePopover();
      return;
    }

    closePopover();

    const popover = document.createElement('div');
    popover.className = 'sb-help-popover';
    popover.setAttribute('role', 'dialog');
    popover.innerHTML = `
      <div class="sb-help-popover-arrow"></div>
      <h4 class="sb-help-popover-title">${escapeHtml(entry.title)}</h4>
      <div class="sb-help-popover-body">${renderBody(entry.body)}</div>
      ${entry.docs ? `<a class="sb-help-popover-link" href="${entry.docs}" target="_blank" rel="noopener">Read more in docs →</a>` : ''}
    `;
    document.body.appendChild(popover);
    trigger.classList.add('is-open');
    placePopover(trigger, popover);
    active = { trigger, popover };
  }

  function onTriggerClick(event) {
    const trigger = event.target.closest('[data-help]');
    if (!trigger) return;
    event.preventDefault();
    event.stopPropagation();
    openPopover(trigger);
  }

  function onKeydown(event) {
    if (event.key === 'Escape') closePopover();
  }

  function onPointerDown(event) {
    if (!active) return;
    if (active.popover.contains(event.target) || active.trigger.contains(event.target)) return;
    closePopover();
  }

  function decorateTriggers(root) {
    root.querySelectorAll('[data-help]').forEach((trigger) => {
      if (!trigger.classList.contains('sb-help')) trigger.classList.add('sb-help');
      if (!trigger.hasAttribute('tabindex')) trigger.tabIndex = 0;
      if (!trigger.hasAttribute('role')) trigger.setAttribute('role', 'button');
      if (!trigger.textContent.trim()) trigger.textContent = '?';
    });
  }

  function onTriggerKeydown(event) {
    const trigger = event.target.closest('[data-help]');
    if (!trigger) return;
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      openPopover(trigger);
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    decorateTriggers(document);
    document.addEventListener('click', onTriggerClick);
    document.addEventListener('keydown', onTriggerKeydown);
    document.addEventListener('keydown', onKeydown);
    document.addEventListener('pointerdown', onPointerDown, true);
    window.addEventListener('resize', () => {
      if (active) placePopover(active.trigger, active.popover);
    }, { passive: true });
    document.addEventListener('scroll', () => {
      if (active) placePopover(active.trigger, active.popover);
    }, true);

    const observer = new MutationObserver((records) => {
      records.forEach((record) => {
        record.addedNodes.forEach((node) => {
          if (node.nodeType !== 1) return;
          if (node.matches && node.matches('[data-help]')) decorateTriggers(node.parentNode || document);
          else if (node.querySelectorAll) decorateTriggers(node);
        });
      });
    });
    observer.observe(document.body, { childList: true, subtree: true });
  });
})();
