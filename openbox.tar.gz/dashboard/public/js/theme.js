/* ============================================================
   OpenBox Theme Picker
   - Reads localStorage.sb_theme, applies data-theme attribute
   - Renders picker into #theme-picker-mount on Settings page
   - All themes unlocked (v1.6.51 — was Pro-gated pre-v1.6.3 pivot)
   - Standalone — does not touch app.js state
   ============================================================ */
(function () {
  'use strict';

  var STORAGE_KEY = 'sb_theme';        // dark theme variant (Pro picker)
  var MODE_KEY    = 'sb_mode';         // 'light' or 'dark' (free toggle)
  var DEFAULT_THEME = 'midnight-purple';

  var THEMES = [
    { id: 'midnight-purple', name: 'Midnight Purple', desc: 'The original OpenBox' },
    { id: 'forest',          name: 'Forest',          desc: 'Deep green calm' },
    { id: 'sunset',          name: 'Sunset',          desc: 'Warm amber glow' },
    { id: 'arctic',          name: 'Arctic',          desc: 'Cool cyan clarity' },
    { id: 'rose',            name: 'Rose',            desc: 'Soft pink evening' }
  ];

  // Apply theme attribute immediately (before DOMContentLoaded) to avoid flash.
  function applyTheme(theme, animate) {
    var root = document.documentElement;
    if (animate) {
      root.classList.add('theme-transitioning');
      setTimeout(function () { root.classList.remove('theme-transitioning'); }, 450);
    }
    root.setAttribute('data-theme', theme);
  }

  function getStoredTheme() {
    try {
      var t = localStorage.getItem(STORAGE_KEY);
      if (t && THEMES.some(function (x) { return x.id === t; })) return t;
    } catch (e) { /* localStorage blocked */ }
    return DEFAULT_THEME;
  }

  function setStoredTheme(t) {
    try { localStorage.setItem(STORAGE_KEY, t); } catch (e) { /* ignore */ }
  }

  function getStoredMode() {
    try {
      var m = localStorage.getItem(MODE_KEY);
      return (m === 'light') ? 'light' : 'dark';
    } catch (e) { return 'dark'; }
  }

  function setStoredMode(m) {
    try { localStorage.setItem(MODE_KEY, m); } catch (e) { /* ignore */ }
  }

  // Resolve the theme that should actually be applied to <html>.
  // In dark mode: the picker's choice directly (midnight-purple, forest, etc.)
  // In light mode: the light variant of the picker's choice (light, light-forest, etc.)
  // midnight-purple in light mode → 'light' (the base light theme)
  function resolveTheme() {
    var theme = getStoredTheme();
    if (getStoredMode() === 'light') {
      return theme === DEFAULT_THEME ? 'light' : 'light-' + theme;
    }
    return theme;
  }

  // --- Early apply (before DOM ready): read from storage only.
  applyTheme(resolveTheme(), false);

  // Light/dark mode toggle in the topbar. Wires up once DOM is ready.
  function wireModeToggle() {
    var btn = document.getElementById('mode-toggle');
    if (!btn || btn._sbWired) return;
    btn._sbWired = true;
    btn.addEventListener('click', function () {
      var nowLight = getStoredMode() !== 'light';
      setStoredMode(nowLight ? 'light' : 'dark');
      applyTheme(resolveTheme(), true);
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', wireModeToggle);
  } else {
    wireModeToggle();
  }

  // --- Deferred: fetch license + render picker when Settings mount exists.
  var licensePromise = null;
  function fetchLicense() {
    if (licensePromise) return licensePromise;
    licensePromise = fetch('/api/license', { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : { tier: 'free' }; })
      .catch(function () { return { tier: 'free' }; });
    return licensePromise;
  }

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      for (var k in attrs) {
        if (k === 'class') node.className = attrs[k];
        else if (k === 'text') node.textContent = attrs[k];
        else if (k === 'html') node.innerHTML = attrs[k];
        else node.setAttribute(k, attrs[k]);
      }
    }
    if (children) {
      for (var i = 0; i < children.length; i++) {
        if (children[i]) node.appendChild(children[i]);
      }
    }
    return node;
  }

  function buildSwatch(theme, currentTheme, isPro, onPick) {
    var btn = el('button', {
      type: 'button',
      class: 'theme-swatch sw-' + theme.id + (currentTheme === theme.id ? ' selected' : ''),
      'data-theme-value': theme.id,
      'aria-label': 'Switch to ' + theme.name + ' theme',
      'aria-pressed': currentTheme === theme.id ? 'true' : 'false'
    });
    btn.appendChild(el('div', { class: 'theme-swatch-preview' }));
    btn.appendChild(el('div', { class: 'theme-swatch-name', text: theme.name }));
    btn.appendChild(el('div', { class: 'theme-swatch-check', text: '\u2713' }));
    btn.addEventListener('click', function () { onPick(theme.id); });
    return btn;
  }

  function render(mount) {
    mount.innerHTML = '';
    mount.className = 'settings-group';

    // v1.6.51: OpenBox is free for personal use; themes are no longer
    // Pro-gated. Drop the "Pro" tag in the header and the .locked
    // grayscale-out style on the swatches — every theme works for
    // everyone. The /api/license fetch is no longer needed.
    var header = el('div', { class: 'settings-group-title' });
    header.appendChild(document.createTextNode('Appearance'));
    mount.appendChild(header);

    var wrap = el('div', { class: 'theme-picker' });
    wrap.appendChild(el('div', { class: 'theme-picker-sub',
      text: 'Choose an accent palette. Works in both light and dark mode.' }));

    var grid = el('div', { class: 'theme-swatches' });
    var current = getStoredTheme();

    function pickTheme(id) {
      current = id;
      setStoredTheme(id);
      applyTheme(id, true);
      // Update selected state
      var swatches = grid.querySelectorAll('.theme-swatch');
      for (var i = 0; i < swatches.length; i++) {
        var isSel = swatches[i].getAttribute('data-theme-value') === id;
        swatches[i].classList.toggle('selected', isSel);
        swatches[i].setAttribute('aria-pressed', isSel ? 'true' : 'false');
      }
    }

    THEMES.forEach(function (t) {
      grid.appendChild(buildSwatch(t, current, true, pickTheme));
    });
    wrap.appendChild(grid);

    // Coming soon teasers
    var coming = el('div', { class: 'theme-picker-coming' });
    var c1 = el('div', { class: 'theme-coming-card' });
    c1.innerHTML = '<strong>Custom accent</strong>Pick any color. Coming soon.';
    var c2 = el('div', { class: 'theme-coming-card' });
    c2.innerHTML = '<strong>Reorder launcher</strong>Pin favourites. Coming soon.';
    coming.appendChild(c1);
    coming.appendChild(c2);
    wrap.appendChild(coming);

    mount.appendChild(wrap);
  }

  // Observe for Settings page becoming active and render once mount exists.
  function tryRender() {
    var mount = document.getElementById('theme-picker-mount');
    if (!mount || mount.getAttribute('data-theme-rendered') === '1') return;
    mount.setAttribute('data-theme-rendered', '1');
    render(mount);
  }

  // Force a re-render — clears the "already rendered" flag.
  function forceRerender() {
    var mount = document.getElementById('theme-picker-mount');
    if (mount) mount.removeAttribute('data-theme-rendered');
    tryRender();
  }

  function init() {
    tryRender();
    // App.js may add/remove pages dynamically; watch for nav to Settings tab.
    var nav = document.querySelector('[data-page="settings"]');
    if (nav) nav.addEventListener('click', function () { setTimeout(tryRender, 50); });
    // Also observe DOM mutations so if settings mount is added later it still renders.
    if (window.MutationObserver) {
      var mo = new MutationObserver(function () { tryRender(); });
      mo.observe(document.body, { childList: true, subtree: true });
      // Stop observing after 10 seconds (it will have mounted by then)
      setTimeout(function () { mo.disconnect(); }, 10000);
    }
    // Re-render after login when app.js has an authenticated license check.
    // The DOMContentLoaded fetch hits /api/license before login → 401 →
    // cached as "free" forever. This event fires post-login with real data.
    document.addEventListener('openbox:license-ready', forceRerender);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
