// ==========================================
// OpenBox — AI Troubleshooting Widget (Pro / Ultimate)
// ==========================================

(function () {
  'use strict';

  const $ = (s) => document.querySelector(s);
  const show = (el) => { el.classList.remove('hidden'); el.classList.add('active'); };
  const hide = (el) => { el.classList.add('hidden'); el.classList.remove('active'); };

  let socket = null;
  let sessionId = null;
  let isStreaming = false;

  // Wait for socket.io to be available
  function getSocket() {
    if (!socket && window.io) {
      socket = window.io();
      setupSocketListeners();
    }
    return socket;
  }

  // Use the existing socket if available
  function tryExistingSocket() {
    const existing = document.querySelector('script[src="/socket.io/socket.io.js"]');
    if (existing && window.io) {
      // Reuse the global socket connection from app.js
      // We need our own listeners but can share the connection
      socket = window.io();
      setupSocketListeners();
    }
  }

  function setupSocketListeners() {
    if (!socket) return;

    socket.on('chat:session-created', (data) => {
      sessionId = data.sessionId;
      sessionStorage.setItem('sb-chat-session', sessionId);
    });

    socket.on('chat:start', () => {
      isStreaming = true;
      showTypingIndicator();
    });

    socket.on('chat:token', (data) => {
      appendToken(data.token);
    });

    socket.on('chat:done', (data) => {
      isStreaming = false;
      finalizeAssistantMessage();
      loadUsageStatus();
    });

    socket.on('chat:error', (data) => {
      isStreaming = false;
      hideTypingIndicator();
      addMessage('assistant', data.error || 'Something went wrong. Try again.');
    });
  }

  // --- UI Rendering ---

  function init() {
    const fab = $('#chat-fab');
    const drawer = $('#chat-drawer');
    if (!fab || !drawer) return;

    // Restore session
    sessionId = sessionStorage.getItem('sb-chat-session');

    // FAB click toggles drawer
    fab.addEventListener('click', toggleDrawer);

    // Close button
    const closeBtn = $('#chat-close');
    if (closeBtn) closeBtn.addEventListener('click', toggleDrawer);

    // Send button + enter key
    const sendBtn = $('#chat-send');
    const input = $('#chat-input');
    if (sendBtn) sendBtn.addEventListener('click', sendMessage);
    if (input) {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendMessage();
        }
      });
    }

    // New session button
    const newBtn = $('#chat-new-session');
    if (newBtn) newBtn.addEventListener('click', startNewSession);

    // Check if Pro and API key configured
    checkChatAvailability();

    // Re-check after login — the DOMContentLoaded fetch fires before
    // login and gets 401, hiding the FAB permanently. This event fires
    // post-login with real authenticated data.
    document.addEventListener('openbox:license-ready', checkChatAvailability);
  }

  async function checkChatAvailability() {
    const fab = $('#chat-fab');
    if (!fab) return;

    try {
      // Server-side feature flag check first — /api/chat/available
      // returns { available: false } when OB_AI_CHAT_ENABLED isn't
      // set, which is the default. The chat widget stays hidden and
      // users use the Community Help FAB (help.js) to post in
      // demox.world/d/openbox instead.
      const availRes = await fetch('/api/chat/available', { headers: { 'Content-Type': 'application/json' } });
      const avail = await availRes.json();
      if (!avail.available) {
        fab.classList.add('hidden');
        return;
      }

      const res = await fetch('/api/license', { headers: { 'Content-Type': 'application/json' } });
      const license = await res.json();

      if (!license.features.aiChat) {
        fab.classList.add('hidden');
        return;
      }

      // Chat is available for Pro (50/mo) and Ultimate (unlimited)
      fab.classList.remove('hidden');
      // Tell the layout that both FABs are now in play so the help-fab
      // can stack above the chat-fab instead of overlapping it.
      document.body.classList.add('ai-fab-visible');

      // Load usage status for display
      loadUsageStatus();
    } catch {
      // Not authenticated or error — hide chat
      fab.classList.add('hidden');
    }
  }

  function toggleDrawer() {
    const drawer = $('#chat-drawer');
    if (!drawer) return;

    const isOpen = drawer.classList.contains('active');
    if (isOpen) {
      hide(drawer);
    } else {
      show(drawer);
      tryExistingSocket();
      loadUsageStatus();
      const input = $('#chat-input');
      if (input) input.focus();

      // Load history if we have a session
      if (sessionId) loadHistory();
    }
  }

  async function loadUsageStatus() {
    try {
      const res = await fetch('/api/chat/usage', { headers: { 'Content-Type': 'application/json' } });
      if (!res.ok) return;
      const data = await res.json();
      const usageEl = document.getElementById('chat-usage');
      if (!usageEl) return;

      if (data.unlimited) {
        usageEl.textContent = 'Unlimited messages';
        usageEl.className = 'chat-usage chat-usage--unlimited';
      } else {
        usageEl.textContent = `${data.used} / ${data.limit} this month`;
        usageEl.className = 'chat-usage';
        if (data.remaining === 0) {
          usageEl.classList.add('chat-usage--empty');
        } else if (data.remaining <= 10) {
          usageEl.classList.add('chat-usage--low');
        }
      }
    } catch {}
  }

  async function loadHistory() {
    if (!sessionId) return;
    try {
      const res = await fetch(`/api/chat/history/${sessionId}`, {
        headers: { 'Content-Type': 'application/json' },
      });
      if (!res.ok) return;
      const session = await res.json();
      const messages = $('#chat-messages');
      if (!messages) return;
      messages.innerHTML = '';
      for (const msg of session.messages || []) {
        addMessage(msg.role, msg.content);
      }
      messages.scrollTop = messages.scrollHeight;
    } catch {}
  }

  function sendMessage() {
    const input = $('#chat-input');
    if (!input || !input.value.trim() || isStreaming) return;

    const message = input.value.trim();
    input.value = '';

    // Create session if needed. Server validates with /^sess-[a-f0-9]{16}$/
    // so we must use hex chars only — Math.random().toString(36) emits base36
    // (a-z + 0-9) which fails that regex and returns "Invalid session ID".
    if (!sessionId) {
      const hex = Array.from(crypto.getRandomValues(new Uint8Array(8)))
        .map(b => b.toString(16).padStart(2, '0')).join('');
      sessionId = 'sess-' + hex;
      sessionStorage.setItem('sb-chat-session', sessionId);
    }

    // Add user message to UI
    addMessage('user', message);

    // Send via socket — check connection state first. Before this,
    // a disconnected socket silently dropped the emit and the
    // customer just saw their own message with no response, no
    // failure feedback, no retry path.
    const s = getSocket();
    if (s && s.connected) {
      s.emit('chat:send', { sessionId, message });
    } else {
      addMessage('system', `Couldn't send — the connection to the OpenBox server dropped. Trying to reconnect… refresh the page if this sticks for more than 30 seconds.`);
      // Restore the draft so the customer doesn't have to retype.
      const input = document.getElementById('chat-input');
      if (input) { input.value = message; input.focus(); }
    }
  }

  function startNewSession() {
    sessionId = null;
    sessionStorage.removeItem('sb-chat-session');
    const messages = $('#chat-messages');
    if (messages) {
      messages.innerHTML = `
        <div class="chat-welcome">
          <p>Describe any OpenBox problem and I'll help diagnose it. I can see your containers, logs, and configuration — I know every module inside out.</p>
        </div>`;
    }
  }

  // --- Message Rendering ---

  function addMessage(role, content) {
    const messages = $('#chat-messages');
    if (!messages) return;

    // Remove welcome message if present
    const welcome = messages.querySelector('.chat-welcome, .chat-setup');
    if (welcome) welcome.remove();

    const div = document.createElement('div');
    div.className = `chat-message chat-message--${role}`;
    div.innerHTML = formatMessage(content);
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
  }

  // Streaming: show typing indicator
  function showTypingIndicator() {
    const messages = $('#chat-messages');
    if (!messages) return;

    // Remove welcome if present
    const welcome = messages.querySelector('.chat-welcome');
    if (welcome) welcome.remove();

    // Create streaming message container
    let streaming = messages.querySelector('.chat-message--streaming');
    if (!streaming) {
      streaming = document.createElement('div');
      streaming.className = 'chat-message chat-message--assistant chat-message--streaming';
      streaming.textContent = '';
      messages.appendChild(streaming);
    }
    messages.scrollTop = messages.scrollHeight;
  }

  function hideTypingIndicator() {
    const messages = $('#chat-messages');
    if (!messages) return;
    const streaming = messages.querySelector('.chat-message--streaming');
    if (streaming) streaming.remove();
  }

  // Append a token to the streaming message
  function appendToken(token) {
    const messages = $('#chat-messages');
    if (!messages) return;

    let streaming = messages.querySelector('.chat-message--streaming');
    if (!streaming) {
      showTypingIndicator();
      streaming = messages.querySelector('.chat-message--streaming');
    }
    streaming.textContent += token;
    messages.scrollTop = messages.scrollHeight;
  }

  // Finalize the streaming message (convert to formatted HTML)
  function finalizeAssistantMessage() {
    const messages = $('#chat-messages');
    if (!messages) return;

    const streaming = messages.querySelector('.chat-message--streaming');
    if (streaming) {
      const text = streaming.textContent;
      streaming.classList.remove('chat-message--streaming');
      streaming.innerHTML = formatMessage(text);
      // Add a "share to demox" button so users can escalate AI replies
      // that didn't fully solve their problem to the public forum where
      // Crush Code Works can ship a real fix. Pre-fills the post body with the
      // question + AI reply so the user doesn't retype anything.
      appendShareToDemox(streaming, text);
      messages.scrollTop = messages.scrollHeight;
    }
  }

  // Append a "share to demox.world" footer to a finalized assistant
  // message. Pulls the prior user message as the question, the AI reply
  // as context, and opens demox.world/submit pre-filled.
  function appendShareToDemox(assistantEl, replyText) {
    const messages = $('#chat-messages');
    if (!messages) return;
    // Find the user message that prompted this reply (the last
    // .chat-message--user before this assistant element).
    let question = '';
    let prev = assistantEl.previousElementSibling;
    while (prev) {
      if (prev.classList && prev.classList.contains('chat-message--user')) {
        question = prev.textContent.trim();
        break;
      }
      prev = prev.previousElementSibling;
    }
    const footer = document.createElement('div');
    footer.className = 'chat-message-actions';
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'chat-share-btn';
    btn.title = 'Open demox.world/d/openbox with this conversation pre-filled';
    btn.innerHTML = '<span class="chat-share-icon">↗</span> Didn\u2019t fully fix it? Share to demox so Tom can ship an update';
    btn.addEventListener('click', () => {
      const title = question ? question.slice(0, 90) : 'OpenBox AI follow-up';
      const body = [
        '**My question:**',
        question || '(see AI reply)',
        '',
        '**OpenBox AI replied:**',
        replyText.trim(),
        '',
        '**What I still need help with:**',
        '(describe what didn\'t work or what\'s still broken)',
      ].join('\n');
      const url = new URL('https://demox.world/submit');
      url.searchParams.set('community', 'openbox');
      url.searchParams.set('title', title);
      url.searchParams.set('body', body);
      window.open(url.toString(), '_blank', 'noopener');
    });
    footer.appendChild(btn);
    assistantEl.appendChild(footer);
  }

  // Simple markdown-lite formatting
  function formatMessage(text) {
    if (!text) return '';
    // Escape HTML
    let html = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    // Code blocks
    html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, '<pre><code>$2</code></pre>');
    // Inline code
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    // Bold
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    // Line breaks
    html = html.replace(/\n/g, '<br>');
    return html;
  }

  // --- Init on DOM ready ---
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
