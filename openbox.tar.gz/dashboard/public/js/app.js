// ==========================================
// OpenBox — Friendly Dashboard Frontend
// ==========================================

(function () {
  'use strict';

  let socket = null;
  let currentLogStream = null;

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => document.querySelectorAll(s);
  function show(el) { el.classList.remove('hidden'); el.classList.add('active'); }
  function hide(el) { el.classList.add('hidden'); el.classList.remove('active'); }

  // --- Dynamic metadata (loaded from API) ---

  let _serviceMeta = {};   // keyed by container name (e.g. 'ob-pihole')
  let _moduleMeta = {};    // keyed by module id (e.g. 'privacy')
  let _criticalSet = new Set();
  let _storeData = null;   // cached /api/modules/store response
  let _containers = [];    // cached container list for cross-feature use

  // --- Batch install state ---
  // Apps-page toggles queue their changes into _pending instead of firing
  // API calls immediately. The apply bar at the bottom of the page shows
  // "Install N / Remove N / Apply" and commits the whole set in one POST.
  // Key: module id, Value: desired enabled state (true/false).
  // We also snapshot the server-side enabled set at load so we can compute
  // a diff at apply time (and prune pending entries that match the baseline,
  // e.g. user toggles off then back on).
  let _pendingChanges = new Map();
  let _originalEnabled = new Set();

  const CATEGORY_LABELS = {
    infrastructure: 'Infrastructure',
    privacy: 'Privacy & Security',
    productivity: 'Productivity',
    cloud: 'Cloud & Files',
    network: 'Networking',
    system: 'System',
    tools: 'Tools',
    media: 'Media',
    documents: 'Documents',
    development: 'Development',
    automation: 'Automation',
    communication: 'Communication',
    // Tom 2026-04-24 live review: "monitoring" was the only filter
    // rendered lowercase because there was no label entry. Other
    // categories fall through esc(cat) which shows the raw key.
    monitoring: 'Monitoring',
    security: 'Security',
    other: 'Other'
  };

  // App launcher category grouping (maps x-openbox categories to launcher groups)
  const LAUNCHER_GROUPS = {
    'Media': ['media'],
    'Privacy': ['privacy'],
    'Productivity': ['productivity', 'cloud', 'documents'],
    'Tools': ['tools', 'development', 'automation', 'communication', 'network'],
    'System': ['system', 'infrastructure', 'other']
  };

  // SVG icon file map — maps service ID to the icon filename in /icons/
  // Falls back to emoji if no SVG exists
  const SERVICE_ICON_FILES = {
    'jellyfin': 'jellyfin', 'jellyfin-media': 'jellyfin',
    'immich': 'immich', 'navidrome': 'navidrome',
    'pihole': 'pi-hole', 'vaultwarden': 'vaultwarden',
    'nextcloud': 'nextcloud', 'qbittorrent': 'qbittorrent',
    'sonarr': 'sonarr', 'radarr': 'radarr', 'prowlarr': 'prowlarr',
    'portainer': 'portainer', 'npm': 'nginx-proxy-manager',
    'nginx-proxy-manager': 'nginx-proxy-manager',
    'filebrowser': 'filebrowser', 'file-browser': 'filebrowser',
    'uptime-kuma': 'uptime-kuma', 'paperless': 'paperless-ngx',
    'paperless-ngx': 'paperless-ngx', 'mealie': 'mealie',
    'audiobookshelf': 'audiobookshelf', 'gitea': 'gitea',
    'wireguard': 'wireguard', 'tailscale': 'tailscale',
    'homepage': 'homarr', 'homarr': 'homarr',
    'bazarr': 'bazarr', 'jellyseerr': 'jellyseerr', 'seerr': 'jellyseerr',
    'lidarr': 'lidarr', 'freshrss': 'freshrss',
    'authelia': 'authelia', 'gotify': 'gotify',
    'n8n': 'n8n', 'speedtest': 'speedtest-tracker',
    'stirling-pdf': 'stirling-pdf',
    'changedetection': 'changedetection-io',
    'linkding': 'linkding', 'gluetun': 'gluetun',
    // Added 2026-04-15 — icon SVGs already shipped in /icons but were
    // never wired up in this lookup, so the launcher fell back to emoji
    // (or the generic package box) for these services.
    'adguard': 'adguard', 'adguardhome': 'adguard',
    'actual': 'actual', 'actual-budget': 'actual', 'budget': 'actual',
    'bookstack': 'bookstack',
    'calibre': 'calibre-web', 'calibre-web': 'calibre-web',
    'duplicati': 'duplicati',
    'element': 'element',
    'frigate': 'frigate',
    'grafana': 'grafana',
    'homeassistant': 'homeassistant', 'home-assistant': 'homeassistant',
    'kavita': 'kavita',
    'localai': 'localai', 'local-ai': 'localai',
    'matrix': 'matrix', 'synapse': 'synapse',
    'ollama': 'ollama',
    'openwebui': 'open-webui', 'open-webui': 'open-webui',
    'photoprism': 'photoprism',
    'prometheus': 'prometheus',
  };

  // Emoji fallbacks for services without SVG icons
  const SERVICE_ICONS = {
    'jellyfin': '\uD83C\uDFAC', 'jellyfin-media': '\uD83C\uDFAC',
    'immich': '\uD83D\uDCF8', 'navidrome': '\uD83C\uDFB5',
    'pihole': '\uD83D\uDEE1\uFE0F', 'vaultwarden': '\uD83D\uDD10',
    'nextcloud': '\u2601\uFE0F', 'qbittorrent': '\u2B07\uFE0F',
    'sonarr': '\uD83D\uDCFA', 'radarr': '\uD83C\uDFA5',
    'prowlarr': '\uD83D\uDD0D', 'portainer': '\uD83D\uDC33',
    'npm': '\uD83C\uDF10', 'nginx-proxy-manager': '\uD83C\uDF10',
    'filebrowser': '\uD83D\uDCC1', 'file-browser': '\uD83D\uDCC1',
    'uptime-kuma': '\uD83D\uDCCA', 'paperless': '\uD83D\uDCC4',
    'paperless-ngx': '\uD83D\uDCC4', 'mealie': '\uD83C\uDF73',
    'audiobookshelf': '\uD83D\uDCDA', 'gitea': '\uD83D\uDD27',
    'wireguard': '\uD83D\uDD12', 'tailscale': '\uD83C\uDF0D',
    'homepage': '\uD83C\uDFE0', 'homarr': '\uD83C\uDFE0',
    'bazarr': '\uD83D\uDCAC', 'jellyseerr': '\u2728', 'seerr': '\u2728',
    'lidarr': '\uD83C\uDFB6', 'freshrss': '\uD83D\uDCF0',
    'authelia': '\uD83D\uDD10', 'openbox-dashboard': '\u26A1',
    'gotify': '\uD83D\uDD14', 'n8n': '\u2699\uFE0F',
    'speedtest': '\uD83C\uDFC3', 'stirling-pdf': '\uD83D\uDCC4',
    'changedetection': '\uD83D\uDC41\uFE0F', 'linkding': '\uD83D\uDD17',
  };

  // Returns an <img> tag for the SVG icon, or the emoji string as fallback
  function serviceIcon(svcId, size) {
    const file = SERVICE_ICON_FILES[svcId];
    if (file) {
      const px = size || 28;
      return `<img src="/icons/${file}.svg" alt="" width="${px}" height="${px}" style="object-fit:contain" onerror="this.outerHTML='${SERVICE_ICONS[svcId] || '\uD83D\uDCE6'}'">`;
    }
    return SERVICE_ICONS[svcId] || '\uD83D\uDCE6';
  }

  // Load metadata from /api/modules/store and build SERVICE_META + MODULE_META dynamically
  async function loadMetadata() {
    if (_storeData) return; // already loaded
    try {
      const mods = await api('GET', '/modules/store');
      _storeData = mods;

      _serviceMeta = {};
      _moduleMeta = {};
      _criticalSet = new Set();

      for (const mod of mods) {
        // Build MODULE_META
        const theme = mod.theme || {};
        _moduleMeta[mod.id] = {
          emoji: theme.emoji || '\uD83D\uDCE6',
          color: theme.color || '#6e6e73',
          bg: theme.bg || '#f5f5f7',
          friendly: mod.name,
          desc: mod.description || ''
        };

        // Build critical containers set
        if (mod.critical_services) {
          for (const cs of mod.critical_services) {
            _criticalSet.add(cs);
          }
        }

        // Build SERVICE_META from services
        if (mod.services) {
          for (const svc of mod.services) {
            const containerName = 'ob-' + svc.id;
            // Use specific icon from SERVICE_ICONS map if available, else module theme emoji
            const specificIcon = SERVICE_ICONS[svc.id] || null;
            _serviceMeta[containerName] = {
              emoji: specificIcon || theme.emoji || '\uD83D\uDCE6',
              color: theme.color || '#6e6e73',
              bg: theme.bg || '#f5f5f7',
              name: svc.name || svc.id,
              port: svc.port || null,
              https: svc.https || false,
              path: svc.path || null,
              desc: svc.description || '',
              tip: svc.tip || '',
              first_login: svc.first_login || '',
              guide_url: svc.guide_url || '',
              // Bound to 127.0.0.1 — a LAN link would refuse. Tile
              // builder renders a local-only badge + SSH-tunnel hint
              // instead of a broken clickable URL.
              loopback_only: svc.loopback_only === true,
              category: mod.category || 'other',
              moduleId: mod.id,
              svcId: svc.id
            };
          }
        }
      }
    } catch {
      // If store endpoint fails, metadata stays empty — graceful fallback
    }
  }

  function isCritical(containerName) {
    return _criticalSet.has(containerName);
  }

  // --- API ---

  function getCsrfToken() {
    const m = document.cookie.match(/(?:^|;\s*)_csrf=([^;]*)/);
    return m ? m[1] : '';
  }

  function needsRecentReauth(path) {
    // Endpoints the server guards with requireRecentReauth(). When these
    // 401 with error='reauth_required', api() auto-prompts and retries.
    // Stay in sync with dashboard/server.js — grep "requireRecentReauth\b"
    // there; every match outside a comment must be covered here.
    // scripts/test-reauth-long-session.js asserts this.
    if (path === '/passwords') return true;
    if (path === '/wizard/backup-key') return true;
    if (path === '/setup/complete') return true;
    if (path === '/config') return true;
    if (path === '/backup/restore') return true;
    if (path === '/license' || path === '/license/activate') return true;
    if (path === '/update') return true;
    if (path === '/self-update/apply') return true;
    if (path === '/migrate/export' || path === '/migrate/import') return true;
    if (path === '/domains/setup') return true;
    if (path === '/support/enable') return true;
    if (path === '/remote-access/wireguard/client') return true;
    if (path.startsWith('/server/') && (path.endsWith('-reset') || path.endsWith('-defaults'))) return true;
    if (path.startsWith('/updates/') && (path.endsWith('/apply') || path.endsWith('/rollback'))) return true;
    if (path.startsWith('/backups/')) return true;
    if (path.startsWith('/containers/') && path.endsWith('/first-login-creds')) return true;
    if (path.startsWith('/modules/') && path.endsWith('/clean-slate')) return true;
    return false;
  }

  async function promptRecentReauth() {
    const password = window.prompt('Please confirm your password to continue.');
    if (password === null) {
      const err = new Error('Password confirmation canceled.');
      err.error = 'reauth_canceled';
      throw err;
    }
    const opts = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': getCsrfToken(),
      },
      body: JSON.stringify({ password }),
    };
    const res = await fetch('/api/auth/reauth', opts);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(data.message || data.error || 'Password confirmation failed.');
      Object.assign(err, data);
      throw err;
    }
    return data;
  }

  async function api(method, path, body, options) {
    const optsMeta = options || {};
    const opts = { method, headers: { 'Content-Type': 'application/json' } };
    if (method !== 'GET' && method !== 'HEAD') {
      opts.headers['X-CSRF-Token'] = getCsrfToken();
    }
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(`/api${path}`, opts);
    const data = await res.json().catch(() => ({}));
    if (!res.ok && res.status === 401 && data.error === 'reauth_required' && needsRecentReauth(path) && !optsMeta._retriedAfterReauth) {
      await promptRecentReauth();
      return api(method, path, body, { _retriedAfterReauth: true });
    }
    if (!res.ok) {
      const err = new Error(data.message || data.error || `Request failed`);
      // Attach structured flags so callers can branch on them.
      Object.assign(err, data);
      throw err;
    }
    return data;
  }

  // --- Helpers ---

  function formatBytes(b) {
    if (!b) return '0 B';
    const k = 1024;
    const s = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(b) / Math.log(k));
    return parseFloat((b / Math.pow(k, i)).toFixed(1)) + ' ' + s[i];
  }

  function getGreeting() {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning! \u2600\uFE0F';
    if (h < 17) return 'Good afternoon! \uD83D\uDC4B';
    return 'Good evening! \uD83C\uDF19';
  }

  function toast(msg, type = 'info') {
    const wrap = $('#toast-wrap');
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.setAttribute('role', 'alert');
    el.textContent = msg;
    wrap.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, 3500);
  }

  // --- In-page confirm dialog ---
  // Replaces window.confirm() — looks part of the app instead of a phishing popup.
  // Returns a Promise that resolves true (confirm) or false (cancel/dismiss).
  function confirmDialog({ title, body, confirmLabel = 'OK', cancelLabel = 'Cancel', danger = false, cancelDanger = false }) {
    return new Promise((resolve) => {
      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:100000;display:flex;align-items:center;justify-content:center;padding:1.5rem';
      const confirmStyle = danger
        ? 'background:hsl(0,75%,55%);color:#fff'
        : 'background:var(--accent,#6366f1);color:#fff';
      // cancelDanger styles the secondary "destructive" path with a subtle red
      // tint instead of a neutral gray, so users see it's the consequential
      // option (e.g. "Skip VPN, Media stays disabled") even though it's not
      // the primary action.
      const cancelStyle = cancelDanger
        ? 'border:1px solid hsla(0,75%,55%,0.5);background:transparent;color:hsl(0,75%,68%)'
        : 'border:1px solid var(--border,rgba(255,255,255,0.15));background:transparent;color:var(--text,#fff)';
      overlay.innerHTML = `
        <div role="dialog" aria-modal="true" style="background:var(--bg-card,#1a1a1f);max-width:480px;width:100%;border-radius:1rem;padding:1.5rem;border:1px solid var(--border,rgba(255,255,255,0.08));box-shadow:0 20px 60px rgba(0,0,0,0.5);color:var(--text,#fff)">
          <h3 style="margin:0 0 0.85rem;font-size:1.15rem;font-weight:700">${esc(title)}</h3>
          <div style="font-size:0.92rem;line-height:1.5;color:var(--text-secondary,rgba(255,255,255,0.78))">${body}</div>
          <div style="display:flex;gap:0.6rem;justify-content:flex-end;margin-top:1.25rem">
            <button class="btn-pill" data-act="cancel" style="padding:0.55rem 1.1rem;border-radius:8px;${cancelStyle};cursor:pointer">${esc(cancelLabel)}</button>
            <button class="btn-pill primary" data-act="confirm" style="padding:0.55rem 1.1rem;border-radius:8px;border:0;${confirmStyle};font-weight:600;cursor:pointer">${esc(confirmLabel)}</button>
          </div>
        </div>`;
      document.body.appendChild(overlay);
      const close = (val) => { overlay.remove(); resolve(val); };
      overlay.querySelector('[data-act="confirm"]').addEventListener('click', () => close(true));
      overlay.querySelector('[data-act="cancel"]').addEventListener('click', () => close(false));
      overlay.addEventListener('click', e => { if (e.target === overlay) close(false); });
      // Esc to cancel
      const onKey = (e) => { if (e.key === 'Escape') { document.removeEventListener('keydown', onKey); close(false); } };
      document.addEventListener('keydown', onKey);
    });
  }

  // Vaultwarden-specific setup popup. The web vault can't load over plain
  // HTTP on a non-localhost browser (WebCrypto / secure-context rule), so
  // most users hitting :8222 directly get a blank error and bounce. This
  // modal fires INSTEAD of the generic first-login dialog on a vaultwarden
  // tile click — pushes them straight at the Bitwarden BROWSER EXTENSION
  // path (which is exempt from the HTTPS rule), with browser-detected
  // install link, a click-to-copy Server URL, and the admin token from
  // state pulled in async. The web-vault path is left as a fallback note.
  async function vaultwardenSetupModal(launchUrl, container) {
    const serverUrl = `http://${location.hostname}:8222`;
    const ua = navigator.userAgent.toLowerCase();
    const isFirefox = /firefox/.test(ua) && !/seamonkey/.test(ua);
    const isSafari = /safari/.test(ua) && !/chrome|crios|fxios|opr|edg|brave/.test(ua);
    const isChromium = !isFirefox && !isSafari;
    const extInstallUrl = isFirefox
      ? 'https://addons.mozilla.org/firefox/addon/bitwarden-password-manager/'
      : isSafari
        ? 'https://apps.apple.com/app/bitwarden-password-manager/id1352778147'
        : 'https://chromewebstore.google.com/detail/bitwarden-password-manage/nngceckbapebfimnlniiiahkandclblb';
    const browserLabel = isFirefox ? 'Firefox' : isSafari ? 'Safari' : 'Chrome / Edge / Brave';

    // Pull admin token from the first-login-creds endpoint (state file).
    let adminToken = '';
    try {
      const r = await api('GET', `/containers/${encodeURIComponent(container)}/first-login-creds`);
      if (r && Array.isArray(r.matches)) {
        const tokenLine = r.matches.find((m) => /admin[_ -]token/i.test(m));
        if (tokenLine) {
          const colonIdx = tokenLine.indexOf(':');
          adminToken = colonIdx >= 0 ? tokenLine.slice(colonIdx + 1).trim() : '';
        }
      }
    } catch { /* token is optional — modal still renders */ }

    const stepStyle = 'display:flex;gap:0.7rem;padding:0.75rem 0;border-top:1px solid var(--border,rgba(255,255,255,0.08))';
    const stepNum = 'flex-shrink:0;width:1.5rem;height:1.5rem;border-radius:50%;background:var(--accent,#6366f1);color:#fff;display:grid;place-items:center;font-size:0.78rem;font-weight:700';
    const codeStyle = 'flex:1;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:0.82rem;background:var(--bg-card-darker,rgba(0,0,0,0.35));padding:0.4rem 0.6rem;border-radius:6px;border:1px solid var(--border,rgba(255,255,255,0.08));overflow-wrap:anywhere';
    const copyBtnStyle = 'flex-shrink:0;padding:0.4rem 0.7rem;border-radius:6px;border:1px solid var(--border,rgba(255,255,255,0.12));background:transparent;color:var(--text,#fff);cursor:pointer;font-size:0.78rem';
    const ctaStyle = 'display:inline-block;padding:0.5rem 0.85rem;border-radius:6px;background:var(--accent,#6366f1);color:#fff;text-decoration:none;font-weight:600;font-size:0.85rem';

    const bodyHtml = `
      <div style="margin-bottom:0.85rem">
        Vaultwarden's web vault won't load on a LAN IP — browser HTTPS rules block it. The Bitwarden <strong>browser extension</strong> is exempt and works the same. 60-second setup:
      </div>
      <div style="${stepStyle};border-top:none">
        <div style="${stepNum}">1</div>
        <div style="flex:1;align-self:center">
          Install the Bitwarden extension for ${esc(browserLabel)}:<br>
          <a href="${esc(extInstallUrl)}" target="_blank" rel="noopener" style="${ctaStyle};margin-top:0.4rem">Install Bitwarden →</a>
        </div>
      </div>
      <div style="${stepStyle}">
        <div style="${stepNum}">2</div>
        <div style="flex:1;align-self:center">
          Open the extension, click the <strong>gear icon</strong> (Settings), tap <strong>Self-hosted</strong>.
        </div>
      </div>
      <div style="${stepStyle}">
        <div style="${stepNum}">3</div>
        <div style="flex:1">
          Paste this as the <strong>Server URL</strong>, then Save and log in:
          <div style="display:flex;gap:0.5rem;align-items:center;margin-top:0.4rem">
            <code style="${codeStyle}">${esc(serverUrl)}</code>
            <button data-vw-copy="${esc(serverUrl)}" style="${copyBtnStyle}">Copy</button>
          </div>
        </div>
      </div>
      ${adminToken ? `
      <details style="margin-top:0.9rem;padding:0.7rem;border-radius:8px;background:var(--bg-card-darker,rgba(0,0,0,0.25));border:1px solid var(--border,rgba(255,255,255,0.06))">
        <summary style="cursor:pointer;font-weight:600;font-size:0.85rem">Admin panel token (only needed for /admin)</summary>
        <div style="display:flex;gap:0.5rem;align-items:center;margin-top:0.5rem">
          <code style="${codeStyle}">${esc(adminToken)}</code>
          <button data-vw-copy="${esc(adminToken)}" style="${copyBtnStyle}">Copy</button>
        </div>
      </details>` : ''}
      <details style="margin-top:0.55rem;padding:0.7rem;border-radius:8px;background:var(--bg-card-darker,rgba(0,0,0,0.25));border:1px solid var(--border,rgba(255,255,255,0.06))">
        <summary style="cursor:pointer;font-weight:600;font-size:0.85rem">On mobile? Use the Bitwarden app</summary>
        <div style="margin-top:0.5rem;font-size:0.85rem;line-height:1.45">
          Install the Bitwarden app from the App Store / Play Store. Tap the <strong>gear icon</strong> → <strong>Self-hosted environment</strong>, set Server URL to <code style="font-family:ui-monospace,Menlo,monospace">${esc(serverUrl)}</code>, save and log in.
        </div>
      </details>
    `;

    // confirmDialog renders the body as HTML directly. Wire the Copy buttons
    // after the overlay is appended — we listen on the document so we don't
    // need a handle to the overlay element.
    const copyHandler = (e) => {
      const btn = e.target.closest('button[data-vw-copy]');
      if (!btn) return;
      const text = btn.getAttribute('data-vw-copy') || '';
      if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
          const orig = btn.textContent;
          btn.textContent = 'Copied!';
          setTimeout(() => { btn.textContent = orig; }, 1200);
        }).catch(() => {});
      }
    };
    document.addEventListener('click', copyHandler);

    const ok = await confirmDialog({
      title: 'Set up Vaultwarden',
      body: bodyHtml,
      confirmLabel: 'Open Vaultwarden anyway',
      cancelLabel: 'Done',
    });

    document.removeEventListener('click', copyHandler);
    if (ok && launchUrl) {
      window.open(launchUrl, '_blank', 'noopener');
    }
  }

  // --- Loading Button Helper ---
  function btnLoading(btn, loading) {
    if (!btn) return;
    if (loading) {
      btn.classList.add('btn-loading');
      btn.disabled = true;
      btn._origText = btn.textContent;
    } else {
      btn.classList.remove('btn-loading');
      btn.disabled = false;
      if (btn._origText) btn.textContent = btn._origText;
    }
  }

  // Escape HTML to prevent XSS from API data
  function esc(s) {
    if (!s) return '';
    const d = document.createElement('div');
    d.textContent = s;
    // textContent/innerHTML only encodes <, >, &. Also encode quotes
    // to prevent breakout from HTML attributes and JS string contexts.
    return d.innerHTML.replace(/'/g, '&#39;').replace(/"/g, '&quot;');
  }

  // Render free-form module text (tips, env_var prompts) with clickable
  // links: markdown-style [label](url) becomes a real anchor with the
  // label as visible text, and any leftover bare URL gets auto-linkified.
  // Both label and URL are esc()'d before going into HTML so this is
  // safe to call on user-controllable strings.
  //
  // Used by: App Store tips, wizard-config form prompts, and the
  // batch-config form prompts. Plain esc() should be reserved for
  // contexts that genuinely shouldn't render links (titles, attributes).
  function linkifyHtml(raw) {
    if (!raw) return '';
    const A = (label, href) =>
      `<a href="${esc(href)}" target="_blank" rel="noopener" style="color:var(--accent);text-decoration:underline">${esc(label)}</a>`;
    // Parse [label](url) on the raw text first so we can extract label+url
    // before HTML-escaping mangles the brackets/parens.
    const parts = [];
    let last = 0;
    const mdRe = /\[([^\]]+)\]\(([^\s)]+)\)/g;
    let m;
    while ((m = mdRe.exec(raw)) !== null) {
      if (m.index > last) parts.push({ kind: 'text', text: raw.slice(last, m.index) });
      parts.push({ kind: 'link', label: m[1], url: m[2] });
      last = m.index + m[0].length;
    }
    if (last < raw.length) parts.push({ kind: 'text', text: raw.slice(last) });
    return parts.map((p) => {
      if (p.kind === 'link') return A(p.label, p.url);
      // Text segment: escape, then auto-linkify any bare URLs that the
      // module author didn't bother wrapping in markdown.
      return esc(p.text)
        .replace(/(https?:\/\/[A-Za-z0-9.\-_/?#=&%~+]+)/g, '<a href="$1" target="_blank" rel="noopener" style="color:var(--accent);text-decoration:underline">$1</a>')
        .replace(/\b([a-z0-9-]+\.tomspark\.tech)\b/g, '<a href="https://$1" target="_blank" rel="noopener" style="color:var(--accent);text-decoration:underline">$1</a>');
    }).join('');
  }

  // Convert bright theme colors to dark-mode-friendly semi-transparent backgrounds.
  // Server-side themes use Material "50" tints (#e8f5e9, #ede7f6, etc.) designed for
  // light backgrounds. On our dark theme these look jarring. This maps the text color
  // to a subtle rgba() glow instead.
  function darkBg(color) {
    // Parse hex color to rgba with low opacity
    if (!color || color === '#f5f5f7' || color === '#6e6e73') return 'rgba(255,255,255,0.06)';
    const hex = color.replace('#', '');
    if (hex.length !== 6) return 'rgba(255,255,255,0.06)';
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    return `rgba(${r},${g},${b},0.12)`;
  }

  function meta(name) {
    const fallbackId = name.replace('sb-', '');
    return _serviceMeta[name] || { emoji: '\uD83D\uDCE6', color: '#6e6e73', bg: '#f5f5f7', name: fallbackId, port: null, desc: '', tip: '', category: 'other', svcId: fallbackId };
  }

  // --- Confirm Dialog ---

  function confirm(title, message, opts = {}) {
    return new Promise((resolve) => {
      const overlay = $('#confirm-overlay');
      $('#confirm-title').textContent = title;
      $('#confirm-message').textContent = message;
      const okBtn = $('#confirm-ok');
      const cancelBtn = $('#confirm-cancel');
      if (opts.confirmLabel) okBtn.textContent = opts.confirmLabel;
      else okBtn.textContent = 'Confirm';
      if (opts.cancelLabel) cancelBtn.textContent = opts.cancelLabel;
      else cancelBtn.textContent = 'Cancel';

      // Optional secondary link injected below the message — used by the
      // first-login modal to surface a "Read the full guide →" pointer
      // at crushcodeworks.com/guides/... when the module declares guide_url.
      // The link is appended once into the modal DOM and reused across
      // calls; if a later call doesn't pass linkUrl, the element is
      // hidden so it doesn't leak.
      {
        const msgEl = $('#confirm-message');
        let linkEl = overlay.querySelector('.confirm-extra-link');
        if (opts.linkUrl && opts.linkLabel) {
          if (!linkEl) {
            linkEl = document.createElement('a');
            linkEl.className = 'confirm-extra-link';
            linkEl.target = '_blank';
            linkEl.rel = 'noopener';
            linkEl.style.cssText = 'display:inline-block;margin-top:0.85em;font-size:0.92em;color:var(--accent,#6366f1);text-decoration:none;font-weight:600';
            msgEl.parentElement.insertBefore(linkEl, msgEl.nextSibling);
          }
          linkEl.href = opts.linkUrl;
          linkEl.textContent = opts.linkLabel;
          linkEl.style.display = '';
        } else if (linkEl) {
          linkEl.style.display = 'none';
        }
      }

      // Optional "Don't show again" / similar opt-in checkbox. Injected
      // once into the modal DOM and reused across calls. Callers that
      // don't pass opts.checkboxLabel get the traditional boolean
      // return; callers that do get { confirmed, checked }.
      let checkboxEl = null;
      const useCheckbox = !!opts.checkboxLabel;
      if (useCheckbox) {
        let wrap = overlay.querySelector('.confirm-checkbox');
        if (!wrap) {
          wrap = document.createElement('label');
          wrap.className = 'confirm-checkbox';
          wrap.style.cssText = 'display:flex;align-items:center;gap:0.5em;margin-top:1em;font-size:0.9em;cursor:pointer';
          wrap.innerHTML = '<input type="checkbox" id="confirm-checkbox-input" style="cursor:pointer"><span id="confirm-checkbox-label"></span>';
          const buttonsRow = overlay.querySelector('.modal-buttons, .modal-actions, .button-row') || okBtn.parentElement;
          buttonsRow.parentElement.insertBefore(wrap, buttonsRow);
        }
        wrap.style.display = '';
        const input = wrap.querySelector('#confirm-checkbox-input');
        input.checked = false;
        wrap.querySelector('#confirm-checkbox-label').textContent = opts.checkboxLabel;
        checkboxEl = input;
      } else {
        // Hide any previously-inserted checkbox so it doesn't leak
        // into non-checkbox confirms.
        const wrap = overlay.querySelector('.confirm-checkbox');
        if (wrap) wrap.style.display = 'none';
      }

      // Remember who had focus before the modal opened so we can
      // restore it on close — a basic but load-bearing accessibility
      // win for keyboard users. Without this, Tab after closing the
      // modal lands on whatever was focused last, which is usually
      // far from where the user was working.
      const previouslyFocused = document.activeElement;
      show(overlay);

      // Focus the primary action so Enter confirms immediately and
      // screen readers announce where they are.
      setTimeout(() => okBtn.focus(), 50);

      // Focus trap: keep Tab inside the modal until it closes.
      // Escape resolves as cancel (non-destructive default).
      function onKey(e) {
        if (e.key === 'Escape') { e.preventDefault(); onCancel(); return; }
        if (e.key !== 'Tab') return;
        const focusable = overlay.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (!focusable.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
      function resolveWith(confirmed) {
        const checked = !!(checkboxEl && checkboxEl.checked);
        cleanup();
        resolve(useCheckbox ? { confirmed, checked } : confirmed);
      }
      function cleanup() {
        hide(overlay);
        okBtn.removeEventListener('click', onOk);
        cancelBtn.removeEventListener('click', onCancel);
        document.removeEventListener('keydown', onKey);
        if (previouslyFocused && previouslyFocused.focus) {
          try { previouslyFocused.focus(); } catch {}
        }
      }
      function onOk() { resolveWith(true); }
      function onCancel() { resolveWith(false); }

      okBtn.addEventListener('click', onOk);
      cancelBtn.addEventListener('click', onCancel);
      document.addEventListener('keydown', onKey);
    });
  }

  // --- Auth ---

  async function checkAuth() {
    try {
      const s = await api('GET', '/auth/status');
      if (s.authenticated) { showDashboard(); }
      else if (s.firstRun) { showFirstRun(); }
      else { showLogin(); }
    } catch { showLogin(); }
  }

  function showLogin() {
    show($('#login-screen'));
    hide($('#dashboard'));
    $('#login-title').textContent = 'Welcome to OpenBox';
    $('#login-sub').textContent = 'Your private server is ready for you.';
    $('#login-password').placeholder = 'Enter your password';
    $('#login-btn').textContent = 'Let me in';
    $('#login-password').focus();
    // Surface the post-update flag if the user just got bounced here
    // by a self-update reload. Cleared by the welcome modal post-login.
    try {
      const banner = $('#login-update-banner');
      if (banner) {
        if (localStorage.getItem('sb-update-just-completed')) banner.classList.remove('hidden');
        else banner.classList.add('hidden');
      }
    } catch {}
  }

  function showFirstRun() {
    show($('#login-screen'));
    hide($('#dashboard'));
    const tokenField = $('#login-bootstrap-token');
    if (tokenField) {
      tokenField.classList.remove('hidden');
      tokenField.value = '';
    }
    $('#login-title').textContent = 'Claim your OpenBox';
    $('#login-sub').textContent = 'Paste the one-time bootstrap token from the installer output, then pick an admin password (8+ characters).';
    $('#login-password').placeholder = 'Create a password (8+ characters)';
    $('#login-btn').textContent = 'Claim server';
    if (tokenField) tokenField.focus();
    else $('#login-password').focus();
  }

  async function showDashboard() {
    hide($('#login-screen'));

    // Codex round 6 #3/#4: show-dashboard used to fire /api/license
    // and /api/auth/status sequentially (two round-trips before the
    // page even rendered). /api/bootstrap (added v1.5.100) returns
    // auth + license + wizard + modules + containers + vpn in one
    // response — serial await becomes one request.
    //
    // We still fall back to the old two-call flow if the bootstrap
    // endpoint is missing (e.g. when the dashboard is running a
    // version older than what its client is hitting during a staged
    // rollout). Cache the response on window._sbBootstrap so later
    // loaders can skip their own re-fetch.
    let boot = null;
    try {
      const bootResp = await fetch('/api/bootstrap', { credentials: 'same-origin' });
      if (bootResp.ok) boot = await bootResp.json();
    } catch {}
    // v1.6.3: no license-screen gate. OpenBox is free for personal
    // use; activation is optional and lives in Settings. The dashboard
    // opens directly after admin claim + setup wizard. /api/bootstrap
    // auto-creates the license-skipped marker on first run if no
    // license is set, so the relaxed license middleware passes.
    if (boot && boot.authenticated) {
      window._sbBootstrap = boot;
      hide($('#license-screen'));
      if (boot.needsSetup) {
        show($('#dashboard'));
        await loadMetadata();
        initSocket();
        setupOperationListeners();
        showSetupWizard();
        return;
      }
    } else {
      // Fallback: boot failed or unauth.
      hide($('#license-screen'));
      try {
        const status = await api('GET', '/auth/status');
        if (status.needsSetup) {
          show($('#dashboard'));
          await loadMetadata();
          initSocket();
          setupOperationListeners();
          showSetupWizard();
          return;
        }
      } catch {}
    }

    show($('#dashboard'));
    await loadMetadata();
    initSocket();
    setupOperationListeners();
    setupAlertListeners();
    loadHome();
    loadSystemInfo();
    await loadLicenseStatus();
    // theme.js and chat.js fetch /api/license on DOMContentLoaded (before
    // login), get 401, and cache "free" forever. Fire an event after the
    // real authenticated license check so they can re-render as Pro.
    document.dispatchEvent(new CustomEvent('openbox:license-ready'));
    loadApiKeyStatus();
    loadAlerts();
    renderHelpServices();
    showOnboarding();
    setupQuickActions();
    showPostUpgradeWelcome();
  }

  // Post-upgrade welcome modal. Hits /api/last-upgrade once on login;
  // if the helper script left a flag (set after a successful self-
  // update), pops up a celebratory summary with the version bump and
  // the changelog entries between the old and new versions. Endpoint
  // is one-shot (deletes flag on read) so the modal won't reappear.
  async function showPostUpgradeWelcome() {
    try {
      const data = await api('GET', '/last-upgrade');
      if (!data || data.none || !data.from || !data.to) return;
      // Clear the login-screen "Update complete" banner flag now that
      // we're surfacing the full welcome modal.
      try { localStorage.removeItem('sb-update-just-completed'); } catch {}
      let entries = [];
      try {
        const r = await fetch('/changelog.json', { cache: 'no-store' });
        const cl = await r.json();
        const all = cl.releases || [];
        // Pick every release whose version is > from AND <= to.
        const cmp = (a, b) => {
          const pa = a.split('.').map(Number);
          const pb = b.split('.').map(Number);
          for (let i = 0; i < 3; i++) {
            if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
          }
          return 0;
        };
        entries = all.filter(r => cmp(r.version, data.from) > 0 && cmp(r.version, data.to) <= 0);
      } catch { /* changelog optional */ }
      const items = entries.flatMap(e => [
        `<h3 style="margin:1rem 0 0.5rem;font-size:1rem;color:var(--accent)">v${esc(e.version)} — ${esc(e.title || '')}</h3>`,
        '<ul style="margin:0;padding-left:1.25rem;">',
        ...(e.items || []).map(item => `<li style="margin-bottom:0.5rem;line-height:1.4">${esc(item)}</li>`),
        '</ul>',
      ]).join('');
      const body = items
        || `<p>OpenBox upgraded successfully. Check the <a href="/changelog.html" target="_blank" rel="noopener">full changelog</a> for what's new.</p>`;
      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;padding:1.5rem';
      overlay.innerHTML = `
        <div style="background:var(--surface,#1a1a1f);max-width:640px;max-height:80vh;overflow:auto;border-radius:1rem;padding:1.75rem;border:1px solid var(--border,rgba(255,255,255,0.1));box-shadow:0 20px 60px rgba(0,0,0,0.5);color:var(--text,#fff)">
          <div style="display:flex;align-items:center;gap:0.7rem;margin-bottom:0.4rem">
            <span style="display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;background:var(--accent,#6366f1);color:white;font-weight:700;font-size:1.2rem;flex-shrink:0">✓</span>
            <h2 style="margin:0;font-size:1.5rem">Update complete!</h2>
          </div>
          <p style="margin:0 0 1.25rem;color:var(--text-muted,rgba(255,255,255,0.7));font-size:0.95rem">OpenBox upgraded <strong>${esc(data.from)}</strong> → <strong>${esc(data.to)}</strong>. Here's what changed:</p>
          <div>${body}</div>
          <div style="margin-top:1.5rem;display:flex;justify-content:flex-end">
            <button class="btn-main" id="post-upgrade-close" style="padding:0.65rem 1.5rem">Got it</button>
          </div>
        </div>`;
      document.body.appendChild(overlay);
      const close = () => overlay.remove();
      overlay.querySelector('#post-upgrade-close').addEventListener('click', close);
      overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
    } catch { /* not licensed / endpoint missing — skip silently */ }
  }

  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('#login-btn');
    btnLoading(btn, true);
    try {
      const payload = { password: $('#login-password').value };
      const tokenEl = $('#login-bootstrap-token');
      if (tokenEl && !tokenEl.classList.contains('hidden')) {
        payload.bootstrapToken = tokenEl.value.trim();
      }
      const result = await api('POST', '/login', payload);
      if (result.firstRun) {
        toast('Password set! Welcome to OpenBox!', 'success');
        sessionStorage.setItem('sb-first-run', '1');
      }
      showDashboard();
    } catch (err) {
      const el = $('#login-error');
      el.textContent = err.message;
      el.classList.remove('hidden');
      // If the server says first-run + bootstrap required, reveal the
      // bootstrap token field and rewrite the form copy.
      if (err.bootstrapRequired || /bootstrap token/i.test(err.message || '')) {
        const tokenField = $('#login-bootstrap-token');
        const title = $('#login-title');
        const sub = $('#login-sub');
        const submit = $('#login-btn');
        if (tokenField) tokenField.classList.remove('hidden');
        if (title) title.textContent = 'Claim your OpenBox';
        if (sub) sub.textContent = 'Paste the one-time token from the installer output, then pick an admin password.';
        if (submit) submit.textContent = 'Claim server';
      }
    } finally {
      btnLoading(btn, false);
    }
  });

  // Data-protection banner — visible by default, dismissed when the
  // user clicks Dismiss or when we detect a full backup has been run.
  // Uses localStorage so it stays dismissed across refreshes, but
  // resets if the user clears browser data (intentional: better to
  // nag than to silently let data go unprotected).
  (function () {
    const banner = $('#data-protection-banner');
    const dismiss = $('#data-protection-dismiss');
    if (!banner) return;
    if (localStorage.getItem('sb-data-protection-dismissed')) {
      banner.style.display = 'none';
      return;
    }
    // Also hide if a full backup exists (check via /api/backups if available)
    // Codex round 4 finding #10: backup API returns `filename` not `name`,
    // so the check never matched and the "no backup" banner stuck around
    // even after successful backups.
    (async () => {
      try {
        const backups = await api('GET', '/backups');
        if (Array.isArray(backups) && backups.some(b => (b.filename || b.name || '').includes('-full-'))) {
          banner.style.display = 'none';
          return;
        }
      } catch {}
    })();
    if (dismiss) {
      dismiss.addEventListener('click', () => {
        localStorage.setItem('sb-data-protection-dismissed', '1');
        banner.style.display = 'none';
      });
    }
  })();

  // Forgot-password link on the login screen. Shows a modal that
  // explains the CLI recovery path — see #forgot-password-overlay in
  // index.html for the rationale behind doing this via sudo openbox
  // reset-password instead of exposing a network endpoint.
  const forgotLink = $('#login-forgot-link');
  const forgotOverlay = $('#forgot-password-overlay');
  const forgotClose = $('#forgot-password-close');
  if (forgotLink && forgotOverlay) {
    forgotLink.addEventListener('click', (e) => {
      e.preventDefault();
      show(forgotOverlay);
    });
  }
  if (forgotClose && forgotOverlay) {
    forgotClose.addEventListener('click', () => hide(forgotOverlay));
  }

  $('#logout-btn').addEventListener('click', async () => {
    try { await api('POST', '/logout'); } catch {}
    if (socket) socket.disconnect(); socket = null;
    _storeData = null; // clear cache on logout
    showLogin();
  });

  // License activation form — shown after login when /api/license says
  // licensed:false. On success, rerun showDashboard() to advance past
  // the license gate into the real dashboard + wizard flow.
  const licenseForm = $('#license-form');
  if (licenseForm) {
    licenseForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = $('#license-btn');
      const errEl = $('#license-error');
      errEl.classList.add('hidden');
      errEl.textContent = '';
      btnLoading(btn, true);
      try {
        const key = $('#license-key-input').value.trim().toUpperCase();
        const purchaseEmail = ($('#license-email-input')?.value || '').trim().toLowerCase();
        // v1.6.0 free pivot: empty key + email → mint a free personal-use
        // key for the email. The worker's POST /issue-free endpoint
        // returns { key, email } and we feed it back into /license/activate.
        let activateKey = key;
        if (!activateKey && purchaseEmail) {
          const minted = await api('POST', '/license/issue-free', { email: purchaseEmail });
          if (minted && minted.key) {
            activateKey = minted.key;
          } else {
            errEl.textContent = (minted && minted.error) || 'Could not mint a free key. Try again or paste an existing one.';
            errEl.classList.remove('hidden');
            return;
          }
        }
        const result = await api('POST', '/license/activate', { key: activateKey, purchaseEmail });
        if (result && (result.ok || result.success)) {
          toast('License activated.', 'success');
          hide($('#license-screen'));
          await showDashboard();
          return;
        }
        errEl.textContent = (result && result.error) || 'Activation failed. Check the key and try again.';
        errEl.classList.remove('hidden');
      } catch (err) {
        errEl.textContent = err.message || 'Activation failed. Check your network and try again.';
        errEl.classList.remove('hidden');
      } finally {
        btnLoading(btn, false);
      }
    });
  }

  // "Open dashboard" — drop the user into the dashboard without a key.
  // Auto-updates stay disabled (hasValidLicense() is false), but every
  // other feature works. Customer can activate later from Settings.
  // Wires both the new primary button (#license-skip-btn) and the old
  // text-link id for any cached-page hold-over.
  const wireSkip = (el) => {
    if (!el) return;
    el.addEventListener('click', async (e) => {
      e.preventDefault();
      try {
        await api('POST', '/license/skip', {});
      } catch { /* skip endpoint may 404 on older servers; UI continues */ }
      hide($('#license-screen'));
      await showDashboard();
    });
  };
  wireSkip(document.getElementById('license-skip-btn'));
  wireSkip(document.getElementById('license-skip-link'));

  // v1.6.3: inline license-activation form in Settings → License.
  // Same email-only flow as the (now-removed) welcome-screen form,
  // but lives inside Settings as an opt-in panel.
  const licenseFormInline = document.getElementById('license-form-inline');
  if (licenseFormInline) {
    licenseFormInline.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = document.getElementById('license-btn-inline');
      const errEl = document.getElementById('license-error-inline');
      if (errEl) { errEl.classList.add('hidden'); errEl.textContent = ''; }
      btnLoading(btn, true);
      try {
        const key = (document.getElementById('license-key-input-inline').value || '').trim().toUpperCase();
        const purchaseEmail = (document.getElementById('license-email-input-inline').value || '').trim().toLowerCase();
        let activateKey = key;
        if (!activateKey && purchaseEmail) {
          const minted = await api('POST', '/license/issue-free', { email: purchaseEmail });
          if (minted && minted.key) {
            activateKey = minted.key;
          } else {
            if (errEl) {
              errEl.textContent = (minted && minted.error) || 'Could not mint a free key. Try again or paste an existing one.';
              errEl.classList.remove('hidden');
            }
            return;
          }
        }
        const result = await api('POST', '/license/activate', { key: activateKey, purchaseEmail });
        if (result && (result.ok || result.success)) {
          toast('License activated. Auto-updates are now enabled.', 'success');
          await loadLicenseStatus();  // Refresh the panel display
          return;
        }
        if (errEl) {
          errEl.textContent = (result && result.error) || 'Activation failed. Check the key and try again.';
          errEl.classList.remove('hidden');
        }
      } catch (err) {
        if (errEl) {
          errEl.textContent = err.message || 'Activation failed. Check your network and try again.';
          errEl.classList.remove('hidden');
        }
      } finally {
        btnLoading(btn, false);
      }
    });
  }

  // --- Navigation ---

  $$('.tab').forEach(t => t.addEventListener('click', (e) => {
    // External tabs (the Community link that opens demox.world) have
    // no data-page and should navigate normally via the href.
    if (!t.dataset.page) return;
    e.preventDefault();
    switchPage(t.dataset.page);
  }));

  // Also catch any other element (e.g. home bento shortcuts) that carries
  // data-page and wants to trigger a page switch. Delegated so new elements
  // added later work automatically.
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-page]');
    if (!el) return;
    if (el.classList.contains('tab')) return; // already handled above
    const page = el.dataset.page;
    if (!page) return;
    e.preventDefault();
    switchPage(page);
  });

  function switchPage(page) {
    $$('.tab').forEach(t => {
      const isActive = t.dataset.page === page;
      t.classList.toggle('active', isActive);
      if (isActive) t.setAttribute('aria-current', 'page');
      else t.removeAttribute('aria-current');
    });
    $$('.page').forEach(p => { p.classList.add('hidden'); p.classList.remove('active'); });
    const el = $(`#page-${page}`);
    if (el) { el.classList.remove('hidden'); el.classList.add('active'); }

    switch (page) {
      case 'home': loadHome(); break;
      case 'apps': loadApps(); break;
      case 'updates': loadUpdatesPage(); break;
      case 'releases': loadReleasesPage(); break;
      case 'logs': loadLogs(); break;
      case 'settings': loadSettings(); break;
    }
  }

  // --- Socket ---

  function initSocket() {
    if (socket) return;
    socket = io();

    // State store: snapshot + deltas → in-memory reducer → renderHome.
    // Push model. No polling. renderHome is called when state actually
    // changes, not on a timer.
    if (window.SB && window.SB.store) {
      socket.on('state:snapshot', (list) => {
        window.SB.store.applySnapshot(list);
      });
      socket.on('state:delta', (delta) => {
        window.SB.store.applyDelta(delta);
        // Activity feed deltas stream in from the state-store ring
        // buffer — every container lifecycle event appends a new row
        // to the home-page Activity card in real time.
        if (delta && delta.type === 'activity:add') {
          // Prepend to the current client-side list.
          if (!window._activityCache) window._activityCache = [];
          window._activityCache.unshift(delta.entry);
          if (window._activityCache.length > ACTIVITY_MAX) {
            window._activityCache.length = ACTIVITY_MAX;
          }
          renderActivity(window._activityCache);
        }
      });
      window.SB.store.subscribe((list) => {
        _containers = list;
        renderHome(list);
        resubscribeVisibleStats();
      });
    } else {
      // Fallback for older clients / bootstrap order edge cases.
      socket.on('status:update', renderHome);
    }

    // Streaming per-container stats. The old path fired N HTTP GETs
    // on every render. Now: one persistent Docker stream per visible
    // container, deltas pushed over the socket. See resubscribeVisibleStats.
    socket.on('stats:update', ({ id, cpu, memory }) => {
      const cpuEl = document.getElementById(`cpu-${id}`);
      const memEl = document.getElementById(`mem-${id}`);
      if (cpuEl) cpuEl.textContent = cpu.toFixed(1) + '%';
      if (memEl) memEl.textContent = formatBytes(memory.usage);
    });

    socket.on('hoststats:update', renderGauges);
    // Filter + follow + download support for the Logs viewer.
    // Before v1.5.49 the log window streamed the raw feed with no
    // way to filter or pause auto-scroll — noisy containers were
    // unusable for debugging.
    window._logBuffer = [];
    window._logCurrentContainer = null;
    socket.on('logs:data', ({ line }) => {
      const o = $('#log-output');
      const filterEl = $('#log-filter');
      const followEl = $('#log-follow');
      const filterText = (filterEl?.value || '').toLowerCase();
      // Keep full buffer for filter-toggle + download; append to the
      // DOM only if the filter matches.
      window._logBuffer.push(line);
      if (window._logBuffer.length > 5000) window._logBuffer.shift();
      if (!filterText || line.toLowerCase().includes(filterText)) {
        o.textContent += line;
        if (!followEl || followEl.checked) o.scrollTop = o.scrollHeight;
      }
    });

    // Surface the result of a VPN-save-triggered media restart. The
    // POST /api/vpn/config returns 200 immediately while compose is
    // still recreating containers — without this listener, the user
    // would see "VPN configured" even when the restart itself choked
    // (lock contention, bad creds, gluetun unhealthy). Tie the toast
    // to the actual outcome so they know whether to retry.
    socket.on('vpn:restart-complete', (payload) => {
      if (payload && payload.success) {
        toast('VPN settings applied — media stack restarted with new config.', 'success');
      } else {
        const detail = (payload && payload.error) || 'Media restart failed after saving VPN settings.';
        toast(detail, 'error', 10000);
      }
    });

    const subscribeAll = () => {
      socket.emit('state:subscribe');
      socket.emit('hoststats:subscribe');
    };
    subscribeAll();
    socket.on('connect', subscribeAll);
  }

  // --- Visibility-gated stats subscriptions ---
  // When the tab is hidden we tear down per-container stats streams
  // entirely — the server stops pulling from Docker, the daemon stops
  // computing. Zero work while nobody's watching. When the tab comes
  // back we resubscribe for whichever containers are currently rendered.
  let _subscribedStats = new Set();
  function resubscribeVisibleStats() {
    if (!socket) return;
    if (document.visibilityState === 'hidden') {
      if (_subscribedStats.size) {
        socket.emit('stats:unsubscribe-all');
        _subscribedStats.clear();
      }
      return;
    }
    const want = new Set((_containers || []).filter(c => c.state === 'running').map(c => c.id));
    const toAdd = [];
    const toRemove = [];
    for (const id of want) if (!_subscribedStats.has(id)) toAdd.push(id);
    for (const id of _subscribedStats) if (!want.has(id)) toRemove.push(id);
    if (toAdd.length) socket.emit('stats:subscribe', toAdd);
    if (toRemove.length) socket.emit('stats:unsubscribe', toRemove);
    _subscribedStats = want;
  }
  document.addEventListener('visibilitychange', resubscribeVisibleStats);

  // --- Home page: Activity feed, Release, Network, Backup, Pro upsell ---
  //
  // All four fill the empty space on the home page. Data is fetched
  // once on home-page load and — for activity — refreshed via the
  // state:delta socket channel so new container events appear in real
  // time without polling.
  const ACTIVITY_MAX = 15;
  const ACTIVITY_ACTION_WORDS = {
    start: 'started',
    stop: 'stopped',
    die: 'crashed',
    restart: 'restarted',
    create: 'created',
    destroy: 'removed',
    kill: 'killed',
    'health_status: healthy': 'is healthy',
    'health_status: unhealthy': 'went unhealthy',
  };
  function relTime(ts) {
    const s = Math.max(0, (Date.now() - ts) / 1000);
    if (s < 60) return `${Math.floor(s)}s ago`;
    if (s < 3600) return `${Math.floor(s / 60)}m ago`;
    if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
    return `${Math.floor(s / 86400)}d ago`;
  }
  function shortActionClass(a) {
    if (a.includes('healthy')) return 'healthy';
    if (a.includes('unhealthy')) return 'unhealthy';
    return a.split(':')[0].trim();
  }
  function renderActivity(events) {
    const list = document.getElementById('activity-list');
    if (!list) return;
    if (!events || events.length === 0) {
      list.innerHTML = '<li class="activity-empty">Nothing\'s happened yet. OpenBox will log container events here as they happen.</li>';
      return;
    }
    list.innerHTML = events.slice(0, ACTIVITY_MAX).map(e => {
      const label = ACTIVITY_ACTION_WORDS[e.action] || e.action;
      const cls = shortActionClass(e.action);
      return `<li class="activity-row">
        <span class="activity-dot ${esc(cls)}"></span>
        <span class="activity-row-name">${esc(e.name)}</span>
        <span class="activity-row-action">${esc(label)}</span>
        <span class="activity-row-time">${esc(relTime(e.ts))}</span>
      </li>`;
    }).join('');
  }
  async function loadActivity() {
    try {
      const data = await api('GET', '/activity');
      window._activityCache = (data.events || []).slice(0, ACTIVITY_MAX);
      renderActivity(window._activityCache);
    } catch { /* silent */ }
  }

  async function loadLatestRelease() {
    try {
      const res = await fetch('/changelog.json', { cache: 'no-cache' });
      if (!res.ok) return;
      const data = await res.json();
      const latest = (data.releases || [])[0];
      if (!latest) return;
      const verEl = document.getElementById('release-version');
      if (verEl) verEl.textContent = 'v' + latest.version;
      const body = document.getElementById('release-body');
      if (!body) return;
      // Full day/month/year date — "Apr 13, 2026". Also compute a
      // relative "shipped today / yesterday / N days ago" for context.
      let dateHtml = '';
      if (latest.date) {
        const dt = new Date(latest.date);
        const full = dt.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
        const daysAgo = Math.floor((Date.now() - dt.getTime()) / 86400000);
        let rel = '';
        if (daysAgo === 0) rel = 'shipped today';
        else if (daysAgo === 1) rel = 'shipped yesterday';
        else if (daysAgo < 7) rel = `shipped ${daysAgo} days ago`;
        else if (daysAgo < 30) rel = `shipped ${Math.floor(daysAgo / 7)}w ago`;
        else rel = `shipped ${Math.floor(daysAgo / 30)}mo ago`;
        dateHtml = `<div class="release-date"><time datetime="${esc(latest.date)}">${esc(full)}</time> · ${esc(rel)}</div>`;
      }
      const tagHtml = latest.tag ? `<span class="release-tag">${esc(latest.tag)}</span>` : '';
      const itemCount = (latest.items || []).length;
      const firstItem = (latest.items || [])[0] || '';
      body.innerHTML = `
        ${tagHtml}
        ${dateHtml}
        <h3 class="release-title">${esc(latest.title || 'OpenBox update')}</h3>
        <p class="release-summary">${esc(firstItem)}${itemCount > 1 ? ` <span style="color:var(--text-muted)">(+${itemCount - 1} more)</span>` : ''}</p>
        <a class="release-link" data-page="releases" href="#">See what's new →</a>`;
    } catch { /* silent */ }
  }

  async function loadNetwork() {
    try {
      const data = await api('GET', '/network');
      const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
      set('network-hostname', data.hostname || '—');
      set('network-domain', data.domain || 'not set');
      set('network-dashport', `:${data.dashboardPort || '8443'}`);
      const addrs = (data.addresses || []).map(a => `${a.iface}: ${a.address}`).join(' · ') || 'none';
      set('network-lan', addrs);
    } catch { /* silent */ }
  }

  async function loadBackupStatus() {
    try {
      const data = await api('GET', '/backup/status');
      const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
      set('backup-meta', data.count > 0 ? `${data.count} saved` : '0');
      if (data.lastBackupAt) {
        set('backup-last', relTime(data.lastBackupAt));
      } else {
        set('backup-last', 'never');
      }
      if (data.lastBackupSize) {
        set('backup-size', formatBytes(data.lastBackupSize));
      } else {
        set('backup-size', '—');
      }
      const encEl = document.getElementById('backup-encryption');
      if (encEl) {
        encEl.textContent = data.encrypted ? 'On' : 'Off';
        encEl.classList.toggle('backup-encryption-on', !!data.encrypted);
        encEl.classList.toggle('backup-encryption-off', !data.encrypted);
      }
    } catch { /* silent */ }
  }

  async function maybeShowProUpsell() {
    // 1.4.0: single-tier — the bento pro-upsell card is gone and
    // anyone who reaches this function is already licensed. Kept as
    // a no-op so the one call site in the home render path doesn't
    // need to be ripped out.
    const el = document.getElementById('bento-pro-upsell');
    if (el) el.classList.add('hidden');
  }

  // --- System Gauges ---

  function updateGauge(id, percent) {
    const ring = $(`#${id}`);
    if (!ring) return;
    const fill = ring.querySelector('.gauge-fill');
    const text = ring.querySelector('.gauge-text');
    if (!fill || !text) return;
    fill.setAttribute('stroke-dasharray', `${percent}, 100`);
    fill.classList.remove('warn', 'danger');
    if (percent > 80) fill.classList.add('danger');
    else if (percent > 60) fill.classList.add('warn');
    text.textContent = `${percent}%`;
  }

  function formatUptime(seconds) {
    const d = Math.floor(seconds / 86400);
    const h = Math.floor((seconds % 86400) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    if (d > 0) return `${d}d ${h}h`;
    if (h > 0) return `${h}h ${m}m`;
    return `${m}m`;
  }

  function renderGauges(stats) {
    updateGauge('gauge-cpu', stats.cpu.percent);
    updateGauge('gauge-ram', stats.memory.percent);
    updateGauge('gauge-disk', stats.disk.percent);

    const ramDetail = $(`#gauge-ram-detail`);
    if (ramDetail) ramDetail.textContent = `${formatBytes(stats.memory.used)} / ${formatBytes(stats.memory.total)}`;

    const diskDetail = $(`#gauge-disk-detail`);
    if (diskDetail && stats.disk.total) diskDetail.textContent = `${formatBytes(stats.disk.used)} / ${formatBytes(stats.disk.total)}`;

    const uptime = $(`#gauge-uptime`);
    if (uptime) uptime.textContent = formatUptime(stats.uptime);

    // Live topbar stats
    const cpuPct = Math.round(stats.cpu.percent);
    const ramPct = Math.round(stats.memory.percent);
    const diskPct = Math.round(stats.disk.percent);
    const tCpu = $('#topbar-cpu');
    const tRam = $('#topbar-ram');
    const tDisk = $('#topbar-disk');
    if (tCpu) {
      tCpu.textContent = cpuPct + '%';
      tCpu.className = 'topbar-stat' + (cpuPct > 80 ? ' warn' : '');
    }
    if (tRam) {
      tRam.textContent = ramPct + '%';
      tRam.className = 'topbar-stat' + (ramPct > 85 ? ' warn' : '');
    }
    if (tDisk) {
      tDisk.textContent = diskPct + '%';
      tDisk.className = 'topbar-stat' + (diskPct > 90 ? ' warn' : '');
    }
  }

  // --- Quick Action Bar ---

  function setupQuickActions() {
    // Set Portainer links (topbar quick-action + home bento action) +
    // surface the first-login hint as a hover tooltip so the user
    // doesn't have to dig into Settings to find the auto-generated
    // admin password.
    const portainerMeta = _serviceMeta['ob-portainer'];
    const portainerPort = (portainerMeta && portainerMeta.port) || 9000;
    const portainerUrl = `http://${location.hostname}:${portainerPort}`;
    const portainerHint = (portainerMeta && portainerMeta.first_login) || '';
    const portainerTargets = ['#qa-portainer-link', '#bento-action-portainer'];
    portainerTargets.forEach((sel) => {
      const el = document.querySelector(sel);
      if (el) {
        el.href = portainerUrl;
        if (portainerHint) {
          el.title = `Open Portainer\n\n${portainerHint}`;
        }
        // Attach the same first-login-creds intercept the app-launcher
        // tiles use. Without this, clicking a Portainer quick-action
        // opens Portainer's login screen without ever showing the
        // customer the generated admin password.
        if (!el._sbPortainerIntercept) {
          el._sbPortainerIntercept = true;
          el.setAttribute('data-first-login', portainerHint || 'Use the admin password OpenBox generated for you.');
          el.setAttribute('data-first-login-key', 'sb-first-login-seen-v3-ob-portainer');
          el.setAttribute('data-launch-url', portainerUrl);
          el.setAttribute('data-container', 'ob-portainer');
        }
      }
    });

    // Restart all button
    const restartTargets = ['#qa-restart-all', '#bento-action-restart'];
    restartTargets.forEach((sel) => {
      const btn = document.querySelector(sel);
      if (!btn) return;
      btn.addEventListener('click', async () => {
        const ok = await confirm('Restart all services?', 'This will briefly restart every running OpenBox service. Your server may be unreachable for a moment.');
        if (!ok) return;
        btnLoading(btn, true);
        try {
          await api('POST', '/containers/restart-all');
          toast('All services restarting...', 'success');
          setTimeout(loadHome, 2000);
        } catch (err) {
          toast(err.message, 'error');
        } finally {
          btnLoading(btn, false);
        }
      });
    });
  }

  function updateQuickActionBar(containers) {
    const running = containers.filter(c => c.state === 'running').length;
    const total = containers.length;
    const statusText = $('#qa-status-text');
    const dot = $('#qa-dot');

    // 2026-04-21 beta review fix: "N of 0 services running" (denominator
    // zero) is confusing. Show "N services running" when total is
    // missing or impossibly small relative to running.
    // 2026-04-21 Codex review fix: when BOTH are zero (fresh install,
    // containers still pulling, /api/containers returns [] transiently)
    // show a neutral "Waiting for services..." instead of a scary
    // red "0 services running" — we don't know if anything is actually
    // broken yet.
    if (statusText) {
      if (total <= 0 && running === 0) {
        statusText.textContent = 'Waiting for services...';
      } else if (total <= 0 || running > total) {
        statusText.textContent = `${running} service${running === 1 ? '' : 's'} running`;
      } else {
        statusText.textContent = `${running} of ${total} services running`;
      }
    }
    if (dot) {
      dot.classList.remove('warn', 'error');
      // Neutral dot while waiting; error only once we know nothing is
      // running AND at least one container was expected.
      if (total > 0 && running === 0) dot.classList.add('error');
      else if (total > 0 && running < total) dot.classList.add('warn');
    }
  }

  // --- App Launcher (Desktop OS Grid) ---

  function renderAppLauncher(containers) {
    const launcher = $('#app-launcher');
    if (!launcher) return;

    // Build a map of container states by name
    const stateMap = {};
    for (const c of containers) {
      stateMap[c.name] = c.state;
    }

    // Collect all services that have a port AND an actual container on
    // the host. `_serviceMeta` is the full catalog of every service in
    // every module, so filtering by `stateMap` (which comes from
    // /api/containers and only includes containers that actually exist)
    // is what restricts the launcher to enabled modules.
    //
    // Previously this loop added every catalog entry with a port, so the
    // Home page launcher showed apps from disabled modules as broken
    // tiles — misleading users into thinking everything was "installed".
    const launchableServices = [];
    for (const [containerName, m] of Object.entries(_serviceMeta)) {
      if (m.port === null) continue;
      if (!(containerName in stateMap)) continue; // module not enabled
      launchableServices.push({
        containerName,
        ...m,
        state: stateMap[containerName],
      });
    }

    // Group services by launcher category
    const grouped = {};
    for (const [groupName, categories] of Object.entries(LAUNCHER_GROUPS)) {
      const svcs = launchableServices.filter(s => categories.includes(s.category));
      if (svcs.length > 0) {
        grouped[groupName] = svcs;
      }
    }

    // Render
    let html = '';
    for (const [groupName, svcs] of Object.entries(grouped)) {
      html += `<div class="launcher-category">`;
      html += `<div class="launcher-category-title">${esc(groupName)}</div>`;
      html += `<div class="launcher-grid">`;
      for (const svc of svcs) {
        const proto = svc.https ? 'https' : 'http';
        // Apps like Pi-hole serve their admin UI at a sub-path (/admin/)
        // and 403 on the root. The module's compose meta can declare
        // `path:` to land users on the right page.
        const url = `${proto}://${location.hostname}:${svc.port}${svc.path || ''}`;
        const isRunning = svc.state === 'running';
        const statusClass = svc.health === 'unhealthy' ? 'unhealthy' : svc.state === 'running' ? 'on' : 'off';
        // If this service has a first_login hint AND the user hasn't
        // dismissed it for this container yet, add a data attribute the
        // click handler uses to intercept and show a credentials modal.
        // The dismissed-set lives in localStorage so the hint only fires
        // until the user has seen it once per app per install.
        // Key prefix bumped to v3 on 2026-04-23 (v1.5.73): modal UX
        // changed from "Close/Open both dismiss forever" to "dismissal
        // only happens if the user explicitly ticks a checkbox."
        // Previously customers who clicked Close to avoid opening a
        // new tab accidentally lost the ability to re-view the
        // credentials. v3 prefix gives everyone (including existing
        // installs that auto-updated) a fresh modal they can re-visit
        // any time until they explicitly opt out.
        const firstLoginKey = svc.first_login ? `sb-first-login-seen-v3-${svc.containerName || svc.svcId}` : '';
        const needsFirstLogin = !!svc.first_login && !localStorage.getItem(firstLoginKey);
        const firstLoginAttr = needsFirstLogin
          ? ` data-first-login="${esc(svc.first_login)}" data-first-login-key="${esc(firstLoginKey)}" data-launch-url="${esc(url)}" data-container="${esc(svc.containerName)}"${svc.guide_url ? ` data-guide-url="${esc(svc.guide_url)}"` : ''}`
          : svc.guide_url
            ? ` data-guide-url="${esc(svc.guide_url)}"`
            : '';
        // Compose the hover-tooltip: short tip on top, then first-login
        // creds on a second line if the module declared any. Browsers
        // render \n in the title attribute as a line break in the
        // native tooltip, so users who hover get the credentials
        // without a click. The full modal still fires on click for
        // first-time launches via the data-first-login attribute.
        const tipBase = svc.tip || svc.desc || svc.name;
        const tooltipText = svc.first_login
          ? `${tipBase}\n\n${svc.first_login}`
          : tipBase;
        // Guard: a dead-service launcher click used to open a blank
        // browser tab with no explanation. Now we intercept the click
        // and tell the customer the service isn't running.
        const notRunningAttr = isRunning ? '' : ` data-not-running="1"`;
        const notRunningTitle = isRunning ? tooltipText : `${svc.name} isn't running yet. Check the Apps page for status.`;
        // Tom's 2026-04-24 live review: Nginx Proxy Manager's launcher
        // link was advertised to the LAN but the admin port is bound
        // to 127.0.0.1 only — LAN clicks always connection-refuse. For
        // loopback-only services, skip the broken link and intercept
        // the click with a "local-only" modal instead.
        if (svc.loopback_only) {
          const loopbackTitle = `${svc.name} admin UI is bound to 127.0.0.1 for security. Click for SSH-tunnel instructions.`;
          html += `
            <a href="#" class="launcher-icon launcher-icon-loopback" title="${esc(loopbackTitle)}" data-loopback-service="${esc(svc.name)}" data-loopback-port="${esc(String(svc.port))}">
              <div class="launcher-icon-circle" style="background:${darkBg(svc.color)}; color:${svc.color}">
                ${serviceIcon(svc.svcId, 32)}
                <span class="launcher-icon-status ${statusClass}"></span>
              </div>
              <span class="launcher-icon-name">${esc(svc.name)} <span style="opacity:.6;font-size:.75em">local-only</span></span>
            </a>`;
          continue;
        }
        html += `
          <a href="${url}" target="_blank" class="launcher-icon${isRunning ? '' : ' launcher-icon-dim'}" title="${esc(isRunning ? tooltipText : notRunningTitle)}"${firstLoginAttr}${notRunningAttr}>
            <div class="launcher-icon-circle" style="background:${darkBg(svc.color)}; color:${svc.color}">
              ${serviceIcon(svc.svcId, 32)}
              <span class="launcher-icon-status ${statusClass}"></span>
            </div>
            <span class="launcher-icon-name">${esc(svc.name)}</span>
          </a>`;
      }
      html += `</div></div>`;
    }

    if (!html) {
      html = '<p style="color:var(--text-muted); font-size:0.9rem;">No launchable services found. Enable some modules from the Apps tab.</p>';
    }

    launcher.innerHTML = html;
  }

  // --- HOME ---

  async function loadHome() {
    try {
      const containers = await api('GET', '/containers');
      renderHome(containers);
    } catch (err) { toast('Could not load services.', 'error'); }
    // Fill the right-column cards + row 3 cards. These fire in
    // parallel and tolerate individual failures — one slow endpoint
    // doesn't block the rest.
    loadActivity();
    loadLatestRelease();
    loadNetwork();
    loadBackupStatus();
    loadVpnStatus();
    loadRecyclarrStatus();
    loadIndexerNeededBanner();
    maybeShowProUpsell();
  }

  // Indexer-needed banner. v1.6.x removed default indexer auto-seeding
  // for legal compliance (Terms §6 — OpenBox doesn't pre-configure
  // indexers/trackers/sources). Cost: out-of-box Sonarr/Radarr requests
  // queue forever with zero feedback because Prowlarr has 0 indexers.
  // This banner detects that empty state and tells the customer
  // explicitly: "add one in Prowlarr before anything will work."
  async function loadIndexerNeededBanner() {
    const banner = $('#indexer-needed-banner');
    if (!banner) return;
    try {
      const s = await api('GET', '/media/indexer-count');
      // Show ONLY when Prowlarr is reachable (so we don't false-flag
      // a fresh install where Prowlarr hasn't booted yet) AND has
      // zero indexers. Hide otherwise.
      if (s && s.prowlarrReachable && s.count === 0) {
        // Build the launcher URL dynamically — Prowlarr is reachable
        // on the same host as the dashboard but on port 9696.
        const openLink = $('#indexer-needed-open');
        if (openLink) {
          const host = window.location.hostname || 'localhost';
          openLink.href = `http://${host}:9696/`;
        }
        banner.classList.remove('hidden');
      } else {
        banner.classList.add('hidden');
      }
    } catch {
      banner.classList.add('hidden');
    }
  }

  // Recyclarr / TRaSH-Guides status strip. One read per dashboard
  // load — Recyclarr only changes when the daily sync runs, so a
  // poll loop would be wasted work. Hidden unless Recyclarr has
  // actually run (state/recyclarr-synced marker present).
  async function loadRecyclarrStatus() {
    const strip = $('#recyclarr-strip');
    if (!strip) return;
    try {
      const s = await api('GET', '/recyclarr/status');
      if (!s.enabled) {
        strip.classList.add('hidden');
        return;
      }
      const formats = (s.sonarr && s.sonarr.count) || (s.radarr && s.radarr.count) || 0;
      const formatsEl = $('#recyclarr-formats');
      if (formatsEl) {
        formatsEl.textContent = formats > 0
          ? `${formats} custom formats applied`
          : 'config present, no formats yet';
      }
      const syncedEl = $('#recyclarr-synced');
      if (syncedEl && s.lastSyncedAt) {
        const t = new Date(s.lastSyncedAt);
        const ago = Math.max(0, Math.floor((Date.now() - t.getTime()) / 60000));
        const human = ago < 60 ? `${ago}m ago`
          : ago < 1440 ? `${Math.floor(ago / 60)}h ago`
          : `${Math.floor(ago / 1440)}d ago`;
        syncedEl.textContent = `last sync ${human}`;
      }
      strip.classList.remove('hidden');
    } catch {
      strip.classList.add('hidden');
    }
  }

  // Poll the dashboard's /api/vpn/status. Shown as a bento tile ONLY
  // when the media module is enabled — the endpoint returns
  // { media_enabled: false, ... } otherwise and we hide the tile.
  //
  // Cadence: 30s when healthy, 8s when the tunnel is reported down.
  // The fast retry recovers quickly after a gluetun restart instead
  // of leaving the user staring at "down" for up to a full minute.
  // Also re-probes whenever the tab regains focus (visibilitychange)
  // and on page show — a returning user shouldn't see stale state.
  let _vpnPollTimer = null;
  async function loadVpnStatus() {
    const banner = $('#vpn-banner');
    if (!banner) return;
    let nextDelay = 30 * 1000;
    try {
      const s = await api('GET', '/vpn/status');
      if (!s.media_enabled || s.vpn_enabled === false) {
        banner.classList.add('hidden');
        return;
      }
      banner.classList.remove('hidden');
      renderVpnStatus(s);
      if (!s.tunnel_up) nextDelay = 8 * 1000;
    } catch (err) {
      banner.classList.remove('hidden');
      banner.className = 'vpn-banner vpn-banner-bad';
      const meta = $('#vpn-meta');
      if (meta) meta.textContent = 'error';
      const headline = $('#vpn-banner-headline');
      if (headline) headline.textContent = 'VPN check failed';
      const verdict = $('#vpn-verdict');
      if (verdict) verdict.textContent = err.message || 'Could not reach /api/vpn/status.';
      nextDelay = 8 * 1000;
    } finally {
      if (_vpnPollTimer) clearTimeout(_vpnPollTimer);
      _vpnPollTimer = setTimeout(loadVpnStatus, nextDelay);
    }
  }
  // Refresh the VPN banner whenever the user brings the tab back.
  // Without this, a user who switches away for 2 minutes sees the
  // stale state the poll captured on the last pre-blur tick.
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && $('#vpn-banner')) {
      loadVpnStatus();
    }
  });

  // Known provider slugs → display names. Anything not in the map
  // falls back to the slug with a capitalized first letter — close
  // enough for one-offs without maintaining an exhaustive list.
  const VPN_PROVIDER_NAMES = {
    surfshark: 'Surfshark',
    nordvpn: 'NordVPN',
    protonvpn: 'Proton VPN',
    mullvad: 'Mullvad',
    ivpn: 'IVPN',
    privateinternetaccess: 'Private Internet Access',
    pia: 'Private Internet Access',
    expressvpn: 'ExpressVPN',
    windscribe: 'Windscribe',
    privado: 'Privado VPN',
    privatevpn: 'PrivateVPN',
    hidemyass: 'HideMyAss',
    perfectprivacy: 'Perfect Privacy',
    purevpn: 'PureVPN',
    vyprvpn: 'VyprVPN',
    custom: 'Custom provider',
  };
  function prettyProvider(slug) {
    if (!slug) return null;
    const s = String(slug).toLowerCase();
    if (VPN_PROVIDER_NAMES[s]) return VPN_PROVIDER_NAMES[s];
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  // Logo files that live under /vpn-logos/. Add more here as they're
  // dropped in — the lookup is by the normalized provider slug.
  const VPN_PROVIDER_LOGOS = {
    surfshark: '/vpn-logos/surfshark.webp',
    protonvpn: '/vpn-logos/protonvpn.png',
  };

  // ISO-3166 alpha-2 country code → regional indicator emoji (flag).
  // Gluetun's ipinfo probe returns country as 2-letter code like "US".
  function flagFromCountry(code) {
    if (!code || typeof code !== 'string' || code.length !== 2) return '🌐';
    const A = 0x1f1e6;
    const base = 'A'.charCodeAt(0);
    const up = code.toUpperCase();
    return String.fromCodePoint(A + (up.charCodeAt(0) - base)) + String.fromCodePoint(A + (up.charCodeAt(1) - base));
  }

  function renderVpnStatus(s) {
    const banner = $('#vpn-banner');
    const meta = $('#vpn-meta');
    const headline = $('#vpn-banner-headline');
    const providerName = $('#vpn-provider-name');
    const protocolChip = $('#vpn-protocol-chip');
    const verdict = $('#vpn-verdict');
    const tunnel = $('#vpn-tunnel');
    const exitIp = $('#vpn-exit-ip');
    const exitLoc = $('#vpn-exit-loc');
    const flag = $('#vpn-flag');
    const qbt = $('#vpn-qbt');
    const kill = $('#vpn-killswitch');
    const qbtFact = $('#vpn-fact-qbt');
    const killFact = $('#vpn-fact-kill');

    const good = s.tunnel_up && s.kill_switch_ok;
    // v1.6.57: same containers-still-settling tolerance applied here so
    // the BIG headline "VPN has a problem" doesn't fire during the
    // post-update recovery window. If gluetun or qBit started < 90s
    // ago and we're not "good," show "Checking VPN…" instead of red.
    const _vpnIsSettling = (() => {
      const STARTING_GRACE_MS = 90 * 1000;
      const within = (c) => {
        if (!c || !c.startedAt) return false;
        const t = new Date(c.startedAt).getTime();
        return Number.isFinite(t) && (Date.now() - t) < STARTING_GRACE_MS;
      };
      return !good && (within(s.gluetun && s.gluetun.container) || within(s.qbittorrent && s.qbittorrent.container));
    })();
    // Data attributes let CSS theme the banner on a per-provider /
    // per-protocol basis (e.g. red WireGuard chip, Surfshark logo
    // color mode).
    if (banner) {
      banner.className = 'vpn-banner ' + (good ? 'vpn-banner-good' : 'vpn-banner-bad');
      if (s.provider) banner.dataset.provider = String(s.provider).toLowerCase();
      else delete banner.dataset.provider;
      if (s.protocol) banner.dataset.protocol = String(s.protocol).toLowerCase();
      else delete banner.dataset.protocol;
    }
    if (meta) meta.textContent = good ? 'protected' : 'needs attention';

    // Swap in the provider logo if we have one on disk; otherwise keep
    // the generic shield SVG.
    const logoEl = $('#vpn-provider-logo');
    const shieldSvg = $('#vpn-shield-svg');
    if (logoEl && shieldSvg) {
      const slug = s.provider ? String(s.provider).toLowerCase() : '';
      const src = good && slug && VPN_PROVIDER_LOGOS[slug];
      if (src) {
        logoEl.src = src;
        logoEl.alt = prettyProvider(slug) || 'VPN provider';
        logoEl.classList.remove('hidden');
        shieldSvg.classList.add('hidden');
      } else {
        logoEl.classList.add('hidden');
        shieldSvg.classList.remove('hidden');
      }
    }

    // Headline: "Protected by Surfshark" (or generic fallback if provider
    // unknown, or a red "VPN has a problem" message on failure).
    const pretty = prettyProvider(s.provider);
    if (headline) {
      if (_vpnIsSettling) {
        headline.textContent = 'Checking VPN…';
      } else if (!good) {
        headline.textContent = 'VPN has a problem';
      } else if (pretty) {
        headline.textContent = 'Protected by';
      } else {
        headline.textContent = 'VPN on — downloads protected';
      }
    }
    if (providerName) {
      if (good && pretty) {
        providerName.hidden = false;
        providerName.textContent = pretty;
      } else {
        providerName.hidden = true;
        providerName.textContent = '';
      }
    }
    if (protocolChip) {
      if (good && s.protocol) {
        protocolChip.hidden = false;
        protocolChip.textContent = s.protocol === 'wireguard' ? 'WireGuard' : (s.protocol === 'openvpn' ? 'OpenVPN' : s.protocol);
      } else {
        protocolChip.hidden = true;
      }
    }

    if (verdict) {
      // When the tunnel is broken AND we don't even have a provider
      // configured (fresh Media install, user hasn't entered VPN creds
      // yet), inject a Surfshark recommendation directly into the
      // verdict line — this is the highest-intent moment to convert.
      // Plain copy with a single inline link, no banner-stuffing.
      if (!good && !s.provider) {
        verdict.innerHTML = "No VPN configured. Need one? "
          + '<a href="https://get.surfshark.net/aff_c?offer_id=1126&aff_id=9447&aff_sub=hr52es" '
          + 'target="_blank" rel="noopener nofollow sponsored" '
          + 'style="color:hsl(173,80%,55%);text-decoration:underline;">'
          + 'Surfshark — 87% off + 4 months free</a>'
          + ' (the one we use, prefilled in the wizard).';
      } else {
        verdict.textContent = s.verdict || '';
      }
    }

    // v1.6.57: containers-still-settling tolerance. After self-update,
    // gluetun + qBit + the *arrs are all recreated and need ~30-90s
    // before their wget IP probes succeed. The dashboard probes them
    // during that window, sees failures, and the banner used to flash
    // "Tunnel down / Kill switch at risk / qBit probe failed" — making
    // a perfectly healthy update look broken. Server already returns
    // each container's startedAt; if a container started < 90s ago
    // AND its probe failed, render "starting…" in neutral copy
    // instead of alarmist red.
    const STARTING_GRACE_MS = 90 * 1000;
    const isSettling = (c) => {
      if (!c || !c.startedAt) return false;
      const t = new Date(c.startedAt).getTime();
      return Number.isFinite(t) && (Date.now() - t) < STARTING_GRACE_MS;
    };
    const gluetunSettling = isSettling(s.gluetun && s.gluetun.container);
    const qbitSettling   = isSettling(s.qbittorrent && s.qbittorrent.container);

    if (tunnel) {
      tunnel.textContent = s.tunnel_up ? 'up' : (gluetunSettling ? 'starting…' : 'down');
    }
    if (exitIp) exitIp.textContent = (s.gluetun && s.gluetun.public && s.gluetun.public.ip) || '—';
    if (exitLoc) {
      const p = s.gluetun && s.gluetun.public;
      const parts = p && p.ok ? [p.city, p.region].filter(Boolean) : [];
      const countryName = p && p.country ? p.country : '';
      exitLoc.textContent = parts.length ? `${parts.join(', ')}${countryName ? ', ' + countryName : ''}` : (countryName || '—');
    }
    if (flag) {
      const p = s.gluetun && s.gluetun.public;
      flag.textContent = flagFromCountry(p && p.country);
    }
    if (qbt) {
      const q = s.qbittorrent && s.qbittorrent.public;
      const gl = s.gluetun && s.gluetun.public;
      if (q && q.ok && gl && gl.ok) {
        qbt.textContent = q.ip === gl.ip ? 'via VPN ✓' : 'NOT in tunnel ✗';
      } else if (q && !q.ok) {
        qbt.textContent = qbitSettling ? 'starting…' : 'probe failed';
      } else {
        qbt.textContent = '—';
      }
    }
    if (kill) {
      kill.textContent = s.kill_switch_ok
        ? 'active ✓'
        : ((gluetunSettling || qbitSettling) ? 'checking…' : 'at risk ✗');
    }

    if (qbtFact) qbtFact.classList.toggle('vpn-fact-ok', !!(qbt && (qbt.textContent || '').includes('✓')));
    if (killFact) killFact.classList.toggle('vpn-fact-ok', !!s.kill_switch_ok);
  }

  const vpnRecheckBtn = $('#btn-vpn-recheck');
  if (vpnRecheckBtn) {
    vpnRecheckBtn.addEventListener('click', async () => {
      btnLoading(vpnRecheckBtn, true);
      const meta = $('#vpn-meta');
      if (meta) meta.textContent = 'checking…';
      await loadVpnStatus();
      btnLoading(vpnRecheckBtn, false);
    });
  }

  // --- Edit VPN modal ---
  // Populates from current .env via /api/config, handles protocol toggle
  // (WG/OV), saves via /api/config (which accepts OB_AI_CHAT_ENABLED,
  // VPN_*, and WIREGUARD_* per the config whitelist), then restarts the
  // media module so gluetun reconnects.
  const vpnEditBtn = $('#btn-vpn-edit');
  const vpnEditOverlay = $('#vpn-edit-overlay');
  const vpnEditCancel = $('#btn-vpn-edit-cancel');
  const vpnEditSave = $('#btn-vpn-edit-save');
  const editProtocolSel = $('#edit-vpn-type');

  function syncEditVpnFields() {
    if (!editProtocolSel) return;
    const wg = $('#edit-vpn-wg-fields');
    const ov = $('#edit-vpn-ov-fields');
    if (!wg || !ov) return;
    if (editProtocolSel.value === 'openvpn') {
      wg.classList.add('hidden');
      ov.classList.remove('hidden');
    } else {
      wg.classList.remove('hidden');
      ov.classList.add('hidden');
    }
  }
  if (editProtocolSel) editProtocolSel.addEventListener('change', syncEditVpnFields);

  if (vpnEditBtn && vpnEditOverlay) {
    vpnEditBtn.addEventListener('click', async () => {
      // Pre-fill from current config. The GET redacts password-shaped
      // values as '********', so clear those placeholders in the form.
      try {
        const cfg = await api('GET', '/config');
        const setVal = (id, key) => {
          const el = $(id);
          if (!el) return;
          const v = cfg[key];
          if (v === undefined || v === '********' || v === null) el.value = '';
          else el.value = v;
        };
        setVal('#edit-vpn-provider', 'VPN_PROVIDER');
        const typeEl = $('#edit-vpn-type');
        if (typeEl) typeEl.value = (cfg.VPN_TYPE === 'openvpn') ? 'openvpn' : 'wireguard';
        setVal('#edit-vpn-user', 'VPN_USER');
        setVal('#edit-vpn-wg-addr', 'WIREGUARD_ADDRESSES');
        setVal('#edit-vpn-country', 'SERVER_COUNTRIES');
        setVal('#edit-vpn-cities', 'SERVER_CITIES');
        setVal('#edit-vpn-hostnames', 'SERVER_HOSTNAMES');
        // Passwords/keys stay empty — user types a new one to replace, or
        // leaves blank to keep the existing.
        const pw = $('#edit-vpn-pass'); if (pw) pw.value = '';
        const wk = $('#edit-vpn-wg-key'); if (wk) wk.value = '';
        syncEditVpnFields();
      } catch (err) {
        toast('Could not load current VPN config.', 'error');
        return;
      }
      show(vpnEditOverlay);
    });
  }
  // Settings → Network → "Edit VPN settings" reuses the same modal so
  // there's one canonical form for VPN config. Summary line is
  // refreshed from /api/vpn/status whenever the Network tab is
  // opened (see handler in Settings tab switcher). Punchlist P3 2026-04-21.
  const settingsVpnBtn = $('#btn-settings-edit-vpn');
  if (settingsVpnBtn && vpnEditBtn) {
    settingsVpnBtn.addEventListener('click', () => vpnEditBtn.click());
  }
  async function refreshSettingsVpnSummary() {
    const el = $('#vpn-settings-summary');
    if (!el) return;
    try {
      const cfg = await api('GET', '/config');
      const provider = cfg.VPN_PROVIDER || '(not set)';
      const type = cfg.VPN_TYPE === 'openvpn' ? 'OpenVPN' : 'WireGuard';
      const country = cfg.SERVER_COUNTRIES || '(any)';
      el.textContent = `Current: ${provider} · ${type} · ${country}`;
    } catch {
      el.textContent = 'Current VPN configuration unavailable.';
    }
  }
  // Run whenever Network tab is shown.
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-stab="network"]');
    if (btn) setTimeout(refreshSettingsVpnSummary, 50);
  });
  if (vpnEditCancel) vpnEditCancel.addEventListener('click', () => hide(vpnEditOverlay));
  if (vpnEditSave) {
    vpnEditSave.addEventListener('click', async () => {
      const updates = {};
      const provider = $('#edit-vpn-provider').value;
      const type = $('#edit-vpn-type').value;
      if (provider) updates.VPN_PROVIDER = provider;
      if (type === 'openvpn' || type === 'wireguard') updates.VPN_TYPE = type;
      // Read country/cities/hostnames. Treat empty string as a deliberate
      // "clear this filter" so the user can broaden again. Server-side
      // updateConfigField handles the empty-clears-the-line case.
      const country = ($('#edit-vpn-country') || {}).value;
      if (country !== undefined) updates.SERVER_COUNTRIES = country.trim();
      const cities = ($('#edit-vpn-cities') || {}).value;
      if (cities !== undefined) updates.SERVER_CITIES = cities.trim();
      const hostnames = ($('#edit-vpn-hostnames') || {}).value;
      if (hostnames !== undefined) updates.SERVER_HOSTNAMES = hostnames.trim();

      if (type === 'wireguard') {
        const k = $('#edit-vpn-wg-key').value.trim();
        const a = $('#edit-vpn-wg-addr').value.trim();
        if (k) updates.WIREGUARD_PRIVATE_KEY = k;
        if (a) updates.WIREGUARD_ADDRESSES = a;
      } else {
        const u = $('#edit-vpn-user').value.trim();
        const p = $('#edit-vpn-pass').value;
        if (u) updates.VPN_USER = u;
        if (p) updates.VPN_PASSWORD = p;
      }

      if (Object.keys(updates).length === 0) {
        toast('Nothing changed — close or edit a field first.', 'info');
        return;
      }

      btnLoading(vpnEditSave, true);
      try {
        // v1.6.44: PUT /api/config now auto-triggers media restart on
        // any gluetun-relevant key change (server returns mediaRestarting
        // = true when it does). Previous JS-side check against
        // window._cachedModules was racy — stale module state made the
        // SERVER_CITIES save silently no-op for users who saved the
        // city after enabling media via the wizard. Trust the server.
        const resp = await api('PUT', '/config', updates);
        if (resp && resp.mediaRestarting) {
          toast('VPN updated — media stack restarting. Banner will refresh in a few seconds.', 'success');
          setTimeout(loadVpnStatus, 20 * 1000);
        } else {
          toast('VPN credentials saved. They\'ll apply when you enable the Media module.', 'success');
        }
        hide(vpnEditOverlay);
      } catch (err) {
        toast(err.message || 'Save failed.', 'error');
      } finally {
        btnLoading(vpnEditSave, false);
      }
    });
  }

  // Brave browser detection, cached for the page lifetime. Brave's
  // HTTPS-First upgrade rewrites http://<LAN-IP>:<port> to https,
  // the TLS handshake fails (OpenBox apps serve plain HTTP), and
  // app SPAs like Jellyseerr's React treat the resulting network
  // error as "session expired" → redirect to /login every ~30s.
  // We use this to prepend a one-liner to the first-login launcher
  // modal so the tip shows up ONLY when the customer is about to
  // click through to an affected app, not as a dashboard-wide banner.
  let _isBraveCache = null;
  async function isBrave() {
    if (_isBraveCache !== null) return _isBraveCache;
    try {
      if (navigator.brave && typeof navigator.brave.isBrave === 'function') {
        _isBraveCache = await navigator.brave.isBrave();
      } else {
        _isBraveCache = false;
      }
    } catch { _isBraveCache = false; }
    return _isBraveCache;
  }

  function renderHome(containers) {
    _containers = containers;
    $('#greeting').textContent = getGreeting();

    const running = containers.filter(c => c.state === 'running').length;
    const total = containers.length;

    if (running === total) {
      $('#hero-sub').textContent = "All your services are humming along perfectly.";
    } else if (running === 0) {
      $('#hero-sub').textContent = "Looks like nothing's running. Let's fix that!";
    } else {
      $('#hero-sub').textContent = `${running} of ${total} services are up. Almost there!`;
    }

    // Update quick action bar
    updateQuickActionBar(containers);

    // Build the app launcher grid (primary view, grouped by category)
    renderAppLauncher(containers);

    // Running list — keyed diff render. The list is kept in place
    // across ticks; only changed rows touch the DOM. Stats elements
    // (#cpu-{id}, #mem-{id}) survive re-renders so the streamed
    // values stay visible instead of flashing to "--".
    const runningList = $('#running-list');
    const buildActions = (c, m, on, critical) => on
      ? `<button class="btn-pill" data-quicklog="${c.id}" data-cname="${esc(m.name)}" aria-label="View logs for ${esc(m.name)}" title="Quick logs">Logs</button>
         <button class="btn-pill" data-action="restart" data-cid="${c.id}" data-cname="${esc(m.name)}" data-critical="${critical}" aria-label="Restart ${esc(m.name)}">Restart</button>
         <button class="btn-pill" data-action="stop" data-cid="${c.id}" data-cname="${esc(m.name)}" data-critical="${critical}" aria-label="Pause ${esc(m.name)}" title="Pause — keeps all data, resume any time">Pause</button>`
      : `<button class="btn-pill primary" data-action="start" data-cid="${c.id}" data-cname="${esc(m.name)}" data-critical="false" aria-label="Resume ${esc(m.name)}">Resume</button>`;
    const healthBadge = (c) =>
      c.health === 'unhealthy' ? '<span class="health-badge unhealthy">Unhealthy</span>'
      : c.health === 'starting' ? '<span class="health-badge starting">Starting</span>'
      : '';

    if (runningList && window.SB && window.SB.renderList) {
      window.SB.renderList(runningList, containers, {
        key: c => c.id,
        create: (c) => {
          const m = meta(c.name);
          const on = c.state === 'running';
          const critical = isCritical(c.name);
          const row = document.createElement('div');
          row.className = 'running-row';
          row.innerHTML = `
            <div class="running-icon" style="background:${darkBg(m.color)}; color:${m.color}">${serviceIcon(m.svcId, 22)}</div>
            <div class="running-info">
              <div class="running-name" data-field="name">${esc(m.name)} <span class="sb-help" data-help="container-row" tabindex="0" role="button" aria-label="What this service row does">?</span> ${critical ? '<span class="critical-badge">Core</span>' : ''} <span data-field="health">${healthBadge(c)}</span></div>
              <div class="running-detail"><span class="status-dot ${on ? 'on' : 'off'}" data-field="dot"></span> <span data-field="status">${esc(c.status || c.state)}</span></div>
            </div>
            <div class="running-stats">
              <div class="mini-stat"><div class="mini-stat-val" id="cpu-${c.id}">--</div><div class="mini-stat-label">CPU</div></div>
              <div class="mini-stat"><div class="mini-stat-val" id="mem-${c.id}">--</div><div class="mini-stat-label">MEM</div></div>
            </div>
            <div class="running-actions" data-field="actions">${buildActions(c, m, on, critical)}</div>`;
          return row;
        },
        update: (row, c) => {
          const m = meta(c.name);
          const on = c.state === 'running';
          const critical = isCritical(c.name);
          const statusText = esc(c.status || c.state);
          const statusEl = row.querySelector('[data-field="status"]');
          if (statusEl && statusEl.textContent !== statusText) statusEl.textContent = statusText;
          const dot = row.querySelector('[data-field="dot"]');
          if (dot) dot.className = `status-dot ${on ? 'on' : 'off'}`;
          const healthEl = row.querySelector('[data-field="health"]');
          const newHealth = healthBadge(c);
          if (healthEl && healthEl.innerHTML !== newHealth) healthEl.innerHTML = newHealth;
          const actions = row.querySelector('[data-field="actions"]');
          const newActions = buildActions(c, m, on, critical);
          if (actions && actions.innerHTML !== newActions) actions.innerHTML = newActions;
        },
      });
    } else if (runningList) {
      // Fallback to innerHTML if the keyed renderer didn't load.
      runningList.innerHTML = containers.map(c => {
        const m = meta(c.name);
        const on = c.state === 'running';
        const critical = isCritical(c.name);
        return `<div class="running-row"><div class="running-icon" style="background:${darkBg(m.color)}; color:${m.color}">${serviceIcon(m.svcId, 22)}</div><div class="running-info"><div class="running-name">${esc(m.name)} <span class="sb-help" data-help="container-row" tabindex="0" role="button" aria-label="What this service row does">?</span> ${critical ? '<span class="critical-badge">Core</span>' : ''} ${healthBadge(c)}</div><div class="running-detail"><span class="status-dot ${on ? 'on' : 'off'}"></span> ${esc(c.status || c.state)}</div></div><div class="running-stats"><div class="mini-stat"><div class="mini-stat-val" id="cpu-${c.id}">--</div><div class="mini-stat-label">CPU</div></div><div class="mini-stat"><div class="mini-stat-val" id="mem-${c.id}">--</div><div class="mini-stat-label">MEM</div></div></div><div class="running-actions">${buildActions(c, m, on, critical)}</div></div>`;
      }).join('');
    }

    // Stats are now pushed over the socket via stats:update. See
    // resubscribeVisibleStats in initSocket — the subscription set is
    // synced after every renderHome so newly visible containers get
    // streams and removed ones have theirs torn down.
  }

  // Event delegation for container action buttons (restart/stop/start)
  document.addEventListener('click', async function (e) {
    const btnEl = e.target.closest('[data-action][data-cid]');
    if (!btnEl) return;

    const action = btnEl.dataset.action;
    const id = btnEl.dataset.cid;
    const name = btnEl.dataset.cname;
    const isCrit = btnEl.dataset.critical === 'true';

    if (action === 'stop' && isCrit) {
      const ok = await confirm(
        `Pause ${name}?`,
        `${name} is a critical service — pausing it may break other services or log you out. All data is preserved and you can resume at any time.`
      );
      if (!ok) return;
    } else if (action === 'stop') {
      const ok = await confirm(
        `Pause ${name}?`,
        `This stops ${name} without touching any of its data, settings, or history. Click Resume later to bring it back exactly as it was.`
      );
      if (!ok) return;
    } else if (action === 'restart' && isCrit) {
      const ok = await confirm(
        `Restart ${name}?`,
        `${name} is a critical service. It will be briefly unavailable during restart.`
      );
      if (!ok) return;
    }

    // Disable all action buttons for this container to prevent double-fire
    const row = btnEl.closest('.running-row');
    const btns = row ? row.querySelectorAll('.btn-pill') : [];
    btns.forEach(b => btnLoading(b, true));

    try {
      await api('POST', `/containers/${id}/${action}`);
      const verb = action === 'restart' ? 'restarted' : action === 'stop' ? 'paused' : 'resumed';
      toast(`${name} ${verb}!`, 'success');
      setTimeout(loadHome, 800);
    } catch (err) {
      toast(err.message, 'error');
      btns.forEach(b => btnLoading(b, false));
    }
  });

  // --- Clean Slate: delete app data and start fresh ---
  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-clean-module]');
    if (!btn) return;
    const moduleId = btn.dataset.cleanModule;
    const name = btn.dataset.cleanName || moduleId;
    const ok = await confirm(
      `Clean slate ${name}?`,
      `This permanently deletes ALL data for ${name} — databases, configs, uploaded files, everything. The app will be disabled and can be re-enabled later for a completely fresh start. This cannot be undone.`
    );
    if (!ok) return;
    btnLoading(btn, true);
    try {
      await api('POST', `/modules/${moduleId}/clean-slate`);
      toast(`${name} wiped clean. Re-enable from the Apps page for a fresh start.`, 'success');
      _pendingChanges.delete(moduleId);
      // Invalidate caches and refresh BOTH the apps store AND the home
      // launcher. Clean-slate previously only refreshed loadApps(), so
      // the wiped module's launcher icon stayed visible on the home
      // page until the next full reload.
      _storeData = null;
      loadMetadata().then(() => {
        loadApps();
        loadHome();
      });
    } catch (err) {
      toast(err.message || 'Clean slate failed.', 'error');
    }
    btnLoading(btn, false);
  });

  // --- Quick Logs popup ---
  // Click "Logs" on any running service to see the last 50 lines.
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-quicklog]');
    if (!btn) return;
    const cid = btn.dataset.quicklog;
    const cname = btn.dataset.cname || 'Service';
    const overlay = $('#quicklog-overlay');
    const title = $('#quicklog-title');
    const output = $('#quicklog-output');
    if (!overlay || !output) return;

    title.textContent = `${cname} — Recent Logs`;
    output.textContent = 'Loading...';
    show(overlay);

    // Fetch logs via the existing streaming endpoint
    if (socket) {
      // Unsubscribe from any previous stream
      socket.emit('logs:unsubscribe');
      output.textContent = '';
      socket.emit('logs:subscribe', cid);
      // The logs:data handler already appends to #log-output on the Logs
      // page. Wire a temporary handler for the quicklog output.
      const handler = ({ line }) => {
        output.textContent += line;
        output.scrollTop = output.scrollHeight;
      };
      socket.on('logs:data', handler);

      const cleanup = () => {
        socket.off('logs:data', handler);
        socket.emit('logs:unsubscribe');
        hide(overlay);
      };
      $('#quicklog-close').onclick = cleanup;
      overlay.onclick = (ev) => { if (ev.target === overlay) cleanup(); };
      $('#quicklog-goto-logs').onclick = () => {
        cleanup();
        switchPage('logs');
        // Select this container in the logs dropdown
        const sel = $('#log-select');
        if (sel) { sel.value = cid; sel.dispatchEvent(new Event('change')); }
      };
    }
  });

  // --- APPS (App Store) ---

  let currentStoreFilter = 'all';
  let currentStoreSort = 'newest';
  let currentStoreSearch = ''; // matches module title/tagline/desc + svc names
  const NEW_BADGE_DAYS = 30;
  let _availableUpdates = {}; // moduleId -> true if update available

  // Load cached update state to show badges on app cards
  async function loadUpdateBadges() {
    try {
      const data = await api('GET', '/updates/available');
      _availableUpdates = {};
      if (data.available && data.available.length) {
        data.available.forEach(u => { _availableUpdates[u.module] = u; });
      }
    } catch {}
  }
  loadUpdateBadges();

  function isNewModule(m) {
    if (!m.added_at) return false;
    const ts = Date.parse(m.added_at);
    if (isNaN(ts)) return false;
    const ageDays = (Date.now() - ts) / (1000 * 60 * 60 * 24);
    return ageDays >= 0 && ageDays < NEW_BADGE_DAYS;
  }

  function sortModules(modules) {
    const copy = modules.slice();
    if (currentStoreSort === 'name') {
      copy.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    } else if (currentStoreSort === 'category') {
      copy.sort((a, b) => {
        const ca = (a.category || 'zzz').localeCompare(b.category || 'zzz');
        return ca !== 0 ? ca : (a.name || '').localeCompare(b.name || '');
      });
    } else {
      // newest: modules with added_at first (desc), then the rest alphabetically
      copy.sort((a, b) => {
        const ta = a.added_at ? Date.parse(a.added_at) : 0;
        const tb = b.added_at ? Date.parse(b.added_at) : 0;
        if (ta !== tb) return tb - ta;
        return (a.name || '').localeCompare(b.name || '');
      });
    }
    return copy;
  }

  async function loadApps() {
    try {
      const mods = await api('GET', '/modules/store');
      // Cache the module list on window so cross-cutting checks
      // (VPN Save "is media enabled?", WireGuard button "is vpn
      // enabled?") can see the latest enable state without
      // re-hitting the API.
      window._cachedModules = Array.isArray(mods) ? mods : [];
      // Snapshot the current enabled set so the toggle-queue handler has
      // a baseline to diff against. This is what determines whether a
      // toggle becomes a "pending install" or a "pending remove".
      snapshotEnabled(mods);
      renderApps(mods);
      // Re-render the apply bar: any pending entries that match the new
      // baseline get pruned, and the bar shows/hides accordingly.
      prunePendingAgainstBaseline();
      renderApplyBar();
    } catch {
      // Fallback to basic endpoint
      try {
        const mods = await api('GET', '/modules');
        snapshotEnabled(mods);
        renderAppsBasic(mods);
        prunePendingAgainstBaseline();
        renderApplyBar();
      } catch (err) { toast('Could not load modules.', 'error'); }
    }
  }

  function snapshotEnabled(mods) {
    _originalEnabled = new Set();
    for (const m of mods) {
      if (m.enabled) _originalEnabled.add(m.id);
    }
  }

  // If the server state has moved to match a pending change (e.g. a
  // previous batch applied successfully), remove that change from the
  // pending set.
  function prunePendingAgainstBaseline() {
    for (const [id, desired] of [..._pendingChanges.entries()]) {
      const isEnabled = _originalEnabled.has(id);
      if (desired === isEnabled) {
        _pendingChanges.delete(id);
      }
    }
  }

  function renderAppsBasic(modules) {
    const grid = $('#apps-grid');
    grid.innerHTML = modules.map(m => {
      const mm = _moduleMeta[m.id] || { emoji: '\uD83D\uDCE6', color: '#6e6e73', bg: '#f5f5f7', friendly: m.name, desc: m.description };
      const actionBtn = renderAppActionButton(m, mm.friendly);
      return `
        <div class="app-card ${m.enabled ? 'enabled' : ''} ${m.required ? 'required' : ''}">
          <div class="app-top">
            <div class="app-icon" style="background:${darkBg(mm.color)}; color:${mm.color}">${serviceIcon(m.id, 28)}</div>
            ${actionBtn}
          </div>
          <div class="app-name">${esc(mm.friendly)}</div>
          <div class="app-desc">${esc(mm.desc || m.description)}</div>
          <div class="app-meta">
            <span class="app-tag ${m.required ? 'required' : 'optional'}">${m.required ? 'Always On' : 'Optional'}</span>
            <span class="app-tag ram">${m.ram}</span>
          </div>
        </div>`;
    }).join('');
  }

  // Render the install/remove button for a single app card. Has four
  // states depending on whether the module is currently installed and
  // whether the user has a pending change queued for it:
  //   off + no pending  → "+ Install"       (primary purple)
  //   off + pending on  → "✓ Queued"        (neutral, card shows QUEUED · INSTALL flag)
  //   on  + no pending  → "Installed"       (neutral, hover reveals "Remove")
  //   on  + pending off → "✓ Queued remove" (neutral, card shows QUEUED · REMOVE flag)
  // Required modules (core, dashboard) render as a locked "Always On" tag.
  function renderAppActionButton(m, friendlyName) {
    const name = friendlyName || m.name || m.id;
    if (m.required) {
      return `<span class="app-action-btn locked" title="Always on, cannot be disabled">Always On</span>`;
    }
    const pending = _pendingChanges.has(m.id) ? _pendingChanges.get(m.id) : null;
    let cls, label;
    if (pending === true) {
      cls = 'queued-install';
      label = '✓ Queued';
    } else if (pending === false) {
      cls = 'queued-remove';
      label = '✕ Queued';
    } else if (m.enabled) {
      cls = 'is-installed';
      label = 'Installed';
    } else {
      cls = '';
      label = '+ Install';
    }
    const helpKey = m.enabled ? 'module-disable' : 'module-enable';
    const cleanSlate = m.enabled ? `<button class="app-clean-slate" data-clean-module="${esc(m.id)}" data-clean-name="${esc(name).replace(/"/g, '&quot;')}" title="Delete all data and start fresh">Clean Slate</button><span class="sb-help" data-help="clean-slate" tabindex="0" role="button" aria-label="What Clean Slate does">?</span>` : '';
    return `<button class="app-action-btn ${cls}"
              data-module="${esc(m.id)}"
              data-friendly="${esc(name).replace(/"/g, '&quot;')}"
              aria-label="${m.enabled ? 'Remove' : 'Install'} ${esc(name)}">${label}</button><span class="sb-help" data-help="${helpKey}" tabindex="0" role="button" aria-label="${m.enabled ? 'How disabling modules works' : 'How enabling modules works'}">?</span>${cleanSlate}`;
  }

  function renderApps(modules) {
    // Build category filter bar
    const categories = [...new Set(modules.map(m => m.category))];
    const filterBar = $('#store-filters');
    if (filterBar) {
      filterBar.innerHTML = `<button class="store-filter ${currentStoreFilter === 'all' ? 'active' : ''}" data-filter="all">All</button>` +
        categories.map(cat =>
          `<button class="store-filter ${currentStoreFilter === cat ? 'active' : ''}" data-filter="${cat}">${CATEGORY_LABELS[cat] || esc(cat)}</button>`
        ).join('');
      filterBar.addEventListener('click', function (e) {
        const btn = e.target.closest('[data-filter]');
        if (btn) { currentStoreFilter = btn.dataset.filter; loadApps(); }
      });
    }

    // Wire sort dropdown (once)
    const sortSelect = $('#store-sort-select');
    if (sortSelect && !sortSelect._sbWired) {
      sortSelect._sbWired = true;
      sortSelect.value = currentStoreSort;
      sortSelect.addEventListener('change', function () {
        currentStoreSort = sortSelect.value;
        loadApps();
      });
    }

    // Wire search input + clear button (once). Filters re-run on each
    // keystroke without re-fetching modules — purely client-side.
    const searchInput = $('#store-search-input');
    const searchClear = $('#store-search-clear');
    if (searchInput && !searchInput._sbWired) {
      searchInput._sbWired = true;
      searchInput.value = currentStoreSearch || '';
      // Codex round 6 #11: debounce so typing a multi-char query
      // doesn't fire loadApps() on every keystroke (which re-GETs
      // /modules/store + rebuilds the whole grid). 200ms is
      // perceptually instant but collapses a typed 10-char query
      // from 10 fetches to 1.
      let applyTimer = null;
      const apply = () => {
        currentStoreSearch = searchInput.value.trim().toLowerCase();
        if (searchClear) searchClear.classList.toggle('hidden', !currentStoreSearch);
        loadApps();
      };
      const debouncedApply = () => {
        clearTimeout(applyTimer);
        applyTimer = setTimeout(apply, 200);
      };
      searchInput.addEventListener('input', debouncedApply);
      if (searchClear) searchClear.addEventListener('click', () => {
        searchInput.value = '';
        currentStoreSearch = '';
        searchClear.classList.add('hidden');
        loadApps();
        searchInput.focus();
      });
    }

    // Filter and sort modules. Search matches module title, tagline,
    // description, AND any service's friendly_name — so typing
    // "vault" finds the privacy module (because Vaultwarden lives in it).
    let filtered = currentStoreFilter === 'all' ? modules : modules.filter(m => m.category === currentStoreFilter);
    if (currentStoreSearch) {
      const q = currentStoreSearch;
      filtered = filtered.filter(m => {
        const haystack = [
          m.title, m.tagline, m.description,
          ...(m.services || []).map(s => s.name + ' ' + (s.description || '')),
        ].join(' ').toLowerCase();
        return haystack.includes(q);
      });
    }
    const sorted = sortModules(filtered);

    // Build container state map for status indicators
    const stateMap = {};
    for (const c of _containers) {
      stateMap[c.name] = c.state;
    }

    // Render cards with status indicators and RAM info
    const grid = $('#apps-grid');
    grid.innerHTML = sorted.map(m => {
      const theme = m.theme || {};
      const emoji = theme.emoji || '\uD83D\uDCE6';
      const color = theme.color || '#6e6e73';
      const bg = theme.bg || '#f5f5f7';
      const escapedName = (m.name || '').replace(/'/g, "\\'");

      // Determine module status from its service containers
      let moduleStatus = 'stopped';
      let runningCount = 0;
      let startingCount = 0;
      let unhealthyCount = 0;
      let totalSvc = 0;
      if (m.services && m.services.length) {
        totalSvc = m.services.length;
        for (const svc of m.services) {
          const cname = 'sb-' + svc.id;
          const state = stateMap[cname];
          if (state === 'running') runningCount++;
          // Check for containers that exist but aren't running yet (created, restarting)
          const cHealth = _containers.find(c => c.name === cname);
          if (cHealth && cHealth.health === 'starting') startingCount++;
          // An 'unhealthy' service means the container is running
          // but its health check is failing — the app is effectively
          // down from the customer's perspective. Before v1.5.50 we
          // still counted it toward runningCount and the card said
          // 'Running', hiding a broken service.
          if (cHealth && cHealth.health === 'unhealthy') unhealthyCount++;
        }
        if (runningCount === totalSvc && totalSvc > 0 && unhealthyCount === 0) moduleStatus = 'running';
        else if (unhealthyCount > 0) moduleStatus = 'unhealthy';
        else if (runningCount > 0 || startingCount > 0) moduleStatus = 'partial';
      }

      // After ~3 minutes of "enabled but 0 running" a module is
      // genuinely broken (gluetun stuck without creds, missing env
      // var, or a pull failure). Flip to "Needs attention" red so
      // customers notice instead of staring at "Starting up..."
      // forever.
      let longStuck = false;
      if (m.enabled && runningCount === 0 && totalSvc > 0) {
        window._moduleFirstSeenDead = window._moduleFirstSeenDead || {};
        const first = window._moduleFirstSeenDead[m.id] || Date.now();
        window._moduleFirstSeenDead[m.id] = first;
        if (Date.now() - first > 3 * 60 * 1000) longStuck = true;
      } else if (runningCount > 0 && window._moduleFirstSeenDead) {
        delete window._moduleFirstSeenDead[m.id];
      }

      let statusColor, statusLabel;
      if (moduleStatus === 'running') {
        statusColor = 'var(--green)';
        statusLabel = 'Running';
      } else if (moduleStatus === 'unhealthy') {
        statusColor = 'var(--red)';
        statusLabel = unhealthyCount === 1 ? '1 service unhealthy' : `${unhealthyCount} services unhealthy`;
      } else if (m.enabled && runningCount === 0 && totalSvc > 0) {
        if (longStuck) {
          statusColor = 'var(--red)';
          statusLabel = 'Needs attention';
        } else {
          statusColor = 'var(--orange)';
          statusLabel = 'Starting up\u2026 give it a minute';
        }
      } else if (moduleStatus === 'partial') {
        statusColor = 'var(--orange)';
        statusLabel = startingCount > 0 ? 'Starting up\u2026' : `${runningCount}/${totalSvc} Running`;
      } else {
        statusColor = 'var(--text-muted)';
        statusLabel = m.enabled ? 'Stopped' : '';
      }

      const actionBtn = renderAppActionButton(m, m.name);
      const hasFirstLogin = (m.services || []).some((svc) => svc.first_login);
      const firstLoginChip = hasFirstLogin ? '<span class="app-tag optional">First login <span class="sb-help" data-help="app-first-login" tabindex="0" role="button" aria-label="Why first login credentials are shown">?</span></span>' : '';
      const newBadge = isNewModule(m) ? '<span class="app-new-badge" title="Added to OpenBox in the last 30 days">NEW</span>' : '';
      const updateBadge = _availableUpdates[m.id] ? '<span class="app-update-badge" title="The publisher rebuilt the same pinned version with new base layers. Optional — only worth pulling for security patches.">REBUILD</span>' : '';
      return `
        <div class="app-card ${m.enabled ? 'enabled' : ''} ${m.required ? 'required' : ''}">
          <div class="app-top">
            <div class="app-icon" style="background:${darkBg(color)}; color:${color}">${serviceIcon(m.id, 28)}</div>
            ${actionBtn}
          </div>
          <div class="app-name">${esc(m.name)}${newBadge}${updateBadge}</div>
          ${m.enabled ? `
            <div class="app-card-status" style="color:${statusColor}">
              <span class="status-dot ${moduleStatus === 'running' ? 'on' : 'off'}"></span>
              ${statusLabel}
            </div>` : ''}
          ${m.tagline ? `<div class="app-tagline">${esc(m.tagline)}</div>` : ''}
          <div class="app-desc">${esc(m.description)}</div>
          ${m.services && m.services.length ? `
            <div class="app-services">
              <div class="app-services-title">Included services</div>
              ${m.services.map(svc => {
                const svcIcon = serviceIcon(svc.id, 16);
                const svcState = stateMap['sb-' + svc.id];
                const svcRunning = svcState === 'running';
                return `
                <div class="app-service-row">
                  <span class="app-service-name">${svcIcon} ${esc(svc.name)}</span>
                  <span style="display:flex;align-items:center;gap:0.35rem;">
                    ${m.enabled ? `<span class="status-dot ${svcRunning ? 'on' : 'off'}" style="width:6px;height:6px;"></span>` : ''}
                    ${svc.port ? `<span class="app-service-port">:${svc.port}</span>` : ''}
                  </span>
                </div>`;
              }).join('')}
            </div>` : ''}
          ${m.tips && m.tips.length ? `
            <div class="app-tips">
              ${m.tips.map(t => `<div class="app-tip">${linkifyHtml(t)}</div>`).join('')}
            </div>` : ''}
          <div class="app-meta">
            ${firstLoginChip}
            <span class="app-tag ${m.required ? 'required' : 'optional'}">${m.required ? 'Always On' : 'Optional'}</span>
            <span class="app-tag ram">${m.ram}</span>
            <span class="app-tag category">${CATEGORY_LABELS[m.category] || esc(m.category)}</span>
          </div>
        </div>`;
    }).join('');

    // Update store stats
    const enabledCount = modules.filter(m => m.enabled && !m.required).length;
    const totalOptional = modules.filter(m => !m.required).length;
    const storeStats = $('#store-stats');
    if (storeStats) {
      storeStats.textContent = `${enabledCount} of ${totalOptional} optional modules enabled`;
    }

    // Update RAM usage bar
    updateRamBar(modules);
  }

  // --- RAM Usage Bar ---

  function parseRam(ramStr) {
    if (!ramStr || ramStr === '?') return 0;
    const match = ramStr.match(/([\d.]+)\s*(MB|GB)/i);
    if (!match) return 0;
    const val = parseFloat(match[1]);
    if (match[2].toUpperCase() === 'GB') return val * 1024;
    return val;
  }

  function updateRamBar(modules) {
    let totalEstimated = 0;
    for (const m of modules) {
      if (m.enabled) {
        totalEstimated += parseRam(m.ram);
      }
    }

    // Get total system RAM from cached system info
    api('GET', '/system').then(info => {
      const totalSystemMB = Math.round(info.memory / (1024 * 1024));
      const percent = totalSystemMB > 0 ? Math.min(100, Math.round((totalEstimated / totalSystemMB) * 100)) : 0;
      const ramText = $('#ram-usage-text');
      const ramFill = $('#ram-bar-fill');
      if (ramText) ramText.textContent = `~${Math.round(totalEstimated)} MB / ${totalSystemMB} MB`;
      if (ramFill) {
        ramFill.style.width = percent + '%';
        ramFill.classList.remove('warn', 'danger');
        if (percent > 80) ramFill.classList.add('danger');
        else if (percent > 60) ramFill.classList.add('warn');
      }
    }).catch(() => {});
  }

  // --- Profile Selector ---

  // Event delegation for profile buttons
  document.addEventListener('click', async function (e) {
    const btn = e.target.closest('.profile-btn[data-profile]');
    if (!btn) return;

    const profileId = btn.dataset.profile;

    if (profileId === 'custom') {
      // Just select the button, no action
      $$('.profile-btn').forEach(b => b.classList.toggle('active', b.dataset.profile === 'custom'));
      return;
    }

    const ok = await confirm(
      `Apply ${profileId} profile?`,
      `This will change which modules are enabled. Your current custom selection will be replaced.`
    );
    if (!ok) return;

    try {
      toast(`Applying ${profileId} profile...`, 'info');
      const result = await api('POST', `/profiles/${profileId}/apply`);
      // Codex round 4 #5: /profiles/:id/apply returns warnings[] when
      // it drops modules that failed prerequisites (VPN not configured,
      // conflicts_with another enabled module). Those were silently
      // stripped — customer saw "Profile applied!" but media was NOT
      // enabled. Surface the warnings as a blocking alert so the user
      // knows what got dropped and why.
      if (result && Array.isArray(result.warnings) && result.warnings.length > 0) {
        const bullets = result.warnings.map(w => `  • ${w}`).join('\n');
        await confirm(
          'Profile applied with warnings',
          `${profileId} was applied, but some modules were skipped:\n\n${bullets}\n\nFix the prerequisites and retry from the Apps page.`,
          { confirmLabel: 'Got it', cancelLabel: '' },
        );
      } else {
        toast(`Profile applied! Reloading...`, 'success');
      }
      _storeData = null;
      await loadMetadata();
      loadApps();
      // Update button states
      $$('.profile-btn').forEach(b => b.classList.toggle('active', b.dataset.profile === profileId));
    } catch (err) {
      toast(err.message, 'error');
    }
  });

  // Module toggle handler — superseded by streaming handler registered in capturing phase (see bottom of file)

  // --- LOGS ---

  async function loadLogs() {
    try {
      const containers = await api('GET', '/containers');
      const sel = $('#log-select');
      sel.innerHTML = '<option value="">Pick a service...</option>' +
        containers.map(c => {
          const m = meta(c.name);
          return `<option value="${c.id}">${(SERVICE_ICONS[m.svcId] || m.emoji)} ${m.name}</option>`;
        }).join('');
    } catch (err) { toast('Could not load services.', 'error'); }
  }

  $('#log-select').addEventListener('change', (e) => {
    const id = e.target.value;
    const o = $('#log-output');
    o.textContent = '';
    window._logBuffer = [];
    if (currentLogStream) { socket.emit('logs:unsubscribe'); currentLogStream = null; }
    if (id) {
      currentLogStream = id;
      window._logCurrentContainer = e.target.selectedOptions[0]?.text || id;
      socket.emit('logs:subscribe', id);
      o.textContent = 'Connecting...\n';
      const dlBtn = $('#btn-log-download');
      if (dlBtn) dlBtn.disabled = false;
    } else {
      o.textContent = 'Pick a service above to see its logs here.';
      const dlBtn = $('#btn-log-download');
      if (dlBtn) dlBtn.disabled = true;
    }
  });

  // Log filter: re-render the pre from the full buffer whenever the
  // filter text changes, so toggling a filter off shows everything
  // instead of permanently losing the hidden lines.
  const logFilterInput = $('#log-filter');
  if (logFilterInput) {
    logFilterInput.addEventListener('input', () => {
      const o = $('#log-output');
      const filterText = logFilterInput.value.toLowerCase();
      const lines = window._logBuffer || [];
      o.textContent = filterText
        ? lines.filter(l => l.toLowerCase().includes(filterText)).join('')
        : lines.join('');
      const followEl = $('#log-follow');
      if (!followEl || followEl.checked) o.scrollTop = o.scrollHeight;
    });
  }

  // Log download: dumps the buffered stream (up to 5000 lines) to
  // a .log file. Customer can paste this into a forum post without
  // SSH-ing to the box.
  const logDownloadBtn = $('#btn-log-download');
  if (logDownloadBtn) {
    logDownloadBtn.addEventListener('click', () => {
      const lines = (window._logBuffer || []);
      if (!lines.length) { toast('Nothing to download yet — wait for some log output first.', 'info'); return; }
      const blob = new Blob([lines.join('')], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const container = window._logCurrentContainer || 'openbox';
      const safe = String(container).replace(/[^a-z0-9-]/gi, '_');
      const ts = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
      a.href = url;
      a.download = `${safe}-${ts}.log`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  }

  // --- SETTINGS ---

  // Settings sub-tab switching
  document.addEventListener('click', (e) => {
    const tab = e.target.closest('.settings-tab[data-stab]');
    if (!tab) return;
    const target = tab.dataset.stab;
    $$('.settings-tab').forEach(t => t.classList.toggle('active', t.dataset.stab === target));
    $$('.settings-panel').forEach(p => p.classList.toggle('hidden', p.dataset.stabPanel !== target));
  });

  async function loadSettings() {
    try {
      const [cfg, schema] = await Promise.all([
        api('GET', '/config'),
        api('GET', '/config/schema').catch(() => null)
      ]);
      renderSettings(cfg, schema);
      const backups = await api('GET', '/backups');
      renderBackups(backups);
      loadBackupSchedule();
      loadServicePasswords();
      loadHealthReports();
      loadAlertSettings();
      loadRemoteAccess();
      loadTelemetrySettings();
      const generalDomain = $('#general-domain-display');
      const generalTimezone = $('#general-timezone-display');
      if (generalDomain) generalDomain.textContent = cfg.OB_DOMAIN || '—';
      if (generalTimezone) generalTimezone.textContent = cfg.TZ || cfg.TIMEZONE || '—';
      // Show domain warning if OB_DOMAIN is not set
      const domainWarn = $('#domain-warning');
      const domainInput = $('#domain-base-input');
      if (domainWarn) {
        const domain = cfg.OB_DOMAIN;
        const hasDomain = domain && domain !== 'localhost' && domain !== 'openbox.local' && !/^\d+\.\d+\.\d+\.\d+$/.test(domain) && !domain.endsWith('.local');
        domainWarn.classList.toggle('hidden', hasDomain);
        if (hasDomain && domainInput && !domainInput.value) domainInput.value = domain;
      }
    } catch (err) { toast('Could not load settings.', 'error'); }
  }

  function renderSettings(cfg, schema) {
    const isSecret = (k) => /PASSWORD|SECRET|TOKEN|KEY|HASH/.test(k);

    // If we have a dynamic schema, use it
    if (schema && schema.length) {
      $('#settings-cards-tab').innerHTML = schema.map(group => {
        const hasDangerous = group.keys.some(k => k.dangerous);
        const rows = group.keys.filter(k => k.key in cfg || k.config_editable === false).map(k => {
          return `
          <div class="setting-row ${k.dangerous ? 'dangerous' : ''}">
            <label class="setting-label">
              ${esc(k.label)}
              ${k.tip ? `<span class="setting-tip" title="${esc(k.tip)}">i</span>` : ''}
              ${k.dangerous ? '<span class="danger-badge">Don\'t change</span>' : ''}
            </label>
            <input class="setting-input" type="${isSecret(k.key) ? 'password' : 'text'}"
                   data-key="${k.key}" data-original-value="${esc(String(cfg[k.key] || ''))}" value="${esc(String(cfg[k.key] || ''))}" placeholder="${isSecret(k.key) ? '\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022' : ''}"
                   ${k.dangerous || k.config_editable === false ? 'readonly' : ''}>
          </div>`;
        }).join('');
        if (!rows) return '';
        return `
          <div class="settings-group ${hasDangerous ? 'dangerous-group' : ''}">
            <div class="settings-group-title">
              ${esc(group.title)}
              <span class="sb-help" data-help="env-vars" tabindex="0" role="button" aria-label="How environment variable settings work">?</span>
              ${hasDangerous ? '<span class="group-warning">Contains security keys \u2014 be careful!</span>' : ''}
            </div>
            ${rows}
          </div>`;
      }).join('');
      return;
    }

    // Fallback: render all config keys in a single group
    $('#settings-cards-tab').innerHTML = `
      <div class="settings-group">
        <div class="settings-group-title">Configuration</div>
        ${Object.entries(cfg).map(([k, v]) => `
          <div class="setting-row">
            <label class="setting-label">${esc(k)}</label>
            <input class="setting-input" type="${isSecret(k) ? 'password' : 'text'}"
                   data-key="${esc(k)}" data-original-value="${esc(String(v || ''))}" value="${esc(String(v || ''))}" placeholder="${isSecret(k) ? '\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022' : ''}">
          </div>`).join('')}
      </div>`;
  }

  // Keys that are ONLY honored by containers at start time. If any
  // of these change, surfaced fields need a module recreate to take
  // effect — generic "settings saved" without this hint left
  // customers confused about whether their change was live.
  const RESTART_TRIGGERING_KEYS = new Set([
    'PUID', 'PGID', 'TZ', 'HTTP_PORT', 'HTTPS_PORT',
    'PIHOLE_DNS_PORT', 'PORTAINER_PORT', 'MEDIA_ROOT',
    'PHOTOS_PATH', 'BOOKS_PATH', 'MANGA_PATH',
    'JELLYFIN_HW_ACCEL', 'JELLYFIN_VIDEO_GID', 'JELLYFIN_RENDER_GID',
  ]);

  $('#btn-save-config-tab').addEventListener('click', async () => {
    const updates = {};
    // Capture current values so we can diff against the form — this
    // is how we know which keys actually changed vs which are just
    // being re-written with the same value.
    const previous = {};
    $$('#settings-cards-tab .setting-input').forEach(inp => {
      if (inp.value !== '********' && !inp.readOnly) {
        updates[inp.dataset.key] = inp.value;
        previous[inp.dataset.key] = inp.dataset.originalValue || '';
      }
    });

    if (Object.keys(updates).length === 0) {
      toast('No changes to save.', 'info');
      return;
    }

    const changedKeys = Object.keys(updates).filter(k => updates[k] !== previous[k]);
    const restartRequired = changedKeys.filter(k => RESTART_TRIGGERING_KEYS.has(k));

    const msg = restartRequired.length
      ? `This will update your configuration. These fields need a container recreate to take effect: ${restartRequired.join(', ')}. Hit "Restart All" in the top bar after saving, or the changes won't apply to running apps.`
      : 'This will update your server configuration.';
    const ok = await confirm('Save settings?', msg);
    if (!ok) return;

    const btn = $('#btn-save-config-tab');
    btnLoading(btn, true);
    try {
      await api('PUT', '/config', updates);
      if (restartRequired.length) {
        toast(`Saved. ${restartRequired.join(', ')} changed — click "Restart All" in the top bar for the new values to take effect.`, 'warning', 10000);
      } else {
        toast('Settings saved!', 'success');
      }
    } catch (err) { toast(err.message, 'error'); }
    finally { btnLoading(btn, false); }
  });

  function renderBackups(list) {
    const el = $('#backup-list');
    if (!list.length) { el.innerHTML = '<p style="color:var(--text-muted); font-size:0.9rem;">No backups yet. Create your first one!</p>'; return; }
    el.innerHTML = list.map(b => `
      <div class="backup-row">
        <div class="backup-row-info">
          <span class="backup-row-name">${b.filename} <span class="sb-help" data-help="backup-list" tabindex="0" role="button" aria-label="What this backup file contains">?</span>${b.encrypted ? ' <span class="badge-encrypted">\uD83D\uDD12 Encrypted</span>' : ''}${b.filename.includes('-full-') ? ' <span style="color:var(--accent);font-size:0.75rem">FULL</span>' : ' <span style="color:var(--text-muted);font-size:0.75rem">config</span>'}</span>
          <span class="backup-row-meta">${formatBytes(b.size)} \u00b7 ${new Date(b.created).toLocaleDateString()}</span>
        </div>
        <div style="display:flex;gap:0.5rem">
          <button class="btn-pill backup-restore-btn" data-backup="${esc(b.filename)}" style="background:var(--bg-raised);border:1px solid var(--border)">Restore</button>
          <span class="sb-help" data-help="backup-restore" tabindex="0" role="button" aria-label="How restore works">?</span>
          <a href="/api/backups/${b.filename}" class="btn-pill" download>Download</a>
        </div>
      </div>`).join('');
    // Wire up restore buttons
    el.querySelectorAll('.backup-restore-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const filename = btn.dataset.backup;
        const ok = await confirm('Restore from backup?', `This will overwrite your current configuration and data with the contents of ${filename}. Your services will restart.\n\nThis cannot be undone.`);
        if (!ok) return;
        btnLoading(btn, true);
        try {
          await api('POST', '/backup/restore', { filename });
          toast('Restore complete! Restarting services...', 'success');
          setTimeout(() => location.reload(), 3000);
        } catch (err) { toast(err.message, 'error'); }
        finally { btnLoading(btn, false); }
      });
    });
  }

  async function loadServicePasswords() {
    const el = $('#service-passwords-list');
    if (!el) return;
    try {
      const data = await api('GET', '/passwords');
      const entries = Object.values(data || {});
      if (entries.length === 0) {
        el.innerHTML = '<p style="color:var(--text-muted);font-size:0.88rem">No auto-generated passwords found.</p>';
        return;
      }
      el.innerHTML = entries.map(e => {
        // State files are either a bare one-line password, or a
        // labeled multi-line `username: admin\npassword: XXX` form
        // (qbittorrent, jellyfin autoseed). Render multi-line as a
        // pre-block so newlines survive; one-liner stays as a code span.
        const hasLineBreaks = /\n/.test(e.password);
        const credMarkup = hasLineBreaks
          ? `<pre style="background:var(--bg-sunken);padding:0.4rem 0.6rem;border-radius:4px;font-size:0.85rem;white-space:pre-wrap;user-select:all;margin:0">${esc(e.password)}</pre>`
          : `<code style="background:var(--bg-sunken);padding:0.25rem 0.6rem;border-radius:4px;font-size:0.85rem;user-select:all">${esc(e.password)}</code>`;
        return `
          <div class="setting-row" style="padding:0.5rem 0;border-bottom:1px solid var(--border);display:flex;align-items:flex-start;gap:0.75rem;flex-wrap:wrap">
            <span class="setting-label" style="font-weight:600;min-width:12rem">${esc(e.label)}</span>
            ${credMarkup}
          </div>`;
      }).join('');
    } catch (err) {
      el.innerHTML = `<p style="color:var(--text-muted);font-size:0.88rem">${esc(err.message || 'Could not load passwords.')}</p>`;
    }
  }

  $('#btn-create-backup').addEventListener('click', async () => {
    const btn = $('#btn-create-backup');
    btnLoading(btn, true);
    // Let the customer know this isn't a fast operation. A full
    // backup (with module data + media libraries) can take 10+
    // minutes on a NAS. Before this, the button just spun silently
    // with no duration hint and users thought the UI had frozen.
    toast('Creating backup — this can take a few minutes on large libraries. You can leave this page and check back.', 'info', 8000);
    try {
      const result = await api('POST', '/backup');
      // Codex round 4 #9: the previous toast ('Backup created!') didn't
      // tell customers where the backup went or imply anything about
      // off-box protection. Surface the filename AND remind them that
      // the backup lives on the SAME drive as the data it's backing up.
      const fn = (result && (result.filename || result.name)) || 'a new backup file';
      toast(
        `Saved to backups/${fn}. Download a copy to another drive — backups on the same disk won't help if the drive fails.`,
        'success',
        12000,
      );
      const backups = await api('GET', '/backups');
      renderBackups(backups);
    } catch (err) { toast(err.message, 'error'); }
    finally { btnLoading(btn, false); }
  });

  const revealBackupKeyBtn = $('#btn-reveal-backup-key');
  if (revealBackupKeyBtn) {
    revealBackupKeyBtn.addEventListener('click', async () => {
      btnLoading(revealBackupKeyBtn, true);
      try {
        const data = await api('GET', '/wizard/backup-key');
        const valueEl = $('#backup-key-value');
        if (valueEl) {
          valueEl.textContent = data.key || 'No backup key set.';
          valueEl.classList.remove('hidden');
        }
        toast('Backup key revealed. Save it somewhere safe.', 'success');
      } catch (err) {
        toast(err.message || 'Could not reveal backup key.', 'error');
      } finally {
        btnLoading(revealBackupKeyBtn, false);
      }
    });
  }

  // --- Backup Schedule (Pro Feature) ---

  const BACKUP_PRESETS = ['0 2 * * 0', '0 3 * * *', '0 2 1 * *'];

  async function loadBackupSchedule() {
    try {
      const schedule = await api('GET', '/backup/schedule');
      renderBackupSchedule(schedule);
    } catch { /* no schedule */ }
  }

  function renderBackupSchedule(schedule) {
    const checkbox = $('#backup-schedule-enabled');
    const configEl = $('#backup-schedule-config');
    const statusEl = $('#backup-schedule-status');
    if (checkbox) checkbox.checked = schedule.enabled;
    if (configEl) configEl.classList.toggle('hidden', !schedule.enabled);

    if (schedule.cron) {
      const presetSel = $('#backup-schedule-preset');
      const customRow = $('#backup-schedule-custom-row');
      const cronInput = $('#backup-schedule-cron');
      if (BACKUP_PRESETS.includes(schedule.cron)) {
        if (presetSel) presetSel.value = schedule.cron;
        if (customRow) customRow.classList.add('hidden');
      } else {
        if (presetSel) presetSel.value = 'custom';
        if (customRow) customRow.classList.remove('hidden');
        if (cronInput) cronInput.value = schedule.cron;
      }
    }

    const retentionInput = $('#backup-schedule-retention');
    if (retentionInput) retentionInput.value = schedule.retentionCount || 4;

    if (statusEl) {
      const parts = [];
      if (schedule.lastRun) parts.push(`Last scheduled backup: ${new Date(schedule.lastRun).toLocaleString()}`);
      if (schedule.enabled && schedule.cron) {
        const next = cronNextRun(schedule.cron);
        if (next) parts.push(`Next backup: ${next.toLocaleString()}`);
      }
      statusEl.textContent = parts.join(' \u00b7 ');
    }
  }

  function cronNextRun(expr) {
    try {
      const parts = expr.split(' ');
      if (parts.length !== 5) return null;
      const [min, hour, dom, mon, dow] = parts;
      const now = new Date();
      for (let i = 0; i < 400; i++) {
        const d = new Date(now.getTime() + i * 86400000);
        if (mon !== '*' && d.getMonth() + 1 !== parseInt(mon)) continue;
        if (dom !== '*' && d.getDate() !== parseInt(dom)) continue;
        if (dow !== '*' && d.getDay() !== parseInt(dow)) continue;
        d.setHours(parseInt(hour) || 0, parseInt(min) || 0, 0, 0);
        if (d > now) return d;
      }
      return null;
    } catch { return null; }
  }

  const backupScheduleToggle = $('#backup-schedule-enabled');
  if (backupScheduleToggle) {
    backupScheduleToggle.addEventListener('change', () => {
      const configEl = $('#backup-schedule-config');
      if (configEl) configEl.classList.toggle('hidden', !backupScheduleToggle.checked);
    });
  }

  const backupPresetSel = $('#backup-schedule-preset');
  if (backupPresetSel) {
    backupPresetSel.addEventListener('change', () => {
      const customRow = $('#backup-schedule-custom-row');
      if (customRow) customRow.classList.toggle('hidden', backupPresetSel.value !== 'custom');
    });
  }

  const saveBackupScheduleBtn = $('#btn-save-backup-schedule');
  if (saveBackupScheduleBtn) {
    saveBackupScheduleBtn.addEventListener('click', async () => {
      const enabled = $('#backup-schedule-enabled').checked;
      const presetVal = $('#backup-schedule-preset').value;
      const cronExpr = presetVal === 'custom' ? ($('#backup-schedule-cron').value || '').trim() : presetVal;
      const retentionCount = parseInt($('#backup-schedule-retention').value, 10) || 4;

      if (!cronExpr) {
        toast('Please enter a cron expression.', 'error');
        return;
      }

      btnLoading(saveBackupScheduleBtn, true);
      try {
        const result = await api('PUT', '/backup/schedule', { cron: cronExpr, enabled, retentionCount });
        renderBackupSchedule(result);
        toast('Backup schedule saved!', 'success');
      } catch (err) {
        toast(err.message || 'Failed to save backup schedule.', 'error');
      }
      btnLoading(saveBackupScheduleBtn, false);
    });
  }

  // --- Remote Access (Pro Feature) ---

  async function loadRemoteAccess() {
    const container = $('#remote-access-methods');
    if (!container) return;
    try {
      const data = await api('GET', '/remote-access');
      renderAccessMethods(data.methods);
    } catch (err) {
      if (err.message && (err.message.includes('License required') || err.message.includes('Pro feature'))) {
        container.innerHTML = '<p style="color:var(--text-muted); font-size:0.85rem;">Activate a free license to manage remote access — Settings → License.</p>';
      } else {
        container.innerHTML = '<p style="color:var(--text-muted); font-size:0.85rem;">Could not load remote access info.</p>';
      }
    }
  }

  // --- Telemetry (Settings → Privacy) ---
  async function loadTelemetrySettings() {
    const toggle = $('#telemetry-toggle');
    const label = $('#telemetry-toggle-label');
    if (!toggle) return;
    try {
      const settings = await api('GET', '/telemetry/settings');
      toggle.checked = !!settings.enabled;
      if (label) label.textContent = settings.enabled ? 'On — thank you!' : 'Off';
    } catch {
      toggle.checked = false;
      if (label) label.textContent = 'Off';
    }
    // Wire change handler once.
    if (!toggle.dataset.wired) {
      toggle.dataset.wired = '1';
      toggle.addEventListener('change', async () => {
        const enabled = toggle.checked;
        try {
          await api('POST', '/telemetry/settings', { enabled });
          if (label) label.textContent = enabled ? 'On — thank you!' : 'Off';
          toast(enabled ? 'Error tracking enabled. Thanks for helping the beta.' : 'Error tracking disabled.', 'ok');
        } catch (err) {
          toggle.checked = !enabled; // revert
          toast('Could not save telemetry setting.', 'error');
        }
      });
    }
    // Wire history-viewer once.
    const histBtn = $('#btn-telemetry-history');
    const histOut = $('#telemetry-history-output');
    if (histBtn && histOut && !histBtn.dataset.wired) {
      histBtn.dataset.wired = '1';
      histBtn.addEventListener('click', async () => {
        if (!histOut.classList.contains('hidden') && histOut.dataset.shown === '1') {
          histOut.classList.add('hidden');
          histOut.dataset.shown = '0';
          histBtn.textContent = "View what we've sent (last 50)";
          return;
        }
        try {
          const { history } = await api('GET', '/telemetry/history');
          if (!history || history.length === 0) {
            histOut.textContent = 'No events sent yet. (Either telemetry is off, or nothing has crashed since you turned it on.)';
          } else {
            histOut.textContent = JSON.stringify(history, null, 2);
          }
          histOut.classList.remove('hidden');
          histOut.dataset.shown = '1';
          histBtn.textContent = 'Hide history';
        } catch {
          toast('Could not load telemetry history.', 'error');
        }
      });
    }
  }

  function renderAccessMethods(methods) {
    const container = $('#remote-access-methods');
    if (!container || !methods) return;

    const iconMap = { wifi: '&#128246;', globe: '&#127760;', link: '&#128279;', 'at-sign': '&#64;' };

    container.innerHTML = methods.map(m => `
      <div style="display:flex; align-items:center; gap:0.75rem; padding:0.75rem 0; border-bottom:1px solid var(--border);">
        <span style="font-size:1.4rem; width:2rem; text-align:center;">${iconMap[m.icon] || '&#128279;'}</span>
        <div style="flex:1; min-width:0;">
          <div style="font-weight:600; font-size:0.9rem;">${esc(m.name)}
            <span style="font-size:0.75rem; padding:0.15rem 0.5rem; border-radius:0.25rem; margin-left:0.5rem;
              background:${m.available ? 'rgba(52,199,89,0.15)' : 'rgba(255,59,48,0.1)'};
              color:${m.available ? 'var(--green, #34c759)' : 'var(--red, #ff3b30)'};">
              ${m.available ? (m.status === 'running' ? 'Active' : 'Enabled') : 'Not configured'}
            </span>
          </div>
          <div style="font-size:0.8rem; color:var(--text-muted); margin-top:0.15rem;">${esc(m.description)}</div>
          ${m.url ? `<div style="font-size:0.78rem; color:var(--accent); margin-top:0.25rem; cursor:pointer; word-break:break-all;"
            onclick="navigator.clipboard.writeText('${esc(m.url)}'); this.textContent='Copied!'; setTimeout(()=>this.textContent='${esc(m.url)}',1500)"
            title="Click to copy">${esc(m.url)}</div>` : ''}
        </div>
      </div>
    `).join('');
  }

  const btnSetupWg = $('#btn-setup-wireguard');
  if (btnSetupWg) {
    btnSetupWg.addEventListener('click', async () => {
      // Pre-flight: the vpn module has to be enabled before we can
      // create a WireGuard client — it owns the wg-easy container.
      // Before this guard, clicking Set Up WireGuard on a box that
      // had never enabled VPN returned an opaque "Cannot reach
      // wg-easy" backend error.
      //
      // 2026-04-29: ABOhiccups reported "WireGuard app was already
      // installed" but Remote Access said "not setup". Root cause:
      // window._cachedModules was empty (Settings tab opened directly
      // without first loading Apps), so .some() returned false and
      // the false-negative message fired. Fetch fresh module state
      // when cache is missing/empty so the check is reliable.
      let modulesList = window._cachedModules;
      if (!modulesList || modulesList.length === 0) {
        try {
          const r = await api('GET', '/modules');
          if (r && Array.isArray(r.modules)) modulesList = r.modules;
        } catch { /* fall through to cached/empty */ }
      }
      const vpnEnabled = (modulesList || []).some(m => m && m.id === 'vpn' && m.enabled);
      if (!vpnEnabled) {
        const ok = await confirm(
          'Enable the VPN module first',
          'WireGuard clients are created by the VPN module\'s wg-easy container, which isn\'t running yet.\n\nEnable the VPN module from the Apps page, wait ~30 seconds for it to start, then come back here.'
        , { confirmLabel: 'Go to Apps', cancelLabel: 'Close' });
        if (ok) switchPage('apps');
        return;
      }
      btnLoading(btnSetupWg, true);
      try {
        const result = await api('POST', '/remote-access/wireguard/client');
        const panel = $('#wireguard-result');
        panel.classList.remove('hidden');

        if (result.qrDataUrl) {
          $('#wireguard-qr').innerHTML = `<img src="${result.qrDataUrl}" alt="WireGuard QR Code" style="max-width:200px; border-radius:0.5rem;">`;
        } else {
          $('#wireguard-qr').innerHTML = '<p style="color:var(--text-muted); font-size:0.8rem;">QR code not available. Copy config below.</p>';
        }

        $('#wireguard-config-text').value = result.config || '';
        toast('WireGuard client created! Scan the QR code with the WireGuard app.', 'success');
      } catch (err) {
        toast(err.message || 'Failed to create WireGuard client.', 'error');
      }
      btnLoading(btnSetupWg, false);
    });
  }

  const btnCopyWg = $('#btn-copy-wg-config');
  if (btnCopyWg) {
    btnCopyWg.addEventListener('click', () => {
      const text = $('#wireguard-config-text').value;
      navigator.clipboard.writeText(text).then(() => toast('Config copied!', 'success'));
    });
  }

  const btnDownloadWg = $('#btn-download-wg-config');
  if (btnDownloadWg) {
    btnDownloadWg.addEventListener('click', () => {
      const text = $('#wireguard-config-text').value;
      const blob = new Blob([text], { type: 'text/plain' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'openbox-wireguard.conf';
      a.click();
      URL.revokeObjectURL(a.href);
    });
  }

  const btnCheckTs = $('#btn-check-tailscale');
  if (btnCheckTs) {
    btnCheckTs.addEventListener('click', async () => {
      btnLoading(btnCheckTs, true);
      try {
        const status = await api('GET', '/remote-access/tailscale/status');
        const panel = $('#tailscale-result');
        panel.classList.remove('hidden');
        const content = $('#tailscale-status-content');

        if (status.connected) {
          // The dashboard port that opens by default is 8443. Show
          // the exact URL a customer needs to hit from their phone/
          // laptop. Without this, customers saw an IP + tailnet
          // name but had no idea what URL to plug into their
          // browser on a remote device.
          const dashPort = (location.port || '8443');
          const proto = location.protocol.replace(':', '');
          const tailscaleDashUrl = status.ip ? `${proto}://${status.ip}:${dashPort}` : null;
          content.innerHTML = `
            <div style="display:grid; gap:0.5rem; font-size:0.85rem;">
              <div><strong>Status:</strong> <span style="color:var(--green, #34c759);">Connected</span></div>
              ${status.hostname ? `<div><strong>Hostname:</strong> ${esc(status.hostname)}</div>` : ''}
              ${status.ip ? `<div><strong>Tailscale IP:</strong> <span style="cursor:pointer; color:var(--accent);"
                onclick="navigator.clipboard.writeText('${esc(status.ip)}'); this.textContent='Copied!'; setTimeout(()=>this.textContent='${esc(status.ip)}',1500)">${esc(status.ip)}</span></div>` : ''}
              ${status.tailnetName ? `<div><strong>Tailnet:</strong> ${esc(status.tailnetName)}</div>` : ''}
              ${status.peers && status.peers.length ? `
                <div style="margin-top:0.5rem;"><strong>Connected Peers:</strong></div>
                ${status.peers.filter(p => p.online).map(p => `
                  <div style="padding-left:1rem; color:var(--text-muted);">${esc(p.hostname)} (${esc(p.ip || '?')})</div>
                `).join('')}
              ` : ''}
              ${tailscaleDashUrl ? `
                <div style="margin-top:0.75rem; padding:0.6rem 0.8rem; background:var(--bg-sunken); border-radius:6px; border-left:3px solid var(--accent);">
                  <strong>How to connect from your phone/laptop:</strong><br>
                  <span style="color:var(--text-muted); font-size:0.82rem;">
                    1. Install the Tailscale app from <a href="https://tailscale.com/download" target="_blank" rel="noopener" style="color:var(--accent);">tailscale.com/download</a> on the device you want to connect FROM<br>
                    2. Sign in with the same account as this OpenBox<br>
                    3. Open this URL in your browser:
                  </span>
                  <div style="margin-top:0.4rem;"><code style="background:var(--bg);padding:0.2rem 0.5rem;border-radius:4px;color:var(--accent);cursor:pointer"
                    onclick="navigator.clipboard.writeText('${esc(tailscaleDashUrl)}'); this.textContent='Copied!'; setTimeout(()=>this.textContent='${esc(tailscaleDashUrl)}',1500)">${esc(tailscaleDashUrl)}</code></div>
                </div>` : ''}
            </div>`;
        } else {
          content.innerHTML = `
            <div style="font-size:0.85rem;">
              <p style="color:var(--red, #ff3b30);">Tailscale is not connected.</p>
              <p style="color:var(--text-muted); margin-top:0.5rem;">
                <strong>To set up Tailscale:</strong><br>
                1. Get an auth key from <a href="https://login.tailscale.com/admin/settings/keys" target="_blank" rel="noopener" style="color:var(--accent);">Tailscale Admin Console</a><br>
                2. Enable the Tailscale module in the App Store<br>
                3. Enter your auth key when prompted
              </p>
              ${status.error ? `<p style="color:var(--text-muted); font-size:0.78rem; margin-top:0.5rem;">Error: ${esc(status.error)}</p>` : ''}
            </div>`;
        }
      } catch (err) {
        // Before v1.5.49 this toast was the ONLY feedback — after
        // it faded the customer saw an empty panel and had no
        // idea what went wrong or what to try next. Now we also
        // render the error inline with the usual suspects.
        toast(err.message || 'Failed to check Tailscale status.', 'error');
        const panel = $('#tailscale-result');
        const content = $('#tailscale-status-content');
        if (panel && content) {
          panel.classList.remove('hidden');
          content.innerHTML = `
            <div style="font-size:0.85rem;">
              <p style="color:var(--red, #ff3b30);"><strong>Couldn't reach Tailscale.</strong></p>
              <p style="color:var(--text-muted); margin-top:0.4rem; font-size:0.82rem;">${esc(err.message || 'Network error')}</p>
              <p style="color:var(--text-muted); margin-top:0.75rem; font-size:0.82rem;">Common causes:</p>
              <ul style="color:var(--text-muted); font-size:0.82rem; padding-left:1.25rem; margin-top:0.25rem;">
                <li>Tailscale module isn't enabled — enable it from the Apps page.</li>
                <li>Auth key is missing or expired — regenerate at <a href="https://login.tailscale.com/admin/settings/keys" target="_blank" rel="noopener" style="color:var(--accent);">Tailscale Admin Console</a> and re-paste in Settings.</li>
                <li>Tailscale container is restarting — give it ~60 seconds and re-click Check.</li>
              </ul>
            </div>`;
        }
      }
      btnLoading(btnCheckTs, false);
    });
  }

  // --- Domain Wizard (Pro Feature) ---

  let _domainSuggestions = [];

  const btnLoadSuggestions = $('#btn-load-suggestions');
  if (btnLoadSuggestions) {
    btnLoadSuggestions.addEventListener('click', async () => {
      const baseDomain = $('#domain-base-input').value.trim();
      if (!baseDomain || !baseDomain.includes('.')) {
        toast('Enter a valid base domain (e.g., example.com).', 'error');
        return;
      }
      btnLoading(btnLoadSuggestions, true);
      try {
        // Fetch the detected server IP so we can tell the customer
        // EXACTLY what A-record(s) to create — before this they were
        // told "your DNS must point to this server" with no idea what
        // the server's IP even is.
        let serverIp = 'your-server-ip';
        try {
          const vpn = await api('GET', '/vpn/status').catch(() => null);
          if (vpn && vpn.real_ip) serverIp = vpn.real_ip;
        } catch {}
        // Fallback: if the user opened the dashboard via LAN IP,
        // reuse that — it's what their A record should point at
        // for local use. For internet-facing, they'll need their
        // router's public IP or a DDNS hostname.
        if (serverIp === 'your-server-ip' && location.hostname && /^[0-9a-fA-F.:]+$/.test(location.hostname)) {
          serverIp = location.hostname;
        }
        const preflightOk = await confirm(
          'DNS preflight check',
          `Before we set up subdomains under ${baseDomain}, make sure you've pointed DNS at this server.\n\n` +
          `Create this record at your domain registrar (Cloudflare, Namecheap, etc.):\n\n` +
          `  Type:  A  (or CNAME if using DDNS)\n` +
          `  Name:  *   (wildcard — points all subdomains at your server)\n` +
          `  Value: ${serverIp}\n` +
          `  TTL:   300 (or Auto)\n\n` +
          `If you're on a home NAS, you'll also need to forward port 443 from your router to this server, and use a public IP or DDNS hostname (not a LAN IP). DNS changes take ~5 minutes to propagate.\n\n` +
          `Ready to continue?`
        , { confirmLabel: 'DNS is ready, continue', cancelLabel: 'Let me set it up first' });
        if (!preflightOk) return;

        _domainSuggestions = await api('GET', `/domains/suggestions?domain=${encodeURIComponent(baseDomain)}`);
        renderDomainSuggestions(_domainSuggestions);

        // Also load existing proxy hosts
        try {
          const existing = await api('GET', '/domains');
          renderExistingDomains(existing);
        } catch { /* NPM might not be reachable */ }
      } catch (err) {
        toast(err.message || 'Failed to load suggestions.', 'error');
      }
      btnLoading(btnLoadSuggestions, false);
    });
  }

  function renderDomainSuggestions(suggestions) {
    const container = $('#domain-suggestions');
    if (!container) return;
    if (!suggestions.length) {
      container.innerHTML = '<p style="color:var(--text-muted); font-size:0.85rem;">No enabled services found to configure.</p>';
      return;
    }

    container.innerHTML = `
      <div style="margin-bottom:0.5rem; font-size:0.85rem; font-weight:600;">Suggested Subdomains</div>
      ${suggestions.map((s, i) => `
        <div style="display:flex; align-items:center; gap:0.75rem; padding:0.6rem 0; border-bottom:1px solid var(--border);">
          <label style="display:flex; align-items:center; gap:0.5rem; cursor:pointer; flex:1; min-width:0;">
            <input type="checkbox" class="domain-toggle" data-index="${i}" checked style="width:1.1rem; height:1.1rem; accent-color:var(--accent);">
            <div style="min-width:0;">
              <div style="font-size:0.85rem; font-weight:500;">${esc(s.domain)}</div>
              <div style="font-size:0.75rem; color:var(--text-muted);">Routes to ${esc(s.serviceName)} (internal only — OpenBox handles the details) <span class="sb-tooltip" title="Technical target: ${esc(s.forwardHost)}:${s.forwardPort}" style="cursor:help; opacity:0.6;">ⓘ</span></div>
            </div>
          </label>
        </div>
      `).join('')}
    `;

    const setupBtn = $('#btn-setup-domains');
    if (setupBtn) setupBtn.classList.remove('hidden');
  }

  function renderExistingDomains(hosts) {
    const container = $('#domain-existing');
    if (!container) return;
    if (!hosts.length) return;

    container.innerHTML = `
      <div style="margin-top:1rem; margin-bottom:0.5rem; font-size:0.85rem; font-weight:600;">Existing Proxy Hosts</div>
      ${hosts.map(h => `
        <div style="display:flex; align-items:center; gap:0.75rem; padding:0.5rem 0; border-bottom:1px solid var(--border);">
          <span style="font-size:0.75rem; padding:0.15rem 0.5rem; border-radius:0.25rem;
            background:${h.enabled ? 'rgba(52,199,89,0.15)' : 'rgba(255,59,48,0.1)'};
            color:${h.enabled ? 'var(--green, #34c759)' : 'var(--red, #ff3b30)'};">
            ${h.ssl ? 'SSL' : h.enabled ? 'Active' : 'Disabled'}
          </span>
          <div style="flex:1; min-width:0;">
            <div style="font-size:0.85rem; font-weight:500;">${esc(h.domain)}</div>
            <div style="font-size:0.75rem; color:var(--text-muted);">${esc(h.forwardHost)}:${h.forwardPort}</div>
          </div>
        </div>
      `).join('')}
    `;
  }

  const btnSetupDomains = $('#btn-setup-domains');
  if (btnSetupDomains) {
    btnSetupDomains.addEventListener('click', async () => {
      const checkboxes = document.querySelectorAll('.domain-toggle:checked');
      if (!checkboxes.length) {
        toast('Select at least one domain to set up.', 'info');
        return;
      }

      const ok = await confirm(
        'Set up domains?',
        `This will create ${checkboxes.length} proxy host(s) in Nginx Proxy Manager with Let\'s Encrypt SSL. Your DNS must already point to this server.`
      );
      if (!ok) return;

      btnLoading(btnSetupDomains, true);
      const statusEl = $('#domain-setup-status');
      const results = [];

      for (const cb of checkboxes) {
        const idx = parseInt(cb.dataset.index);
        const s = _domainSuggestions[idx];
        if (!s) continue;

        try {
          await api('POST', '/domains/setup', {
            domain: s.domain,
            service: s.service,
            ssl: true,
          });
          results.push({ domain: s.domain, success: true });
        } catch (err) {
          results.push({ domain: s.domain, success: false, error: err.message });
        }
      }

      statusEl.innerHTML = results.map(r => `
        <div style="font-size:0.82rem; padding:0.25rem 0; color:${r.success ? 'var(--green, #34c759)' : 'var(--red, #ff3b30)'};">
          ${r.success ? '&#10003;' : '&#10007;'} ${esc(r.domain)} ${r.error ? '&mdash; ' + esc(r.error) : ''}
        </div>
      `).join('');

      const successCount = results.filter(r => r.success).length;
      if (successCount > 0) {
        toast(`${successCount} domain(s) configured!`, 'success');
      }
      if (successCount < results.length) {
        toast(`${results.length - successCount} domain(s) failed. Check DNS settings.`, 'error');
      }

      btnLoading(btnSetupDomains, false);
    });
  }

  // --- Help Page ---

  function renderHelpServices() {
    const el = $('#help-services');
    if (!el) return;
    el.innerHTML = Object.entries(_serviceMeta)
      .filter(([, m]) => m.desc)
      .map(([key, m]) => `
        <div class="help-service-card">
          <div class="help-service-icon" style="background:${darkBg(m.color)}; color:${m.color}">${serviceIcon(m.svcId, 24)}</div>
          <div class="help-service-info">
            <div class="help-service-name">${esc(m.name)}</div>
            <div class="help-service-desc">${esc(m.desc)}</div>
            ${m.tip ? `<div class="help-service-tip">${esc(m.tip)}</div>` : ''}
          </div>
        </div>`
      ).join('');
  }

  // Onboarding banner removed in v1.6.20 along with the wizard. The
  // dashboard's nav (Home / Apps / Help / Settings) is self-evident —
  // the 3-step "Check Home / Toggle Apps / Read Help" guide added
  // visual noise without clarifying anything a real-world user could
  // figure out in 5 seconds. showOnboarding() is now a no-op stub for
  // any callers that haven't been migrated; safe to delete entirely
  // once the dust settles.
  function showOnboarding() { /* removed — see comment above */ }

  // ---- Help FAB (the "?" bottom-right button) ----
  // Opens the community-help modal. Markup + modal exist in
  // index.html but no click handler was wired — this is the fix.
  // Modal closes on cancel button OR clicking outside the box.
  // "Copy my server info" button gathers diagnostic data and
  // shows it inline + copies to clipboard for pasting in a forum
  // thread.
  document.addEventListener('click', async function (e) {
    if (e.target.closest('#help-fab')) {
      const overlay = $('#help-modal-overlay');
      if (overlay) overlay.classList.remove('hidden');
      return;
    }
    if (e.target.closest('#help-modal-cancel')) {
      const overlay = $('#help-modal-overlay');
      if (overlay) overlay.classList.add('hidden');
      return;
    }
    // Click outside the modal box (on the overlay backdrop) closes too.
    if (e.target.id === 'help-modal-overlay') {
      e.target.classList.add('hidden');
      return;
    }
    // Open the private-ticket modal. Multiple trigger points around
    // the app — Help modal footer link + any guide/settings card that
    // sets data-open-ticket="1". Unified handler so every surface
    // opens the same modal. Tom asked to put it "in every support
    // area" on v1.5.108.
    const ticketTrigger = e.target.closest('#help-modal-open-ticket, [data-open-ticket]');
    if (ticketTrigger) {
      e.preventDefault();
      $('#help-modal-overlay')?.classList.add('hidden');
      const tm = $('#ticket-modal-overlay');
      if (tm) {
        tm.classList.remove('hidden');
        const errEl = $('#ticket-modal-error'); if (errEl) { errEl.textContent = ''; errEl.style.display = 'none'; }
        const okEl = $('#ticket-modal-success'); if (okEl) { okEl.textContent = ''; okEl.style.display = 'none'; }
        setTimeout(() => $('#ticket-subject')?.focus(), 50);
      }
      return;
    }
    if (e.target.closest('#ticket-modal-cancel') || e.target.id === 'ticket-modal-overlay') {
      const tm = $('#ticket-modal-overlay');
      if (tm) tm.classList.add('hidden');
      return;
    }
    if (e.target.closest('#ticket-modal-submit')) {
      const btn = e.target.closest('#ticket-modal-submit');
      const errEl = $('#ticket-modal-error');
      const okEl = $('#ticket-modal-success');
      const subject = $('#ticket-subject')?.value?.trim() || '';
      const message = $('#ticket-message')?.value?.trim() || '';
      const replyTo = $('#ticket-reply-to')?.value?.trim() || '';
      const includeServerInfo = !!$('#ticket-include-server-info')?.checked;
      if (errEl) { errEl.textContent = ''; errEl.style.display = 'none'; }
      if (okEl) { okEl.textContent = ''; okEl.style.display = 'none'; }
      if (!subject) { if (errEl) { errEl.textContent = 'Subject is required.'; errEl.style.display = 'block'; } return; }
      if (!message) { if (errEl) { errEl.textContent = 'Message is required.'; errEl.style.display = 'block'; } return; }
      const origLabel = btn.textContent;
      btn.disabled = true;
      btn.textContent = 'Sending…';
      try {
        // Use the api() helper (not raw fetch) so the X-CSRF-Token
        // header gets added — dashboard's CSRF middleware rejects
        // POSTs without it. Previous raw-fetch version failed with
        // "CSRF token mismatch" on every submit.
        const payload = await api('POST', '/support/ticket', {
          subject, message, replyTo, includeServerInfo,
        });
        if (payload && payload.success) {
          if (okEl) {
            okEl.textContent = `Ticket sent. Reference: ${payload.ticketId || 'confirmed'}. Crush Code Works will reply by email (usually same day).`;
            okEl.style.display = 'block';
          }
          if ($('#ticket-subject')) $('#ticket-subject').value = '';
          if ($('#ticket-message')) $('#ticket-message').value = '';
          setTimeout(() => $('#ticket-modal-overlay')?.classList.add('hidden'), 4000);
        } else if (errEl) {
          errEl.textContent = (payload && payload.error) || 'Send failed. Try again, or post on d/openbox.';
          errEl.style.display = 'block';
        }
      } catch (err) {
        if (errEl) {
          errEl.textContent = err.message || err.error || 'Network error — your message wasn\'t sent.';
          errEl.style.display = 'block';
        }
      } finally {
        btn.disabled = false;
        btn.textContent = origLabel;
      }
      return;
    }
    if (e.target.closest('#help-modal-copy')) {
      const btn = e.target.closest('#help-modal-copy');
      const orig = btn.textContent;
      btn.textContent = 'Gathering…';
      btn.disabled = true;
      try {
        // Pull server-side diagnostic info via the same endpoints the
        // dashboard's other panels use. Fail silently per-call so a
        // partial result still copies something useful.
        const safe = async (fn) => { try { return await fn(); } catch { return null; } };
        const [version, status, license] = await Promise.all([
          safe(() => fetch('/api/auth/status').then(r => r.json())),
          safe(() => api('GET', '/containers').catch(() => null)),
          safe(() => api('GET', '/license').catch(() => null)),
        ]);
        const containers = Array.isArray(status) ? status : (status?.containers || []);
        const lines = [
          'OpenBox diagnostic info',
          '------',
          'URL: ' + location.origin,
          'User-Agent: ' + navigator.userAgent,
          'License tier: ' + (license?.tier || 'unknown'),
          'Containers: ' + (containers.length || 0) + ' running',
          '',
          'Tell us what went wrong below this line.',
          '',
        ];
        const text = lines.join('\n');
        try { await navigator.clipboard.writeText(text); } catch {}
        const diag = $('#help-modal-diagnostic');
        const diagText = $('#help-diagnostic-text');
        if (diag && diagText) {
          diagText.textContent = text;
          diag.classList.remove('hidden');
        }
        btn.textContent = '✓ Copied to clipboard';
      } catch (err) {
        btn.textContent = 'Couldn\'t gather — copy manually';
      }
      setTimeout(() => { btn.textContent = orig; btn.disabled = false; }, 3000);
    }
  });

  // Launcher first-login interceptor — when the user clicks an app that
  // has a first_login hint (default credentials, a setup-wizard flow,
  // etc.) and hasn't seen the hint yet for this app, show a modal with
  // the hint before opening the app in a new tab. Prevents the
  // "installed the app but have no idea what the login is" wall that
  // hit every app with defaults (BookStack admin@admin.com, AdGuard's
  // setup wizard, PhotoPrism's user-set admin password, etc.).
  //
  // Auto-detect: if the app's container logs contain a credential
  // printout (Frigate's "Password: <hex>" pattern etc.), we also hit
  // /api/containers/:id/first-login-creds and surface those matches
  // in the same modal so users never have to SSH in and grep.
  // Separate handler for the "launcher clicked while service isn't
  // running" case. Before this, clicking a dim tile opened a dead
  // browser tab with no explanation.
  // Loopback-only services (NPM admin, etc.) bound to 127.0.0.1 on the
  // host. LAN links refuse — show an SSH-tunnel instruction modal
  // instead. Tom's 2026-04-24 live review.
  document.addEventListener('click', async function (e) {
    const loop = e.target.closest('.launcher-icon[data-loopback-service]');
    if (!loop) return;
    e.preventDefault();
    const svcName = loop.getAttribute('data-loopback-service') || 'this service';
    const port = loop.getAttribute('data-loopback-port') || '';
    const host = location.hostname;
    const tunnelCmd = `ssh -L ${port}:localhost:${port} USER@${host}`;
    await confirm(
      `${svcName} admin UI is local-only`,
      `${svcName} binds its admin port (${port}) to 127.0.0.1 on the NAS for security. A direct LAN link would always refuse.\n\nTo access it, open an SSH tunnel from your laptop:\n\n  ${tunnelCmd}\n\nThen open http://localhost:${port}/ in your browser.\n\nMost domain and SSL tasks are also available from Settings → Domains without needing the raw admin UI.`,
      { confirmLabel: 'Copy SSH command', cancelLabel: 'Close' },
    ).then((ok) => {
      if (ok && navigator.clipboard) {
        navigator.clipboard.writeText(tunnelCmd).catch(() => {});
      }
    });
  });

  document.addEventListener('click', async function (e) {
    const deadLink = e.target.closest('.launcher-icon[data-not-running="1"]');
    if (!deadLink) return;
    // Let the first-login handler below handle cases where BOTH
    // attributes are present — that handler already covers the
    // dead-service case via the title attribute.
    if (deadLink.hasAttribute('data-first-login')) return;
    e.preventDefault();
    const name = deadLink.querySelector('.launcher-icon-name')?.textContent || 'This app';
    await confirm(
      `${name} isn't running`,
      `${name} hasn't started yet — the container is stopped or still waiting on its dependencies.\n\nCheck the Apps page for status. Most commonly this means the module needs configuration (VPN creds for Media, SMTP for Vaultwarden, etc.) that hasn't been filled in yet.`,
      { confirmLabel: 'Go to Apps', cancelLabel: 'Close' }
    ).then(ok => { if (ok) switchPage('apps'); });
  });

  document.addEventListener('click', async function (e) {
    const link = e.target.closest('.launcher-icon[data-first-login]');
    if (!link) return;
    e.preventDefault();
    const hint = link.getAttribute('data-first-login');
    const key = link.getAttribute('data-first-login-key');
    const url = link.getAttribute('data-launch-url') || link.href;
    const container = link.getAttribute('data-container');
    const name = link.querySelector('.launcher-icon-name')?.textContent || 'this app';

    // Vaultwarden gets a dedicated rich-popup setup flow instead of the
    // generic plain-text modal — the HTTPS-on-LAN problem deserves an
    // actual interactive guide with browser-detected install link and
    // copy-to-clipboard server URL. Generic modal just dumps the text
    // hint and that wasn't getting through.
    if (container === 'ob-vaultwarden') {
      if (key) {
        localStorage.setItem(key, '1');
        link.removeAttribute('data-first-login');
      }
      await vaultwardenSetupModal(url, container);
      return;
    }
    let extra = '';
    let credsAvailable = false;
    if (container) {
      try {
        // api() auto-prompts + retries once when the server returns
        // 401 reauth_required (see needsRecentReauth whitelist + the
        // retry branch in api()). No manual handling needed here.
        const r = await api('GET', `/containers/${encodeURIComponent(container)}/first-login-creds`);
        if (r && Array.isArray(r.matches) && r.matches.length > 0) {
          // State-file path (source: 'state-file') returns creds
          // directly; log-scrape returns lines from container logs.
          // Label accordingly so the customer knows where to trust.
          const label = r.source === 'state-file'
            ? '\n\nOpenBox generated these for you:'
            : '\n\nFound in container logs:';
          extra = label + '\n' + r.matches.join('\n');
          credsAvailable = true;
        }
        // Intentionally do NOT surface the "couldn't find in logs"
        // truncated hint when there's already a static first_login
        // hint above — the static hint IS the answer for apps like
        // BookStack with baked-in defaults.
      } catch (e) {
        // If the user dismissed the password-confirmation prompt OR
        // the reauth flow itself errored, surface that explicitly
        // instead of silently falling through to the misleading
        // "credentials haven't been generated yet" message below.
        // Tom 2026-04-29: clicked Seerr launcher, was past the 10-min
        // reauth window, dashboard showed creds-not-generated when
        // the actual problem was "needs to confirm password again".
        if (e?.error === 'reauth_canceled' || e?.error === 'reauth_required') {
          extra = '\n\nConfirm your dashboard password to view the saved credentials. Click the app again to retry.';
          credsAvailable = false;
        }
      }
    }
    // If the static hint promises credentials "shown below" but our
    // lookup returned nothing (Jellyfin/Seerr creds are written only
    // AFTER autoseed runs — which needs gluetun healthy — so clicking
    // either launcher before Media is fully up would lie), replace
    // the promise with an explanation.
    const promisedCreds = /(shown below|are shown below|below\.)/i.test(hint);
    // Helper builds the full modal body for a given creds state. Used
    // both at initial render AND by the v1.6.45 live-poll path that
    // updates the body in place when arr-bootstrap finishes seeding.
    const buildBody = (haveCreds, credsExtra) => {
      let displayedHint = hint;
      if (!haveCreds && promisedCreds) {
        displayedHint = hint.replace(/(?:shown|are shown)\s+below[.\s]*/ig, '')
          + '\n\n(Credentials haven\'t been generated yet — the Media module is still finishing setup. We\'ll check again every few seconds and update this dialog automatically — no need to close and click again.)';
      }
      const credsReady = haveCreds || !promisedCreds;
      const footer = credsReady
        ? '\n\nTick the box below if you\'ve saved these and don\'t want to see this again. Otherwise this modal reappears next time you click the app — that\'s the easy way back to the credentials.'
        : '\n\nThis dialog auto-refreshes once the credentials are written.';
      return `${braveTip}${displayedHint}${credsExtra}${footer}`;
    };
    const credsReady = credsAvailable || !promisedCreds;
    // Prepend a small Brave-specific tip when the user is browsing in
    // Brave — this app will likely log them out every ~30 seconds until
    // they turn off Brave's HTTPS upgrade for OpenBox URLs.
    const braveTip = (await isBrave())
      ? '⚠️ Brave note: if this app logs you out every ~30 seconds, open brave://settings/security and turn off "Upgrade connections to HTTPS". (OpenBox apps serve plain HTTP on your LAN.)\n\n'
      : '';

    // v1.6.45: if we don't have creds yet but the app is supposed to
    // surface them (state-file-backed: *arrs, jellyfin, seerr, etc.),
    // poll the endpoint every 5s for up to 90s and live-update the
    // modal body when creds appear. Fixes the UX where a user clicked
    // an *arr tile during the 1-3 minutes that arr-bootstrap was still
    // seeding and saw "credentials haven't been generated yet" — they
    // had to close and click again to see the password. Now they can
    // leave the dialog open, grab a coffee, come back, and the
    // credentials are right there.
    let pollHandle = null;
    let pollDeadline = Date.now() + 90 * 1000;
    let modalDone = false;
    if (!credsAvailable && container && promisedCreds) {
      const messageEl = $('#confirm-message');
      pollHandle = setInterval(async () => {
        if (modalDone || Date.now() > pollDeadline) {
          clearInterval(pollHandle); pollHandle = null; return;
        }
        try {
          const r2 = await api('GET', `/containers/${encodeURIComponent(container)}/first-login-creds`);
          if (r2 && Array.isArray(r2.matches) && r2.matches.length > 0) {
            const label = r2.source === 'state-file'
              ? '\n\nOpenBox generated these for you:'
              : '\n\nFound in container logs:';
            const liveExtra = label + '\n' + r2.matches.join('\n');
            if (messageEl) messageEl.textContent = buildBody(true, liveExtra);
            credsAvailable = true;
            clearInterval(pollHandle); pollHandle = null;
          }
        } catch { /* keep polling — auth retry already handled in api() */ }
      }, 5000);
    }

    const guideUrl = link.getAttribute('data-guide-url') || '';
    const ok = await confirm(
      `Opening ${name}`,
      buildBody(credsAvailable, extra),
      {
        confirmLabel: 'Open app',
        cancelLabel: 'Close',
        // Only offer the dismissal checkbox when we actually have
        // credentials to show — useless otherwise.
        checkboxLabel: credsReady ? 'Don\'t show this again for this app' : null,
        // Surface a "Read the full guide →" link below the message
        // when the module's compose declares guide_url. Clickable,
        // opens in a new tab, doesn't dismiss the modal.
        linkLabel: guideUrl ? 'Read the full guide →' : null,
        linkUrl: guideUrl || null,
      }
    );
    modalDone = true;
    if (pollHandle) clearInterval(pollHandle);
    // ok is now an object or boolean depending on opts.checkboxLabel. When
    // a checkbox was offered, ok.confirmed is true/false for button
    // picked and ok.checked is the checkbox state. Back-compat: if
    // checkbox not offered, ok is the boolean as before.
    const confirmed = typeof ok === 'object' ? !!ok.confirmed : !!ok;
    const wantSuppress = typeof ok === 'object' ? !!ok.checked : false;
    if (credsReady && key && wantSuppress) {
      localStorage.setItem(key, '1');
      link.removeAttribute('data-first-login');
    }
    if (confirmed) {
      window.open(url, '_blank', 'noopener');
    }
  });

  // --- Global Search ---

  const searchInput = $('#app-search');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const query = e.target.value.toLowerCase().trim();
      const icons = $$('.launcher-icon');
      const categories = $$('.launcher-category');

      if (!query) {
        // Show all
        icons.forEach(i => i.style.display = '');
        categories.forEach(c => c.style.display = '');
        return;
      }

      icons.forEach(icon => {
        const name = (icon.querySelector('.launcher-icon-name')?.textContent || '').toLowerCase();
        const title = (icon.getAttribute('title') || '').toLowerCase();
        const match = name.includes(query) || title.includes(query);
        icon.style.display = match ? '' : 'none';
      });

      // Hide empty categories
      categories.forEach(cat => {
        const visible = cat.querySelectorAll('.launcher-icon:not([style*="display: none"])');
        cat.style.display = visible.length ? '' : 'none';
      });
    });

    // Keyboard shortcut: / to focus search
    document.addEventListener('keydown', (e) => {
      if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
        e.preventDefault();
        searchInput.focus();
      }
      // Escape to clear and blur
      if (e.key === 'Escape' && document.activeElement === searchInput) {
        searchInput.value = '';
        searchInput.dispatchEvent(new Event('input'));
        searchInput.blur();
      }
    });
  }

  // --- System Info ---

  async function loadSystemInfo() {
    try {
      const info = await api('GET', '/system');
      $('#host-pill').textContent = `${info.hostname} \u00b7 ${info.cpus} CPU \u00b7 ${formatBytes(info.memory)}`;
    } catch {
      $('#host-pill').textContent = '';
    }
  }

  // --- Password Change ---

  // Reopen the first-time setup wizard from Settings. Resets wizard.json
  // on the server so the next page load would also auto-open it, then
  // immediately opens it in-place so the user sees the flow right away.
  const btnReopenWizard = $('#btn-reopen-wizard');
  if (btnReopenWizard) {
    btnReopenWizard.addEventListener('click', async () => {
      try {
        await api('POST', '/wizard/reopen');
        // Clear the local kill-switch so wizard.js maybeAutoOpen will
        // re-fire next time. The user explicitly asked for it back.
        localStorage.removeItem('sb-wizard-dismissed');
        if (window.SB && window.SB.wizard && typeof window.SB.wizard.open === 'function') {
          window.SB.wizard.open();
        }
      } catch (err) {
        toast('Could not reopen wizard.', 'error');
      }
    });
  }

  const btnChangePw = $('#btn-change-password');
  if (btnChangePw) {
    btnChangePw.addEventListener('click', async () => {
      const current = $('#pw-current').value;
      const newPw = $('#pw-new').value;
      const confirmPw = $('#pw-confirm').value;

      if (!current) { toast('Enter your current password.', 'error'); return; }
      if (!newPw || newPw.length < 8) { toast('New password must be at least 8 characters.', 'error'); return; }
      if (newPw !== confirmPw) { toast('New passwords do not match.', 'error'); return; }

      btnLoading(btnChangePw, true);
      try {
        await api('POST', '/auth/change-password', { currentPassword: current, newPassword: newPw });
        toast('Password changed!', 'success');
        $('#pw-current').value = '';
        $('#pw-new').value = '';
        $('#pw-confirm').value = '';
      } catch (err) {
        toast(err.message, 'error');
      } finally {
        btnLoading(btnChangePw, false);
      }
    });
  }

  // --- *arr LAN-trust toggle (v1.6.43) ---
  // Reflects the live AuthenticationMethod in each *arr's config.xml
  // (forms = login required, external = trust LAN). Hidden when the
  // media stack isn't installed. Flip writes via POST /api/arr-auth/state
  // which edits config.xml in all 3 *arrs and restarts the containers
  // — gated on requireRecentReauth on the server side, so the user may
  // get a one-time password prompt before the flip applies.
  const arrAuthSection = $('#arr-auth-section');
  const arrAuthToggle = $('#arr-auth-trust-toggle');
  if (arrAuthSection && arrAuthToggle) {
    // v1.6.48: this init runs once when the script loads — at that
    // moment we're usually still on the login screen, so the
    // /api/arr-auth/state call hits 401 and the section stays
    // hidden forever (until a manual reload). Refresh on the
    // openbox:license-ready event (fired post-login by showDashboard)
    // AND when the user clicks into the Settings tab — either path
    // catches the typical first-visit-after-login flow.
    const refreshArrAuth = async () => {
      try {
        const s = await api('GET', '/arr-auth/state');
        if (!s.mediaInstalled) {
          arrAuthSection.classList.add('hidden');
          return;
        }
        arrAuthSection.classList.remove('hidden');
        arrAuthToggle.checked = s.mode === 'external';
      } catch { /* keep current state on read failure */ }
    };
    refreshArrAuth();
    document.addEventListener('openbox:license-ready', refreshArrAuth);
    document.addEventListener('click', (e) => {
      if (e.target.closest('[data-page="settings"], [data-stab="general"]')) {
        setTimeout(refreshArrAuth, 100);
      }
    });

    arrAuthToggle.addEventListener('change', async () => {
      const wantTrust = arrAuthToggle.checked;
      const target = wantTrust ? 'external' : 'forms';
      try {
        await api('POST', '/arr-auth/state', { mode: target });
        toast(wantTrust
          ? 'LAN trust ON — Sonarr / Radarr / Prowlarr now skip login on local network. Restarting *arrs to apply…'
          : 'LAN trust OFF — Sonarr / Radarr / Prowlarr now require login. Restarting *arrs to apply…',
          'success');
      } catch (err) {
        arrAuthToggle.checked = !wantTrust; // revert UI on failure
        toast(err.message || 'Could not change auth mode.', 'error');
      }
    });
  }

  // --- Network profile (v1.6.58+) ---
  // Read-only surface that shows nas/private/public classification and a
  // soft warning banner when the host has a publicly-routable IP. Populated
  // from /api/environment, which reads OB_PROFILE from install-meta.conf.
  // Mirrors arr-auth-section's refresh-on-login pattern (init can fire
  // pre-login, hits 401, so we re-fetch on openbox:license-ready and on
  // Settings clicks to handle that race).
  const netProfileSection = $('#network-profile-section');
  if (netProfileSection) {
    const badgeEl   = $('#network-profile-badge');
    const summaryEl = $('#network-profile-summary');
    const reasonsEl = $('#network-profile-reasons');
    const reasonsWrap = $('#network-profile-reasons-wrap');
    const vpsWarn   = $('#network-profile-vps-warning');

    const PROFILE_META = {
      nas:     { label: 'NAS appliance', summary: 'Running on a NAS. Network exposure is governed by your router and any port forwarding you set up.', color: '#3b82f6' },
      private: { label: 'Private network', summary: 'Default-route source IP is RFC1918 / CGNAT. Inbound services are not internet-reachable unless you explicitly forward a port.', color: '#22c55e' },
      public:  { label: 'Public IP', summary: 'This host has a publicly-routable IP, so admin services are reachable from the internet by default.', color: '#f59e0b' },
      unknown: { label: 'Unknown', summary: 'Network profile is not yet recorded. Re-run the installer (or update OpenBox) to refresh classification.', color: '#9ca3af' },
    };

    const refreshNetworkProfile = async () => {
      try {
        const env = await api('GET', '/environment');
        const profile = (env && env.profile) || 'unknown';
        const meta = PROFILE_META[profile] || PROFILE_META.unknown;
        if (badgeEl) {
          badgeEl.textContent = meta.label;
          badgeEl.style.background = meta.color + '22';
          badgeEl.style.color = meta.color;
          badgeEl.style.border = `1px solid ${meta.color}55`;
        }
        if (summaryEl) summaryEl.textContent = meta.summary;
        if (reasonsEl) {
          reasonsEl.replaceChildren();
          const reasons = Array.isArray(env && env.reasons) ? env.reasons : [];
          for (const r of reasons) {
            const li = document.createElement('li');
            li.textContent = r;
            reasonsEl.appendChild(li);
          }
          if (reasonsWrap) {
            reasonsWrap.classList.toggle('hidden', reasons.length === 0);
          }
        }
        if (vpsWarn) {
          vpsWarn.classList.toggle('hidden', profile !== 'public');
        }
        netProfileSection.classList.remove('hidden');
      } catch { /* leave hidden on auth/network failure */ }
    };

    refreshNetworkProfile();
    document.addEventListener('openbox:license-ready', refreshNetworkProfile);
    document.addEventListener('click', (e) => {
      if (e.target.closest('[data-page="settings"], [data-stab="general"]')) {
        setTimeout(refreshNetworkProfile, 100);
      }
    });
  }

  // --- AI Troubleshooting opt-out toggle ---
  // Reflects OB_AI_CHAT_ENABLED from .env. Unset/blank/"true" → on.
  // Flip writes the value via PUT /api/config and re-hides/shows the
  // chat FAB immediately (isChatAvailable reads .env on each call, so
  // no dashboard restart is needed).
  const aiChatToggle = $('#ai-chat-toggle');
  if (aiChatToggle) {
    (async () => {
      try {
        const cfg = await api('GET', '/config');
        const raw = String(cfg.OB_AI_CHAT_ENABLED || '').toLowerCase();
        const isOff = raw === 'false' || raw === '0' || raw === 'no' || raw === 'off';
        aiChatToggle.checked = !isOff;
      } catch { /* keep default-checked */ }
    })();

    // Channel selector mirrors the chat toggle pattern: read .env on
    // mount, persist via PUT /api/config, no dashboard restart needed
    // since self-update's checkForUpdate re-reads .env on every check.
    const channelSel = $('#update-channel-select');
    if (channelSel) {
      (async () => {
        try {
          const cfg = await api('GET', '/config');
          const raw = String(cfg.OB_UPDATE_CHANNEL || 'stable').toLowerCase();
          channelSel.value = raw === 'canary' ? 'canary' : 'stable';
        } catch { /* keep default */ }
      })();
      channelSel.addEventListener('change', async () => {
        const pick = channelSel.value;
        try {
          await api('PUT', '/config', { OB_UPDATE_CHANNEL: pick });
          toast(pick === 'canary'
            ? 'Switched to canary — you\'ll get new releases ~3 days before stable.'
            : 'Switched to stable channel.', 'success');
        } catch (err) {
          toast(err.message || 'Could not save channel.', 'error');
        }
      });
    }

    aiChatToggle.addEventListener('change', async () => {
      const enabled = aiChatToggle.checked;
      try {
        await api('PUT', '/config', { OB_AI_CHAT_ENABLED: enabled ? 'true' : 'false' });
        toast(enabled ? 'AI Troubleshooting enabled.' : 'AI Troubleshooting disabled — chat widget hidden.', 'success');
        // Re-run the chat.js availability check so the FAB updates now
        // instead of on next page load.
        document.dispatchEvent(new Event('openbox:license-ready'));
      } catch (err) {
        aiChatToggle.checked = !enabled; // revert
        toast(err.message || 'Could not save setting.', 'error');
      }
    });
  }

  // --- Moonfin Jellyfin plugin toggle (v1.6.65) ---
  // Hand-coded toggle (the generic config UI doesn't render type:boolean
  // so each boolean setting gets its own block, like the AI chat toggle
  // above and the Trust-LAN toggle in arr-auth-section). Reads + writes
  // MOONFIN_ENABLED in .env via PUT /api/config; on flip-on, also fires
  // POST /api/media-finish/run so the plugin is fetched + extracted +
  // Jellyfin restarted right then instead of waiting for the next
  // openbox up.
  const moonfinToggle = $('#moonfin-toggle');
  const moonfinStatus = $('#moonfin-status');
  if (moonfinToggle) {
    const setStatus = (text) => {
      if (!moonfinStatus) return;
      if (text) { moonfinStatus.textContent = text; moonfinStatus.style.display = ''; }
      else      { moonfinStatus.textContent = '';   moonfinStatus.style.display = 'none'; }
    };
    (async () => {
      try {
        const cfg = await api('GET', '/config');
        const raw = String(cfg.MOONFIN_ENABLED || '').toLowerCase();
        moonfinToggle.checked = raw === 'true';
      } catch { /* keep default unchecked */ }
    })();
    // v1.6.86: poll /api/media-finish/status after a flip-on so the
    // status text actually reflects what's happening. Previously this
    // text got set once to "Installing…" and never updated, leaving
    // users staring at a stuck label even after the install completed
    // (notrike DM 2026-05-10).
    let moonfinPollHandle = null;
    const stopMoonfinPolling = () => {
      if (moonfinPollHandle) { clearInterval(moonfinPollHandle); moonfinPollHandle = null; }
    };
    const startMoonfinPolling = () => {
      stopMoonfinPolling();
      const startedAt = Date.now();
      moonfinPollHandle = setInterval(async () => {
        // Stop polling after 10 min as a safety cap.
        if (Date.now() - startedAt > 10 * 60 * 1000) {
          stopMoonfinPolling();
          setStatus('Install is taking longer than expected. Check `state/media-finish.log` via SSH for details.');
          return;
        }
        try {
          const s = await api('GET', '/media-finish/status');
          if (s.moonfin_status === 'installed' && !s.running) {
            stopMoonfinPolling();
            setStatus('Plugin installed in Jellyfin. ✓ For the Netflix-style UI, install the Moonfin app on your TV/phone (Roku · Apple TV · Fire TV · iOS · Android) — search "Moonfin" in your app store and point it at this server.');
          } else if (s.moonfin_status === 'failed') {
            stopMoonfinPolling();
            setStatus('Install reported a failure. Check `state/media-finish.log` for details, or retry via SSH: sudo /opt/openbox/openbox media-finish');
          }
          // 'installing' and 'unknown' just keep polling.
        } catch {
          // Network blip — keep polling, the next tick will retry.
        }
      }, 5000);
    };

    moonfinToggle.addEventListener('change', async () => {
      const enabled = moonfinToggle.checked;
      try {
        await api('PUT', '/config', { MOONFIN_ENABLED: enabled ? 'true' : 'false' });
        if (enabled) {
          setStatus('Installing Moonfin plugin in Jellyfin (downloading from GitHub + restarting Jellyfin)…');
          try {
            await api('POST', '/media-finish/run', {});
            toast('Moonfin install started. Status will update below when it finishes (~2 min).', 'success');
            startMoonfinPolling();
          } catch (err) {
            // PUT succeeded; only the post-install kick failed. User can
            // re-trigger via "openbox media-finish" or wait for the next
            // openbox up to pick it up.
            setStatus('Toggle saved, but auto-install couldn\'t start. Run "openbox media-finish" via SSH, or just restart the media stack.');
            toast('Setting saved, install will run on next media-stack startup.', 'info');
          }
        } else {
          stopMoonfinPolling();
          setStatus('Toggle off. Existing plugin (if any) stays installed in Jellyfin until you remove it via Jellyfin\'s plugin UI.');
          toast('Moonfin install disabled. Existing plugin not touched.', 'success');
        }
      } catch (err) {
        moonfinToggle.checked = !enabled; // revert
        toast(err.message || 'Could not save setting.', 'error');
      }
    });
  }

  // --- Progress Modal ---

  let _progressCallback = null;
  let _progressSuccessTitle = 'Done!';

  function showProgressModal(title, onClose, opts) {
    const overlay = $('#progress-overlay');
    $('#progress-title').textContent = title;
    $('#progress-log').textContent = '';
    $('#progress-steps').innerHTML = '';
    hide($('#progress-actions'));
    show(overlay);
    _progressCallback = onClose || null;
    _progressSuccessTitle = (opts && opts.successTitle) || 'Done!';
  }

  function appendProgressLine(line) {
    const log = $('#progress-log');
    if (!log) return;
    // Parse Docker progress to show friendly messages in steps
    const steps = $('#progress-steps');
    if (line.includes('Pulling')) {
      const img = line.match(/Pulling\s+(\S+)/);
      if (img && steps) {
        const existing = steps.querySelector(`[data-step="${img[1]}"]`);
        if (!existing) {
          steps.innerHTML += `<span class="progress-step active" data-step="${esc(img[1])}">Pulling ${esc(img[1])}</span>`;
        }
      }
    } else if (line.includes('Creating') || line.includes('Recreating')) {
      const svc = line.match(/(Creating|Recreating)\s+(\S+)/);
      if (svc && steps) {
        // Mark pull steps as done
        steps.querySelectorAll('.progress-step.active').forEach(s => {
          s.classList.remove('active');
          s.classList.add('done');
        });
        steps.innerHTML += `<span class="progress-step active" data-step="${esc(svc[2])}">Starting ${esc(svc[2])}</span>`;
      }
    } else if (line.includes('Started') || line.includes('done')) {
      steps.querySelectorAll('.progress-step.active').forEach(s => {
        s.classList.remove('active');
        s.classList.add('done');
      });
    }
    log.textContent += line + '\n';
    log.scrollTop = log.scrollHeight;
  }

  function completeProgressModal(success) {
    const steps = $('#progress-steps');
    if (steps) {
      steps.querySelectorAll('.progress-step.active').forEach(s => {
        s.classList.remove('active');
        s.classList.add(success ? 'done' : '');
      });
    }
    $('#progress-title').textContent = success ? _progressSuccessTitle : 'Something went wrong';
    show($('#progress-actions'));
  }

  const progressCloseBtn = $('#progress-close');
  if (progressCloseBtn) {
    progressCloseBtn.addEventListener('click', () => {
      hide($('#progress-overlay'));
      if (_progressCallback) { _progressCallback(); _progressCallback = null; }
    });
  }

  // Listen for streaming operation events
  function setupOperationListeners() {
    if (!socket) return;
    socket.on('operation:progress', ({ line }) => {
      appendProgressLine(line);
    });
    socket.on('operation:complete', ({ success }) => {
      completeProgressModal(success);
      if (success) {
        toast('Operation completed!', 'success');
        // Refresh data
        _storeData = null;
        loadMetadata().then(() => {
          loadHome();
          // If on apps page, refresh it
          if ($('#page-apps.active')) loadApps();
        });
      } else {
        toast('Operation failed. Check the log for details.', 'error');
      }
    });
    socket.on('operation:error', (payload) => {
      // Prefer the friendly `message` field over the raw `error` code so
      // users see "OpenBox Pro requires a license..." instead of
      // "license_required". Falls back to error then a generic string.
      const msg = (payload && (payload.message || payload.error)) || 'Operation failed.';
      appendProgressLine('ERROR: ' + msg);
      completeProgressModal(false);
    });
    socket.on('operation:busy', ({ message }) => {
      toast(message, 'error');
    });
  }

  // --- Module Config Prompt ---

  let _pendingModuleEnable = null;

  async function promptModuleConfig(moduleName, friendlyName) {
    try {
      const { configRequired, missingDependencies } = await api('GET', `/modules/${moduleName}/config-required`);

      // Show dependency warnings
      const depsEl = $('#module-config-deps');
      if (missingDependencies && missingDependencies.length > 0) {
        depsEl.innerHTML = `\u26A0\uFE0F This module depends on: <strong>${missingDependencies.join(', ')}</strong>. These will be enabled automatically.`;
        depsEl.classList.remove('hidden');
      } else {
        depsEl.classList.add('hidden');
      }

      // If no config needed, go straight to install
      if (!configRequired || configRequired.length === 0) {
        return doModuleEnable(moduleName, friendlyName);
      }

      // Show config form
      const overlay = $('#module-config-overlay');
      $('#module-config-title').textContent = `Configure ${friendlyName}`;
      $('#module-config-desc').textContent = 'Fill in the required settings before enabling this module.';
      const fields = $('#module-config-fields');
      // Tips + prompts are rendered with linkifyHtml (markdown-style
      // links + bare-URL auto-linkify) so affiliate URLs and doc
      // references are clickable. Defined at the top of this module.
      // SERVER_CITIES gets a multi-select dropdown of valid provider POPs
      // (Surfshark/ProtonVPN have curated lists baked in; everything else
      // falls back to free-text). Same UX as the Settings → Network → VPN
      // modal so customers don't typo a city the provider doesn't have.
      // Re-renders when VPN_PROVIDER changes (provider-specific city list).
      const MODULE_CONFIG_PROVIDER_CITIES = {
        surfshark: [
          'Atlanta','Bend','Boston','Buffalo','Charlotte','Chicago','Dallas','Denver',
          'Houston','Kansas City','Las Vegas','Latham','Los Angeles','Manassas','Miami',
          'Nashville','New York','Orlando','Phoenix','Saint Louis','Salt Lake City',
          'San Francisco','San Jose','Seattle',
          'Toronto','Montreal','Vancouver','Mexico City',
          'Amsterdam','Berlin','Brussels','Bucharest','Copenhagen','Dublin','Edinburgh',
          'Frankfurt','Helsinki','Lisbon','London','Madrid','Manchester','Marseille',
          'Milan','Oslo','Paris','Prague','Rome','Sofia','Stockholm','Tallinn','Vienna',
          'Vilnius','Warsaw','Zagreb','Zurich','Athens','Belgrade','Bratislava',
          'Budapest','Reykjavik','Riga','Luxembourg',
          'Bangkok','Hong Kong','Jakarta','Kuala Lumpur','Manila','Mumbai','New Delhi',
          'Seoul','Singapore','Taipei','Tel Aviv','Tokyo','Yerevan','Almaty',
          'Sydney','Melbourne','Auckland',
          'Buenos Aires','Sao Paulo','Santiago','Bogota','Lima',
          'Cape Town','Lagos','Nairobi',
        ],
        protonvpn: [
          'Atlanta','Chicago','Dallas','Denver','Los Angeles','Miami','New York',
          'San Jose','Seattle','Toronto','Vancouver',
          'Amsterdam','Berlin','Copenhagen','Dublin','Frankfurt','London','Madrid',
          'Milan','Oslo','Paris','Stockholm','Vienna','Warsaw','Zurich',
          'Hong Kong','Singapore','Tokyo','Sydney',
        ],
      };
      // Show/hide fields whose data-show-if attribute names a boolean toggle.
      function syncShowIfFields(container) {
        container.querySelectorAll('[data-boolean]').forEach(toggle => {
          const key = toggle.dataset.configKey;
          container.querySelectorAll(`[data-show-if="${key}"]`).forEach(el => {
            el.style.display = toggle.checked ? '' : 'none';
          });
        });
      }
      const renderField = (f) => {
        const showIfAttr = f.show_if ? ` data-show-if="${esc(f.show_if)}"` : '';
        const advancedAttr = f.advanced ? ' data-advanced="1"' : '';
        if (f.type === 'boolean') {
          const checked = (f.default === 'true' || f.default === true) ? ' checked' : '';
          return `
        <div class="wizard-field"${advancedAttr}${showIfAttr}>
          <label style="display:flex;align-items:center;gap:0.7rem;cursor:pointer;font-weight:500">
            <input type="checkbox" data-config-key="${esc(f.key)}" data-boolean="1"
                   style="width:1.1rem;height:1.1rem;cursor:pointer;accent-color:var(--teal)"${checked}>
            ${esc(f.label)}
          </label>
          ${f.prompt ? `<span class="wizard-hint">${linkifyHtml(f.prompt)}</span>` : ''}
        </div>`;
        }
        if (f.key === 'SERVER_CITIES') {
          // Render as multi-select. Picks the provider currently selected
          // in the same modal (or surfshark default before the user picks).
          const picked = (f.default || '').split(',').map(s => s.trim()).filter(Boolean);
          return `
        <div class="wizard-field"${advancedAttr}${showIfAttr}>
          <label>${esc(f.label)}</label>
          <select class="wizard-select" multiple size="6" style="height:auto;min-height:6em;width:100%"
                  data-config-key="${esc(f.key)}" data-multi="1" data-cities-for-provider="surfshark">
            ${MODULE_CONFIG_PROVIDER_CITIES.surfshark.map(c =>
              `<option value="${esc(c)}"${picked.includes(c) ? ' selected' : ''}>${esc(c)}</option>`
            ).join('')}
          </select>
          ${f.prompt ? `<span class="wizard-hint">${linkifyHtml(f.prompt)}</span>` : ''}
          <span class="wizard-hint" style="margin-top:0.35rem">Hold Ctrl/Cmd to multi-select. Leave nothing selected for any city in your country.</span>
        </div>`;
        }
        return `
        <div class="wizard-field"${advancedAttr}${showIfAttr}>
          <label>${esc(f.label)}</label>
          ${f.options
            ? `<select class="wizard-select" data-config-key="${esc(f.key)}">
                <option value="">Select...</option>
                ${f.options.map(o => `<option value="${esc(typeof o === 'string' ? o : o.value)}">${esc(typeof o === 'string' ? o : o.label)}</option>`).join('')}
               </select>`
            : `<input class="setting-input" style="max-width:none" type="${f.type === 'password' || f.type === 'secret' ? 'password' : 'text'}"
                data-config-key="${esc(f.key)}" value="${esc(f.default || '')}"
                placeholder="${esc(f.label)}">` }
          ${f.prompt ? `<span class="wizard-hint">${linkifyHtml(f.prompt)}</span>` : ''}
        </div>`;
      };
      const essentials = configRequired.filter((f) => !f.advanced);
      const advanced = configRequired.filter((f) => f.advanced);
      fields.innerHTML = essentials.map(renderField).join('') + (advanced.length
        ? `<details style="margin-top:0.75rem">
             <summary style="cursor:pointer;color:var(--text-muted);font-size:0.88rem;padding:0.5rem 0">Advanced (only fill these if you're not using WireGuard)</summary>
             <div style="padding-top:0.5rem">${advanced.map(renderField).join('')}</div>
           </details>`
        : '');
      syncShowIfFields(fields);
      fields.addEventListener('change', (e) => { if (e.target.dataset.boolean) syncShowIfFields(fields); });

      _pendingModuleEnable = { moduleName, friendlyName };
      show(overlay);
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  // Save config and enable
  const configSaveBtn = $('#module-config-save');
  if (configSaveBtn) {
    configSaveBtn.addEventListener('click', async () => {
      if (!_pendingModuleEnable) return;
      const updates = {};
      $$('#module-config-fields [data-config-key]').forEach(el => {
        // Skip fields hidden by a show_if toggle.
        const group = el.closest('[data-show-if]');
        if (group && group.style.display === 'none') return;
        // Boolean checkboxes → write "true"/"false".
        if (el.dataset.boolean) {
          updates[el.dataset.configKey] = el.checked ? 'true' : 'false';
          return;
        }
        // Multi-select fields (SERVER_CITIES) → join selected options with comma.
        if (el.dataset.multi && el.tagName === 'SELECT') {
          const vals = Array.from(el.selectedOptions).map(o => o.value);
          updates[el.dataset.configKey] = vals.join(', ');
          return;
        }
        if (el.value) updates[el.dataset.configKey] = el.value;
      });
      btnLoading(configSaveBtn, true);
      try {
        if (Object.keys(updates).length > 0) {
          await api('PUT', '/config', updates);
        }
        hide($('#module-config-overlay'));
        doModuleEnable(_pendingModuleEnable.moduleName, _pendingModuleEnable.friendlyName);
      } catch (err) {
        toast(err.message, 'error');
      } finally {
        btnLoading(configSaveBtn, false);
      }
    });
  }

  const configCancelBtn = $('#module-config-cancel');
  if (configCancelBtn) {
    configCancelBtn.addEventListener('click', () => {
      hide($('#module-config-overlay'));
      _pendingModuleEnable = null;
      loadApps(); // reset toggle state
    });
  }

  function doModuleEnable(moduleName, friendlyName) {
    showProgressModal(
      `Installing ${friendlyName}... (title will say ✓ Installed when done)`,
      () => { loadApps(); },
      { successTitle: `✓ ${friendlyName} installed!` },
    );
    // Pre-populate so the modal is never truly empty during the
    // emit→server→response window. If the request fails fast the user
    // still has context for the error message that follows.
    appendProgressLine(`Asking server to install ${friendlyName} (${moduleName})...`);
    socket.emit('module:enable', moduleName);
  }

  function doModuleDisable(moduleName, friendlyName) {
    showProgressModal(`Removing ${friendlyName}...`, () => {
      loadApps();
    });
    appendProgressLine(`Asking server to remove ${friendlyName} (${moduleName})...`);
    socket.emit('module:disable', moduleName);
  }

  // --- Update Button ---

  const btnUpdate = $('#btn-update-all');
  if (btnUpdate) {
    btnUpdate.addEventListener('click', async () => {
      const ok = await confirm('Update all services?', 'This will pull the latest images and restart services. Your server may be briefly unavailable.');
      if (!ok) return;
      showProgressModal('Updating services...', () => {});
      socket.emit('system:update');
    });
  }

  // --- Setup Wizard ---

  // --- First-run welcome splash (replaces the old multi-step wizard) ---
  //
  // The wizard used to walk the user through 5 steps: welcome → basics →
  // profile → vpn → done. Three+ rounds of cold-install testing surfaced
  // layout bugs (Next button below fold), confusing dialogs (skip-VPN
  // primary action wrong), and just plain too-many-clicks friction. Tom
  // pulled the plug 2026-05-03: 'fuck the wizard, just remove it'.
  //
  // The new flow: bootstrap-token + password → welcome splash → 'Get
  // started' button → /api/setup/complete with profile=essentials → drop
  // straight onto the dashboard. No apps pre-installed; user picks them
  // from the App Store. VPN, domain, timezone, etc. all configurable
  // anytime via Settings.

  async function showSetupWizard() {
    hide($('#login-screen'));
    hide($('#dashboard'));
    show($('#setup-wizard'));
  }

  const welcomeBtn = document.getElementById('welcome-get-started');
  if (welcomeBtn) {
    welcomeBtn.addEventListener('click', async () => {
      btnLoading(welcomeBtn, true);
      try {
        // profile=essentials means no apps pre-enabled. Domain + timezone
        // default server-side; user adjusts later. No VPN config needed
        // at first-run — Media install will prompt for it via the
        // existing vpn-required modal flow when the user enables Media.
        await api('POST', '/setup/complete', {
          profile: 'essentials',
          domain: '',
          timezone: '',
          vpnProvider: '',
          vpnType: 'wireguard',
          vpnUser: '',
          vpnPass: '',
          vpnWgKey: '',
          vpnWgAddr: '',
        });
        toast('You\'re in! Browse the App Store to get started.', 'success');
        setTimeout(() => {
          hide($('#setup-wizard'));
          showDashboard();
        }, 400);
      } catch (err) {
        toast(err.message || 'Could not finish setup. Try again or check the dashboard logs.', 'error', 8000);
        btnLoading(welcomeBtn, false);
      }
    });
  }


  // --- Override Module Toggle to Use Streaming ---

  // App-card action button handler — click queues the change into
  // _pendingChanges instead of firing the API immediately. The floating
  // apply bar at the bottom of the page commits the whole set in one
  // batch request. Captures at document level so it catches clicks on
  // dynamically-rendered cards.
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('.app-action-btn[data-module]');
    if (!btn || btn.classList.contains('locked')) return;
    e.preventDefault();
    e.stopPropagation();

    const id = btn.dataset.module;
    const wasEnabled = _originalEnabled.has(id);

    // Current effective "desired" state = pending override OR original.
    const currentDesired = _pendingChanges.has(id)
      ? _pendingChanges.get(id)
      : wasEnabled;
    const newDesired = !currentDesired;

    const card = btn.closest('.app-card');
    if (card) card.classList.remove('pending-install', 'pending-remove');

    if (newDesired === wasEnabled) {
      // Back to the original state — drop any pending entry.
      _pendingChanges.delete(id);
    } else {
      _pendingChanges.set(id, newDesired);
      if (card) {
        card.classList.add(newDesired ? 'pending-install' : 'pending-remove');
      }
    }

    // Update the button visual in place so we don't need a full re-render.
    btn.classList.remove('queued-install', 'queued-remove', 'is-installed');
    if (_pendingChanges.has(id)) {
      if (newDesired) { btn.classList.add('queued-install'); btn.textContent = '✓ Queued'; }
      else            { btn.classList.add('queued-remove');  btn.textContent = '✕ Queued'; }
    } else if (wasEnabled) {
      btn.classList.add('is-installed'); btn.textContent = 'Installed';
    } else {
      btn.textContent = '+ Install';
    }

    renderApplyBar();
  }, true);

  // --- Apply bar (bottom-sticky action strip on Apps page) ---

  function renderApplyBar() {
    let bar = $('#apps-apply-bar');
    if (_pendingChanges.size === 0) {
      if (bar) bar.remove();
      return;
    }
    const toEnable = [];
    const toDisable = [];
    for (const [id, desired] of _pendingChanges.entries()) {
      (desired ? toEnable : toDisable).push(id);
    }
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'apps-apply-bar';
      bar.className = 'apps-apply-bar';
      document.body.appendChild(bar);
    }
    const summaryBits = [];
    if (toEnable.length) summaryBits.push(`<strong>${toEnable.length}</strong> to install`);
    if (toDisable.length) summaryBits.push(`<strong>${toDisable.length}</strong> to remove`);
    bar.innerHTML = `
      <div class="apps-apply-bar-summary">${summaryBits.join(' · ')}</div>
      <div class="apps-apply-bar-actions">
        <button class="btn-pill" id="apps-apply-cancel">Cancel</button>
        <button class="btn-pill primary" id="apps-apply-go">Apply changes</button>
      </div>
    `;
    $('#apps-apply-cancel').addEventListener('click', cancelPendingChanges);
    $('#apps-apply-go').addEventListener('click', applyPendingChanges);
  }

  function cancelPendingChanges() {
    _pendingChanges.clear();
    // Strip any pending visual flags before re-rendering (in case the
    // re-render reuses card elements).
    document.querySelectorAll('.app-card.pending-install, .app-card.pending-remove')
      .forEach(c => c.classList.remove('pending-install', 'pending-remove'));
    loadApps(); // re-render with original state, toggles snap back
  }

  function showInstallDisclosure(enable, disable) {
    return new Promise((resolve) => {
      const overlay = $('#install-disclosure-overlay');
      const list = $('#install-disclosure-list');
      const intro = $('#install-disclosure-intro');
      const footer = $('#install-disclosure-footer');

      const modsById = {};
      (_storeData || []).forEach(m => { modsById[m.id] = m; });

      const enableMods = enable.map(id => modsById[id]).filter(Boolean);
      const disableMods = disable.map(id => modsById[id]).filter(Boolean);

      const parts = [];
      if (enableMods.length) parts.push(`${enableMods.length} app${enableMods.length === 1 ? '' : 's'} to install`);
      if (disableMods.length) parts.push(`${disableMods.length} app${disableMods.length === 1 ? '' : 's'} to remove`);
      intro.textContent = parts.join(' · ') + '. Here\u2019s what\u2019s going to happen:';

      let totalServices = 0;
      let totalPorts = 0;
      let html = '';

      if (enableMods.length) {
        html += '<div class="install-disclosure-section"><div class="install-disclosure-section-title">Installing</div>';
        enableMods.forEach(m => {
          const services = m.services || [];
          totalServices += services.length;
          const ports = services.filter(s => s.port).map(s => s.port);
          totalPorts += ports.length;
          const serviceNames = services.map(s => s.name).join(', ') || m.name;
          const autoConfig = m.id === 'media'
            ? `<div class="install-disclosure-autocfg">
                 <span class="install-disclosure-autocfg-icon">⚡</span>
                 <div>
                   <strong>1-click ARR auto-config.</strong>
                   Sonarr, Radarr, Prowlarr &amp; qBittorrent are pre-wired — Prowlarr indexers sync into Sonarr/Radarr, downloads route through qBittorrent + Gluetun. No manual setup required after install.
                 </div>
               </div>`
            : '';
          html += `
            <div class="install-disclosure-item install-disclosure-item-enable">
              <div class="install-disclosure-item-name">${esc(m.name)}</div>
              <div class="install-disclosure-item-detail">
                <span class="install-disclosure-chip">${services.length} service${services.length === 1 ? '' : 's'}</span>
                ${ports.length ? `<span class="install-disclosure-chip">Ports: ${ports.join(', ')}</span>` : ''}
                ${m.ram && m.ram !== '?' ? `<span class="install-disclosure-chip">RAM: ${esc(m.ram)}</span>` : ''}
              </div>
              <div class="install-disclosure-item-services">${esc(serviceNames)}</div>
              ${autoConfig}
            </div>`;
        });
        html += '</div>';
      }

      if (disableMods.length) {
        html += '<div class="install-disclosure-section"><div class="install-disclosure-section-title">Removing</div>';
        disableMods.forEach(m => {
          html += `
            <div class="install-disclosure-item install-disclosure-item-disable">
              <div class="install-disclosure-item-name">${esc(m.name)}</div>
              <div class="install-disclosure-item-detail">Container stops and is removed. Data in the <code>state/</code> and <code>modules/${esc(m.id)}/config</code> folders is kept on disk.</div>
            </div>`;
        });
        html += '</div>';
      }

      list.innerHTML = html;

      const metaBits = [];
      if (enableMods.length) {
        metaBits.push(`${totalServices} new container${totalServices === 1 ? '' : 's'}`);
        if (totalPorts) metaBits.push(`${totalPorts} port${totalPorts === 1 ? '' : 's'} opened on your LAN`);
      }
      // Loud, reassuring patience notice — neon green so users actually
      // read it and don't panic when an app takes a minute to come up.
      const noticeHtml = enableMods.length
        ? `<div class="install-disclosure-notice">
             <span class="install-disclosure-notice-icon">⏱</span>
             <div class="install-disclosure-notice-text">
               <strong>Don't panic if apps don't load right away.</strong>
               First install takes <strong>1–3 minutes</strong> to pull images,
               and some apps (Immich, Nextcloud, Matrix) need <strong>another minute or two</strong>
               after that to fully start. Refresh the page and give it a moment.
             </div>
           </div>`
        : '';
      footer.innerHTML =
        (metaBits.length ? `<div class="install-disclosure-meta">${metaBits.join(' \u00b7 ')}</div>` : '') +
        noticeHtml;

      show(overlay);

      function cleanup() {
        hide(overlay);
        $('#install-disclosure-ok').removeEventListener('click', onOk);
        $('#install-disclosure-cancel').removeEventListener('click', onCancel);
      }
      function onOk() { cleanup(); resolve(true); }
      function onCancel() { cleanup(); resolve(false); }
      $('#install-disclosure-ok').addEventListener('click', onOk);
      $('#install-disclosure-cancel').addEventListener('click', onCancel);
    });
  }

  // Collect required env_vars across every module being enabled in this
  // batch and show one combined modal. Returns true if the user filled
  // everything in and saved, false if they canceled.
  //
  // Why this exists: applyPendingChanges used to go straight from the
  // disclosure modal to socket.emit('modules:install-stream') — skipping
  // the config-required check entirely. Every module that declared
  // required env_vars (PhotoPrism admin password, BookStack DB password,
  // etc.) got installed with those vars blank, and the container booted
  // into an unusable state the user couldn't log in to. The old
  // promptModuleConfig() function was built for this but never wired
  // into the real install path.
  async function collectRequiredConfigs(enableList, moduleMeta) {
    if (!enableList || enableList.length === 0) return true;
    // Gather required fields per module.
    const perModule = [];
    for (const id of enableList) {
      try {
        const { configRequired } = await api('GET', `/modules/${id}/config-required`);
        if (configRequired && configRequired.length > 0) {
          perModule.push({ id, fields: configRequired });
        }
      } catch (err) {
        toast(`Failed to check config for ${id}: ${err.message}`, 'error');
        return false;
      }
    }
    if (perModule.length === 0) return true;

    // Build the combined form. One section per module so users see
    // which fields belong to which app.
    const overlay = $('#module-config-overlay');
    const title = $('#module-config-title');
    const desc = $('#module-config-desc');
    const fields = $('#module-config-fields');
    const deps = $('#module-config-deps');
    if (deps) deps.classList.add('hidden');
    if (title) title.textContent = perModule.length === 1
      ? `Configure ${moduleMeta[perModule[0].id] || perModule[0].id}`
      : 'Configure your new apps';
    if (desc) desc.textContent = 'These apps need a few settings before they can run. Fill them in once and we\'ll remember.';
    if (fields) {
      // Same SERVER_CITIES dropdown as promptModuleConfig (single-module path).
      // Both code paths render the same per-module config form; the dropdown
      // for SERVER_CITIES needs to live in BOTH or customers hitting one but
      // not the other (depending on whether the install is single or batch)
      // see the wrong UX. v1.6.30 missed this one.
      const SURFSHARK_CITIES = [
        'Atlanta','Bend','Boston','Buffalo','Charlotte','Chicago','Dallas','Denver',
        'Houston','Kansas City','Las Vegas','Latham','Los Angeles','Manassas','Miami',
        'Nashville','New York','Orlando','Phoenix','Saint Louis','Salt Lake City',
        'San Francisco','San Jose','Seattle','Toronto','Montreal','Vancouver','Mexico City',
        'Amsterdam','Berlin','Brussels','Bucharest','Copenhagen','Dublin','Edinburgh',
        'Frankfurt','Helsinki','Lisbon','London','Madrid','Manchester','Marseille',
        'Milan','Oslo','Paris','Prague','Rome','Sofia','Stockholm','Tallinn','Vienna',
        'Vilnius','Warsaw','Zagreb','Zurich','Athens','Belgrade','Bratislava',
        'Budapest','Reykjavik','Riga','Luxembourg','Bangkok','Hong Kong','Jakarta',
        'Kuala Lumpur','Manila','Mumbai','New Delhi','Seoul','Singapore','Taipei',
        'Tel Aviv','Tokyo','Yerevan','Almaty','Sydney','Melbourne','Auckland',
        'Buenos Aires','Sao Paulo','Santiago','Bogota','Lima','Cape Town','Lagos','Nairobi',
      ];
      const renderField = (f) => {
        const showIfAttr = f.show_if ? ` data-show-if="${esc(f.show_if)}"` : '';
        if (f.type === 'boolean') {
          const checked = (f.default === 'true' || f.default === true) ? ' checked' : '';
          return `
          <div class="wizard-field"${showIfAttr}>
            <label style="display:flex;align-items:center;gap:0.7rem;cursor:pointer;font-weight:500">
              <input type="checkbox" data-config-key="${esc(f.key)}" data-boolean="1"
                     style="width:1.1rem;height:1.1rem;cursor:pointer;accent-color:var(--teal)"${checked}>
              ${esc(f.label)}
            </label>
            ${f.prompt ? `<span class="wizard-hint">${linkifyHtml(f.prompt)}</span>` : ''}
          </div>`;
        }
        if (f.key === 'SERVER_CITIES') {
          const picked = (f.default || '').split(',').map(s => s.trim()).filter(Boolean);
          return `
          <div class="wizard-field"${showIfAttr}>
            <label>${esc(f.label)}</label>
            <select class="wizard-select" multiple size="6" style="height:auto;min-height:6em;width:100%"
                    data-config-key="${esc(f.key)}" data-multi="1">
              ${SURFSHARK_CITIES.map(c =>
                `<option value="${esc(c)}"${picked.includes(c) ? ' selected' : ''}>${esc(c)}</option>`
              ).join('')}
            </select>
            ${f.prompt ? `<span class="wizard-hint">${linkifyHtml(f.prompt)}</span>` : ''}
            <span class="wizard-hint" style="margin-top:0.35rem">Hold Ctrl/Cmd to multi-select. Leave nothing selected for any city in your country.</span>
          </div>`;
        }
        return `
          <div class="wizard-field"${showIfAttr}>
            <label>${esc(f.label)}</label>
            ${f.options
              ? `<select class="wizard-select" data-config-key="${esc(f.key)}">
                   <option value="">Select...</option>
                   ${f.options.map(o => `<option value="${esc(typeof o === 'string' ? o : o.value)}">${esc(typeof o === 'string' ? o : o.label)}</option>`).join('')}
                 </select>`
              : `<input class="setting-input" style="max-width:none" type="${f.type === 'secret' || f.type === 'password' ? 'password' : 'text'}"
                  data-config-key="${esc(f.key)}" value="${esc(f.default || '')}"
                  placeholder="${esc(f.prompt || '')}">` }
            ${f.prompt ? `<span class="wizard-hint">${linkifyHtml(f.prompt)}</span>` : ''}
          </div>`;
      };
      fields.innerHTML = perModule.map(m => {
        const name = moduleMeta[m.id] || m.id;
        const body = m.fields.map(renderField).join('');
        return perModule.length === 1
          ? body
          : `<div class="config-module-section"><h4 style="margin:1rem 0 0.5rem;font-size:0.95rem;opacity:0.85">${esc(name)}</h4>${body}</div>`;
      }).join('');
      // Wire up boolean toggles (e.g. VPN_ENABLED) to show/hide dependent fields.
      const syncBatchShowIf = () => {
        fields.querySelectorAll('[data-boolean]').forEach(toggle => {
          const key = toggle.dataset.configKey;
          fields.querySelectorAll(`[data-show-if="${key}"]`).forEach(el => {
            el.style.display = toggle.checked ? '' : 'none';
          });
        });
      };
      syncBatchShowIf();
      fields.addEventListener('change', (e) => { if (e.target.dataset.boolean) syncBatchShowIf(); });
    }
    show(overlay);

    return new Promise((resolve) => {
      const saveBtn = $('#module-config-save');
      const cancelBtn = $('#module-config-cancel');
      const onSave = async () => {
        const updates = {};
        $$('#module-config-fields [data-config-key]').forEach(el => {
          // Skip fields hidden by a show_if toggle.
          const group = el.closest('[data-show-if]');
          if (group && group.style.display === 'none') return;
          // Boolean checkboxes → write "true"/"false".
          if (el.dataset.boolean) {
            updates[el.dataset.configKey] = el.checked ? 'true' : 'false';
            return;
          }
          // Multi-select fields (SERVER_CITIES) → join selected options.
          if (el.dataset.multi && el.tagName === 'SELECT') {
            const vals = Array.from(el.selectedOptions).map(o => o.value);
            // Only include in updates if the user picked anything.
            // Empty multi-select means "leave SERVER_CITIES unset" —
            // gluetun will pick from any city in SERVER_COUNTRIES.
            if (vals.length > 0) updates[el.dataset.configKey] = vals.join(', ');
            return;
          }
          if (el.value !== '') updates[el.dataset.configKey] = el.value;
        });
        // Require every REQUIRED field to be filled — an empty secret
        // means the container will boot broken. But fields marked
        // `required: false` in the metadata (e.g. SERVER_CITIES,
        // SERVER_HOSTNAMES) can stay blank — those are fine-tuning
        // knobs, not boot-blockers. v1.6.32 hit this: SERVER_HOSTNAMES
        // would always be blank for normal users → red toast → can't
        // install Media at all.
        const blanks = [];
        for (const m of perModule) {
          for (const f of m.fields) {
            if (f.required === false) continue;  // optional, skip
            // Also skip fields hidden by show_if toggle.
            const fieldEl = fields.querySelector(`[data-config-key="${f.key}"]`);
            const group = fieldEl && fieldEl.closest('[data-show-if]');
            if (group && group.style.display === 'none') continue;
            if (updates[f.key] === undefined || updates[f.key] === '') {
              blanks.push(f.label || f.key);
            }
          }
        }
        if (blanks.length > 0) {
          toast(`Please fill in: ${blanks.join(', ')}`, 'error');
          return;
        }
        btnLoading(saveBtn, true);
        try {
          await api('PUT', '/config', updates);
          cleanup();
          resolve(true);
        } catch (err) {
          toast(err.message, 'error');
        } finally {
          btnLoading(saveBtn, false);
        }
      };
      const onCancel = () => { cleanup(); resolve(false); };
      function cleanup() {
        hide(overlay);
        saveBtn.removeEventListener('click', onSave);
        cancelBtn.removeEventListener('click', onCancel);
      }
      saveBtn.addEventListener('click', onSave);
      cancelBtn.addEventListener('click', onCancel);
    });
  }

  async function applyPendingChanges() {
    const enable = [];
    const disable = [];
    for (const [id, desired] of _pendingChanges.entries()) {
      (desired ? enable : disable).push(id);
    }

    const ok = await showInstallDisclosure(enable, disable);
    if (!ok) return;

    // Collect required env_vars for every module being enabled. This
    // blocks the install until the user has filled in every required
    // secret (admin passwords etc.). Skipping this step is what caused
    // users to enable e.g. PhotoPrism and then find they had no way to
    // log in, because PHOTOPRISM_ADMIN_PASSWORD was never set.
    const moduleMeta = {};
    try {
      const list = await api('GET', '/modules');
      for (const m of (list || [])) moduleMeta[m.id] = m.name || m.id;
    } catch {}
    const configOk = await collectRequiredConfigs(enable, moduleMeta);
    if (!configOk) return;

    runInstallStreaming(enable, disable);
  }

  // Extracted from applyPendingChanges so the VPN-gate retry path can
  // reuse the same progress modal + socket listeners without making
  // the user click through the disclosure + required-config step twice.
  function runInstallStreaming(enable, disable) {
    const btn = $('#apps-apply-go');
    if (btn) btnLoading(btn, true);

    // Make sure the socket is connected before we wire install listeners.
    if (!socket) initSocket();

    // Open the live log modal.
    const overlay = $('#progress-overlay');
    const titleEl = $('#progress-title');
    const logEl = $('#progress-log');
    const actionsEl = $('#progress-actions');
    const closeBtn = $('#progress-close');

    if (titleEl) {
      const parts = [];
      if (enable.length) parts.push(`Installing ${enable.length}`);
      if (disable.length) parts.push(`Removing ${disable.length}`);
      titleEl.textContent = parts.join(' · ') + '... (title will say ✓ Installed when done)';
    }
    if (logEl) logEl.textContent = '';
    if (actionsEl) actionsEl.classList.add('hidden');
    show(overlay);

    const appendLine = ({ line, stream }) => {
      if (!logEl) return;
      logEl.textContent += (line || '') + '\n';
      logEl.scrollTop = logEl.scrollHeight;
      if (stream === 'stderr') {
        logEl.classList.add('has-stderr');
      }
    };

    const cleanupListeners = () => {
      socket.off('install:started', onStarted);
      socket.off('install:line', appendLine);
      socket.off('install:done', onDone);
      socket.off('install:error', onError);
    };

    const onStarted = () => {
      appendLine({ line: '> openbox up', stream: 'stdout' });
    };
    const onDone = ({ success, code }) => {
      cleanupListeners();
      // Only clear pending changes on actual success. Before v1.5.49
      // we cleared on ANY completion — so when openbox up exited
      // non-zero (one module failed to start), the client discarded
      // the customer's pending toggles and they couldn't even see
      // which app had broken. Now a failed batch keeps the pending
      // state intact so customers can retry or untoggle the problem
      // module from the same apply bar.
      if (success) {
        _pendingChanges.clear();
      }
      renderApplyBar();
      if (titleEl) {
        titleEl.textContent = success ? '✓ Installed!' : `Apps install failed (exit code ${code})`;
      }
      appendLine({ line: success
        ? '\n[OpenBox] All set.\n\nNote: Some apps (Immich, Nextcloud, Matrix) take 1-3 minutes to fully start.\nIf an app doesn\'t load right away, give it a moment and refresh.'
        : `\n[OpenBox] Install exited with code ${code}. Your pending changes are preserved — review the log above, then Apply again (or untoggle the broken module from the apply bar at the bottom).`,
        stream: success ? 'stdout' : 'stderr' });
      if (actionsEl) actionsEl.classList.remove('hidden');
      if (btn) btnLoading(btn, false);
      loadApps();
      if (success) toast('Apps updated!', 'success');
      else toast('Install failed. Check the log — your pending changes are saved so you can retry.', 'error', 10000);
    };
    const onError = (payload) => {
      cleanupListeners();
      const error = (payload && (payload.message || payload.error)) || 'Install failed.';
      // VPN-gated module enable blocked before anything ran. Pop the
      // VPN config prompt instead of showing a scary error log — the
      // user's next action is clear (fill the form, retry).
      if (payload && payload.vpn_required) {
        if (overlay && overlay.classList) overlay.classList.add('hidden');
        if (btn) btnLoading(btn, false);
        promptVpnConfigThenRetry(payload, enable, disable);
        return;
      }
      if (titleEl) titleEl.textContent = 'Install failed';
      appendLine({ line: `\n[OpenBox] ${error}`, stream: 'stderr' });
      if (actionsEl) actionsEl.classList.remove('hidden');
      if (btn) btnLoading(btn, false);
      toast(error, 'error');
    };

    socket.on('install:started', onStarted);
    socket.on('install:line', appendLine);
    socket.on('install:done', onDone);
    socket.on('install:error', onError);

    // Pre-populate so the modal isn't briefly empty between emit and the
    // server's first event. If the install fails immediately (bad name,
    // license missing, lock contention) the user still sees this line
    // followed by the error message instead of a blank box.
    appendLine({ line: `Asking server to apply: enable=[${enable.join(', ') || '(none)'}] disable=[${disable.join(', ') || '(none)'}]...`, stream: 'stdout' });

    socket.emit('modules:install-stream', { enable, disable });

    if (closeBtn && !closeBtn._sbInstallWired) {
      closeBtn._sbInstallWired = true;
      closeBtn.addEventListener('click', () => { hide(overlay); });
    }
  }

  // --- VPN config prompt (triggered when enable of a VPN-gated module
  //     like Media is blocked until VPN provider is set) ---
  async function promptVpnConfigThenRetry(errorPayload, enable, disable) {
    // Lazy-build a modal the first time we need it so the main markup
    // stays small. Gluetun's supported-provider list is large; pick the
    // common ones and offer "Custom" as a fallback.
    let modal = document.getElementById('sb-vpn-config-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'sb-vpn-config-modal';
      modal.className = 'modal-overlay hidden';
      modal.innerHTML = `
<div class="modal" style="max-width:560px;">
  <h3 style="margin-top:0;">Configure VPN provider</h3>
  <p class="muted" style="margin-top:0;">The Media module (Sonarr, Radarr, qBittorrent) routes downloads through a VPN tunnel. Fill in your provider's WireGuard details to continue.</p>

  <div class="vpn-rec-card" style="margin:1rem 0 1.25rem;padding:1rem 1.1rem;border:1px solid hsla(173,80%,50%,0.4);border-left-width:3px;border-radius:8px;background:hsla(173,80%,50%,0.06);">
    <div style="display:flex;align-items:center;gap:0.5rem;margin-bottom:0.5rem;">
      <strong style="color:hsl(173,80%,55%);font-size:1em;">Don't have a VPN yet?</strong>
      <span style="font-size:0.7em;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em;">Recommended</span>
    </div>
    <div style="font-size:0.92em;line-height:1.55;color:var(--text-secondary);">
      <strong>Surfshark</strong> is the one we use and the one OpenBox is tuned for:
    </div>
    <ul style="margin:0.6rem 0 0.7rem 1.2rem;padding:0;font-size:0.88em;line-height:1.6;color:var(--text-secondary);">
      <li><strong>The #1 VPN for OpenBox.</strong> Only top-performing VPN with native WireGuard configs out of the box — most premium VPNs run proprietary protocols our stack can't connect to.</li>
      <li><strong>Paste-one-key setup</strong> — gluetun auto-picks a working P2P server, no server-list maintenance. No script-based credential extraction.</li>
      <li><strong>P2P allowed on every server</strong> — torrents work everywhere. Most VPNs at this price restrict P2P to specific servers or need port-forwarding config to saturate gigabit.</li>
      <li><strong>~$1.99/mo with the deal</strong> — about half the price of mainstream alternatives.</li>
    </ul>
    <a href="https://get.surfshark.net/aff_c?offer_id=1126&amp;aff_id=9447&amp;aff_sub=hr52es" target="_blank" rel="noopener nofollow sponsored"
       style="display:inline-block;margin-top:0.4rem;padding:0.55rem 1rem;background:hsl(173,80%,40%);color:#fff;border-radius:6px;font-weight:600;font-size:0.9em;text-decoration:none;">
      Get Surfshark — 87% off + 4 months free →
    </a>
    <span style="display:block;margin-top:0.5rem;font-size:0.75em;color:var(--text-muted);">Affiliate link — supports OpenBox at no extra cost. Already have Surfshark or another provider? Skip to the form below.</span>
  </div>

  <div id="sb-vpn-error" class="hidden" style="background:rgba(255,69,58,0.1);border:1px solid rgba(255,69,58,0.4);padding:0.5rem 0.75rem;border-radius:6px;margin:0.5rem 0;color:var(--red,#ff453a);"></div>
  <label style="display:block;margin-top:0.75rem;">
    <span class="muted" style="display:block;font-size:0.85em;margin-bottom:0.25rem;">Provider</span>
    <select id="sb-vpn-provider" class="input">
      <option value="">Select…</option>
      <option value="surfshark">Surfshark (recommended)</option>
      <option value="protonvpn">Proton VPN</option>
      <option value="nordvpn">NordVPN</option>
      <option value="mullvad">Mullvad</option>
      <option value="ivpn">IVPN</option>
      <option value="privateinternetaccess">Private Internet Access</option>
      <option value="windscribe">Windscribe</option>
      <option value="custom">Custom (advanced)</option>
    </select>
  </label>
  <label style="display:block;margin-top:0.75rem;">
    <span class="muted" style="display:block;font-size:0.85em;margin-bottom:0.25rem;">WireGuard private key</span>
    <input id="sb-vpn-wgkey" type="password" class="input" autocomplete="off" spellcheck="false" placeholder="gAAAAB... (from your provider's config file)">
  </label>
  <label style="display:block;margin-top:0.75rem;">
    <span class="muted" style="display:block;font-size:0.85em;margin-bottom:0.25rem;">WireGuard addresses <span style="opacity:0.6;">(optional)</span></span>
    <input id="sb-vpn-wgaddr" type="text" class="input" autocomplete="off" spellcheck="false" placeholder="10.14.0.2/16 (from your provider's config file)">
    <span class="muted" style="display:block;font-size:0.78em;margin-top:0.35rem;">Typical defaults: Surfshark <code>10.14.0.2/16</code>, ProtonVPN <code>10.2.0.2/32</code>, Mullvad <code>10.64.0.2/32</code>. Use yours exactly to be safe.</span>
  </label>
  <label style="display:block;margin-top:0.75rem;">
    <span class="muted" style="display:block;font-size:0.85em;margin-bottom:0.25rem;">Server countries <span style="opacity:0.6;">(optional, comma-separated)</span></span>
    <input id="sb-vpn-countries" type="text" class="input" placeholder="United States, Switzerland">
  </label>
  <label style="display:block;margin-top:0.75rem;">
    <span style="display:flex;align-items:center;gap:0.5rem;margin-bottom:0.25rem;">
      <span class="muted" style="font-size:0.85em;">Server cities <span style="opacity:0.6;">(optional — narrower than country)</span></span>
      <button type="button" id="sb-vpn-closest" style="margin-left:auto;padding:0.2rem 0.6rem;font-size:0.75em;border:1px solid var(--border,rgba(255,255,255,0.18));background:transparent;color:var(--accent,#6366f1);border-radius:4px;cursor:pointer;">Pick closest to me</button>
    </span>
    <div id="sb-vpn-cities-wrap"></div>
    <span class="muted" style="display:block;font-size:0.78em;margin-top:0.35rem;">If your country is huge, gluetun otherwise picks any server — sometimes far across the country, adding latency. Hold Ctrl/Cmd to pick multiple cities for fallback. Click "Pick closest to me" to auto-select based on your host's region.</span>
  </label>
  <p class="muted" style="font-size:0.8em;margin-top:0.75rem;">Your private key is stored locally in your OpenBox .env file — it never leaves this server.</p>
  <div style="display:flex;gap:0.5rem;justify-content:flex-end;margin-top:1rem;">
    <button class="btn-pill" id="sb-vpn-cancel">Cancel</button>
    <button class="btn-pill primary" id="sb-vpn-save">Save &amp; retry install</button>
  </div>
</div>`;
      document.body.appendChild(modal);
    }

    // Hardcoded city lists per provider. Surfshark is most thorough
    // because that's what we recommend; ProtonVPN gets a representative
    // subset; everything else falls back to free-text input. Sorted
    // alphabetically so the dropdown is scannable. Updated 2026-05-04
    // from each provider's published server list.
    const PROVIDER_CITIES = {
      surfshark: [
        // North America
        'Atlanta','Bend','Boston','Buffalo','Charlotte','Chicago','Dallas','Denver',
        'Houston','Kansas City','Las Vegas','Latham','Los Angeles','Manassas','Miami',
        'Nashville','New York','Orlando','Phoenix','Saint Louis','Salt Lake City',
        'San Francisco','San Jose','Seattle',
        'Toronto','Montreal','Vancouver','Mexico City',
        // Europe
        'Amsterdam','Berlin','Brussels','Bucharest','Copenhagen','Dublin','Edinburgh',
        'Frankfurt','Helsinki','Lisbon','London','Madrid','Manchester','Marseille',
        'Milan','Oslo','Paris','Prague','Rome','Sofia','Stockholm','Tallinn','Vienna',
        'Vilnius','Warsaw','Zagreb','Zurich','Athens','Belgrade','Bratislava',
        'Budapest','Reykjavik','Riga','Luxembourg',
        // Asia / Middle East / Africa / Oceania
        'Bangkok','Hong Kong','Jakarta','Kuala Lumpur','Manila','Mumbai','New Delhi',
        'Seoul','Singapore','Taipei','Tel Aviv','Tokyo','Yerevan','Almaty',
        'Sydney','Melbourne','Auckland',
        'Buenos Aires','Sao Paulo','Santiago','Bogota','Lima',
        'Cape Town','Lagos','Nairobi',
      ],
      protonvpn: [
        'Atlanta','Chicago','Dallas','Denver','Los Angeles','Miami','New York',
        'San Jose','Seattle','Toronto','Vancouver',
        'Amsterdam','Berlin','Copenhagen','Dublin','Frankfurt','London','Madrid',
        'Milan','Oslo','Paris','Stockholm','Vienna','Warsaw','Zurich',
        'Hong Kong','Singapore','Tokyo','Sydney',
      ],
      // For other providers we don't have a curated list — fall back to text input
    };

    // Render the cities field as a multi-select for known providers,
    // free-text input otherwise. Re-renders when provider changes.
    function renderCitiesField(providerSlug) {
      const wrap = document.getElementById('sb-vpn-cities-wrap');
      if (!wrap) return;
      const cities = PROVIDER_CITIES[providerSlug];
      const previous = (() => {
        const sel = wrap.querySelector('select#sb-vpn-cities');
        if (sel) return Array.from(sel.selectedOptions).map(o => o.value).join(', ');
        const inp = wrap.querySelector('input#sb-vpn-cities');
        if (inp) return inp.value;
        return '';
      })();
      const wantedSet = new Set(previous.split(',').map(s => s.trim()).filter(Boolean));
      if (Array.isArray(cities) && cities.length > 0) {
        const opts = cities.map(c => {
          const sel = wantedSet.has(c) ? ' selected' : '';
          return `<option value="${c}"${sel}>${c}</option>`;
        }).join('');
        wrap.innerHTML = `<select id="sb-vpn-cities" class="input" multiple size="8" style="height:auto;min-height:8em;">${opts}</select>`;
      } else {
        wrap.innerHTML = `<input id="sb-vpn-cities" type="text" class="input" placeholder="(provider-specific) — leave blank for any city, or type comma-separated cities" value="${previous.replace(/"/g, '&quot;')}">`;
      }
    }

    // Pre-fill with any existing config (the user may already have
    // partially configured via the setup wizard).
    let initialProvider = 'surfshark';
    try {
      const cur = await api('GET', '/vpn/config');
      const p = document.getElementById('sb-vpn-provider');
      if (p && cur.provider) { p.value = cur.provider; initialProvider = cur.provider; }
      const c = document.getElementById('sb-vpn-countries');
      if (c && cur.server_countries) c.value = cur.server_countries;
      // Render the cities field for the chosen provider, then preselect
      // any existing values from .env.
      renderCitiesField(initialProvider);
      const wrap = document.getElementById('sb-vpn-cities-wrap');
      if (cur.server_cities && wrap) {
        const wanted = new Set(cur.server_cities.split(',').map(s => s.trim()));
        const sel = wrap.querySelector('select#sb-vpn-cities');
        if (sel) {
          Array.from(sel.options).forEach(o => { if (wanted.has(o.value)) o.selected = true; });
        } else {
          const inp = wrap.querySelector('input#sb-vpn-cities');
          if (inp) inp.value = cur.server_cities;
        }
      }
    } catch {
      renderCitiesField(initialProvider);
    }

    // Re-render cities dropdown whenever the provider changes — Surfshark's
    // catalog is different from ProtonVPN's, etc.
    const provSel = document.getElementById('sb-vpn-provider');
    if (provSel) {
      provSel.addEventListener('change', () => renderCitiesField(provSel.value));
    }

    // "Pick closest to me" — looks at the dashboard's host-IP probe
    // (already cached) and pre-fills the cities field with the nearest
    // Surfshark POPs by US region. For non-US users we just suggest the
    // continent's capital city POPs. User can edit to whatever they want.
    const SURFSHARK_NEAREST_BY_REGION = {
      // US Pacific / Mountain
      'California': 'San Jose, Los Angeles',
      'Nevada': 'San Jose, Las Vegas, Los Angeles',
      'Oregon': 'Seattle, San Jose',
      'Washington': 'Seattle, San Jose',
      'Arizona': 'Phoenix, Las Vegas, Los Angeles',
      'Utah': 'Salt Lake City, Las Vegas, Denver',
      'Colorado': 'Denver, Salt Lake City',
      'Idaho': 'Salt Lake City, Seattle',
      'Montana': 'Salt Lake City, Seattle',
      'Wyoming': 'Denver, Salt Lake City',
      'New Mexico': 'Phoenix, Las Vegas',
      // US Central
      'Texas': 'Dallas, Houston',
      'Oklahoma': 'Dallas',
      'Kansas': 'Dallas, Chicago',
      'Nebraska': 'Chicago, Denver',
      'Iowa': 'Chicago',
      'Missouri': 'Chicago, Dallas',
      'Arkansas': 'Dallas, Atlanta',
      'Louisiana': 'Houston, Atlanta',
      'Minnesota': 'Chicago',
      'Wisconsin': 'Chicago',
      'Illinois': 'Chicago',
      'Indiana': 'Chicago, Atlanta',
      'Michigan': 'Chicago, Buffalo',
      'Ohio': 'Buffalo, Atlanta, Chicago',
      'Kentucky': 'Atlanta, Chicago',
      'Tennessee': 'Atlanta',
      'Mississippi': 'Atlanta, Houston',
      'Alabama': 'Atlanta',
      // US Northeast / Southeast
      'New York': 'New York, Buffalo',
      'New Jersey': 'New York',
      'Pennsylvania': 'New York, Buffalo',
      'Connecticut': 'New York, Boston',
      'Massachusetts': 'Boston, New York',
      'Rhode Island': 'Boston, New York',
      'Maine': 'Boston, New York',
      'New Hampshire': 'Boston, New York',
      'Vermont': 'Boston, New York',
      'Maryland': 'New York, Atlanta',
      'Virginia': 'New York, Atlanta',
      'West Virginia': 'New York, Atlanta',
      'North Carolina': 'Atlanta, New York',
      'South Carolina': 'Atlanta',
      'Georgia': 'Atlanta',
      'Florida': 'Miami, Atlanta',
      'Hawaii': 'San Jose, Los Angeles',
      'Alaska': 'Seattle, San Jose',
      // International — provider-agnostic capitals
      'Ontario': 'Toronto',
      'Quebec': 'Montreal, Toronto',
      'British Columbia': 'Vancouver, Seattle',
      'England': 'London, Manchester',
      'Scotland': 'Edinburgh, London',
    };
    const closestBtn = document.getElementById('sb-vpn-closest');
    if (closestBtn) {
      closestBtn.onclick = async () => {
        try {
          const status = await api('GET', '/vpn/status');
          const region = status && status.host && status.host.region;
          const country = status && status.host && status.host.country;
          let suggested = '';
          if (region && SURFSHARK_NEAREST_BY_REGION[region]) {
            suggested = SURFSHARK_NEAREST_BY_REGION[region];
          } else if (country === 'US') {
            suggested = 'New York, Chicago, San Jose'; // US fallback covering 3 backbones
          }
          if (!suggested) {
            show('Couldn\'t auto-detect your region. Pick a city manually from the dropdown.');
            return;
          }
          // The cities field may be a <select multiple> (provider has a
          // curated list) or an <input> (custom provider). Apply suggested
          // values to whichever is rendered.
          const wanted = new Set(suggested.split(',').map(s => s.trim()).filter(Boolean));
          const sel = document.querySelector('#sb-vpn-cities-wrap select#sb-vpn-cities');
          if (sel) {
            Array.from(sel.options).forEach(o => { o.selected = wanted.has(o.value); });
          } else {
            const inp = document.querySelector('#sb-vpn-cities-wrap input#sb-vpn-cities');
            if (inp) inp.value = suggested;
          }
          // Also auto-fill country if blank, so the cities filter has a
          // valid country scope to work within.
          const cEl = document.getElementById('sb-vpn-countries');
          if (cEl && !cEl.value.trim() && country === 'US') cEl.value = 'United States';
        } catch (err) {
          show('Couldn\'t reach the VPN-status probe. Type cities manually.');
        }
      };
    }

    const errorBox = document.getElementById('sb-vpn-error');
    const show = (text) => { if (errorBox) { errorBox.textContent = text; errorBox.classList.remove('hidden'); } };
    const clearErr = () => { if (errorBox) errorBox.classList.add('hidden'); };
    modal.classList.remove('hidden');

    const cancel = document.getElementById('sb-vpn-cancel');
    const save = document.getElementById('sb-vpn-save');
    cancel.onclick = () => { modal.classList.add('hidden'); };
    save.onclick = async () => {
      clearErr();
      const provider = document.getElementById('sb-vpn-provider').value;
      const wgkey = document.getElementById('sb-vpn-wgkey').value.trim();
      const wgaddr = document.getElementById('sb-vpn-wgaddr').value.trim();
      const countries = document.getElementById('sb-vpn-countries').value.trim();
      // Cities may be a <select multiple> (curated list) or <input> (custom).
      let cities = '';
      const citiesSel = document.querySelector('#sb-vpn-cities-wrap select#sb-vpn-cities');
      if (citiesSel) {
        cities = Array.from(citiesSel.selectedOptions).map(o => o.value).join(', ');
      } else {
        const citiesInp = document.querySelector('#sb-vpn-cities-wrap input#sb-vpn-cities');
        cities = citiesInp ? citiesInp.value : '';
      }
      if (!provider) { show('Pick a VPN provider.'); return; }
      if (!wgkey) { show('WireGuard private key is required — copy it from your provider\'s config file.'); return; }
      btnLoading(save, true);
      try {
        await api('POST', '/vpn/config', {
          provider,
          type: 'wireguard',
          wireguard_private_key: wgkey,
          wireguard_addresses: wgaddr,
          server_countries: countries,
          server_cities: cities.trim(),
        });
        toast('VPN configured — retrying install…', 'success');
        modal.classList.add('hidden');
        // Retry the original install with the same enable/disable
        // diff. The server will re-check and this time pass the gate.
        runInstallStreaming(enable || [], disable || []);
      } catch (err) {
        show(err.message || 'Failed to save VPN configuration.');
      } finally {
        btnLoading(save, false);
      }
    };
  }

  // --- Health Badges in Running List ---

  // Override renderHome to add health indicators
  const _origRenderHome = renderHome;

  // We patch the existing renderHome to add health data.
  // The health field is already provided by the backend (added to docker.js).
  // We just need to surface it in the running list and launcher.

  // --- License & Pro Tier ---

  let _licenseInfo = null;

  function hasLicensedAccess() {
    return !!(_licenseInfo && (_licenseInfo.licensed || _licenseInfo.tier === 'pro'));
  }

  // [data-action="goto-settings"] navigates to the Settings tab — used by
  // CTAs like the "Activate license to enable auto-updates" affordance.
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action="goto-settings"]');
    if (!btn) return;
    e.preventDefault();
    const settingsTab = document.querySelector('[data-page="settings"]');
    if (settingsTab) settingsTab.click();
  });

  async function loadLicenseStatus() {
    try {
      _licenseInfo = await api('GET', '/license');
      updateProUI();
    } catch { /* ignore on first load */ }
  }

  function updateProUI() {
    if (!_licenseInfo) return;
    // 1.4.0: single-tier. If the dashboard is visible, the user is
    // licensed — this function populates the display-only license
    // card in Settings and enables any Pro-gated UI controls.
    const licensed = !!_licenseInfo.licensed;

    // v1.6.0 free pivot: badge says FOUNDING for paid-beta customers
    // (the 2 grandfathered users), LICENSED for free personal-use keys.
    // Footer tier mirrors. Settings card flips description accordingly.
    const isFounding = !!_licenseInfo.founding;
    const badgeText = isFounding ? 'FOUNDING' : 'LICENSED';

    const badge = $('#pro-badge');
    if (badge) {
      badge.classList.toggle('hidden', !licensed);
      badge.textContent = badgeText;
      badge.classList.toggle('badge-founding', isFounding);
    }

    // Footer tier (legacy element, keep in sync)
    const ft = $('#footer-tier');
    if (ft) ft.textContent = licensed ? (isFounding ? 'Founding Member' : 'Licensed') : 'Unlicensed';

    // Settings license card — flips between Founding / Licensed based
    // on whether the underlying KV record was paid pre-pivot or free.
    const tierBadge = $('#tier-badge');
    if (tierBadge) {
      tierBadge.textContent = badgeText;
      tierBadge.className = 'tier-badge ' + (isFounding ? 'tier-founding' : 'tier-pro');
    }
    const tierDesc = $('#tier-description');
    if (tierDesc) {
      tierDesc.textContent = isFounding
        ? 'Founding Member — lifetime access, paid before the free pivot'
        : 'Free personal-use license — auto-updates enabled';
    }

    // Populate the display-only fields
    const keyDisplay = $('#license-key-display');
    if (keyDisplay) keyDisplay.textContent = _licenseInfo.keyPreview || '—';
    const pdEl = $('#license-purchase-date');
    if (pdEl) {
      pdEl.textContent = _licenseInfo.purchaseDate
        ? new Date(_licenseInfo.purchaseDate).toLocaleDateString()
        : '—';
    }
    const actEl = $('#license-activations');
    if (actEl && _licenseInfo.maxActivations != null) {
      const used = _licenseInfo.activations || 1;
      const max = _licenseInfo.maxActivations || 3;
      actEl.textContent = `${used} of ${max} used`;
    }

    // Remove-license button is only shown if we want to let the user
    // un-license this specific install (e.g. before transferring to
    // another box). Stays hidden by default.
    const removeBtn = $('#btn-remove-license');
    if (removeBtn) removeBtn.classList.toggle('hidden', !licensed);

    // v1.6.3: inline activation form in Settings → License. Shown when
    // licensed=false (so customer can opt in to auto-updates without
    // a separate screen). Hidden when licensed=true.
    const activateInline = $('#license-activate-inline');
    if (activateInline) activateInline.classList.toggle('hidden', licensed);
    // The status block (badge + key + activations) is the inverse:
    // shown when licensed, hidden when not.
    const statusBlock = $('#license-status');
    if (statusBlock) statusBlock.classList.toggle('hidden', !licensed);

    // Updates page Pro controls — single-tier, always enabled when
    // the dashboard is visible. Removed the free-tier gating loop.
    const proControls = $('#updates-pro-controls');
    if (proControls) {
      const proButtons = proControls.querySelectorAll(
        '#btn-check-updates, #btn-update-all-pro, #btn-save-schedule, #schedule-enabled'
      );
      proButtons.forEach(btn => { btn.disabled = !licensed; });
    }
  }

  // The in-settings activate button (#btn-activate-license) and
  // license-key-input were removed in 1.4.0 — activation lives on the
  // dedicated #license-screen now. No handler needed here.

  // Remove license
  const removeBtn = $('#btn-remove-license');
  if (removeBtn) {
    removeBtn.addEventListener('click', async () => {
      const ok = await confirm(
        'Remove license?',
        'This locks OpenBox. Every state-changing API (enable/disable modules, change settings, backup, AI chat) will refuse until you re-activate. Your existing module containers keep running — but you won\'t be able to manage them from the dashboard.\n\nUse this only if you\'re moving the license to a different install.'
      );
      if (!ok) return;
      try {
        _licenseInfo = await api('DELETE', '/license');
        toast('License removed. Auto-updates are disabled — re-activate from Settings → License if you want them back.', 'info', 5000);
        updateProUI();
      } catch (err) {
        toast(err.message, 'error');
      }
    });
  }

  // --- Updates Page ---

  // --- OpenBox Self-Update ---

  // Render the release changelog from /changelog.json. Fails silently
  // if the file isn't present (dev installs, older builds). Cached
  // after first fetch since it doesn't change until next release.
  let _changelogCache = null;
  async function loadChangelog() {
    const el = document.getElementById('changelog-list');
    if (!el) return;
    try {
      if (!_changelogCache) {
        const res = await fetch('/changelog.json', { cache: 'no-cache' });
        if (!res.ok) throw new Error('no changelog');
        _changelogCache = await res.json();
      }
      const releases = (_changelogCache.releases || []);
      if (!releases.length) { el.innerHTML = '<p class="empty-state">No release notes yet.</p>'; return; }
      el.innerHTML = releases.map(r => {
        const items = (r.items || []).map(i => `<li>${esc(i)}</li>`).join('');
        const date = r.date ? new Date(r.date).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '';
        const tag = r.tag ? `<span class="changelog-tag changelog-tag-${esc(r.tag)}">${esc(r.tag)}</span>` : '';
        return `
          <article class="changelog-entry">
            <header class="changelog-header">
              <div class="changelog-version">
                <span class="changelog-version-num">v${esc(r.version)}</span>
                ${tag}
              </div>
              <time class="changelog-date">${esc(date)}</time>
            </header>
            ${r.title ? `<h3 class="changelog-title">${esc(r.title)}</h3>` : ''}
            <ul class="changelog-items">${items}</ul>
          </article>`;
      }).join('');
    } catch {
      el.innerHTML = '<p class="empty-state">Could not load release notes.</p>';
    }
  }

  // Returns the parsed status so callers (the Check button click
  // handler) can give the user a result-aware toast instead of the
  // contentless "Checked for OpenBox updates."
  async function loadSelfUpdateStatus() {
    try {
      const data = await api('GET', '/self-update/check');
      const cur = $('#sb-current-version');
      const latest = $('#sb-latest-version');
      const applyBtn = $('#btn-apply-sb-update');

      if (cur) cur.textContent = data.current || 'unknown';
      if (latest) {
        // Three non-update states surface their own messages so the
        // user understands WHY no update is being offered:
        //   freeze        — OpenBox team paused rollout
        //   tooOldToJump  — install predates the min_from_version gate
        //   downgrade     — server is advertising an older version (ignored)
        // Otherwise: "→ X.Y.Z available" (green) or "up to date" (muted).
        if (data.freeze) {
          latest.textContent = ' — updates paused';
          latest.style.color = 'var(--warn, #d97706)';
          latest.title = data.freezeReason || 'OpenBox team temporarily paused rollout while investigating an issue. Will resume shortly.';
        } else if (data.tooOldToJump) {
          latest.textContent = ` — v${data.latest} requires ≥v${data.minFromVersion}, run installer manually`;
          latest.style.color = 'var(--warn, #d97706)';
          latest.title = 'Your install is too old to auto-upgrade directly. Run: curl -fsSL https://get.crushcodeworks.com/install.sh | sudo bash';
        } else if (data.updateAvailable) {
          const channelSuffix = data.channel === 'canary' ? ' (canary)' : '';
          latest.textContent = ` → ${data.latest} available${channelSuffix}`;
          latest.style.color = 'var(--accent)';
          latest.title = '';
        } else {
          latest.textContent = ' (up to date)';
          latest.style.color = 'var(--text-muted)';
          latest.title = '';
        }
        latest.style.marginLeft = '0.5rem';
      }
      // Hide Apply button when there's nothing to apply — freeze,
      // tooOldToJump, or no new version. v1.6.54: dropped the
      // hasLicensedAccess() check that was hiding the button for free
      // users. Manual self-update is now free (auto-updates and
      // rollback stay Pro). Server-side gate at /api/self-update/apply
      // is now requireLicense (skip-marker-aware), so a free install
      // can install Core updates without activating a license.
      if (applyBtn) {
        const canApply = data.updateAvailable && !data.freeze && !data.tooOldToJump;
        applyBtn.classList.toggle('hidden', !canApply);
      }
      return data;
    } catch (err) {
      return { error: err && err.message };
    }
  }

  const checkSbUpdateBtn = $('#btn-check-sb-update');
  if (checkSbUpdateBtn) {
    checkSbUpdateBtn.addEventListener('click', async () => {
      btnLoading(checkSbUpdateBtn, true);
      const data = await loadSelfUpdateStatus();
      btnLoading(checkSbUpdateBtn, false);
      // Tell the user what we found, not just that we looked.
      if (!data || data.error) {
        toast(`Couldn't check for updates: ${(data && data.error) || 'unknown error'}`, 'error');
      } else if (data.updateAvailable) {
        toast(`Update available — OpenBox ${data.latest} (you're on ${data.current}). Click "Update OpenBox" to install.`, 'success');
      } else {
        toast(`OpenBox is up to date (${data.current || 'unknown'})`, 'info');
      }
    });
  }

  const applySbUpdateBtn = $('#btn-apply-sb-update');
  if (applySbUpdateBtn) {
    applySbUpdateBtn.addEventListener('click', async () => {
      const ok = await confirm(
        'Update OpenBox Core?',
        'This will download and install the latest version of OpenBox. Your data and settings will be preserved. The dashboard may need to restart after the update.'
      );
      if (!ok) return;

      btnLoading(applySbUpdateBtn, true);

      const overlay = $('#progress-overlay');
      const title = $('#progress-title');
      const logEl = $('#progress-log');
      const actions = $('#progress-actions');
      const dontClose = $('#progress-do-not-close');

      if (title) title.textContent = 'Updating OpenBox...';
      if (logEl) logEl.textContent = '';
      if (actions) actions.classList.add('hidden');
      if (overlay) overlay.classList.remove('hidden');
      if (dontClose) dontClose.classList.remove('hidden');

      // Block tab close / refresh / navigation during the swap. v1.5.116
      // hotfix: customer on Hostinger VPS lost the box during a self-update
      // earlier today by refreshing mid-swap — dashboard never came back
      // up cleanly and recovery required SSH. The native confirm dialog
      // pops if the user tries to close/refresh while updating; we clear
      // it on completion so they can navigate freely after.
      const beforeUnloadGuard = (e) => {
        const msg = "OpenBox is mid-update — closing or refreshing now will leave the box in a half-installed state that needs SSH to recover. Wait for it to finish (1–3 minutes).";
        e.preventDefault();
        e.returnValue = msg;
        return msg;
      };
      window.addEventListener('beforeunload', beforeUnloadGuard);

      const handler = (data) => {
        if (logEl && data.step) {
          logEl.textContent += data.step + '\n';
          logEl.scrollTop = logEl.scrollHeight;
        }
      };
      if (socket) socket.on('self-update:progress', handler);

      // Pre-populate so the modal isn't visibly empty for the entire
      // request roundtrip. The first real `self-update:progress` event
      // will append below this line.
      if (logEl) {
        logEl.textContent = 'Asking server to start self-update...\n';
      }

      // Wait for the dashboard to come back after its restart and then
      // hard-reload. Shared between the success path (response arrived
      // before restart killed the socket) and the network-error path
      // (restart killed the request in flight). Without this the success
      // path leaves the user on stale JS until they manually refresh.
      const waitForRestartAndReload = () => {
        const startedAt = Date.now();
        // Codex round 4 #14: backend health probe runs up to 180s, so
        // the UI waiting only 90s declared failure on still-healthy
        // updates. Matches the helper's probe window now.
        const MAX_WAIT_MS = 180 * 1000;
        let dots = 0;
        const poll = async () => {
          if (Date.now() - startedAt > MAX_WAIT_MS) {
            if (logEl) logEl.textContent += `\n[Note] Dashboard didn't come back within 3 minutes. The update may have failed health checks and rolled back. Refresh manually (Ctrl+Shift+R) to check.\n`;
            return;
          }
          try {
            const r = await fetch('/api/auth/status', { cache: 'no-store' });
            if (r.ok) {
              if (logEl) logEl.textContent += `\n[OK] Dashboard is back. Reloading...\n`;
              try { localStorage.setItem('sb-update-just-completed', '1'); } catch {}
              setTimeout(() => location.reload(), 400);
              return;
            }
          } catch {}
          dots = (dots + 1) % 4;
          if (title) title.textContent = 'Dashboard restarting' + '.'.repeat(dots);
          setTimeout(poll, 1000);
        };
        setTimeout(poll, 2000);
      };

      try {
        const result = await api('POST', '/self-update/apply');
        if (result.success) {
          if (result.toVersion && result.fromVersion && result.toVersion !== result.fromVersion) {
            toast(`OpenBox updated ${result.fromVersion} → ${result.toVersion} — reloading…`, 'success');
            if (title) title.textContent = `Updated to v${result.toVersion} — reloading…`;
            if (logEl) logEl.textContent += `\n[OK] Update applied. Waiting for dashboard restart, then auto-reloading…\n`;
            waitForRestartAndReload();
          } else {
            // performSelfUpdate returns success:true with message
            // "Already up to date" when no newer release exists.
            // Don't claim we updated when we didn't.
            toast(result.message || 'Already up to date', 'info');
            if (title) title.textContent = 'Already up to date';
            if (logEl) logEl.textContent += `\n${result.message || 'No newer release available.'} Current: v${result.version || 'unknown'}\n`;
          }
        } else {
          if (title) title.textContent = 'Update Failed';
          if (logEl) logEl.textContent += '\n[ERROR] Server returned success:false without an exception.\n';
          toast(result.error || result.message || 'Update failed.', 'error');
        }
      } catch (err) {
        const msg = (err && (err.message || err.error)) || 'Update failed.';
        // "Failed to fetch" / network errors during self-update are
        // EXPECTED — the dashboard restarts itself as part of the
        // upgrade flow, which kills the in-flight request. Treat
        // these as "probably succeeded, refresh to verify" instead
        // of red error.
        const looksLikeRestart = /failed to fetch|networkerror|load failed|err_connection|err_network/i.test(msg);
        if (err && err.blocked === 'too_old' && err.stepped_upgrade) {
          // Codex P2 (2026-04-21): server returned a structured
          // "your install predates this release's baseline" response.
          // Show a guided CTA instead of a red failure state.
          const su = err.stepped_upgrade;
          if (title) title.textContent = 'Stepped upgrade needed';
          if (logEl) {
            logEl.textContent += `\nThis release needs v${su.min_required}+ as a starting point (you're on v${su.current}).\n`;
            logEl.textContent += `Run this on the host to catch up:\n  ${su.manual_install}\n`;
          }
          toast(msg, 'info');
        } else if (looksLikeRestart) {
          if (title) title.textContent = 'Dashboard restarting...';
          if (logEl) logEl.textContent += `\n[Note] Connection lost — the dashboard is restarting itself as part of the upgrade. Waiting for it to come back...\n`;
          toast('Dashboard restarting — auto-reloading when it comes back.', 'info');
          waitForRestartAndReload();
        } else {
          if (title) title.textContent = 'Update Failed';
          if (logEl) logEl.textContent += `\n[ERROR] ${msg}\n`;
          toast(msg, 'error');
        }
      }

      if (socket) socket.off('self-update:progress', handler);
      // Drop the navigation guard so the user can freely refresh / close
      // the tab after the update either finished or visibly failed.
      window.removeEventListener('beforeunload', beforeUnloadGuard);
      if (dontClose) dontClose.classList.add('hidden');
      if (actions) actions.classList.remove('hidden');
      btnLoading(applySbUpdateBtn, false);
      // loadSelfUpdateStatus may itself fail if the dashboard is
      // restarting — guard so we don't paint over the helpful
      // "refresh in a moment" message with a generic error.
      try { loadSelfUpdateStatus(); } catch {}
    });
  }

  // Releases page — historical changelog, read-only. Separated from
  // Updates so the Updates page stays action-focused (check + apply +
  // schedule) and Releases stays history-focused (what shipped when).
  async function loadReleasesPage() {
    // Fill the "currently running" banner with the installed OpenBox
    // version so the user sees the anchor point.
    try {
      const data = await api('GET', '/self-update/check');
      const cur = document.getElementById('releases-current');
      if (cur) cur.textContent = 'v' + (data.current || 'unknown');
    } catch { /* fallthrough — show version unknown */ }
    loadChangelog();
  }

  // Auto-trigger a fresh check if the cached state is older than this.
  // 1 hour is a reasonable freshness window — long enough not to hammer
  // the registry every time the user opens the tab, short enough that
  // the displayed REBUILD badges aren't days-old stale info.
  const UPDATES_CHECK_STALE_AFTER_MS = 60 * 60 * 1000;

  async function loadUpdatesPage() {
    await loadLicenseStatus();
    loadSelfUpdateStatus();

    if (hasLicensedAccess()) {
      let cachedLastCheck = null;
      try {
        const data = await api('GET', '/updates/available');
        // Tom's 2026-04-24 live review: don't render "All services
        // up to date" when there's no lastCheck — that's a lie. Show
        // "No check run yet" until a check actually completes.
        if (data.lastCheck) {
          renderAvailableUpdates(data.available || []);
          cachedLastCheck = new Date(data.lastCheck).getTime();
          $('#updates-last-check').textContent = new Date(data.lastCheck).toLocaleString();
        } else {
          renderAvailableUpdatesUnchecked();
        }
      } catch { /* first time, no state yet */ }

      try {
        const schedule = await api('GET', '/updates/schedule');
        renderSchedule(schedule);
      } catch { /* no schedule */ }

      try {
        const history = await api('GET', '/updates/history');
        renderUpdateHistory(history);
      } catch { /* no history */ }

      // Auto-refresh if cached state is missing or stale. Fires the
      // exact same flow as the Check button — spinner on the button,
      // toast on completion. User can keep using the page while the
      // parallel check runs (≤30s end-to-end on most installs).
      const isStale = !cachedLastCheck || (Date.now() - cachedLastCheck > UPDATES_CHECK_STALE_AFTER_MS);
      if (isStale) {
        const btn = $('#btn-check-updates');
        if (btn && !btn.disabled) {
          btn.click();
        }
      }
    }
  }

  // Tom 2026-04-24 live review: shown when lastCheck has never
  // run. The "All services are up to date" render pretended
  // certainty where there was none.
  function renderAvailableUpdatesUnchecked() {
    const list = $('#updates-list');
    const updateAllBtn = $('#btn-update-all-pro');
    if (!list) return;
    list.innerHTML = '<p class="empty-state">No update check has run yet on this install. Click <strong>Check for updates</strong> to scan for available versions.</p>';
    if (updateAllBtn) updateAllBtn.disabled = true;
    const badge = $('#update-badge');
    if (badge) { badge.textContent = ''; badge.classList.add('hidden'); }
  }

  function renderAvailableUpdates(available) {
    const list = $('#updates-list');
    const updateAllBtn = $('#btn-update-all-pro');
    if (!list) return;

    if (!available.length) {
      list.innerHTML = '<p class="empty-state">All services are up to date.</p>';
      if (updateAllBtn) updateAllBtn.disabled = true;
      // Reset the badge when there are no updates left — otherwise
      // the count from the last check stays pinned to the topbar
      // even though the list is empty.
      const emptyBadge = $('#update-badge');
      if (emptyBadge) {
        emptyBadge.textContent = '0';
        emptyBadge.classList.add('hidden');
      }
      return;
    }

    if (updateAllBtn) updateAllBtn.disabled = false;

    // Update badge
    const badge = $('#update-badge');
    if (badge) {
      badge.textContent = available.length;
      badge.classList.remove('hidden');
    }

    list.innerHTML = available.map(u => `
      <div class="update-item" data-module="${esc(u.module)}">
        <div class="update-item-info">
          <div class="update-item-name">${esc(u.module)} / ${esc(u.service)} <span class="app-tag optional" title="The pinned version tag was rebuilt by the publisher. Same version number, possibly with security patches in the base layers.">rebuild</span> <span class="sb-help" data-help="updates-apply" tabindex="0" role="button" aria-label="What applying this rebuild does">?</span></div>
          <div class="update-item-image">${esc(u.image)}</div>
        </div>
        <button class="btn-soft btn-update-module" data-module="${esc(u.module)}">Pull rebuild</button>
      </div>
    `).join('');

    // Per-module update buttons
    list.querySelectorAll('.btn-update-module').forEach(btn => {
      btn.addEventListener('click', () => applyUpdate(btn.dataset.module));
    });
  }

  function renderSchedule(schedule) {
    const checkbox = $('#schedule-enabled');
    const configEl = $('#schedule-config');
    const statusEl = $('#schedule-status');

    if (checkbox) checkbox.checked = schedule.enabled;
    if (configEl) configEl.classList.toggle('hidden', !schedule.enabled);

    // Parse cron: "0 3 * * 2" -> hour=3, day=2
    if (schedule.cron) {
      const parts = schedule.cron.split(' ');
      const hour = parseInt(parts[1]) || 3;
      const day = parts[4] || '*';
      const hourSel = $('#schedule-hour');
      const daySel = $('#schedule-day');
      if (hourSel) hourSel.value = hour;
      if (daySel) daySel.value = day;
    }

    if (statusEl && schedule.lastRun) {
      statusEl.textContent = `Last scheduled run: ${new Date(schedule.lastRun).toLocaleString()}`;
    }
  }

  function renderUpdateHistory(history) {
    const el = $('#updates-history');
    if (!el) return;

    if (!history || !history.length) {
      el.innerHTML = '<p class="empty-state">No update history yet.</p>';
      return;
    }

    el.innerHTML = history.slice(0, 20).map(h => {
      const icon = h.success ? '&#10003;' : (h.rolledBack ? '&#8635;' : '&#10007;');
      const tag = h.success ? 'success' : (h.rolledBack ? 'rolled-back' : 'failed');
      const label = h.success ? 'Success' : (h.rolledBack ? 'Rolled back' : 'Failed');
      return `
        <div class="history-item">
          <span class="history-icon">${icon}</span>
          <span class="history-module">${esc(h.module)}</span>
          <span class="history-tag ${tag}">${label}</span>
          <span class="history-time">${new Date(h.timestamp).toLocaleString()}</span>
        </div>`;
    }).join('');
  }

  // Check for updates button
  const checkUpdatesBtn = $('#btn-check-updates');
  if (checkUpdatesBtn) {
    checkUpdatesBtn.addEventListener('click', async () => {
      btnLoading(checkUpdatesBtn, true);
      try {
        const data = await api('GET', '/updates/check');
        renderAvailableUpdates(data.available || []);
        $('#updates-last-check').textContent = new Date().toLocaleString();
        toast(`${(data.available || []).length} update(s) found.`, 'success');
      } catch (err) {
        toast(err.message || 'Failed to check for updates.', 'error');
      }
      btnLoading(checkUpdatesBtn, false);
    });
  }

  // Update All button
  const updateAllProBtn = $('#btn-update-all-pro');
  if (updateAllProBtn) {
    updateAllProBtn.addEventListener('click', () => applyUpdate('all'));
  }

  async function applyUpdate(moduleId) {
    const ok = await confirm(
      'Apply update?',
      `This will update ${moduleId === 'all' ? 'all modules' : moduleId}. A pre-update snapshot will be saved for rollback.`
    );
    if (!ok) return;

    // Use progress modal
    const overlay = $('#progress-overlay');
    const title = $('#progress-title');
    const logEl = $('#progress-log');
    const actions = $('#progress-actions');

    if (title) title.textContent = `Updating ${moduleId === 'all' ? 'all modules' : moduleId}...`;
    if (logEl) logEl.textContent = '';
    if (actions) actions.classList.add('hidden');
    if (overlay) overlay.classList.remove('hidden');

    // Listen for streaming progress
    const handler = (data) => {
      if (logEl && data.step) {
        logEl.textContent += data.step + '\n';
        logEl.scrollTop = logEl.scrollHeight;
      }
    };
    socket.on('updates:progress', handler);

    let updateFailed = false;
    try {
      const result = await api('POST', '/updates/apply', { module: moduleId });
      if (result.success) {
        toast('Update complete!', 'success');
      } else if (result.rolledBack) {
        toast('Update failed — rolled back to previous version.', 'error');
        updateFailed = true;
        if (logEl) logEl.textContent += '\n[ROLLBACK] Previous version restored.\n';
      } else {
        // The third case: success=false AND rolledBack=false. Before
        // this fell through silently — the modal title still said
        // "Update Complete" even though the backend reported failure.
        // Now we treat it as a failure with whatever message the
        // server returned.
        updateFailed = true;
        const msg = result.error || result.message || 'Update reported failure with no details.';
        toast(msg, 'error');
        if (logEl) logEl.textContent += '\n[ERROR] ' + msg + '\n';
      }
    } catch (err) {
      updateFailed = true;
      const msg = err.message || 'Update failed.';
      toast(msg, 'error');
      if (logEl) logEl.textContent += '\n[ERROR] ' + msg + '\n';
    }

    socket.off('updates:progress', handler);
    if (actions) actions.classList.remove('hidden');
    if (title) title.textContent = updateFailed ? 'Update Failed' : 'Update Complete';

    // Refresh the updates page
    loadUpdatesPage();
  }

  // Schedule toggle
  const scheduleToggle = $('#schedule-enabled');
  if (scheduleToggle) {
    scheduleToggle.addEventListener('change', () => {
      const configEl = $('#schedule-config');
      if (configEl) configEl.classList.toggle('hidden', !scheduleToggle.checked);
    });
  }

  // Save schedule
  const saveScheduleBtn = $('#btn-save-schedule');
  if (saveScheduleBtn) {
    saveScheduleBtn.addEventListener('click', async () => {
      const enabled = $('#schedule-enabled').checked;
      const hour = $('#schedule-hour').value;
      const day = $('#schedule-day').value;
      const cronExpr = `0 ${hour} * * ${day}`;

      btnLoading(saveScheduleBtn, true);
      try {
        await api('PUT', '/updates/schedule', { cron: cronExpr, enabled });
        toast('Schedule saved!', 'success');
      } catch (err) {
        toast(err.message || 'Failed to save schedule.', 'error');
      }
      btnLoading(saveScheduleBtn, false);
    });
  }

  // --- Server Management: restart all + soft reset ---

  const restartAllSettingsBtn = $('#btn-restart-all-settings');
  if (restartAllSettingsBtn) {
    restartAllSettingsBtn.addEventListener('click', async () => {
      const ok = await confirm(
        'Restart all services?',
        'Every container will be bounced. Takes about 30 seconds. No data is lost.'
      );
      if (!ok) return;
      btnLoading(restartAllSettingsBtn, true);
      const status = $('#server-mgmt-status');
      if (status) status.textContent = 'Restarting all services...';
      try {
        await api('POST', '/containers/restart-all');
        toast('All services restarted!', 'success');
        if (status) status.textContent = 'Restart complete.';
        setTimeout(loadHome, 2000);
      } catch (err) {
        toast(err.message || 'Restart failed.', 'error');
        if (status) status.textContent = '';
      }
      btnLoading(restartAllSettingsBtn, false);
    });
  }

  const softResetBtn = $('#btn-soft-reset');
  if (softResetBtn) {
    softResetBtn.addEventListener('click', async () => {
      const ok = await confirm(
        'Soft reset OpenBox?',
        'This stops all containers, removes them, and brings everything back up fresh. Your settings, passwords, and app data are all preserved. The dashboard will be unavailable for about 60 seconds during the reset.'
      );
      if (!ok) return;
      btnLoading(softResetBtn, true);
      const status = $('#server-mgmt-status');
      if (status) status.textContent = 'Soft reset in progress — the page will reload when ready...';
      try {
        await api('POST', '/server/soft-reset');
        toast('Soft reset started. The page will reload in about 60 seconds.', 'success');
        // Poll until the dashboard comes back
        let attempts = 0;
        const poll = setInterval(async () => {
          attempts++;
          try {
            const res = await fetch('/api/auth/status');
            if (res.ok) {
              clearInterval(poll);
              window.location.reload();
            }
          } catch {}
          if (attempts > 90) {
            clearInterval(poll);
            if (status) status.textContent = 'Reset is taking longer than expected. Try refreshing manually.';
          }
        }, 2000);
      } catch (err) {
        toast(err.message || 'Soft reset failed.', 'error');
        if (status) status.textContent = '';
        btnLoading(softResetBtn, false);
      }
    });
  }

  // --- Factory Reset ---
  // Wipes module configs/data + state, keeps .env (license + admin pw) +
  // backups + /data. User lands back in the first-run wizard with their
  // same login still working. Requires the literal string "DELETE" to be
  // typed — browser prompt() is cheap and works without modal plumbing.
  const factoryResetBtn = $('#btn-factory-reset');
  if (factoryResetBtn) {
    factoryResetBtn.addEventListener('click', async () => {
      // Two-step confirm: first a Yes/No modal (existing helper, same
      // modal plumbing as Soft Reset / Reset to Defaults), then a
      // browser prompt for the DELETE literal. The modal is the
      // primary intent-check; the DELETE string is a belt-and-braces
      // second confirmation that also satisfies the server's body
      // validation. window.prompt() alone was unreliable — some
      // browser configs (especially inside installed PWAs) silently
      // return null, which looked like "click does nothing" to users.
      const ok = await confirm(
        'Factory Reset OpenBox?',
        'This wipes every module\'s config and data folder, clears state/, resets to core-only, and boots into the first-run wizard. KEPT: your license key, admin password, backups, and /data (media files). DELETED: every app\'s saved config and data. The dashboard will be unavailable for about 60-90 seconds during the reset.'
      );
      if (!ok) return;
      const typed = window.prompt('Last check — type DELETE (all caps) to confirm:', '');
      if (typed !== 'DELETE') {
        if (typed !== null) toast('Factory reset cancelled.', 'info');
        return;
      }
      btnLoading(factoryResetBtn, true);
      const status = $('#server-mgmt-status');
      if (status) status.textContent = 'Factory reset in progress — the page will reload into the setup wizard when ready...';
      try {
        await api('POST', '/server/factory-reset', { confirm: 'DELETE' });
        toast('Factory reset started. The page will reload in about 60-90 seconds.', 'success');
        // Poll until the dashboard comes back — same pattern as soft-reset.
        let attempts = 0;
        const poll = setInterval(async () => {
          attempts++;
          try {
            const res = await fetch('/api/auth/status');
            if (res.ok) {
              clearInterval(poll);
              window.location.reload();
            }
          } catch {}
          if (attempts > 120) {
            clearInterval(poll);
            if (status) status.textContent = 'Factory reset is taking longer than expected. Try refreshing manually.';
          }
        }, 2000);
      } catch (err) {
        toast(err.message || 'Factory reset failed.', 'error');
        if (status) status.textContent = '';
        btnLoading(factoryResetBtn, false);
      }
    });
  }

  // --- Reset to Defaults ---

  const resetDefaultsBtn = $('#btn-reset-defaults');
  if (resetDefaultsBtn) {
    resetDefaultsBtn.addEventListener('click', async () => {
      const ok = await confirm(
        'Reset to defaults?',
        'This disables ALL optional apps and goes back to just the core services (dashboard, reverse proxy, homepage, portainer). Your app data is preserved on disk — re-enable any app later from the Apps page and it comes back with all its settings intact. The dashboard will restart.'
      );
      if (!ok) return;
      btnLoading(resetDefaultsBtn, true);
      const status = $('#server-mgmt-status');
      if (status) status.textContent = 'Resetting to defaults — the page will reload when ready...';
      try {
        await api('POST', '/server/reset-defaults');
        toast('Resetting to defaults. The page will reload in about 60 seconds.', 'success');
        let attempts = 0;
        const poll = setInterval(async () => {
          attempts++;
          try {
            const res = await fetch('/api/auth/status');
            if (res.ok) {
              clearInterval(poll);
              window.location.reload();
            }
          } catch {}
          if (attempts > 90) {
            clearInterval(poll);
            if (status) status.textContent = 'Reset is taking longer than expected. Try refreshing manually.';
          }
        }, 2000);
      } catch (err) {
        toast(err.message || 'Reset failed.', 'error');
        if (status) status.textContent = '';
        btnLoading(resetDefaultsBtn, false);
      }
    });
  }

  // --- Remote support session ---

  async function refreshSupportStatus() {
    const enableBtn = $('#btn-support-enable');
    const disableBtn = $('#btn-support-disable');
    const text = $('#support-status-text');
    if (!enableBtn || !text) return;
    try {
      const s = await api('GET', '/support/status');
      if (s && s.enabled) {
        const remSec = Math.max(0, (s.expires_at || 0) - Math.floor(Date.now() / 1000));
        const h = Math.floor(remSec / 3600);
        const m = Math.floor((remSec % 3600) / 60);
        text.innerHTML = `<strong style="color:var(--warn,#d97706)">SESSION OPEN</strong> — Tom can SSH in for ${h}h ${m}m. Hostname: <code>${s.hostname || '?'}</code>.`;
        enableBtn.style.display = 'none';
        if (disableBtn) disableBtn.style.display = '';
      } else {
        text.textContent = 'No active support session.';
        enableBtn.style.display = '';
        if (disableBtn) disableBtn.style.display = 'none';
      }
    } catch (err) {
      text.textContent = 'Could not read support status.';
    }
  }

  const supportEnableBtn = $('#btn-support-enable');
  if (supportEnableBtn) {
    supportEnableBtn.addEventListener('click', async () => {
      const ok = await confirm(
        'Allow Tom to SSH into your server for 4 hours?',
        'OpenBox will install Tailscale (if not already), join Tom\'s support tailnet as a temporary node, and add Tom\'s SSH public key to /root/.ssh/authorized_keys. Auto-revokes after 4 hours, or click "Close session now" any time. The traffic is end-to-end encrypted via Tailscale; nothing is exposed to the public internet.'
      );
      if (!ok) return;
      btnLoading(supportEnableBtn, true);
      const status = $('#support-mgmt-status');
      if (status) status.textContent = 'Opening support session… this can take 30–60 seconds.';
      try {
        await api('POST', '/support/enable', { hours: 4 });
        toast('Support session opening. Tell Tom in Discord: "support is on".', 'success');
        // Poll for status flip — up to ~90s.
        let polls = 0;
        const tick = setInterval(async () => {
          polls++;
          await refreshSupportStatus();
          const s = await api('GET', '/support/status').catch(() => null);
          if (s && s.enabled) {
            clearInterval(tick);
            if (status) status.textContent = `Active until ${new Date((s.expires_at || 0) * 1000).toLocaleTimeString()}.`;
            btnLoading(supportEnableBtn, false);
          }
          if (polls > 45) {
            clearInterval(tick);
            if (status) status.textContent = 'Taking longer than expected — check state/support-enable.log on the host.';
            btnLoading(supportEnableBtn, false);
          }
        }, 2000);
      } catch (err) {
        toast(err.message || 'Could not start support session.', 'error');
        if (status) status.textContent = '';
        btnLoading(supportEnableBtn, false);
      }
    });
  }

  const supportDisableBtn = $('#btn-support-disable');
  if (supportDisableBtn) {
    supportDisableBtn.addEventListener('click', async () => {
      const ok = await confirm(
        'Close support session now?',
        'Tom\'s SSH access will be revoked immediately. The Tailscale ephemeral node will leave the tailnet shortly after.'
      );
      if (!ok) return;
      btnLoading(supportDisableBtn, true);
      const status = $('#support-mgmt-status');
      if (status) status.textContent = 'Closing support session…';
      try {
        await api('POST', '/support/disable');
        toast('Support session closed.', 'success');
        // Poll status to flip back to "no active session"
        setTimeout(refreshSupportStatus, 1500);
        setTimeout(refreshSupportStatus, 4000);
        if (status) status.textContent = 'Closed.';
      } catch (err) {
        toast(err.message || 'Could not close support session.', 'error');
        if (status) status.textContent = '';
      }
      btnLoading(supportDisableBtn, false);
    });
  }

  if (supportEnableBtn) {
    refreshSupportStatus();
    // Also refresh when the Settings tab becomes active so a stale
    // banner doesn't linger after reload.
    setInterval(refreshSupportStatus, 30000);
  }

  // --- Maintenance: prune images ---

  const pruneBtn = $('#btn-prune-images');
  if (pruneBtn) {
    pruneBtn.addEventListener('click', async () => {
      const ok = await confirm(
        'Free up disk space?',
        'This removes old Docker images that no running app is using. It is safe and cannot break your apps. The first run on a NAS typically reclaims 5–20 GB.'
      );
      if (!ok) return;
      btnLoading(pruneBtn, true);
      const status = $('#prune-status');
      if (status) status.textContent = 'Scanning for unused images...';
      try {
        const result = await api('POST', '/maintenance/prune-images');
        const totalBytes = (result.spaceReclaimed || 0) + (result.builderReclaimed || 0);
        const mb = totalBytes / (1024 * 1024);
        const pretty = mb >= 1024
          ? (mb / 1024).toFixed(2) + ' GB'
          : mb.toFixed(1) + ' MB';
        if (totalBytes === 0) {
          toast('Already tidy — nothing to remove.', 'success');
          if (status) status.textContent = 'No unused images found.';
        } else {
          toast(`Reclaimed ${pretty} (${result.imagesDeleted} image${result.imagesDeleted === 1 ? '' : 's'} removed).`, 'success');
          if (status) status.textContent = `Reclaimed ${pretty}.`;
        }
      } catch (err) {
        toast(err.message || 'Prune failed.', 'error');
        if (status) status.textContent = '';
      }
      btnLoading(pruneBtn, false);
    });
  }

  // --- Server Migration ---

  const exportMigBtn = $('#btn-export-migration');
  if (exportMigBtn) {
    exportMigBtn.addEventListener('click', async () => {
      btnLoading(exportMigBtn, true);
      try {
        const res = await fetch('/api/migrate/export', { headers: { 'Content-Type': 'application/json' } });
        if (!res.ok) throw new Error('Export failed');
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'openbox-migration.json';
        a.click();
        URL.revokeObjectURL(url);
        toast('Migration bundle exported!', 'success');
      } catch (err) {
        toast(err.message || 'Export failed.', 'error');
      }
      btnLoading(exportMigBtn, false);
    });
  }

  const importMigInput = $('#btn-import-migration');
  if (importMigInput) {
    importMigInput.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const ok = await confirm(
        'Import migration bundle?',
        'This will update your .env settings and module list. Existing secrets will not be overwritten. You may need to restart services after import.'
      );
      if (!ok) { e.target.value = ''; return; }
      try {
        const text = await file.text();
        const bundle = JSON.parse(text);
        const result = await api('POST', '/migrate/import', bundle);
        let msg = 'Import complete!';
        if (result.warnings && result.warnings.length) {
          msg += ' Warnings: ' + result.warnings.join('; ');
        }
        toast(msg, result.warnings && result.warnings.length ? 'info' : 'success');
        const status = $('#migration-status');
        if (status && result.warnings && result.warnings.length) {
          status.innerHTML = result.warnings.map(w => `<p class="error-msg" style="margin:0.3rem 0">${esc(w)}</p>`).join('');
        }
      } catch (err) {
        toast(err.message || 'Import failed.', 'error');
      }
      e.target.value = '';
    });
  }

  // AI Troubleshooting requires Pro license — routed through OpenBox proxy
  // (chat is routed through the OpenBox proxy using the license key)
  function loadApiKeyStatus() { /* no-op: chat is bundled with Pro */ }

  // --- Alerts Bell ---

  let _alertsList = [];
  let _unreadAlertCount = 0;
  let _alertsLastSeen = localStorage.getItem('sb-alerts-last-seen') || '';

  async function loadAlerts() {
    try {
      _alertsList = await api('GET', '/alerts');
      updateAlertsBadge();
      renderAlertsDropdown();
    } catch { /* not authenticated or free tier */ }
  }

  function updateAlertsBadge() {
    const badge = $('#alerts-badge');
    if (!badge) return;
    // Count alerts newer than last seen
    _unreadAlertCount = _alertsLastSeen
      ? _alertsList.filter(a => a.timestamp > _alertsLastSeen).length
      : _alertsList.length;
    if (_unreadAlertCount > 0) {
      badge.textContent = _unreadAlertCount > 99 ? '99+' : _unreadAlertCount;
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  }

  function renderAlertsDropdown() {
    const list = $('#alerts-dropdown-list');
    if (!list) return;
    if (!_alertsList.length) {
      list.innerHTML = '<p class="alerts-empty">No recent alerts.</p>';
      return;
    }
    list.innerHTML = _alertsList.slice(0, 20).map(a => {
      const typeIcon = a.type === 'recovered' ? '&#10003;' : a.type === 'restart-failed' ? '&#10007;' : '&#9888;';
      const typeClass = a.type === 'recovered' ? 'recovered' : a.type === 'restart-failed' ? 'failed' : 'warning';
      const time = new Date(a.timestamp).toLocaleString();
      return `
        <div class="alerts-item ${typeClass}">
          <span class="alerts-item-icon">${typeIcon}</span>
          <div class="alerts-item-info">
            <div class="alerts-item-name">${esc(a.container)}</div>
            <div class="alerts-item-detail">${esc(a.type)}${a.autoRestarted ? ' (auto-restarted)' : ''}</div>
            <div class="alerts-item-time">${time}</div>
          </div>
        </div>`;
    }).join('');
  }

  // Toggle dropdown
  const bellBtn = $('#alerts-bell-btn');
  if (bellBtn) {
    bellBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const dropdown = $('#alerts-dropdown');
      if (!dropdown) return;
      const isVisible = !dropdown.classList.contains('hidden');
      if (isVisible) {
        dropdown.classList.add('hidden');
      } else {
        dropdown.classList.remove('hidden');
        // Mark as seen
        if (_alertsList.length) {
          _alertsLastSeen = _alertsList[0].timestamp;
          localStorage.setItem('sb-alerts-last-seen', _alertsLastSeen);
          updateAlertsBadge();
        }
        loadAlerts();
      }
    });
  }

  // Close dropdown on outside click
  document.addEventListener('click', (e) => {
    const dropdown = $('#alerts-dropdown');
    const wrap = $('#alerts-bell-wrap');
    if (dropdown && wrap && !wrap.contains(e.target)) {
      dropdown.classList.add('hidden');
    }
  });

  // Clear alerts
  const dismissBtn = $('#alerts-dismiss-btn');
  if (dismissBtn) {
    dismissBtn.addEventListener('click', () => {
      if (_alertsList.length) {
        _alertsLastSeen = _alertsList[0].timestamp;
        localStorage.setItem('sb-alerts-last-seen', _alertsLastSeen);
        _unreadAlertCount = 0;
        updateAlertsBadge();
      }
    });
  }

  // Listen for real-time alert events
  function setupAlertListeners() {
    if (!socket) return;
    socket.on('alert:service-down', (alert) => {
      _alertsList.unshift(alert);
      updateAlertsBadge();
      renderAlertsDropdown();
      toast(`Alert: ${alert.container} is ${alert.type}${alert.autoRestarted ? ' (auto-restarting)' : ''}`, 'error');
    });
    socket.on('alert:service-recovered', (alert) => {
      _alertsList.unshift(alert);
      updateAlertsBadge();
      renderAlertsDropdown();
      toast(`${alert.container} recovered`, 'success');
    });
  }

  // --- Health Reports ---

  async function loadHealthReports() {
    if (!hasLicensedAccess()) return;
    try {
      const [latest, reports] = await Promise.all([
        api('GET', '/reports/latest').catch(() => null),
        api('GET', '/reports').catch(() => [])
      ]);
      renderLatestReport(latest);
      renderReportsList(reports);
    } catch { /* free tier or not loaded */ }
  }

  function renderLatestReport(report) {
    const el = $('#health-report-summary');
    if (!el) return;
    if (!report) {
      el.innerHTML = '<p style="color:var(--text-muted); font-size:0.9rem;">No reports yet. Reports are generated weekly on Sundays.</p>';
      return;
    }
    const period = `${new Date(report.period.start).toLocaleDateString()} &mdash; ${new Date(report.period.end).toLocaleDateString()}`;
    el.innerHTML = `
      <div class="report-summary-row"><span class="report-label">Period</span><span>${period}</span></div>
      <div class="report-summary-row"><span class="report-label">Overall Uptime</span><span class="report-value ${report.uptime.overall >= 99 ? 'good' : report.uptime.overall >= 95 ? 'warn' : 'bad'}">${report.uptime.overall}%</span></div>
      <div class="report-summary-row"><span class="report-label">Alerts</span><span>${report.alerts.total} total, ${report.alerts.autoRestarted} auto-restarted, ${report.alerts.failed} failed</span></div>
      <div class="report-summary-row"><span class="report-label">Updates</span><span>${report.updates.applied} applied, ${report.updates.rolledBack} rolled back</span></div>
      <div class="report-summary-row"><span class="report-label">Disk</span><span>${report.disk.used} / ${report.disk.total} (${report.disk.percent}%)</span></div>
      <div class="report-summary-row"><span class="report-label">AI Troubleshooting Sessions</span><span>${report.chatSessions}</span></div>
      ${Object.keys(report.uptime.containers).length ? `
        <div class="report-containers">
          <div class="report-label" style="margin-top:0.75rem">Container Uptime</div>
          ${Object.entries(report.uptime.containers).map(([name, pct]) => `
            <div class="report-container-row">
              <span>${esc(name)}</span>
              <span class="report-value ${pct >= 99 ? 'good' : pct >= 95 ? 'warn' : 'bad'}">${pct}%</span>
            </div>
          `).join('')}
        </div>` : ''}
    `;
  }

  function renderReportsList(reports) {
    const el = $('#health-reports-list');
    if (!el) return;
    if (!reports || !reports.length) {
      el.innerHTML = '<p style="color:var(--text-muted); font-size:0.9rem;">No reports available.</p>';
      return;
    }
    el.innerHTML = reports.map(r => `
      <div class="report-list-row">
        <span class="report-list-date">${esc(r.date)}</span>
        <span class="report-list-file">${esc(r.filename)}</span>
      </div>
    `).join('');
  }

  // --- Alert Settings ---

  async function loadAlertSettings() {
    if (!hasLicensedAccess()) return;
    try {
      const settings = await api('GET', '/alerts/settings');
      const autoRestart = $('#alert-auto-restart');
      const webhookUrl = $('#alert-webhook-url');
      if (autoRestart) autoRestart.checked = settings.autoRestart;
      if (webhookUrl) webhookUrl.value = settings.webhookUrl || '';
    } catch { /* free tier */ }
  }

  const saveAlertSettingsBtn = $('#btn-save-alert-settings');
  if (saveAlertSettingsBtn) {
    saveAlertSettingsBtn.addEventListener('click', async () => {
      const autoRestart = $('#alert-auto-restart').checked;
      const webhookUrl = ($('#alert-webhook-url').value || '').trim();
      btnLoading(saveAlertSettingsBtn, true);
      try {
        await api('PUT', '/alerts/settings', { autoRestart, webhookUrl });
        toast('Alert settings saved!', 'success');
      } catch (err) {
        toast(err.message || 'Failed to save alert settings.', 'error');
      }
      btnLoading(saveAlertSettingsBtn, false);
    });
  }

  // --- Init ---
  checkAuth();
})();
