// OpenBox Service Worker — enables PWA install + offline shell
//
// CACHE_NAME is rewritten at release-build time by scripts/release.sh,
// which seds 1.6.105 to the current VERSION string. Every release
// therefore ships a unique sw.js; the browser sees a changed SW,
// installs it, `activate` wipes the old cache, and clients.claim()
// puts every open tab on the fresh code. No F12 → Unregister dance.
//
// Dev (where release.sh hasn't run) uses a timestamp-based name so
// local reloads also invalidate — otherwise you'd be stuck on your
// own stale bundle while iterating.
const VERSION_TOKEN = '1.6.105';
const CACHE_NAME = VERSION_TOKEN.includes('VERSION')
  ? 'openbox-dev-' + Math.floor(Date.now() / 1000)
  : 'openbox-' + VERSION_TOKEN;
const SHELL_FILES = ['/', '/css/style.css', '/js/app.js', '/js/chat.js'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      // cache: 'reload' forces the browser to bypass its own HTTP cache
      // when pre-caching the shell. Without this, a stale app.js sitting
      // in the HTTP cache after an update would just move into the SW
      // cache intact, and users would serve old JS indefinitely.
      cache.addAll(SHELL_FILES.map((url) => new Request(url, { cache: 'reload' })))
    )
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Network-first for API calls, cache-first for static assets
  if (event.request.url.includes('/api/') || event.request.url.includes('/socket.io/')) {
    return; // Let these pass through to network
  }
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  );
});
