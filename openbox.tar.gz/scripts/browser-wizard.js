﻿// OpenBox first-run wizard walkthrough — Playwright UI test.
//
// Drives the EXACT click-path a stranger would take after running
// install.sh: open dashboard → bootstrap claim → license activate →
// wizard (basics, profile=media, VPN creds) → finish → verify
// dashboard renders with all media modules running.
//
// Pairs with scripts/cold-install-rehearsal.sh, which exercises the
// same flow via the API. UI coverage catches what API tests skip:
// CSRF cookie roundtrip, focus traps, button-disabled states, modal
// dismissals, the "what does the user actually SEE" question.
//
// Usage:
//
//   NODE_PATH=/tmp/ob-qa-deps/node_modules \
//   OPENBOX_IP=192.168.0.17 \
//   OB_BOOTSTRAP_TOKEN=$(ssh nas 'sudo grep ^OB_BOOTSTRAP_TOKEN= /opt/openbox/.env' | cut -d= -f2) \
//   OB_ADMIN_PASSWORD=openbox-rehearsal-2026 \
//   OB_LICENSE_KEY=OB-PRO-XXXXXXXX-YYYYYYYY \
//   OB_PURCHASE_EMAIL=you@example.com \
//   OB_VPN_PROVIDER=surfshark \
//   OB_VPN_TYPE=wireguard \
//   OB_VPN_WG_KEY="redacted-base64-key=" \
//   OB_VPN_WG_ADDR="10.14.0.2/16" \
//   node scripts/browser-wizard.js
//
// Prerequisites: target NAS already wiped + freshly installed (i.e.
// dashboard is up, unclaimed). The cold-install-rehearsal.sh script
// gets you there for free; pass --ui to that script and it'll chain.
//
// Exit code: 0 on full pass. 1 on any failure (screenshot + dump
// written to ./browser-wizard-screenshots/).

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

// --- config ---
const IP = process.env.OPENBOX_IP || '192.168.0.17';
const PORT = parseInt(process.env.OPENBOX_PORT || '8443', 10);
const BASE = `http://${IP}:${PORT}`;
const BOOT = process.env.OB_BOOTSTRAP_TOKEN || '';
const PASS = process.env.OB_ADMIN_PASSWORD || '';
const LICENSE = process.env.OB_LICENSE_KEY || '';
const EMAIL = process.env.OB_PURCHASE_EMAIL || '';
const VPN_PROV = process.env.OB_VPN_PROVIDER || 'surfshark';
const VPN_TYPE = process.env.OB_VPN_TYPE || 'wireguard';
const VPN_WG_KEY = process.env.OB_VPN_WG_KEY || '';
const VPN_WG_ADDR = process.env.OB_VPN_WG_ADDR || '';
const SCREENSHOT_DIR = process.env.OB_SHOT_DIR || path.join(__dirname, '..', 'browser-wizard-screenshots');
const HEADED = process.env.OB_HEADED === '1';

for (const [k, v] of Object.entries({
    OB_BOOTSTRAP_TOKEN: BOOT, OB_ADMIN_PASSWORD: PASS, OB_LICENSE_KEY: LICENSE,
    OB_PURCHASE_EMAIL: EMAIL, OB_VPN_WG_KEY: VPN_WG_KEY, OB_VPN_WG_ADDR: VPN_WG_ADDR,
})) {
    if (!v) {
        console.error(`✗ Missing env: ${k}`);
        process.exit(2);
    }
}

fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });

// --- ANSI ---
const RED = '\x1b[31m', GRN = '\x1b[32m', YLW = '\x1b[33m', BLU = '\x1b[34m', DIM = '\x1b[2m', OFF = '\x1b[0m';
const step = (s) => console.log(`\n${BLU}▶${OFF} ${s}`);
const ok = (s) => console.log(`${GRN}✓${OFF} ${s}`);
const warn = (s) => console.warn(`${YLW}!${OFF} ${s}`);
const fail = (s) => console.error(`${RED}✗${OFF} ${s}`);

let stepName = 'init';

async function shoot(page, label) {
    const fn = path.join(SCREENSHOT_DIR, `${Date.now()}-${label}.png`);
    try {
        await page.screenshot({ path: fn, fullPage: true });
        return fn;
    } catch {
        return null;
    }
}

async function safeClick(page, sel, opts = {}) {
    await page.waitForSelector(sel, { state: 'visible', timeout: 15_000 });
    await page.click(sel, opts);
}

async function safeFill(page, sel, val) {
    await page.waitForSelector(sel, { state: 'visible', timeout: 15_000 });
    await page.fill(sel, val);
}

async function waitForWizardPage(page, id) {
    try {
        await page.waitForSelector(`#${id}:not(.hidden)`, { timeout: 25_000 });
    } catch (e) {
        const state = await page.evaluate(() => {
            const pages = Array.from(document.querySelectorAll('.wizard-page'));
            return pages.map(p => ({
                id: p.id,
                hidden: p.classList.contains('hidden'),
            }));
        });
        throw new Error(`Wizard page ${id} did not appear. State=${JSON.stringify(state)}`);
    }
}

// Click #wiz-next and confirm advance to expectedNextId. The SPA attaches
// event handlers in its main IIFE which sometimes hasn't run by the time
// Playwright clicks — first click silently no-ops, leaving the wizard
// stuck. Retry pattern: click, wait briefly, click again if still on the
// same page. Caught by 2026-04-25 5x loop where 1/5 runs failed at
// wiz-vpn (SPA's main IIFE racing with our first click).
async function clickNextAndAdvance(page, expectedNextId) {
    await safeClick(page, '#wiz-next');
    try {
        await page.waitForSelector(`#${expectedNextId}:not(.hidden)`, { timeout: 6_000 });
        return;
    } catch {
        // Re-click. Common cause: handler wasn't attached on first try,
        // or the click landed during a render flush.
    }
    await safeClick(page, '#wiz-next');
    await waitForWizardPage(page, expectedNextId);
}

(async () => {
    const t0 = Date.now();
    console.log(`${BLU}═══ OpenBox wizard UI walkthrough ═══${OFF}`);
    console.log(`${DIM}base=${BASE} headless=${!HEADED}${OFF}`);

    const browser = await chromium.launch({ headless: !HEADED });
    const ctx = await browser.newContext({
        ignoreHTTPSErrors: true,
        viewport: { width: 1280, height: 900 },
    });
    const page = await ctx.newPage();

    // Surface page console errors for diagnosis.
    page.on('pageerror', (e) => console.error(`  ${YLW}[page error]${OFF} ${e.message}`));

    try {
        // === 1. open dashboard, expect login screen with bootstrap input ===
        stepName = 'open-dashboard';
        step('Open dashboard, see first-run claim screen');
        await page.goto(BASE, { waitUntil: 'domcontentloaded' });
        // The bootstrap input is initially hidden; the SPA reveals it via
        // /api/auth/status returning {firstRun:true}. Wait for it to
        // leave .hidden state before typing. Retry the goto once if the
        // SPA's checkAuth() fell into the wrong branch (timing race
        // between dashboard startup + first request).
        const waitForBootstrapField = async () => {
            await page.waitForFunction(
                () => {
                    const el = document.querySelector('#login-bootstrap-token');
                    return el && !el.classList.contains('hidden');
                },
                { timeout: 15_000 },
            );
        };
        try {
            await waitForBootstrapField();
        } catch (firstErr) {
            // Diagnostic: what did the BROWSER see for /api/auth/status?
            // Compare to what bash polled before handoff.
            const browserSaw = await page.evaluate(async () => {
                try {
                    const r = await fetch('/api/auth/status');
                    return { ok: r.ok, status: r.status, body: await r.text() };
                } catch (e) { return { error: String(e) }; }
            });
            warn(`Bootstrap field hidden after first goto. Browser saw /api/auth/status: ${JSON.stringify(browserSaw)}`);
            // Reload the page once — gives the SPA a fresh chance.
            await page.reload({ waitUntil: 'domcontentloaded' });
            try {
                await waitForBootstrapField();
            } catch {
                throw new Error(`Bootstrap-token field never became visible after retry. Browser saw: ${JSON.stringify(browserSaw)}`);
            }
        }
        ok('First-run screen rendered.');

        // === 2. claim bootstrap + admin password ===
        stepName = 'claim-bootstrap';
        step('Paste bootstrap token + admin password');
        await safeFill(page, '#login-bootstrap-token', BOOT);
        await safeFill(page, '#login-password', PASS);
        // Listen for /api/login response so we can surface the exact
        // failure if the SPA chokes on it.
        const loginPromise = page.waitForResponse(
            (r) => r.url().includes('/api/login') && r.request().method() === 'POST',
            { timeout: 15_000 },
        );
        // Capture page console errors during the login transition —
        // we missed an exception in showDashboard() once that left
        // login-screen visible with no surfaced error.
        const consoleErrors = [];
        page.on('console', (msg) => {
            if (msg.type() === 'error') consoleErrors.push(`[browser] ${msg.text()}`);
        });
        await safeClick(page, '#login-btn');
        const loginResp = await loginPromise.catch(() => null);
        let loginBody = '';
        if (loginResp) {
            loginBody = await loginResp.text().catch(() => '');
            if (loginResp.status() !== 200) {
                throw new Error(`/api/login returned ${loginResp.status()}: ${loginBody.slice(0, 200)}`);
            }
            ok(`Submitted login form (HTTP ${loginResp.status()}, body=${loginBody.slice(0, 80)}).`);
        } else {
            ok('Submitted login form (no response captured).');
        }

        // === 3. license activation OR dashboard if already-licensed ===
        // After successful login the SPA hides #login-screen and either
        // shows #license-screen (no license cached) or jumps straight
        // to #dashboard / #setup-wizard. Wait for ANY of those to clear
        // the .hidden state, then dispatch on which one we landed on.
        stepName = 'post-login';
        step('Wait for post-login screen');
        try {
            // .hidden adds display:none, so the element is never "visible"
            // while it has that class. Playwright's default waitForSelector
            // semantics wait for VISIBLE — which would block forever here.
            // Use waitForFunction on classList instead.
            await page.waitForFunction(
                () => document.querySelector('#login-screen')?.classList.contains('hidden'),
                { timeout: 20_000 },
            );
        } catch (e) {
            // Surface what we know to make this debuggable next time.
            const visible = await page.evaluate(() => ({
                login: !document.querySelector('#login-screen').classList.contains('hidden'),
                license: !document.querySelector('#license-screen').classList.contains('hidden'),
                dashboard: !document.querySelector('#dashboard').classList.contains('hidden'),
                wizard: !document.querySelector('#setup-wizard').classList.contains('hidden'),
                err: (document.querySelector('#login-error')?.textContent || '').trim(),
            }));
            throw new Error(`Post-login transition timed out. Visible=${JSON.stringify(visible)}; loginBody="${loginBody.slice(0, 120)}"; consoleErrors=${consoleErrors.length ? consoleErrors.join('; ') : 'none'}`);
        }
        await page.waitForFunction(
            () => {
                const ls = document.querySelector('#license-screen');
                const dash = document.querySelector('#dashboard');
                const wiz = document.querySelector('#setup-wizard');
                const visible = (el) => el && !el.classList.contains('hidden');
                return visible(ls) || visible(dash) || visible(wiz);
            },
            { timeout: 20_000 },
        );

        // Branch on what's visible.
        const onLicense = await page.evaluate(
            () => !!document.querySelector('#license-screen:not(.hidden)'),
        );
        if (!onLicense) {
            // Dashboard or wizard came up directly — license must already
            // be cached as valid (rehearsal-rig pre-seeded in worker
            // activations[]). Skip the license-activate step.
            warn('License screen skipped — license already valid.');
        } else {
            stepName = 'license-activate';
            step('Activate license');
            await safeFill(page, '#license-email-input', EMAIL);
            await safeFill(page, '#license-key-input', LICENSE);
            await safeClick(page, '#license-btn');
            // After activation, the license screen hides and either the
            // wizard or dashboard becomes visible. Wait for the .hidden
            // class to be applied — see post-login note above for why
            // waitForSelector('.hidden') doesn't work.
            await page.waitForFunction(
                () => document.querySelector('#license-screen')?.classList.contains('hidden'),
                { timeout: 20_000 },
            );
            // Tolerate a transient license-error flash that auto-clears.
            const errVisible = await page.$('#license-error:not(.hidden)');
            if (errVisible) {
                const errText = await errVisible.textContent();
                throw new Error(`License activation failed: ${errText}`);
            }
            ok('License activated.');
        }

        // === 4. wizard: welcome ===
        stepName = 'wiz-welcome';
        step('Wizard — welcome');
        await waitForWizardPage(page, 'wiz-welcome');
        await clickNextAndAdvance(page, 'wiz-basics');
        ok('Welcome → Next.');

        // === 5. wizard: basics (domain + timezone — leave defaults) ===
        stepName = 'wiz-basics';
        step('Wizard — basics (defaults)');
        await clickNextAndAdvance(page, 'wiz-profile');
        ok('Basics → Next.');

        // === 6. wizard: profile = media ===
        stepName = 'wiz-profile-media';
        step('Wizard — pick Media profile');
        await safeClick(page, '.wizard-profile-card[data-profile="media"]');
        await page.waitForSelector('.wizard-profile-card[data-profile="media"].selected', { timeout: 5_000 });
        await clickNextAndAdvance(page, 'wiz-vpn');
        ok('Media profile selected.');

        // === 7. wizard: VPN credentials ===
        stepName = 'wiz-vpn';
        step('Wizard — fill VPN credentials');
        await page.selectOption('#wiz-vpn-provider', VPN_PROV);
        await page.selectOption('#wiz-vpn-type', VPN_TYPE);
        if (VPN_TYPE === 'wireguard') {
            await safeFill(page, '#wiz-vpn-wg-key', VPN_WG_KEY);
            await safeFill(page, '#wiz-vpn-wg-addr', VPN_WG_ADDR);
        } else {
            throw new Error('OpenVPN path not implemented in rehearsal');
        }
        await clickNextAndAdvance(page, 'wiz-community');
        ok('VPN creds submitted.');

        // === 8. wizard: community page (skip-thru) ===
        stepName = 'wiz-community';
        step('Wizard — community (next-thru)');
        await clickNextAndAdvance(page, 'wiz-done');
        ok('Community → Next.');

        // === 9. wizard: done — Finish triggers /api/setup/complete ===
        stepName = 'wiz-done';
        step('Wizard — Finish');
        await waitForWizardPage(page, 'wiz-done');
        // Listen for /api/setup/complete so we know the click actually
        // hit the server. The wizard then shows a progress area and
        // openbox up runs detached — that takes 2-3 min for image
        // pulls + healthcheck. Don't wait for that here; bash handles
        // the wait-for-lock + wait-for-healthy steps after Playwright
        // exits.
        const setupPromise = page.waitForResponse(
            (r) => r.url().includes('/api/setup/complete') && r.request().method() === 'POST',
            { timeout: 15_000 },
        );
        await safeClick(page, '#wiz-next');  // last next = Finish
        const setupResp = await setupPromise.catch(() => null);
        if (!setupResp) {
            throw new Error('Finish click did not fire POST /api/setup/complete within 15s.');
        }
        if (setupResp.status() !== 200) {
            const body = await setupResp.text().catch(() => '');
            throw new Error(`/api/setup/complete returned ${setupResp.status()}: ${body.slice(0, 200)}`);
        }
        ok(`Finish clicked → /api/setup/complete HTTP ${setupResp.status()}.`);

        const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
        console.log(`\n${GRN}═══ WIZARD UI PASSED (${elapsed}s) ═══${OFF}`);
        process.exit(0);
    } catch (err) {
        const shotPath = await shoot(page, `fail-${stepName}`);
        fail(`Failed at: ${stepName}`);
        fail(err.message);
        if (shotPath) console.error(`  screenshot: ${shotPath}`);
        try {
            const html = await page.content();
            const htmlPath = path.join(SCREENSHOT_DIR, `${Date.now()}-fail-${stepName}.html`);
            fs.writeFileSync(htmlPath, html);
            console.error(`  page html: ${htmlPath}`);
        } catch {}
        const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
        console.error(`\n${RED}═══ WIZARD UI FAILED (${elapsed}s) ═══${OFF}`);
        process.exit(1);
    } finally {
        await browser.close();
    }
})();
