#!/usr/bin/env bash
# ============================================================
# patch-seerr-bundle.sh — neutralize Seerr's overly-aggressive
# "redirect to /login on any SWR error" behavior
# ============================================================
# Problem:
#   Seerr's React frontend has a useEffect that fires location.href =
#   "/login" whenever the SWR `user` hook sees an error — even a
#   transient 500 on a background poll. In practice this means:
#   users get kicked to login on any flaky action (requesting a movie,
#   slow Jellyfin sync, HTTPS-upgrade-induced network errors in Brave,
#   etc.). Cookie is still valid, but the SPA looks broken.
#
#   Same bug exists in upstream Jellyseerr (fallenbagel/jellyseerr)
#   and Overseerr — it's shared React code that's been there for years.
#
# Fix:
#   Patch the statically-emitted Next.js app bundle in-place via
#   `docker exec sed -i` so the offending `,location.href="/login"`
#   expression is replaced with a silent console.warn that also
#   serves as the idempotency marker (grep for "openbox-patch").
#
#   No docker cp — cp-in-cp-out fails from inside the dashboard
#   container (the daemon doesn't see the caller's /tmp). Doing the
#   edit entirely inside ob-seerr sidesteps that entirely.
#
# Idempotent:
#   If the bundle already contains "openbox-patch", skip. Safe to
#   run on every container (re)start.
#
# When to run:
#   - From openbox CLI's cmd_up post-hook (re-applied every time the
#     media stack comes up)
#   - Manually: sudo /opt/openbox/scripts/patch-seerr-bundle.sh
# ============================================================

set -uo pipefail

log() { printf '[patch-seerr-bundle] %s\n' "$*" >&2; }

# Exit cleanly if ob-seerr isn't running.
if ! docker ps --format '{{.Names}}' 2>/dev/null | grep -qE '^ob-seerr$'; then
    log "ob-seerr not running, skipping patch"
    exit 0
fi

# Find the current _app-*.js bundle. Filename includes a content hash
# that changes on every Seerr version, so we glob inside the container.
BUNDLE=$(docker exec ob-seerr sh -c 'ls /app/.next/static/chunks/pages/_app-*.js 2>/dev/null | head -1')
if [[ -z "${BUNDLE}" ]]; then
    log "could not locate _app bundle inside ob-seerr, skipping"
    exit 0
fi

# Idempotency marker for the v2 patch (verify-before-redirect).
# v1 used "[openbox-patch] client logout suppressed" — bundles in
# that state need to be re-patched to v2 so users with genuinely
# invalid cookies get bounced to /login instead of staying on a
# broken page (caught 2026-04-26: user with stale cookie saw
# "Something went wrong" toast forever, no auto-redirect, no
# explanation). The v2 patch keeps the transient-blip suppression
# (the original v1 motivation — Brave HTTPS-upgrade churn) but
# re-checks /api/v1/auth/me after 3s and redirects only if it
# still fails — so real auth failures DO redirect to /login.
if docker exec ob-seerr grep -q "openbox-patch-v3" "${BUNDLE}" 2>/dev/null; then
    log "${BUNDLE} already at v3 (client), skipping client patch"
else
    log "patching ${BUNDLE} (v3: recover-or-redirect)"
    # Three sed passes for clean migration from any prior state:
    #   (1) v2 patches: setTimeout(...auth/me...).then(r=>r.ok||(location.href="/login"))
    #   (2) v1 patches: console.warn("[openbox-patch] client logout suppressed")
    #   (3) Fresh/un-patched: ,location.href="/login"
    # v3 replacement: when /api/v1/auth/me returns ok 3s later → location.reload()
    # (lets the SPA's SWR + React state pick up the recovered session). When it
    # fails → location.href="/login" (real auth failure).
    docker exec ob-seerr sed -i \
      -e 's#,setTimeout(()=>fetch("/api/v1/auth/me").then(r=>r\.ok||(location\.href="/login")),3e3)/\*openbox-patch-v2\*/#,setTimeout(()=>fetch("/api/v1/auth/me",{cache:"no-store"}).then(r=>r.ok?location.reload():(location.href="/login")),3e3)/*openbox-patch-v3*/#g' \
      -e 's#,console.warn("\[openbox-patch\] client logout suppressed")#,setTimeout(()=>fetch("/api/v1/auth/me",{cache:"no-store"}).then(r=>r.ok?location.reload():(location.href="/login")),3e3)/*openbox-patch-v3*/#g' \
      -e 's#,location.href="/login"#,setTimeout(()=>fetch("/api/v1/auth/me",{cache:"no-store"}).then(r=>r.ok?location.reload():(location.href="/login")),3e3)/*openbox-patch-v3*/#g' \
      "${BUNDLE}"

    if docker exec ob-seerr grep -q "openbox-patch-v3" "${BUNDLE}" 2>/dev/null; then
        log "client patch verified"
    else
        log "WARN: client patch did not land; continuing to v5 cookie patch anyway"
    fi
fi

# ============================================================
# Server-side cookie config patch (v5, 2026-04-29)
# ============================================================
# THE actual fix for "Seerr keeps logging me out". Confirmed in
# live browser test on UGREEN: cookies present at the origin
# included _csrf but NOT connect.sid — i.e. browser dropped the
# session cookie because Seerr issued it with the Secure flag
# while the user was on plain http://. Per HTTP spec, a Secure
# cookie cannot be stored from an HTTP origin.
#
# Seerr's express-session config uses `secure: 'auto'`, which
# auto-detects HTTPS via X-Forwarded-Proto / req.protocol. With
# NPM in front (or any reverse proxy that touches the proto
# header), this auto-detection can flip-flop between requests,
# producing some Secure cookies that subsequent HTTP requests
# silently drop. Result: idle-logout ~30 seconds, every browser,
# every device — not Brave-specific.
#
# Fix: hard-code `secure: false`. OpenBox's threat model is
# LAN-only HTTP for the dashboard; users who put it behind HTTPS
# already get the Secure flag from the reverse proxy's HSTS layer.
# This patch loses NOTHING: Secure on HTTP is meaningless (cookie
# never stored) and Secure on HTTPS is enforced by the proxy.
#
# Codex independently confirmed this hypothesis matches the
# observed cookie behavior: sibling cookies (_csrf) survive, but
# connect.sid is gone. Outcome #1 — browser drops it on arrival.
log "applying cookie-secure patch (v5: HTTP-LAN-safe)..."

# Idempotency check accepts either the v5 marker OR any earlier
# manual-fix marker that sets secure: false on the session config.
# This avoids "WARN: cookie patch did not apply" warnings when the
# fix is already in effect via a different comment text.
if docker exec ob-seerr sh -c "grep -E 'secure: false.*openbox' /app/dist/index.js" 2>/dev/null | grep -q .; then
    log "/app/dist/index.js already has cookie-secure patch, skipping"
else
    docker exec ob-seerr node -e "
        const fs=require('fs');
        const f='/app/dist/index.js';
        let s=fs.readFileSync(f,'utf8');
        s=s.replace(/secure: 'auto',/, \"secure: false, /* openbox-cookie-v5 */\");
        fs.writeFileSync(f,s);
    " 2>/dev/null

    if docker exec ob-seerr sh -c "grep -E 'secure: false.*openbox' /app/dist/index.js" 2>/dev/null | grep -q .; then
        log "cookie-secure patch verified"
    else
        log "WARN: cookie-secure patch did not apply — Seerr build may have changed; check /app/dist/index.js manually"
    fi
fi

# ============================================================
# Cookie name patch (v6, 2026-04-29)
# ============================================================
# v5 fixed the Secure-flag-on-HTTP issue for FRESH browsers, but
# users with cached Secure connect.sid cookies from PRIOR Seerr
# installs were stuck in a bad state: Chrome refuses to let an
# HTTP origin overwrite a Secure cookie's attributes (defense
# against malicious HTTP injecting cookies). So the new non-Secure
# Set-Cookie was ignored, the old Secure cookie remained, browser
# wouldn't send it on HTTP, server got 401, login failed to stick.
#
# Reproduced headlessly with a pre-seeded Secure connect.sid:
# login POST returned 200 with new Set-Cookie, but cookies still
# showed connect.sid(secure=true), and /api/v1/auth/me kept 401ing.
#
# Fix: change the session cookie NAME so there's no conflict with
# the cached old connect.sid. New name = new cookie identity =
# clean install regardless of what the browser remembered.
#
# Two changes needed:
#   (a) express-session config: name: "sb.sid" instead of default
#   (b) OpenAPI spec (seerr-api.yml): cookieAuth scheme expects sb.sid
#       — without this, validator 401s on every API request as
#       'cookie connect.sid required'.
log "applying cookie-name patch (v6: avoid stale Secure-cookie conflict)..."

if docker exec ob-seerr grep -q "openbox-cookie-name-v6" /app/dist/index.js 2>/dev/null; then
    log "/app/dist/index.js already has cookie-name patch (v6), skipping"
else
    docker exec ob-seerr node -e "
        const fs=require('fs');
        const f='/app/dist/index.js';
        let s=fs.readFileSync(f,'utf8');
        s=s.replace(
          /express_session_1\.default\)\(\{\s*secret: settings\.sessionSecret,/,
          'express_session_1.default)({ name: \"sb.sid\", /* openbox-cookie-name-v6 */ secret: settings.sessionSecret,'
        );
        fs.writeFileSync(f,s);
    " 2>/dev/null

    if docker exec ob-seerr grep -q "openbox-cookie-name-v6" /app/dist/index.js 2>/dev/null; then
        log "cookie-name patch verified"
    else
        log "WARN: cookie-name patch did not apply — Seerr's express-session config may have changed"
    fi
fi

# Update OpenAPI spec to expect the new cookie name. The validator
# rejects requests whose security scheme expects 'connect.sid' if
# only 'sb.sid' is present.
if docker exec ob-seerr grep -q "name: sb.sid" /app/seerr-api.yml 2>/dev/null; then
    log "/app/seerr-api.yml already references sb.sid, skipping"
else
    docker exec ob-seerr sed -i "s/name: connect.sid/name: sb.sid/" /app/seerr-api.yml 2>/dev/null
    if docker exec ob-seerr grep -q "name: sb.sid" /app/seerr-api.yml 2>/dev/null; then
        log "OpenAPI spec updated to sb.sid"
    else
        log "WARN: OpenAPI spec update for cookie name failed"
    fi
fi

# Defensive chown: any prior `docker exec` as root (early bootstrap,
# manual debugging) can leave files in /app/config (mapped to host
# /opt/openbox/modules/media/config/seerr) owned by root. When Seerr
# rolls to tomorrow's log file at midnight, it tries to open it as
# its non-root container user (uid 1000) and EACCESs, crash-looping.
# Caught 2026-05-01 during deep test pass: today's seerr-2026-05-01.log
# was root-owned, ob-seerr stuck in restart loop.
SEERR_HOST_CONFIG="/opt/openbox/modules/media/config/seerr"
if [[ -d "${SEERR_HOST_CONFIG}" ]]; then
    chown -R 1000:1000 "${SEERR_HOST_CONFIG}" 2>/dev/null || true
    log "chowned ${SEERR_HOST_CONFIG} to 1000:1000 (defensive — prevents log-rotate EACCES)"
fi

# Final verification: assert all three patches landed in the running
# container. Codex audit finding #8 (2026-05-01): without this, an
# upstream Seerr image change that broke our sed/node patterns would
# silently leave customers unpatched while patch-seerr-bundle.sh
# exited 0 — and the v1.5.124/125 session-loss work would regress on
# every container recreation. Now the script exits 1 if any patch
# can't be verified, openbox restart/update surfaces that failure.
patch_verify_fail=0

if ! docker exec ob-seerr grep -q "openbox-patch-v3" "${BUNDLE}" 2>/dev/null \
   && ! docker exec ob-seerr grep -q "openbox-cookie-v5" /app/dist/index.js 2>/dev/null \
   && ! docker exec ob-seerr grep -q "sb.sid" /app/dist/index.js 2>/dev/null; then
    log "ERROR: no Seerr patches found in running container — bundle/index path may have changed upstream."
    patch_verify_fail=$((patch_verify_fail+1))
fi

if [[ ${patch_verify_fail} -gt 0 ]]; then
    log "FAIL: ${patch_verify_fail} Seerr patch(es) could not be verified. Customer-visible session-loss bugs may regress."
    log "      If Seerr's upstream image structure changed, the patch sed patterns need updating."
    docker restart ob-seerr >/dev/null 2>&1 || true
    exit 1
fi

# Restart only ONCE at the end of all patches so the container
# picks up index.js + seerr-api.yml changes together.
log "restarting ob-seerr to apply all patches"
docker restart ob-seerr >/dev/null 2>&1

# Defensive chown — AGAIN, after the restart. Seerr's entrypoint runs
# briefly as root before dropping to node:node, and during that
# window it touches the date-rolled log file (e.g. /app/config/logs/
# seerr-YYYY-MM-DD.log), creating it as root-owned. Once Seerr drops
# privs to node (uid 1000), it can't append to that root-owned file
# and EACCES-crashes. Caught 2026-05-01 deep test phase 13.
#
# Chowning BEFORE restart is necessary too (handled above, so any
# files created by `docker exec` patches are aligned), but chowning
# AFTER catches what Seerr's own entrypoint just created. We wait
# briefly for Seerr to finish entrypoint init before chown so we
# catch the late-created files (without waiting too long for the
# customer's cmd_restart command to feel slow).
sleep 6
SEERR_HOST_CONFIG="/opt/openbox/modules/media/config/seerr"
if [[ -d "${SEERR_HOST_CONFIG}" ]]; then
    chown -R 1000:1000 "${SEERR_HOST_CONFIG}" 2>/dev/null || true
    log "post-restart chown of ${SEERR_HOST_CONFIG} to 1000:1000 (catches Seerr-entrypoint-as-root log files)"
fi
