﻿// OpenBox Heavy-App First-Boot QA.
//
// Data-bearing apps (nextcloud, immich, jellyfin) go through a
// multi-stage boot sequence that's slower than simple single-container
// apps: dependencies come up first (DB, redis, ML), then the main
// service initializes its schema/config, then its HTTP server binds
// a port, then a first-run UI appears. Each stage can take 30-120s.
//
// This script enables each heavy app in turn, waits for the main
// container to be running AND for the HTTP port to respond, then
// Playwright-visits the URL and asserts the expected first-run copy
// ("Create an admin account", "Welcome to Jellyfin", etc). Screenshots
// on both pass and fail so you can eyeball the first-run UX before
// recording your launch video.
//
// Each test takes 2-4 minutes because we wait patiently for the app
// to actually be ready — rushing this is how "the container says
// healthy but the UI is still initializing" bugs hide.
//
// Usage:
//   NODE_PATH=/tmp/ob-qa-deps/node_modules \
//   OPENBOX_IP=<your-test-host> \
//   SB_DASHBOARD_PASSWORD=test-password-12345 \
//   node scripts/browser-heavy-apps.js

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const IP = process.env.OPENBOX_IP || '192.168.0.17';
const DASHBOARD_PORT = parseInt(process.env.OPENBOX_PORT || '8443', 10);
const DASHBOARD_BASE = `http://${IP}:${DASHBOARD_PORT}`;
const PASSWORD = process.env.SB_DASHBOARD_PASSWORD || 'test-password-12345';
const OUT_DIR = path.join(__dirname, '..', 'browser-heavy-screenshots', IP.replace(/\./g, '-'));
fs.mkdirSync(OUT_DIR, { recursive: true });

const APPS = [
  {
    id: 'cloud',
    friendlyName: 'Nextcloud',
    mainContainer: 'ob-nextcloud',
    // Nextcloud compose maps host:8445 → container:443, meaning the
    // host port speaks HTTPS. ignoreHTTPSErrors in the context lets
    // Playwright through the self-signed cert.
    url: `https://${IP}:8445`,
    signatures: ['Nextcloud', 'Create an admin account', 'Username', 'nextcloud'],
    containerTimeout: 180_000,
    httpTimeout: 180_000,
  },
  {
    id: 'immich',
    friendlyName: 'Immich',
    mainContainer: 'ob-immich-server',
    url: `http://${IP}:2283`,
    signatures: ['Immich', 'Sign Up', 'admin', 'immich'],
    containerTimeout: 180_000,
    httpTimeout: 180_000,
  },
  {
    id: 'jellyfin',
    friendlyName: 'Jellyfin',
    mainContainer: 'ob-jellyfin',
    url: `http://${IP}:8097`,
    signatures: ['Jellyfin', 'Welcome', 'Select your preferred display language', 'jellyfin'],
    containerTimeout: 180_000,
    httpTimeout: 180_000,
  },
];

const results = [];
function record(name, status, detail) {
  results.push({ name, status, detail: detail || null });
  const icon = status === 'pass' ? '✓' : status === 'fail' ? '✗' : '…';
  const color = status === 'pass' ? '\x1b[32m' : status === 'fail' ? '\x1b[31m' : '\x1b[33m';
  console.log(`${color}${icon}\x1b[0m ${name}${detail ? ' — ' + detail : ''}`);
}

async function snap(page, label) {
  const safe = label.replace(/[^a-z0-9]+/gi, '_').toLowerCase();
  await page.screenshot({ path: path.join(OUT_DIR, `${safe}.png`), fullPage: true }).catch(() => {});
}

async function csrfHeader(context) {
  const cookies = await context.cookies(DASHBOARD_BASE);
  const csrf = cookies.find(c => c.name === '_csrf');
  return csrf ? { 'X-CSRF-Token': csrf.value } : {};
}
async function apiGet(context, p) {
  const resp = await context.request.get(`${DASHBOARD_BASE}${p}`);
  if (!resp.ok()) throw new Error(`GET ${p} → HTTP ${resp.status()}`);
  return resp.json();
}
async function apiPost(context, p, body) {
  const resp = await context.request.post(`${DASHBOARD_BASE}${p}`, {
    data: body,
    headers: { 'Content-Type': 'application/json', ...(await csrfHeader(context)) },
  });
  return { status: resp.status(), body: await resp.json().catch(() => ({})) };
}

async function listContainers(context) {
  const body = await apiGet(context, '/api/containers');
  return Array.isArray(body) ? body : (body.containers || []);
}

async function waitForContainer(context, containerName, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const arr = await listContainers(context);
      const found = arr.find(c => (c.name || c.Name || '').includes(containerName));
      if (found && (found.state === 'running' || found.State === 'running')) return found;
    } catch {}
    await new Promise(r => setTimeout(r, 4000));
  }
  return null;
}

async function waitForHttp(context, url, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let lastStatus = null;
  while (Date.now() < deadline) {
    try {
      const resp = await context.request.get(url, { timeout: 8000, ignoreHTTPSErrors: true });
      lastStatus = resp.status();
      // Anything under 500 means the server is responding, even a 302
      // redirect to /setup or similar counts as "first-boot UI is ready"
      if (lastStatus < 500) return lastStatus;
    } catch {}
    await new Promise(r => setTimeout(r, 4000));
  }
  return null;
}

(async () => {
  console.log(`\nOpenBox Heavy-App QA: ${DASHBOARD_BASE}`);
  console.log(`Each app can take 2-4 minutes. Be patient.\n`);

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    ignoreHTTPSErrors: true,
    viewport: { width: 1440, height: 900 },
  });
  const page = await context.newPage();

  try {
    // Login
    await page.goto(DASHBOARD_BASE, { waitUntil: 'domcontentloaded', timeout: 15000 });
    await page.waitForSelector('#login-screen:not(.hidden)', { timeout: 10000 });
    await page.fill('#login-password', PASSWORD);
    await page.click('#login-btn');
    await page.waitForSelector('#dashboard:not(.hidden)', { timeout: 10000 });
    await apiPost(context, '/api/wizard/skip', {}).catch(() => {});
    record('login', 'pass');

    for (const app of APPS) {
      const startTime = Date.now();
      console.log(`\n── ${app.friendlyName} (${app.id}) ──────────────`);
      console.log(`   URL: ${app.url}`);

      // 1. Enable
      try {
        const enableResp = await apiPost(context, `/api/modules/${app.id}/enable`, {});
        if (enableResp.status !== 200) throw new Error(`enable → ${enableResp.status}: ${JSON.stringify(enableResp.body)}`);
        record(`${app.friendlyName}: enable`, 'pass');
      } catch (e) {
        record(`${app.friendlyName}: enable`, 'fail', e.message.substring(0, 250));
        continue;
      }

      // 2. Wait for the main container
      console.log(`   waiting for ${app.mainContainer}…`);
      const container = await waitForContainer(context, app.mainContainer, app.containerTimeout);
      if (!container) {
        record(`${app.friendlyName}: container running`, 'fail', `${app.mainContainer} not running within ${app.containerTimeout/1000}s`);
        await apiPost(context, `/api/modules/${app.id}/disable`, {}).catch(() => {});
        continue;
      }
      record(`${app.friendlyName}: container running`, 'pass', container.name || container.Name);

      // 3. Wait for HTTP port
      console.log(`   waiting for HTTP at ${app.url}…`);
      const httpStatus = await waitForHttp(context, app.url, app.httpTimeout);
      if (httpStatus === null) {
        record(`${app.friendlyName}: http reachable`, 'fail', `no response within ${app.httpTimeout/1000}s`);
        await apiPost(context, `/api/modules/${app.id}/disable`, {}).catch(() => {});
        continue;
      }
      record(`${app.friendlyName}: http reachable`, 'pass', `HTTP ${httpStatus}`);

      // 4. Playwright-visit the real URL and look for first-run signatures
      try {
        await page.goto(app.url, { waitUntil: 'domcontentloaded', timeout: app.httpTimeout });
        // Let any JS-rendered first-run UI populate
        await page.waitForTimeout(5000);
        const title = (await page.title().catch(() => '')) || '';
        const html = await page.content();
        const bodyText = await page.evaluate(() => document.body?.innerText || '').catch(() => '');
        const haystack = `${title}\n${html}\n${bodyText}`.toLowerCase();
        const hit = app.signatures.find(s => haystack.includes(s.toLowerCase()));
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        if (!hit) {
          await snap(page, `${app.id}-no-match`);
          record(`${app.friendlyName}: first-run UI`, 'fail',
            `no signature matched (title="${title.substring(0,80)}"), ${elapsed}s total`);
        } else {
          await snap(page, `${app.id}-first-run`);
          record(`${app.friendlyName}: first-run UI`, 'pass',
            `matched "${hit}", title="${title.substring(0,80)}", ${elapsed}s total`);
        }
      } catch (e) {
        await snap(page, `${app.id}-load-fail`);
        record(`${app.friendlyName}: first-run UI`, 'fail', e.message.substring(0, 200));
      }

      // 5. Disable (free up resources before the next heavy app)
      try {
        await apiPost(context, `/api/modules/${app.id}/disable`, {});
        record(`${app.friendlyName}: disable`, 'pass');
      } catch (e) {
        record(`${app.friendlyName}: disable`, 'fail', e.message.substring(0, 150));
      }
    }

    await page.close();
    await browser.close();
  } catch (e) {
    console.error('Fatal:', e.message);
    record('fatal', 'fail', e.message);
    await browser.close().catch(() => {});
  }

  const passed = results.filter(r => r.status === 'pass').length;
  const failed = results.filter(r => r.status === 'fail').length;

  fs.writeFileSync(path.join(OUT_DIR, 'results.json'), JSON.stringify({
    target: DASHBOARD_BASE,
    timestamp: new Date().toISOString(),
    passed, failed, results,
  }, null, 2));

  console.log(`\n${'='.repeat(44)}`);
  console.log(`  ${DASHBOARD_BASE}`);
  console.log(`  passed: ${passed}`);
  console.log(`  failed: ${failed}`);
  console.log(`  output: ${OUT_DIR}`);
  console.log('='.repeat(44));

  process.exit(failed > 0 ? 1 : 0);
})();
