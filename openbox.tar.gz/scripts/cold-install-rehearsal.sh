﻿#!/usr/bin/env bash
# scripts/cold-install-rehearsal.sh
#
# End-to-end automated test of a fresh OpenBox install. Wipes the
# target NAS, runs install.sh, claims bootstrap, activates license,
# saves VPN settings, enables Media, then verifies every container
# is healthy and the v1.5.110 settings-recreate fix actually works.
#
# Catches "stale state survives configuration change" bugs (gluetun
# stale-env, post-restart container survival, etc.) that manual
# testing misses because order-of-operations varies each time.
#
# Run from the dev workstation. SSHs into the target. Reads secrets
# from a local config file (NOT committed).
#
# Usage:
#   scripts/cold-install-rehearsal.sh [--config ~/.openbox-rehearsal.env]
#
# Required config (see scripts/cold-install-rehearsal.env.example):
#   TARGET_HOST            target NAS IP/hostname
#   TARGET_USER            SSH user
#   TARGET_SSH_KEY         path to SSH private key
#   DASHBOARD_URL          e.g. https://192.168.0.17:8444 (uses self-signed cert)
#   ADMIN_PASSWORD         password to set on first-run claim
#   LICENSE_KEY            license key for activation
#   PURCHASE_EMAIL         email for license activation
#   VPN_PROVIDER           e.g. surfshark
#   VPN_TYPE               e.g. wireguard
#   WIREGUARD_PRIVATE_KEY  WG private key
#   WIREGUARD_ADDRESSES    e.g. 10.14.0.2/16
#   SERVER_COUNTRIES       e.g. "United States"
#
# Exit code: 0 on full pass, 1 on any failure (with diagnostic dump).

set -uo pipefail

# --- paint ---
RED=$'\e[31m'; GRN=$'\e[32m'; YLW=$'\e[33m'; BLU=$'\e[34m'; DIM=$'\e[2m'; OFF=$'\e[0m'
say() { printf '%s\n' "$*"; }
step() { printf '\n%s▶%s %s\n' "$BLU" "$OFF" "$*"; }
ok()   { printf '%s✓%s %s\n' "$GRN" "$OFF" "$*"; }
warn() { printf '%s!%s %s\n' "$YLW" "$OFF" "$*"; }
fail() { printf '%s✗%s %s\n' "$RED" "$OFF" "$*" >&2; }

REHEARSAL_START=$(date +%s)
FAILED_STEP=""

# --- config load ---
CONFIG_FILE="${HOME}/.openbox-rehearsal.env"
USE_UI=0
SKIP_DEV_SCRIPT=0
WITH_MODULES=0
while [[ $# -gt 0 ]]; do
    case "$1" in
        --config) CONFIG_FILE="$2"; shift 2 ;;
        --ui) USE_UI=1; shift ;;
        --released) SKIP_DEV_SCRIPT=1; shift ;;
        --with-modules) WITH_MODULES=1; shift ;;
        -h|--help) sed -n '2,30p' "$0"; exit 0 ;;
        *) fail "Unknown arg: $1"; exit 2 ;;
    esac
done

if [[ ! -f "$CONFIG_FILE" ]]; then
    fail "Config not found: $CONFIG_FILE"
    fail "Copy scripts/cold-install-rehearsal.env.example to $CONFIG_FILE and fill in secrets."
    exit 2
fi
# shellcheck disable=SC1090
set -a; . "$CONFIG_FILE"; set +a

for v in TARGET_HOST TARGET_USER TARGET_SSH_KEY DASHBOARD_URL ADMIN_PASSWORD \
         LICENSE_KEY PURCHASE_EMAIL VPN_PROVIDER VPN_TYPE \
         WIREGUARD_PRIVATE_KEY WIREGUARD_ADDRESSES SERVER_COUNTRIES; do
    if [[ -z "${!v:-}" ]]; then
        fail "Missing config var: $v (set it in $CONFIG_FILE)"
        exit 2
    fi
done

# REHEARSAL_INSTALL_ID is the stable install ID used across every
# rehearsal run. Reusing it is critical: the license worker's daily
# activation cap (3 NEW installIds per key per 24h) would block looping
# rehearsals after the third wipe. By forcing a known installId before
# /api/license/activate hits the worker, every call after the first one
# is recognized as the same already-activated install and bypasses both
# the daily cap and the slot-evict path. Loses one slot of the 3-slot
# license to "the rehearsal rig" permanently. That's fine; pick a UUID
# you'll never use for a real install.
REHEARSAL_INSTALL_ID="${REHEARSAL_INSTALL_ID:-rehearsal-rig-ugreen-nas-do-not-use-on-prod}"

SSH="ssh -i ${TARGET_SSH_KEY} -o StrictHostKeyChecking=no -o ConnectTimeout=10 ${TARGET_USER}@${TARGET_HOST}"
COOKIES=$(mktemp)
trap 'rm -f "$COOKIES"' EXIT

# Curl wrapper: cookie-jar + insecure (self-signed cert) + reasonable timeout.
ccurl() {
    curl --cookie-jar "$COOKIES" --cookie "$COOKIES" \
         --insecure --silent --show-error \
         --max-time 30 "$@"
}

# Read CSRF token from cookie jar (set by /api/login on success).
csrf() {
    awk '/_csrf/ {print $7}' "$COOKIES" | tail -1
}

# json field extractor — small enough that we don't need jq.
jget() {
    python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('$1',''))" 2>/dev/null
}

# --- diagnostic dump (called on any failure) ---
dump_diag() {
    fail "Failed at: ${FAILED_STEP:-(unknown)}"
    echo
    echo "${YLW}--- docker ps on target ---${OFF}"
    $SSH 'sudo docker ps --filter "name=ob-" --format "table {{.Names}}\t{{.Status}}"' 2>&1 | head -25 || true
    echo
    echo "${YLW}--- last 30 lines of unhealthy container logs ---${OFF}"
    # shellcheck disable=SC2029
    $SSH 'for c in $(sudo docker ps -a --filter "name=ob-" --format "{{.Names}}\t{{.Status}}" | grep -vE "healthy|Up [0-9]+ (minutes|hours|days)" | cut -f1); do echo "=== $c ==="; sudo docker logs --tail 30 "$c" 2>&1 | tail -30; done' || true
    echo
    echo "${YLW}--- /opt/openbox/state/setup-apply.log tail ---${OFF}"
    $SSH 'sudo tail -30 /opt/openbox/state/setup-apply.log 2>/dev/null' || true
}

trap_fail() {
    dump_diag
    local elapsed=$(( $(date +%s) - REHEARSAL_START ))
    printf '\n%s═══ REHEARSAL FAILED (%ds) ═══%s\n' "$RED" "$elapsed" "$OFF"
    rm -f "$COOKIES"
    exit 1
}

# Wrap each step so the script exits with diagnostics on failure.
guard() {
    FAILED_STEP="$1"
    shift
    if ! "$@"; then
        trap_fail
    fi
    FAILED_STEP=""
}

# Wait for a predicate to become true. predicate is a bash function name.
# Args: <description> <timeout-secs> <predicate-fn>
wait_for() {
    local desc="$1" timeout="$2" pred="$3"
    local start=$(date +%s)
    while ! $pred; do
        if (( $(date +%s) - start > timeout )); then
            fail "Timeout (${timeout}s) waiting for: $desc"
            return 1
        fi
        sleep 3
    done
    return 0
}

# ============================================================
# STEP 1 — wipe target
# ============================================================
do_wipe() {
    step "Wipe target ${TARGET_HOST}"
    if ! $SSH 'sudo test -x /opt/openbox/openbox' 2>/dev/null; then
        warn "No existing OpenBox install at /opt/openbox — skipping wipe."
        return 0
    fi
    # shellcheck disable=SC2029
    if $SSH 'sudo /opt/openbox/openbox reset --nuke --yes' >/dev/null 2>&1; then
        ok "Target wiped."
    else
        fail "Wipe failed."
        return 1
    fi
}

# ============================================================
# STEP 2 — fresh install
# ============================================================
do_install() {
    step "Run install.sh on target"
    # shellcheck disable=SC2029
    if $SSH 'curl -fsSL https://get.crushcodeworks.com/install.sh | sudo bash' >/tmp/ob-install.log 2>&1; then
        ok "Install completed."
        return 0
    else
        fail "Install failed. Last 30 lines:"
        tail -30 /tmp/ob-install.log >&2
        return 1
    fi
}

# ============================================================
# STEP 2.5 — pin SB_INSTALL_ID to the rehearsal rig's stable value
# ============================================================
# install.sh wrote a fresh random UUID. Replace it with our stable
# rehearsal ID so /api/license/activate never registers as a "new
# install" against the worker (avoids hitting 3-new-activations-per-day
# cap on rehearsal loops). Then recreate ob-dashboard so it picks up
# the new env at startup (process.env.SB_INSTALL_ID is cached in-process
# from the moment the container booted).
do_pin_install_id() {
    step "Pin SB_INSTALL_ID to rehearsal rig value"
    # Also override the on-disk openbox script with our local repo's
    # version BEFORE setup-complete fires its openbox up. Otherwise
    # we're testing whatever's bundled in the released install tarball,
    # not the in-development fix. Seed state/.env-hash too so the
    # v1.5.110 hash-and-force-recreate logic has a baseline to compare
    # against (without this, the FIRST openbox up call sees no prior
    # hash and skips the recreate even if .env values changed since
    # install).
    local local_openbox
    local_openbox="$(dirname "$(dirname "$(realpath "$0")")")/openbox"
    if [[ ${SKIP_DEV_SCRIPT} -eq 1 ]]; then
        warn "--released flag set: testing the R2-published bundle as-is."
        # Still seed env-hash so v1.5.110+ logic engages.
        $SSH 'sudo sha256sum /opt/openbox/.env | cut -d" " -f1 | sudo tee /opt/openbox/state/.env-hash >/dev/null && sudo chmod 600 /opt/openbox/state/.env-hash' >/dev/null
        ok "Dev-script override skipped; .env-hash seeded against released bundle."
    elif [[ -f "$local_openbox" ]]; then
        if ! ssh -i "${TARGET_SSH_KEY}" -o StrictHostKeyChecking=no "${TARGET_USER}@${TARGET_HOST}" 'cat > /tmp/openbox.dev' < "$local_openbox"; then
            fail "Could not stage local openbox script."
            return 1
        fi
        if ! $SSH 'sudo install -m 755 -o root -g root /tmp/openbox.dev /opt/openbox/openbox && rm -f /tmp/openbox.dev'; then
            fail "Could not install local openbox script over /opt/openbox/openbox."
            return 1
        fi
        # Enable debug logging in openbox + seed env hash from current
        # .env so v1.5.110 logic engages on the next openbox up triggered
        # by setup-complete. The env file lives inside the dashboard
        # container at /app/.env (bind-mounted from host /opt/openbox/.env),
        # so we set SB_DEBUG_ENV=1 in compose's env block — but to keep
        # changes contained to rehearsal mode, set it via .env so dashboard
        # forwards it as part of its already-existing var passthrough.
        $SSH 'sudo sha256sum /opt/openbox/.env | cut -d" " -f1 | sudo tee /opt/openbox/state/.env-hash >/dev/null && sudo chmod 600 /opt/openbox/state/.env-hash' >/dev/null
        ok "Local openbox v$(awk 'NR==1{print}' "$(dirname "$local_openbox")/VERSION") deployed + .env-hash seeded."

        # Also push local modules/ and scripts/ trees so the rehearsal
        # tests in-flight changes to compose files / arr-bootstrap.sh /
        # etc., not whatever's pinned in the latest R2 bundle. Without
        # this, edits to non-CLI files would only get exercised after
        # release.sh upload, defeating the "validate before ship" loop.
        # Tar-pipe over ssh — version-independent (rsync 3.4 protected-
        # args breaks --rsync-path=sudo rsync against /opt/openbox/).
        local repo_root
        repo_root="$(dirname "$(dirname "$(realpath "$0")")")"
        if tar -C "${repo_root}" -cf - modules scripts \
            | ssh -i "${TARGET_SSH_KEY}" -o StrictHostKeyChecking=no "${TARGET_USER}@${TARGET_HOST}" \
                'sudo tar -C /opt/openbox -xf -' 2>/dev/null; then
            ok "Local modules/ + scripts/ pushed to /opt/openbox/."
        else
            warn "Push of local modules/ + scripts/ failed; rehearsal may be testing R2-pinned versions for those files"
        fi
    else
        warn "Local openbox script not found at ${local_openbox} — testing released bundle."
    fi

    # install.sh does NOT pre-seed SB_INSTALL_ID in .env — the dashboard
    # generates it lazily on the first /api/license/activate call. So we
    # have to handle two cases:
    #   (a) line already exists → sed-replace in place
    #   (b) line missing        → append
    # shellcheck disable=SC2029
    if ! $SSH "if sudo grep -q '^SB_INSTALL_ID=' /opt/openbox/.env; then
                   sudo sed -i 's|^SB_INSTALL_ID=.*|SB_INSTALL_ID=${REHEARSAL_INSTALL_ID}|' /opt/openbox/.env
               else
                   echo 'SB_INSTALL_ID=${REHEARSAL_INSTALL_ID}' | sudo tee -a /opt/openbox/.env >/dev/null
               fi
               # Also flip on SB_DEBUG_ENV so the detached openbox up
               # spawned by /api/setup/complete prints what it sees in
               # .env at compose-time. Critical for diagnosing why
               # gluetun gets created with empty env even though .env
               # has VPN values.
               if ! sudo grep -q '^SB_DEBUG_ENV=' /opt/openbox/.env; then
                   echo 'SB_DEBUG_ENV=1' | sudo tee -a /opt/openbox/.env >/dev/null
               fi"; then
        fail "Could not write SB_INSTALL_ID/SB_DEBUG_ENV to /opt/openbox/.env"
        return 1
    fi
    local actual
    actual=$($SSH 'sudo grep "^SB_INSTALL_ID=" /opt/openbox/.env | cut -d= -f2-' 2>/dev/null)
    if [[ "$actual" != "$REHEARSAL_INSTALL_ID" ]]; then
        fail "SB_INSTALL_ID after rewrite: '$actual' (expected '$REHEARSAL_INSTALL_ID')"
        return 1
    fi
    # Force-recreate ob-dashboard so process.env.SB_INSTALL_ID picks up
    # the new value. `docker restart` would preserve the original env.
    # shellcheck disable=SC2029
    if ! $SSH 'sudo docker compose --env-file /opt/openbox/.env -p openbox -f /opt/openbox/modules/dashboard/docker-compose.yml up -d --force-recreate openbox-dashboard' >/tmp/ob-rh-dashre.log 2>&1; then
        fail "docker compose force-recreate ob-dashboard failed:"
        tail -10 /tmp/ob-rh-dashre.log >&2
        return 1
    fi
    ok "SB_INSTALL_ID pinned + dashboard recreated."
}

# ============================================================
# STEP 3 — read bootstrap token + wait for dashboard
# ============================================================
do_read_bootstrap() {
    step "Read bootstrap token + wait for dashboard"
    BOOTSTRAP_TOKEN=$($SSH 'sudo grep ^OB_BOOTSTRAP_TOKEN= /opt/openbox/.env' 2>/dev/null | cut -d= -f2)
    if [[ -z "$BOOTSTRAP_TOKEN" ]]; then
        fail "Could not read OB_BOOTSTRAP_TOKEN from .env (already claimed?)"
        return 1
    fi
    ok "Bootstrap token: ${BOOTSTRAP_TOKEN:0:6}…"

    dashboard_up() {
        local code
        code=$(ccurl --max-time 5 -o /dev/null -w '%{http_code}' "${DASHBOARD_URL}/login" 2>/dev/null || echo 000)
        [[ "$code" == "200" ]]
    }
    if wait_for "dashboard /login" 60 dashboard_up; then
        ok "Dashboard reachable at ${DASHBOARD_URL}"
    else
        return 1
    fi
    # Also wait until /api/auth/status reports firstRun:true. Without
    # this gate, the loop sometimes hands off to Playwright while the
    # SPA's checkAuth() is still in-flight and falls into the wrong
    # branch (showLogin instead of showFirstRun), leaving the bootstrap
    # token field hidden forever. Caught by 2026-04-25 loop run #2.
    auth_first_run_ready() {
        local body
        body=$(curl --silent --max-time 5 "${DASHBOARD_URL}/api/auth/status" 2>/dev/null)
        [[ "$body" == *'"firstRun":true'* ]]
    }
    if wait_for "first-run state on /api/auth/status" 30 auth_first_run_ready; then
        ok "Dashboard reports first-run state."
    else
        return 1
    fi
}

# ============================================================
# STEP 4 — claim admin password (first-run /api/login)
# ============================================================
do_claim() {
    step "Claim admin password via /api/login"
    rm -f "$COOKIES"; touch "$COOKIES"
    local resp
    resp=$(ccurl -X POST "${DASHBOARD_URL}/api/login" \
        -H 'Content-Type: application/json' \
        -d "{\"bootstrapToken\":\"${BOOTSTRAP_TOKEN}\",\"password\":\"${ADMIN_PASSWORD}\"}")
    local success; success=$(printf '%s' "$resp" | jget success)
    if [[ "$success" != "True" && "$success" != "true" ]]; then
        fail "Claim failed: $resp"
        return 1
    fi
    if [[ -z "$(csrf)" ]]; then
        fail "Claim succeeded but no _csrf cookie set."
        return 1
    fi
    ok "Admin claimed; CSRF token acquired."
}

# ============================================================
# STEP 5 — activate license
# ============================================================
do_activate_license() {
    step "Activate license"
    local resp http
    http=$(ccurl -o /tmp/ob-rh-license.json -w '%{http_code}' \
        -X POST "${DASHBOARD_URL}/api/license/activate" \
        -H 'Content-Type: application/json' \
        -H "X-CSRF-Token: $(csrf)" \
        -d "{\"key\":\"${LICENSE_KEY}\",\"purchaseEmail\":\"${PURCHASE_EMAIL}\"}")
    resp=$(cat /tmp/ob-rh-license.json 2>/dev/null)
    if [[ "$http" != "200" ]]; then
        if printf '%s' "$resp" | grep -qiE 'rate.?limit|too many'; then
            fail "License activation rate-limited."
            fail "  → Either wait until midnight UTC, or clear KV: wrangler kv key delete \"validate-ip::<your-ip>::$(date -u +%F)\" --namespace-id=<id>"
            fail "  → For activation cap, clear: wrangler kv key delete \"activations:${LICENSE_KEY}\" --namespace-id=<id>"
        else
            fail "License activation HTTP $http: $resp"
        fi
        return 1
    fi
    ok "License activated."
}

# ============================================================
# STEP 6 — finalize wizard with profile=media + VPN credentials
# ============================================================
# Uses /api/setup/complete's built-in VPN fields so we exercise the
# canonical wizard happy path: choose Media profile, paste WG creds,
# click finish. This is the flow most customers will follow.
# Saving VPN out-of-band via PUT /api/config and then enabling Media
# via /api/modules/batch races against setup-complete's detached
# openbox up (returns 409). Tracked separately.
do_setup_complete_media() {
    step "Finalize wizard (profile=media, VPN creds inline)"
    local payload
    payload=$(python3 -c "
import json
print(json.dumps({
    'domain': '${TARGET_HOST}',
    'timezone': 'America/Los_Angeles',
    'profile': 'media',
    'vpnProvider': '${VPN_PROVIDER}',
    'vpnType': '${VPN_TYPE}',
    'vpnWgKey': '${WIREGUARD_PRIVATE_KEY}',
    'vpnWgAddr': '${WIREGUARD_ADDRESSES}',
}))")
    local http
    http=$(ccurl -o /tmp/ob-rh-setup.json -w '%{http_code}' \
        -X POST "${DASHBOARD_URL}/api/setup/complete" \
        -H 'Content-Type: application/json' \
        -H "X-CSRF-Token: $(csrf)" \
        -d "$payload")
    if [[ "$http" != "200" ]]; then
        fail "POST /api/setup/complete HTTP $http: $(cat /tmp/ob-rh-setup.json 2>/dev/null)"
        return 1
    fi
    # Verify .env got VPN values + SERVER_COUNTRIES (we need that one set
    # outside the wizard since /api/setup/complete doesn't take it).
    local on_disk
    on_disk=$($SSH 'sudo grep -E "^WIREGUARD_PRIVATE_KEY|^VPN_PROVIDER" /opt/openbox/.env')
    if ! grep -qF "WIREGUARD_PRIVATE_KEY=${WIREGUARD_PRIVATE_KEY}" <<<"$on_disk"; then
        fail "WIREGUARD_PRIVATE_KEY not persisted to .env from wizard:"
        printf '%s\n' "$on_disk" >&2
        return 1
    fi
    # Wizard doesn't set SERVER_COUNTRIES (Surfshark/ProtonVPN need it).
    # Set it via PUT /api/config NOW, before openbox up creates gluetun.
    # If we set it after gluetun exists, v1.5.110's hash-and-recreate
    # logic will catch the diff and recreate — which is fine, just
    # slower. Set it now to keep the rehearsal fast.
    ccurl -X PUT "${DASHBOARD_URL}/api/config" \
        -H 'Content-Type: application/json' \
        -H "X-CSRF-Token: $(csrf)" \
        -d "{\"SERVER_COUNTRIES\":\"${SERVER_COUNTRIES}\"}" >/dev/null
    ok "Wizard finalized; VPN persisted; SERVER_COUNTRIES set."
}

# ============================================================
# STEP 7 — wait for the wizard's detached openbox up to release lock
# ============================================================
do_wait_for_lock_release() {
    step "Wait for wizard's openbox up to finish"
    lock_gone() {
        ! $SSH 'sudo test -f /opt/openbox/state/operation.lock' 2>/dev/null
    }
    if wait_for "operation.lock removal" 300 lock_gone; then
        ok "Operation lock released."
    else
        return 1
    fi
}

# ============================================================
# STEP 9 — wait for media containers healthy
# ============================================================
do_wait_media_healthy() {
    step "Wait for media stack to reach healthy"

    media_healthy() {
        local out
        out=$($SSH 'sudo docker ps --filter "name=ob-" --format "{{.Names}}\t{{.Status}}"' 2>/dev/null)
        # Required containers + health states.
        local required=(ob-gluetun ob-jellyfin-media ob-seerr ob-bazarr ob-qbittorrent ob-radarr ob-sonarr ob-prowlarr ob-deunhealth)
        for c in "${required[@]}"; do
            if ! grep -qE "^${c}\s" <<<"$out"; then
                return 1
            fi
            local status
            status=$(grep -E "^${c}\s" <<<"$out" | cut -f2)
            # Accept "healthy" or — for containers without a healthcheck — "Up <duration>" (no parens).
            if grep -qiE 'unhealthy|restarting|exited|created' <<<"$status"; then
                return 1
            fi
            if grep -qiE 'health: starting' <<<"$status"; then
                return 1
            fi
        done
        return 0
    }

    if wait_for "media stack healthy" 180 media_healthy; then
        ok "All media containers healthy."
    else
        return 1
    fi
}

# ============================================================
# STEP 10 — regression test for v1.5.110 (settings-change recreate)
# ============================================================
# ============================================================
# STEP — VPN actually routes through Surfshark (NOT customer's home IP)
# ============================================================
# "gluetun is healthy" only means the healthcheck binary returned 0,
# not that traffic is actually exiting through the VPN. A real
# customer test: pull our public IP from inside the gluetun container
# and confirm it's NOT the same as our home IP, AND confirm it's
# in a Surfshark-known range.
do_assert_vpn_routes() {
    step "Verify VPN tunnel actually routes (not home IP)"
    local home_ip
    home_ip=$(curl --silent --max-time 8 https://ifconfig.me 2>/dev/null | head -1)
    if [[ -z "$home_ip" ]]; then
        warn "Could not fetch our home public IP (ifconfig.me unreachable from workstation). Falling back to provider-name check only."
    fi
    # Primary IP source: gluetun's own /v1/publicip control endpoint.
    # Authoritative + no external rate-limit (we used to hit ipinfo.io
    # directly and got 429'd on rehearsal loops — see v1.5.105 + the
    # external-API-caching feedback memory).
    local tunnel_json
    tunnel_json=$($SSH 'sudo docker exec ob-gluetun wget -qO- --timeout=5 http://localhost:8000/v1/publicip/ip 2>/dev/null' 2>/dev/null)
    if [[ -z "$tunnel_json" ]]; then
        fail "Could not fetch tunnel IP from gluetun /v1/publicip."
        return 1
    fi
    local tunnel_ip tunnel_org
    tunnel_ip=$(printf '%s' "$tunnel_json" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('public_ip',''))" 2>/dev/null)
    tunnel_org=$(printf '%s' "$tunnel_json" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('organization',''))" 2>/dev/null)
    if [[ -z "$tunnel_ip" ]]; then
        fail "Tunnel IP fetch returned no usable JSON: $tunnel_json"
        return 1
    fi
    if [[ -n "$home_ip" && "$tunnel_ip" == "$home_ip" ]]; then
        fail "VPN LEAK: gluetun's public IP ($tunnel_ip) is the same as the home IP ($home_ip)."
        return 1
    fi
    # Org name should mention Surfshark for the surfshark provider, or
    # the chosen provider's known transit AS for others. Loose match.
    # Gluetun's /v1/publicip currently reports the upstream colo (e.g.
    # "Clouvider Limited" for Surfshark IAD nodes), so this check stays
    # warn-only — it's diagnostic, not a hard fail.
    if [[ "${VPN_PROVIDER,,}" == "surfshark" ]] && ! grep -qiE 'surfshark|m247|cmcs|clouvider|datacamp' <<<"$tunnel_org"; then
        warn "VPN tunnel IP $tunnel_ip org=\"$tunnel_org\" doesn't match a known Surfshark transit. Continuing — provider may have changed peering."
    fi
    ok "VPN routes through tunnel: $tunnel_ip ($tunnel_org)${home_ip:+, home was $home_ip}"
}

# ============================================================
# STEP — ARR stack is actually wired (Prowlarr+Sonarr+Radarr+qBit reachable)
# ============================================================
# Containers being healthy doesn't mean the chain is wired. Hit each
# service's /api/v3/system/status (or qBit's API auth) from inside the
# dashboard container so we exercise the same network path the dashboard
# uses to talk to them.
do_assert_arr_chain() {
    step "Verify ARR stack APIs respond"
    local fails=0
    # All *arr services share the gluetun network namespace; their HTTP
    # ports are exposed on host through gluetun's port maps. From the
    # workstation we hit the host ports directly.
    arr_check() {
        local name="$1" url="$2" expect="$3"
        local code
        code=$(curl --insecure --silent -o /dev/null -w '%{http_code}' --max-time 10 "$url" 2>/dev/null) || code=000
        code="${code:-000}"
        if [[ ",${expect}," == *",${code},"* ]]; then
            ok "  ${name} → HTTP ${code}"
        else
            fail "  ${name} → HTTP ${code} (expected ${expect})"
            fails=$((fails+1))
        fi
    }
    # All *arr endpoints return 401 without auth, which still proves the
    # service is up + listening. 200 from /ping is best when available.
    arr_check "Prowlarr ping"    "http://${TARGET_HOST}:8181/ping"          "200"
    arr_check "Sonarr API"       "http://${TARGET_HOST}:8989/api/v3/system/status" "200,401"
    arr_check "Radarr API"       "http://${TARGET_HOST}:7878/api/v3/system/status" "200,401"
    arr_check "qBit web UI"      "http://${TARGET_HOST}:8089"               "200"
    arr_check "Bazarr web"       "http://${TARGET_HOST}:6767"               "200,302"
    [[ $fails -eq 0 ]]
}

# ============================================================
# STEP — ARR chain is FUNCTIONALLY wired (not just "ports respond")
# ============================================================
# Containers responding ≠ chain working. arr-bootstrap.sh fires after
# media-stack-up to wire qBit as download client into Sonarr+Radarr,
# set library paths, and register Sonarr+Radarr as applications inside
# Prowlarr. No default indexers are seeded (Terms §6 compliance —
# customer-managed). This step waits for that bootstrap to complete
# and then asserts each link via API.
do_assert_arr_chain_functional() {
    step "Verify ARR chain is wired (not just ports)"

    # Wait for arr-bootstrap.sh's done-marker. It runs in background
    # post-`openbox up`; fresh installs take 30-90s for indexer seeding.
    arr_bootstrap_done() {
        $SSH 'sudo test -f /opt/openbox/state/arr-bootstrapped' 2>/dev/null
    }
    if ! wait_for "arr-bootstrap done-marker" 240 arr_bootstrap_done; then
        return 1
    fi
    ok "arr-bootstrap completed."

    # Pull API keys from state/arr-api-keys.json on the NAS.
    local keys_json
    keys_json=$($SSH 'sudo cat /opt/openbox/state/arr-api-keys.json' 2>/dev/null)
    if [[ -z "$keys_json" ]]; then
        fail "state/arr-api-keys.json missing or unreadable."
        return 1
    fi
    local sonarr_key radarr_key prowlarr_key
    sonarr_key=$(printf '%s' "$keys_json" | python3 -c "import sys,json; print(json.load(sys.stdin).get('sonarr',''))")
    radarr_key=$(printf '%s' "$keys_json" | python3 -c "import sys,json; print(json.load(sys.stdin).get('radarr',''))")
    prowlarr_key=$(printf '%s' "$keys_json" | python3 -c "import sys,json; print(json.load(sys.stdin).get('prowlarr',''))")
    if [[ -z "$sonarr_key" || -z "$radarr_key" || -z "$prowlarr_key" ]]; then
        fail "API key(s) missing from state/arr-api-keys.json: sonarr=${#sonarr_key}c radarr=${#radarr_key}c prowlarr=${#prowlarr_key}c"
        return 1
    fi
    ok "API keys retrieved (sonarr/radarr/prowlarr)."

    local fails=0
    # Helper: GET an authed endpoint, return body. Uses python to parse.
    arr_get() {
        local url="$1" key="$2"
        curl --silent --max-time 15 -H "X-Api-Key: ${key}" "$url" 2>/dev/null
    }
    arr_count() {
        local body="$1"
        printf '%s' "$body" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    print(len(d) if isinstance(d, list) else 0)
except Exception:
    print(0)
" 2>/dev/null
    }
    arr_match_field() {
        # arr_match_field <body> <field> <value>  → prints count of array
        # entries whose top-level <field> equals <value>.
        local body="$1" field="$2" value="$3"
        printf '%s' "$body" | python3 -c "
import sys, json
field, value = '$field', '$value'
try:
    d = json.load(sys.stdin)
    n = sum(1 for x in (d if isinstance(d, list) else []) if str(x.get(field, '')) == value)
    print(n)
except Exception:
    print(0)
" 2>/dev/null
    }

    # --- Sonarr: download client (qBit) + root folder (/data/media/TV) ---
    local body
    body=$(arr_get "http://${TARGET_HOST}:8989/api/v3/downloadclient" "$sonarr_key")
    local n=$(arr_match_field "$body" "implementation" "QBittorrent")
    if [[ "${n:-0}" -ge 1 ]]; then ok "  Sonarr: qBittorrent download client wired ($n)";
    else fail "  Sonarr: NO qBittorrent download client. (count=${n:-0}, body=${body:0:200})"; fails=$((fails+1)); fi

    body=$(arr_get "http://${TARGET_HOST}:8989/api/v3/rootfolder" "$sonarr_key")
    n=$(arr_match_field "$body" "path" "/data/media/TV")
    if [[ "${n:-0}" -ge 1 ]]; then ok "  Sonarr: /data/media/TV root folder set";
    else fail "  Sonarr: /data/media/TV root folder NOT set. (body=${body:0:200})"; fails=$((fails+1)); fi

    # --- Radarr: download client + root folder (/data/media/Movies) ---
    body=$(arr_get "http://${TARGET_HOST}:7878/api/v3/downloadclient" "$radarr_key")
    n=$(arr_match_field "$body" "implementation" "QBittorrent")
    if [[ "${n:-0}" -ge 1 ]]; then ok "  Radarr: qBittorrent download client wired ($n)";
    else fail "  Radarr: NO qBittorrent download client. (count=${n:-0})"; fails=$((fails+1)); fi

    body=$(arr_get "http://${TARGET_HOST}:7878/api/v3/rootfolder" "$radarr_key")
    n=$(arr_match_field "$body" "path" "/data/media/Movies")
    if [[ "${n:-0}" -ge 1 ]]; then ok "  Radarr: /data/media/Movies root folder set";
    else fail "  Radarr: /data/media/Movies root folder NOT set."; fails=$((fails+1)); fi

    # --- Prowlarr: Sonarr + Radarr registered as applications ---
    body=$(arr_get "http://${TARGET_HOST}:8181/api/v1/applications" "$prowlarr_key")
    local n_sonarr=$(arr_match_field "$body" "implementation" "Sonarr")
    local n_radarr=$(arr_match_field "$body" "implementation" "Radarr")
    if [[ "${n_sonarr:-0}" -ge 1 ]]; then ok "  Prowlarr: Sonarr application wired";
    else fail "  Prowlarr: Sonarr application NOT wired."; fails=$((fails+1)); fi
    if [[ "${n_radarr:-0}" -ge 1 ]]; then ok "  Prowlarr: Radarr application wired";
    else fail "  Prowlarr: Radarr application NOT wired."; fails=$((fails+1)); fi

    # --- Prowlarr: indexer count is informational only ---
    # Default install seeds zero indexers (Terms §6 compliance —
    # OpenBox does not provide indexers/trackers/sources). Customer
    # adds their own in Prowlarr's UI. We just log the count.
    local n_idx=0
    local last_body=$(arr_get "http://${TARGET_HOST}:8181/api/v1/indexer" "$prowlarr_key")
    n_idx=$(arr_count "$last_body")
    ok "  Prowlarr: ${n_idx} indexer(s) registered (customer-managed; 0 is expected fresh)"

    [[ $fails -eq 0 ]]
}

# ============================================================
# STEP — Per-app content-signature smoke
# ============================================================
# "HTTP 200" is not "the app loaded." nginx returns 200 from a default
# page; a half-broken Node app returns 200 from its error handler.
# This step grabs the rendered HTML for each enabled app's URL and
# greps for a string that proves the REAL app is serving — Jellyfin's
# product name, Prowlarr's Angular bootstrap, etc.
#
# Add new modules here as they're added to the install. Signatures
# should match the COLD page (not after login) since we're not
# authenticated against any of these UIs in the rehearsal.
do_assert_app_signatures() {
    step "Per-app content signatures (proves app actually loaded)"
    local fails=0
    sig_check() {
        local name="$1" url="$2" sig="$3"
        local body
        # v1.6.50: -L follows redirects. v1.6.40 flipped Sonarr / Radarr /
        # Prowlarr to AuthenticationMethod=Forms+Enabled, which makes the
        # bare root URL return 302 → /login with an empty body. Without
        # -L the probe sees no body and fails. Following the redirect
        # lands on the login page, whose body contains the app's name.
        body=$(curl --silent -L --max-time 12 "$url" 2>/dev/null)
        if [[ -z "$body" ]]; then
            fail "  ${name} → no body returned (${url})"
            fails=$((fails+1))
            return
        fi
        if grep -qiE "$sig" <<<"$body"; then
            ok "  ${name} → signature match"
        else
            fail "  ${name} → signature MISSING (expected /${sig}/i in ${url})"
            fail "    body[0..200]=${body:0:200}"
            fails=$((fails+1))
        fi
    }
    # Media profile apps (always running after wizard finish):
    sig_check "Jellyfin"     "http://${TARGET_HOST}:8096/web/index.html"    "jellyfin"
    sig_check "Seerr"        "http://${TARGET_HOST}:5055/login"             "(jellyseerr|overseerr)"
    sig_check "Prowlarr"     "http://${TARGET_HOST}:8181/"                  "prowlarr"
    sig_check "Sonarr"       "http://${TARGET_HOST}:8989/"                  "sonarr"
    sig_check "Radarr"       "http://${TARGET_HOST}:7878/"                  "radarr"
    sig_check "qBittorrent"  "http://${TARGET_HOST}:8089/"                  "qbittorrent"
    sig_check "Bazarr"       "http://${TARGET_HOST}:6767/"                  "bazarr"
    # Core/dashboard always running:
    sig_check "Dashboard"    "http://${TARGET_HOST}:8443/"                  "openbox"
    sig_check "Portainer"    "http://${TARGET_HOST}:9000/"                  "portainer"
    sig_check "Homepage"     "http://${TARGET_HOST}:3000/"                  "homepage"
    [[ $fails -eq 0 ]]
}

do_regression_settings_recreate() {
    step "v1.5.110 regression — change a setting, verify container recreates"
    # Flip JELLYFIN_HW_ACCEL via PUT /api/config. Then trigger openbox up
    # (which the apply path normally fires). Verify ob-jellyfin-media is
    # recreated (Created timestamp moves forward).
    local before
    before=$($SSH 'sudo docker inspect ob-jellyfin-media --format "{{.Created}}" 2>/dev/null')
    if [[ -z "$before" ]]; then
        fail "ob-jellyfin-media not running — can't run recreate regression."
        return 1
    fi

    local current
    current=$($SSH 'sudo grep "^JELLYFIN_HW_ACCEL=" /opt/openbox/.env | cut -d= -f2' 2>/dev/null)
    local flipped
    if [[ "$current" == "off" ]]; then flipped=auto; else flipped=off; fi

    ccurl -X PUT "${DASHBOARD_URL}/api/config" \
        -H 'Content-Type: application/json' \
        -H "X-CSRF-Token: $(csrf)" \
        -d "{\"JELLYFIN_HW_ACCEL\":\"${flipped}\"}" >/dev/null

    # Trigger openbox up via SSH (mimics what /api/modules/batch does).
    $SSH 'sudo OB_SKIP_LOCK=1 /opt/openbox/openbox up' >/tmp/ob-rh-up.log 2>&1 || {
        fail "openbox up failed:"
        tail -20 /tmp/ob-rh-up.log >&2
        return 1
    }

    local after
    after=$($SSH 'sudo docker inspect ob-jellyfin-media --format "{{.Created}}" 2>/dev/null')
    if [[ "$after" == "$before" ]]; then
        fail "ob-jellyfin-media was NOT recreated after .env change."
        fail "  before: $before"
        fail "  after:  $after"
        fail "  → v1.5.110 hash-and-force-recreate logic is broken."
        return 1
    fi
    ok "Container recreated as expected (Created moved $before → $after)."
}

# ============================================================
# STEP 11 — smoke test public URLs
# ============================================================
do_smoke_urls() {
    step "Smoke-test service URLs"
    local fails=0
    # Plain curl (no cookie jar) so a per-call session-cookie miss
    # doesn't manifest as multiple appended status codes. Retry a few
    # times because the regression test's openbox up recreates the
    # whole media stack — seerr/jellyfin can take 30-60s post-recreate
    # to leave health-starting state.
    check() {
        local name="$1" url="$2" expect="$3"
        local code=000
        for attempt in 1 2 3 4 5 6 7 8; do
            code=$(curl --insecure --silent -o /dev/null -w '%{http_code}' --max-time 8 "$url" 2>/dev/null) || code=000
            code="${code:-000}"
            if [[ ",${expect}," == *",${code},"* ]]; then break; fi
            sleep 5
        done
        if [[ ",${expect}," == *",${code},"* ]]; then
            ok "  ${name} → HTTP ${code}"
        else
            fail "  ${name} → HTTP ${code} after retries (expected ${expect})"
            fails=$((fails+1))
        fi
    }
    check "Dashboard /login"     "${DASHBOARD_URL}/login"                  "200"
    check "Jellyfin"             "http://${TARGET_HOST}:8096/System/Info/Public" "200"
    check "Seerr /api/v1/status" "http://${TARGET_HOST}:5055/api/v1/status"      "200"
    [[ $fails -eq 0 ]]
}

# ============================================================
# STEP 12 — synthetic self-update flow
# ============================================================
# Customers don't cold-install on every release — most upgrade in place.
# This step exercises the full self-update mechanism without needing two
# distinct released versions on R2: edit /opt/openbox/VERSION on the
# rig down to a synthetic "1.5.000" so the dashboard's checkForUpdate
# sees an upgrade is available, then drive the same /api/self-update/apply
# path a customer would. install.sh in upgrade mode pulls the real R2
# tarball, swaps it into /opt/openbox atomically, and overwrites the
# synthetic VERSION marker — proving the helper-container handoff,
# atomic swap, dashboard restart, and state preservation all work.
do_assert_self_update_synthetic() {
    step "Self-update: synthetic version downgrade → re-detect → apply"

    local real_version
    real_version=$($SSH 'cat /opt/openbox/VERSION 2>/dev/null' | tr -d '[:space:]')
    if [[ -z "$real_version" ]]; then
        fail "Could not read /opt/openbox/VERSION on rig"
        return 1
    fi

    # Synthetic prior-version. Has to be >= MIN_FROM_VERSION (currently
    # 1.6.0 after the v1.6.1 step-through gate landed) so the
    # stepped-upgrade gate doesn't refuse the synthetic downgrade. We
    # read MIN_FROM_VERSION from the local repo to stay in sync with
    # whatever the next release sets.
    local synth_min_root
    synth_min_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
    local synth
    if [[ -f "${synth_min_root}/MIN_FROM_VERSION" ]]; then
        synth=$(cat "${synth_min_root}/MIN_FROM_VERSION" | tr -d '[:space:]')
    else
        synth="1.6.0"
    fi
    if ! $SSH "echo '${synth}' | sudo tee /opt/openbox/VERSION >/dev/null && sudo docker restart ob-dashboard" >/tmp/ob-rh-su-restart.log 2>&1; then
        fail "Could not write synthetic VERSION + restart ob-dashboard"
        return 1
    fi
    ok "  Downgraded VERSION marker $real_version → $synth (real code unchanged)"

    # Wait for dashboard to come back. /api/auth/status returns 200 (logged in)
    # or 401 (logged out) — both mean reachable.
    local d=$(( $(date +%s) + 60 )) code=000
    while [[ $(date +%s) -lt $d ]]; do
        code=$(curl --insecure --silent --max-time 5 -o /dev/null -w '%{http_code}' "${DASHBOARD_URL}/api/auth/status" 2>/dev/null) || code=000
        [[ "$code" == "200" || "$code" == "401" ]] && break
        sleep 3
    done
    if [[ "$code" != "200" && "$code" != "401" ]]; then
        fail "Dashboard not reachable after restart (code=$code)"
        return 1
    fi

    # Re-login (in-memory session was wiped by the restart).
    local login_resp
    login_resp=$(ccurl -X POST -H 'Content-Type: application/json' \
        -d "{\"password\":\"${ADMIN_PASSWORD}\"}" "${DASHBOARD_URL}/api/login")
    if ! grep -q '"success":true' <<<"$login_resp"; then
        fail "Re-login after restart failed: ${login_resp:0:200}"
        return 1
    fi

    # Update check — should see synth as current, real R2 latest as available.
    local check
    check=$(ccurl "${DASHBOARD_URL}/api/self-update/check")
    local cur_seen latest_seen avail
    cur_seen=$(printf '%s' "$check" | jget current)
    latest_seen=$(printf '%s' "$check" | jget latest)
    avail=$(printf '%s' "$check" | jget updateAvailable)
    if [[ "$cur_seen" != "$synth" ]]; then
        fail "Dashboard didn't pick up synthetic VERSION: current='$cur_seen' (expected '$synth'). Resp: ${check:0:200}"
        return 1
    fi
    if [[ "$avail" != "True" && "$avail" != "true" ]]; then
        fail "Dashboard didn't flag updateAvailable with current=$synth latest=$latest_seen. Resp: ${check:0:200}"
        return 1
    fi
    ok "  Update detected: $cur_seen → $latest_seen"

    # Apply. The helper container restarts ob-dashboard mid-flight, so
    # the connection drops — exit code is whatever curl makes of that.
    # We don't check it; the truth is the VERSION on disk after the swap.
    ccurl -X POST -H "X-CSRF-Token: $(csrf)" --max-time 240 \
        "${DASHBOARD_URL}/api/self-update/apply" >/tmp/ob-rh-su-apply.log 2>&1 || true

    # Wait up to 240s for VERSION on disk to leave the synthetic marker.
    # install.sh upgrade mode overwrites VERSION as part of the atomic swap.
    d=$(( $(date +%s) + 240 )); local final=""
    while [[ $(date +%s) -lt $d ]]; do
        final=$($SSH 'cat /opt/openbox/VERSION 2>/dev/null' | tr -d '[:space:]') || final=""
        [[ -n "$final" && "$final" != "$synth" ]] && break
        sleep 5
    done
    if [[ -z "$final" || "$final" == "$synth" ]]; then
        fail "VERSION on disk not updated after self-update (still '$final')"
        echo "${YLW}--- /tmp/ob-rh-su-apply.log tail ---${OFF}" >&2
        tail -20 /tmp/ob-rh-su-apply.log >&2 || true
        echo "${YLW}--- self-update-helper.log tail (on rig) ---${OFF}" >&2
        $SSH 'sudo tail -50 /opt/openbox/state/self-update-helper.log 2>/dev/null' >&2 || true
        return 1
    fi

    # Wait for the upgraded dashboard to be reachable again.
    d=$(( $(date +%s) + 90 )); code=000
    while [[ $(date +%s) -lt $d ]]; do
        code=$(curl --insecure --silent --max-time 5 -o /dev/null -w '%{http_code}' "${DASHBOARD_URL}/api/auth/status" 2>/dev/null) || code=000
        [[ "$code" == "200" || "$code" == "401" ]] && break
        sleep 3
    done
    if [[ "$code" != "200" && "$code" != "401" ]]; then
        fail "Dashboard not reachable after self-update finished (code=$code)"
        return 1
    fi

    ok "Self-update verified: $synth → $final, dashboard back up + responsive"

    # The self-update just overwrote /opt/openbox/openbox with R2's
    # currently-published version. If we have a local dev openbox AND
    # we're not in --released mode, re-push it so the rest of the
    # rehearsal (e.g., --with-modules) tests our in-flight CLI changes,
    # not the older R2-pinned version.
    if [[ ${SKIP_DEV_SCRIPT} -eq 0 ]]; then
        local local_openbox
        local_openbox="$(dirname "$(dirname "$(realpath "$0")")")/openbox"
        if [[ -f "$local_openbox" ]]; then
            if ssh -i "${TARGET_SSH_KEY}" -o StrictHostKeyChecking=no "${TARGET_USER}@${TARGET_HOST}" 'cat > /tmp/openbox.dev' < "$local_openbox" \
               && $SSH 'sudo install -m 755 -o root -g root /tmp/openbox.dev /opt/openbox/openbox && rm -f /tmp/openbox.dev' >/dev/null 2>&1; then
                ok "  Local openbox re-pushed over R2-installed version (post-self-update)"
            else
                warn "  Could not re-push local openbox after self-update — subsequent steps test R2 version"
            fi
        fi
    fi
}

# ============================================================
# RUN
# ============================================================
say "${BLU}═══ OpenBox cold-install rehearsal ═══${OFF}"
say "${DIM}target=${TARGET_HOST} user=${TARGET_USER} dashboard=${DASHBOARD_URL}${OFF}"

guard "wipe"             do_wipe
guard "install"          do_install
guard "pin-install-id"   do_pin_install_id
guard "read-bootstrap"   do_read_bootstrap

if [[ $USE_UI -eq 1 ]]; then
    # UI mode: hand off the claim → license → wizard sequence to the
    # Playwright walkthrough, then resume bash for health/recreate/smoke.
    do_ui_walkthrough() {
        step "Hand off to Playwright wizard walkthrough"
        local wiz="$(dirname "$0")/browser-wizard.js"
        if [[ ! -f "$wiz" ]]; then
            fail "browser-wizard.js not found at $wiz"
            return 1
        fi
        OPENBOX_IP="$TARGET_HOST" \
        OPENBOX_PORT="${DASHBOARD_URL##*:}" \
        OB_BOOTSTRAP_TOKEN="$BOOTSTRAP_TOKEN" \
        SB_ADMIN_PASSWORD="$ADMIN_PASSWORD" \
        SB_LICENSE_KEY="$LICENSE_KEY" \
        SB_PURCHASE_EMAIL="$PURCHASE_EMAIL" \
        SB_VPN_PROVIDER="$VPN_PROVIDER" \
        SB_VPN_TYPE="$VPN_TYPE" \
        SB_VPN_WG_KEY="$WIREGUARD_PRIVATE_KEY" \
        SB_VPN_WG_ADDR="$WIREGUARD_ADDRESSES" \
        NODE_PATH=/tmp/ob-qa-deps/node_modules \
        node "$wiz"
    }
    guard "ui-walkthrough" do_ui_walkthrough
else
    guard "claim-admin"      do_claim
    guard "activate-license" do_activate_license
    guard "wizard-complete"  do_setup_complete_media
fi

guard "wait-lock"        do_wait_for_lock_release
guard "wait-healthy"     do_wait_media_healthy
guard "vpn-routes"       do_assert_vpn_routes
guard "arr-chain"        do_assert_arr_chain
guard "arr-functional"   do_assert_arr_chain_functional
guard "app-signatures"   do_assert_app_signatures
guard "recreate-regression" do_regression_settings_recreate
guard "smoke-urls"       do_smoke_urls
guard "self-update"      do_assert_self_update_synthetic

# --with-modules: optional slower second pass that exercises non-media
# modules (linkding, gotify, monitoring, budget, homarr, navidrome) by
# enabling each via /api/modules/<id>/enable, asserting its container
# comes up + its UI loads + a content signature matches, then disabling
# it. Adds ~6-9 min on top of the baseline ~7m runtime — gated behind
# a flag so the standard 5x stability loop stays quick.
if [[ $WITH_MODULES -eq 1 ]]; then
    do_assert_non_media_modules() {
        step "Non-media modules pass (browser-apps.js)"
        local apps_script
        apps_script="$(dirname "$0")/browser-apps.js"
        if [[ ! -f "$apps_script" ]]; then
            fail "browser-apps.js not found at $apps_script"
            return 1
        fi
        if OPENBOX_IP="$TARGET_HOST" \
           OPENBOX_PORT="${DASHBOARD_URL##*:}" \
           SB_DASHBOARD_PASSWORD="$ADMIN_PASSWORD" \
           NODE_PATH=/tmp/ob-qa-deps/node_modules \
           node "$apps_script"; then
            ok "Non-media modules pass complete."
        else
            fail "Non-media modules pass had failures (see output above)."
            return 1
        fi
    }
    guard "non-media-modules" do_assert_non_media_modules
fi

elapsed=$(( $(date +%s) - REHEARSAL_START ))

# Write Tier 2 stamp file so release.sh can gate on it. Per Codex review
# 2026-05-01: high-risk releases (touching install.sh / openbox /
# arr-bootstrap.sh / modules/media / patch-seerr-bundle.sh /
# patch-jellyfin-html.sh / dashboard self-update) require fresh rehearsal
# (< 7 days). The stamp records when this rehearsal passed and against
# what commit, so release.sh can compare to HEAD.
PROJECT_ROOT_FOR_STAMP="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STAMP_FILE="${PROJECT_ROOT_FOR_STAMP}/state/last-rehearsal.json"
COMMIT_FOR_STAMP=$(git -C "${PROJECT_ROOT_FOR_STAMP}" rev-parse HEAD 2>/dev/null || echo "unknown")
COMMIT_SHORT_FOR_STAMP=$(git -C "${PROJECT_ROOT_FOR_STAMP}" rev-parse --short HEAD 2>/dev/null || echo "unknown")
TS_FOR_STAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
mkdir -p "${PROJECT_ROOT_FOR_STAMP}/state"
cat > "${STAMP_FILE}" <<JSON
{
  "pass": true,
  "elapsed_seconds": ${elapsed},
  "with_modules": ${WITH_MODULES:-0},
  "ui_walkthrough": ${USE_UI:-0},
  "commit": "${COMMIT_FOR_STAMP}",
  "commit_short": "${COMMIT_SHORT_FOR_STAMP}",
  "target_host": "${TARGET_HOST:-unknown}",
  "timestamp_utc": "${TS_FOR_STAMP}"
}
JSON
printf '%s wrote %s\n' "$DIM" "$STAMP_FILE$OFF"

printf '\n%s═══ REHEARSAL PASSED (%ds) ═══%s\n' "$GRN" "$elapsed" "$OFF"
