// SparkBox Browser QA — comprehensive headless regression test.
//
// Drives the dashboard through every major user journey: login, every
// top-level page, settings sub-tabs, full module enable→run→disable
// lifecycle, config read/write, and backup creation. Read-only API
// checks prove the underlying endpoints work. Destructive ops (restore,
// clean slate, self-update, AI chat, license activation, remote access
// wizard) are deliberately skipped.
//
// Separate from scripts/browser-test.js, which is a first-login-only
// smoke test. This is the post-login, feature-level regression.
//
// Usage:
//
//   NODE_PATH=/tmp/ob-qa-deps/node_modules \
//   SPARKBOX_IP=<your-test-host> \
//   SB_DASHBOARD_PASSWORD=test-password-12345 \
//   node scripts/browser-qa.js
//
// Optional:
//   SPARKBOX_PORT          default 8443
//   SB_QA_TEST_MODULE      default "linkding"  (module to enable/disable)
//   SB_QA_SCREENSHOT_DIR   default ./browser-qa-screenshots
//
// Exits 0 if every check passes, 1 if any check fails. Writes a
// structured results file to ./browser-qa-results-<ip>.json.

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const IP = process.env.SPARKBOX_IP || '192.168.0.17';
const PORT = parseInt(process.env.SPARKBOX_PORT || '8443', 10);
const BASE = `http://${IP}:${PORT}`;
const PASSWORD = process.env.SB_DASHBOARD_PASSWORD || 'test-password-12345';
const TEST_MODULE = process.env.SB_QA_TEST_MODULE || 'linkding';
const SCREENSHOT_DIR = process.env.SB_QA_SCREENSHOT_DIR || path.join(__dirname, '..', 'browser-qa-screenshots');
const RESULTS_FILE = path.join(__dirname, '..', `browser-qa-results-${IP.replace(/\./g, '-')}.json`);
const MODULE_TIMEOUT_MS = 90_000;

fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });

const results = [];
function record(name, status, detail) {
  results.push({ name, status, detail: detail || null, ts: new Date().toISOString() });
  const icon = status === 'pass' ? '✓' : status === 'fail' ? '✗' : '…';
  const color = status === 'pass' ? '\x1b[32m' : status === 'fail' ? '\x1b[31m' : '\x1b[33m';
  console.log(`${color}${icon}\x1b[0m ${name}${detail ? ' — ' + detail : ''}`);
}

async function snap(page, label) {
  const safe = label.replace(/[^a-z0-9]+/gi, '_').toLowerCase();
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, `${IP}-${safe}.png`) }).catch(() => {});
}

// --- Helpers ---
// Read the CSRF token from the _csrf cookie (set by the dashboard's
// CSRF middleware). Required on every POST/PUT/DELETE or the server
// returns 403 CSRF token mismatch.
async function csrfHeader(context) {
  const cookies = await context.cookies(BASE);
  const csrf = cookies.find(c => c.name === '_csrf');
  return csrf ? { 'X-CSRF-Token': csrf.value } : {};
}
async function apiGet(context, path) {
  const resp = await context.request.get(`${BASE}${path}`);
  if (!resp.ok()) throw new Error(`GET ${path} → HTTP ${resp.status()}`);
  return resp.json();
}
async function apiPost(context, path, body) {
  const resp = await context.request.post(`${BASE}${path}`, {
    data: body,
    headers: { 'Content-Type': 'application/json', ...(await csrfHeader(context)) },
  });
  return { status: resp.status(), body: await resp.json().catch(() => ({})) };
}
async function apiPut(context, path, body) {
  const resp = await context.request.put(`${BASE}${path}`, {
    data: body,
    headers: { 'Content-Type': 'application/json', ...(await csrfHeader(context)) },
  });
  return { status: resp.status(), body: await resp.json().catch(() => ({})) };
}

async function listContainers(context) {
  const body = await apiGet(context, '/api/containers');
  return Array.isArray(body) ? body : (body.containers || []);
}

async function waitForContainer(context, containerName, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const arr = await listContainers(context);
      const found = arr.find(c => (c.name || c.Name || '').includes(containerName));
      if (found && (found.state === 'running' || found.State === 'running')) return found;
    } catch {}
    await new Promise(r => setTimeout(r, 3000));
  }
  return null;
}

async function waitForContainerGone(context, containerName, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const arr = await listContainers(context);
      const found = arr.find(c => (c.name || c.Name || '').includes(containerName));
      if (!found) return true;
    } catch {}
    await new Promise(r => setTimeout(r, 3000));
  }
  return false;
}

// --- The test ---
(async () => {
  console.log(`\nSparkBox QA: ${BASE}`);
  console.log(`Password: ${PASSWORD ? '(set)' : '(MISSING — export SB_DASHBOARD_PASSWORD)'}`);
  console.log(`Test module: ${TEST_MODULE}\n`);

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();

  try {
    // === 1. Login ===
    await page.goto(BASE, { waitUntil: 'domcontentloaded', timeout: 15000 });
    await page.waitForSelector('#login-screen:not(.hidden)', { timeout: 10000 });
    await page.fill('#login-password', PASSWORD);
    await page.click('#login-btn');
    try {
      await page.waitForSelector('#dashboard:not(.hidden)', { timeout: 10000 });
      record('login', 'pass');
    } catch (e) {
      const err = await page.textContent('#login-error').catch(() => '');
      record('login', 'fail', `login did not succeed: "${(err || '').trim()}"`);
      await snap(page, 'login-fail');
      throw new Error('cannot proceed without login');
    }

    // Unconditionally skip the setup wizard. It pops up async after
    // login whenever /api/auth/status returns needsSetup=true, and it
    // blocks every click on the underlying dashboard until dismissed.
    // POST is idempotent — if setup is already complete, the endpoint
    // just no-ops. Reloading after the skip gets us a clean dashboard
    // with needsSetup=false.
    try {
      const skipResp = await apiPost(context, '/api/wizard/skip', {});
      if (skipResp.status !== 200 && skipResp.status !== 204) {
        throw new Error(`skip → ${skipResp.status}: ${JSON.stringify(skipResp.body)}`);
      }
      await page.reload({ waitUntil: 'domcontentloaded' });
      await page.waitForSelector('#dashboard:not(.hidden)', { timeout: 10000 });
      // Brief settle time so any modal-open animations finish before
      // we start clicking tabs.
      await page.waitForTimeout(1500);
      // Diagnostic screenshot: if the wizard popped back up, or a
      // modal/toast is blocking the tabs, this is where we find out.
      await snap(page, 'after-wizard-skip');
      // Also dump which top-level screens are visible
      const diag = await page.evaluate(() => {
        const screens = Array.from(document.querySelectorAll('.screen, .page, [id^="setup-wizard"]'));
        return screens
          .filter(el => el.id)
          .map(el => ({
            id: el.id,
            hidden: el.classList.contains('hidden'),
            display: getComputedStyle(el).display,
            zIndex: getComputedStyle(el).zIndex,
          }));
      }).catch(() => []);
      console.log('    [diag] visible screens:', JSON.stringify(diag));
      record('wizard skip', 'pass');
    } catch (e) {
      record('wizard skip', 'fail', e.message.substring(0, 200));
      await snap(page, 'wizard-skip-fail');
    }

    // === 2. Navigation — each top-level tab ===
    const tabs = ['home', 'apps', 'updates', 'releases', 'logs', 'settings', 'help'];
    for (const tab of tabs) {
      try {
        await page.click(`.tab[data-page="${tab}"]`);
        await page.waitForSelector(`#page-${tab}:not(.hidden)`, { timeout: 5000 });
        record(`nav: ${tab}`, 'pass');
      } catch (e) {
        record(`nav: ${tab}`, 'fail', e.message.substring(0, 200));
        await snap(page, `nav-${tab}-fail`);
      }
    }

    // === 3. Settings sub-tabs ===
    await page.click('.tab[data-page="settings"]');
    await page.waitForSelector('#page-settings:not(.hidden)', { timeout: 5000 });
    const stabs = ['general', 'server', 'network', 'tools'];
    for (const stab of stabs) {
      try {
        await page.click(`.settings-tab[data-stab="${stab}"]`);
        // Panels toggle the `hidden` class, not `.active` — the tab
        // button gets .active, the panel gets :not(.hidden).
        await page.waitForSelector(`[data-stab-panel="${stab}"]:not(.hidden)`, { timeout: 3000 });
        record(`settings tab: ${stab}`, 'pass');
      } catch (e) {
        record(`settings tab: ${stab}`, 'fail', e.message.substring(0, 200));
        await snap(page, `stab-${stab}-fail`);
      }
    }

    // === 4. API read-only feature checks (reuse session cookie) ===
    try {
      const containers = await apiGet(context, '/api/containers');
      const arr = Array.isArray(containers) ? containers : (containers.containers || []);
      record('api: /api/containers', arr.length > 0 ? 'pass' : 'fail', `${arr.length} containers`);
    } catch (e) { record('api: /api/containers', 'fail', e.message); }

    try {
      const mods = await apiGet(context, '/api/modules');
      const arr = Array.isArray(mods) ? mods : (mods.modules || []);
      record('api: /api/modules', arr.length > 20 ? 'pass' : 'fail', `${arr.length} modules listed`);
    } catch (e) { record('api: /api/modules', 'fail', e.message); }

    try {
      const store = await apiGet(context, '/api/modules/store');
      const count = Array.isArray(store) ? store.length : (store.modules || []).length;
      record('api: /api/modules/store', count > 20 ? 'pass' : 'fail', `${count} modules`);
    } catch (e) { record('api: /api/modules/store', 'fail', e.message); }

    try {
      const lic = await apiGet(context, '/api/license');
      const ok = lic && (lic.tier === 'free' || lic.tier === 'starter' || lic.tier === 'pro') && lic.features;
      record('api: /api/license', ok ? 'pass' : 'fail', `tier=${lic.tier} moduleLimit=${lic.features?.moduleLimit}`);
    } catch (e) { record('api: /api/license', 'fail', e.message); }

    try {
      const cfg = await apiGet(context, '/api/config');
      record('api: /api/config (read)', cfg && cfg.TZ ? 'pass' : 'fail', `TZ=${cfg?.TZ}`);
    } catch (e) { record('api: /api/config (read)', 'fail', e.message); }

    try {
      // changelog is a static file served from public/, not an API
      const resp = await context.request.get(`${BASE}/changelog.json`);
      const body = await resp.json();
      const latest = (body.releases || [])[0];
      record('static: /changelog.json', latest && latest.version ? 'pass' : 'fail', `latest=${latest?.version}`);
    } catch (e) { record('static: /changelog.json', 'fail', e.message); }

    // === 5. Config write round-trip ===
    try {
      const before = await apiGet(context, '/api/config');
      const origTZ = before.TZ || 'UTC';
      const newTZ = origTZ === 'Europe/London' ? 'America/Los_Angeles' : 'Europe/London';

      const putResp = await apiPut(context, '/api/config', { TZ: newTZ });
      if (putResp.status !== 200) throw new Error(`PUT → ${putResp.status}: ${JSON.stringify(putResp.body)}`);

      const after = await apiGet(context, '/api/config');
      if (after.TZ !== newTZ) throw new Error(`TZ did not persist (got ${after.TZ})`);

      // revert so we don't leave the box in a weird state
      await apiPut(context, '/api/config', { TZ: origTZ });
      record('config write+revert (TZ)', 'pass', `${origTZ} → ${newTZ} → ${origTZ}`);
    } catch (e) {
      record('config write+revert (TZ)', 'fail', e.message.substring(0, 200));
    }

    // === 6. Module lifecycle ===
    // Enable → wait for running → verify in state → disable → verify gone
    try {
      const enableResp = await apiPost(context, `/api/modules/${TEST_MODULE}/enable`, {});
      if (enableResp.status !== 200) throw new Error(`enable → ${enableResp.status}: ${JSON.stringify(enableResp.body)}`);

      const container = await waitForContainer(context, `sb-${TEST_MODULE}`, MODULE_TIMEOUT_MS);
      if (!container) throw new Error(`container sb-${TEST_MODULE} never reached running state within ${MODULE_TIMEOUT_MS/1000}s`);
      record(`module enable: ${TEST_MODULE}`, 'pass', `container running as ${container.name || container.Name}`);

      const disableResp = await apiPost(context, `/api/modules/${TEST_MODULE}/disable`, {});
      if (disableResp.status !== 200) throw new Error(`disable → ${disableResp.status}: ${JSON.stringify(disableResp.body)}`);

      const gone = await waitForContainerGone(context, `sb-${TEST_MODULE}`, 60_000);
      record(`module disable: ${TEST_MODULE}`, gone ? 'pass' : 'fail', gone ? 'container removed' : 'still present after 60s');
    } catch (e) {
      record(`module lifecycle: ${TEST_MODULE}`, 'fail', e.message.substring(0, 300));
    }

    // === 7. Backup creation ===
    try {
      const preList = await apiGet(context, '/api/backups');
      const preCount = (preList.backups || preList || []).length;

      const createResp = await apiPost(context, '/api/backup', {});
      if (createResp.status !== 200) throw new Error(`create → ${createResp.status}: ${JSON.stringify(createResp.body)}`);

      const postList = await apiGet(context, '/api/backups');
      const postCount = (postList.backups || postList || []).length;
      if (postCount <= preCount) throw new Error(`backup count did not increase (${preCount} → ${postCount})`);

      const latest = (postList.backups || postList || [])[0];
      const size = latest.size || 0;
      record('backup create', size > 100 ? 'pass' : 'fail', `new backup ${latest.filename || latest.name}, size ${size}B`);
    } catch (e) {
      record('backup create', 'fail', e.message.substring(0, 300));
    }

    // === 8. Logout + re-login ===
    try {
      await apiPost(context, '/api/logout', {});
      const statusAfterLogout = await apiGet(context, '/api/auth/status');
      if (statusAfterLogout.authenticated) throw new Error('still authenticated after logout');
      record('logout', 'pass');

      // Re-login
      await page.goto(BASE, { waitUntil: 'domcontentloaded' });
      await page.waitForSelector('#login-screen:not(.hidden)', { timeout: 10000 });
      await page.fill('#login-password', PASSWORD);
      await page.click('#login-btn');
      await page.waitForSelector('#dashboard:not(.hidden)', { timeout: 10000 });
      record('re-login', 'pass');
    } catch (e) {
      record('logout / re-login', 'fail', e.message.substring(0, 300));
      await snap(page, 'logout-fail');
    }

    await page.close();
    await browser.close();
  } catch (e) {
    console.error('Fatal error:', e.message);
    record('fatal', 'fail', e.message);
    await browser.close().catch(() => {});
  }

  const passed = results.filter(r => r.status === 'pass').length;
  const failed = results.filter(r => r.status === 'fail').length;

  fs.writeFileSync(RESULTS_FILE, JSON.stringify({
    target: BASE,
    timestamp: new Date().toISOString(),
    passed,
    failed,
    results,
  }, null, 2));

  console.log(`\n=====================================`);
  console.log(`  ${BASE}`);
  console.log(`  passed: ${passed}`);
  console.log(`  failed: ${failed}`);
  console.log(`  results: ${RESULTS_FILE}`);
  console.log(`=====================================\n`);

  process.exit(failed > 0 ? 1 : 0);
})();
