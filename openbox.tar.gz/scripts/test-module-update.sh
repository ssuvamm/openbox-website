#!/usr/bin/env bash
# scripts/test-module-update.sh
#
# Per-module update lifecycle test. Today `openbox update <module>` runs
# `docker compose pull && docker compose up -d` — there's no rollback if
# the new image breaks. This test exercises the path on chosen modules
# and asserts:
#   1. CLI command exits 0
#   2. Image SHA either changed (new image was pulled) or unchanged
#      (already current — both are valid; not testing for an upgrade
#      necessarily, just that the path runs cleanly)
#   3. Container is healthy 60s after the update
#   4. Container is the SAME container ID? No — container is recreated.
#      The check is: container exists + healthy.
#
# Run against test NAS. Usage:
#   scripts/test-module-update.sh                   # tests linkding (small, fast)
#   scripts/test-module-update.sh jellyfin gotify   # specific list

set -uo pipefail

RED=$'\e[31m'; GRN=$'\e[32m'; YLW=$'\e[33m'; BLU=$'\e[34m'; DIM=$'\e[2m'; OFF=$'\e[0m'
say()  { printf '%s\n' "$*"; }
step() { printf '\n%s▶%s %s\n' "$BLU" "$OFF" "$*"; }
ok()   { printf '%s✓%s %s\n' "$GRN" "$OFF" "$*"; }
warn() { printf '%s!%s %s\n' "$YLW" "$OFF" "$*"; }
fail() { printf '%s✗%s %s\n' "$RED" "$OFF" "$*" >&2; }

CONFIG_FILE="${HOME}/.openbox-rehearsal.env"
[[ -f "${CONFIG_FILE}" ]] && source "${CONFIG_FILE}"
TARGET_HOST="${TARGET_HOST:-}"
SSH_USER="${TARGET_USER:-${SSH_USER:-}}"
SSH_KEY="${TARGET_SSH_KEY:-${SSH_KEY:-}}"
[[ -z "${TARGET_HOST}" || -z "${SSH_USER}" || -z "${SSH_KEY}" ]] && {
    fail "Missing TARGET_HOST / SSH_USER / SSH_KEY"; exit 1
}
SSH="ssh -i ${SSH_KEY} -o ConnectTimeout=8 -o StrictHostKeyChecking=accept-new ${SSH_USER}@${TARGET_HOST}"

# Default: test on a small fast module so this completes in <60s. Override
# by passing module names as args.
MODULES=("${@:-linkding}")
START_TIME=$(date +%s)
FAILS=0

for MODULE in "${MODULES[@]}"; do
    step "Module update: ${MODULE}"

    # Confirm module is enabled. `openbox modules` prints a green
    # filled dot (●) for enabled, hollow circle (○) for disabled.
    # Strip ANSI codes before matching since the module name is wrapped
    # in [1m...[0m bold sequences that break word-boundary grep.
    if ! ${SSH} "sudo -n /opt/openbox/openbox modules 2>&1 | sed 's/\x1b\[[0-9;]*m//g' | grep -E '● *${MODULE}\b'" 2>/dev/null | grep -q .; then
        warn "${MODULE}: not enabled — skipping"
        continue
    fi

    # Snapshot all unhealthy containers BEFORE the update. The post-
    # update check is "no NEW unhealthy containers appeared." This is
    # universal — works for single-container modules and composites
    # (media, privacy) without needing to enumerate child containers.
    unhealthy_before=$(${SSH} "sudo -n docker ps --filter 'health=unhealthy' --format '{{.Names}}' | sort" 2>/dev/null || echo "")

    # Snapshot image digests of all openbox containers so we can tell
    # which (if any) were actually re-pulled.
    digests_before=$(${SSH} "sudo -n docker ps --filter 'name=ob-' --format '{{.Names}}' | xargs -I{} sh -c 'echo {}=\$(sudo -n docker inspect --format={{.Image}} {} 2>/dev/null)' | sort" 2>/dev/null || echo "")

    # Run openbox update
    upd_out=$(${SSH} "sudo -n /opt/openbox/openbox update ${MODULE} 2>&1" 2>&1 || echo "FAILED_INVOCATION")
    if echo "${upd_out}" | grep -qiE "FAILED_INVOCATION|error pulling|cannot connect|Unknown module"; then
        fail "${MODULE}: openbox update returned errors"
        echo "${upd_out}" | tail -10
        FAILS=$((FAILS+1))
        continue
    fi
    ok "${MODULE}: openbox update completed cleanly"

    # Wait up to 60s for any restarting containers to settle.
    waited=0
    while [[ ${waited} -lt 60 ]]; do
        starting=$(${SSH} "sudo -n docker ps --format '{{.Status}}' | grep -cE 'starting|restarting'" 2>/dev/null || echo 0)
        starting=$(echo "$starting" | tr -d '[:space:]')
        [[ "${starting:-0}" == "0" ]] && break
        sleep 5; waited=$((waited+5))
    done

    # Compare unhealthy snapshots. Anything in "after" but not "before" is a regression.
    unhealthy_after=$(${SSH} "sudo -n docker ps --filter 'health=unhealthy' --format '{{.Names}}' | sort" 2>/dev/null || echo "")
    new_unhealthy=$(comm -13 <(printf '%s\n' "$unhealthy_before") <(printf '%s\n' "$unhealthy_after") | grep -v '^$' || true)

    if [[ -n "${new_unhealthy}" ]]; then
        fail "${MODULE}: containers became unhealthy after update:"
        echo "${new_unhealthy}"
        FAILS=$((FAILS+1))
    else
        ok "${MODULE}: no new unhealthy containers ${waited}s after update"
    fi

    # Diff the image digests — show what actually changed.
    digests_after=$(${SSH} "sudo -n docker ps --filter 'name=ob-' --format '{{.Names}}' | xargs -I{} sh -c 'echo {}=\$(sudo -n docker inspect --format={{.Image}} {} 2>/dev/null)' | sort" 2>/dev/null || echo "")
    changed=$(diff <(printf '%s\n' "$digests_before") <(printf '%s\n' "$digests_after") | grep -E '^[<>]' | head -10 || true)
    if [[ -n "${changed}" ]]; then
        say "${DIM}  image digest changes:${OFF}"
        echo "${changed}" | sed 's/^/    /'
    else
        say "${DIM}  no image digest changes (already current)${OFF}"
    fi
done

ELAPSED=$(($(date +%s) - START_TIME))
say ""
if [[ ${FAILS} -eq 0 ]]; then
    ok "module-update test PASSED in ${ELAPSED}s for: ${MODULES[*]}"
    exit 0
else
    fail "module-update test FAILED: ${FAILS} module(s) failed in ${ELAPSED}s"
    exit 1
fi
