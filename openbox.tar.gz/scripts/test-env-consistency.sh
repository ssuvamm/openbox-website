#!/usr/bin/env bash
# ==========================================
# OpenBox env-var consistency check
# ==========================================
#
# For every SB_* variable that dashboard/server.js or dashboard/lib/*.js
# reads from process.env, verify it's forwarded to the dashboard
# container via modules/dashboard/docker-compose.yml's environment block.
#
# Why: server.js does NOT call dotenv.config() — it relies entirely on
# docker compose forwarding variables from the host .env file into the
# container's process.env. If a var is referenced in server code but
# missing from the compose environment block, reads return undefined
# even though the var is sitting in .env on disk.
#
# This bit us in 1.3.4: the OB_BOOTSTRAP_TOKEN was written to .env
# correctly by install.sh but never forwarded by compose, so every
# fresh install's first-login silently failed with "missing bootstrap
# token" while the token sat in .env unread. Root cause: two files
# (server.js and dashboard compose) have to agree on the env surface,
# and there was no compile-time check that they did.
#
# Usage: bash scripts/test-env-consistency.sh
# Exits 0 if consistent, 1 with a diff if any var is missing.
#
# Runs in CI via .github/workflows/test.yml.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname "${SCRIPT_DIR}")"
SERVER_JS="${REPO_ROOT}/dashboard/server.js"
LIB_DIR="${REPO_ROOT}/dashboard/lib"
COMPOSE="${REPO_ROOT}/modules/dashboard/docker-compose.yml"

if [[ ! -f "${SERVER_JS}" ]]; then
    echo "FAIL: dashboard/server.js not found at ${SERVER_JS}" >&2
    exit 1
fi
if [[ ! -f "${COMPOSE}" ]]; then
    echo "FAIL: dashboard compose not found at ${COMPOSE}" >&2
    exit 1
fi

# Every SB_* name referenced as process.env.SB_* in the server source.
# These are variables the dashboard READS at runtime, so they must be
# available via process.env — which only happens if compose forwards them.
referenced=$(grep -rhoE 'process\.env\.SB_[A-Z_]+' "${SERVER_JS}" "${LIB_DIR}"/*.js 2>/dev/null \
             | grep -oE 'SB_[A-Z_]+' \
             | sort -u)

# Every SB_* name listed in the dashboard compose's environment block.
# The pattern matches lines like "      - SB_FOO=${SB_FOO:-}".
forwarded=$(grep -oE '^\s*-\s*SB_[A-Z_]+=' "${COMPOSE}" \
            | grep -oE 'SB_[A-Z_]+' \
            | sort -u)

missing=$(comm -23 <(echo "${referenced}") <(echo "${forwarded}") || true)

if [[ -z "${missing}" ]]; then
    count=$(echo "${referenced}" | wc -l)
    echo "OK: all ${count} SB_* vars referenced in dashboard source are forwarded by compose."
    exit 0
fi

echo "FAIL: dashboard/server.js reads these process.env.SB_* vars that"
echo "      modules/dashboard/docker-compose.yml does NOT forward:"
echo ""
for v in ${missing}; do
    echo "  - ${v}"
done
echo ""
echo "Fix: add each missing var to the 'environment:' block of"
echo "     modules/dashboard/docker-compose.yml, e.g."
echo ""
for v in ${missing}; do
    echo "      - ${v}=\${${v}:-}"
done
echo ""
echo "Why this matters: server.js reads from process.env directly (no"
echo "dotenv.config), so any var not forwarded by compose returns"
echo "undefined even when it's set in .env on disk. This is how the"
echo "1.3.4 bootstrap-token bug happened."
exit 1
