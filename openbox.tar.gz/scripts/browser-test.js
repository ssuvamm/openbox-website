// SparkBox Browser Smoke Test
//
// Runs via: node scripts/browser-test.js
// Requires: npm install playwright && npx playwright install chromium
//
// Tests the actual web UIs of each module via headless Chromium:
//   1. Opens the SparkBox dashboard, verifies it loads
//   2. For each module's expected URL, opens it, checks it renders
//      something that looks like the real service (content signature match)
//   3. Captures screenshots of any failures
//   4. Writes structured results to ./browser-test-results.json

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

// --- Config ---
const NAS_IP = process.env.SPARKBOX_IP || '192.168.0.17';
const DASHBOARD_URL = `http://${NAS_IP}:8443`;
const RESULTS_FILE = path.join(__dirname, '..', 'browser-test-results.json');
const SCREENSHOTS_DIR = path.join(__dirname, '..', 'browser-test-screenshots');

// Known service ports and content signatures. Content signatures are strings
// that should appear on the service's landing page when it's actually working.
const SERVICES = {
  dashboard:       { port: 8443, path: '/',          signatures: ['SparkBox', 'password', 'Welcome'],    timeout: 10000 },
  // Core (always running)
  homepage:        { port: 3000, path: '/',          signatures: ['homepage', 'homarr', 'Homepage'],     timeout: 10000 },
  portainer:       { port: 9000, path: '/',          signatures: ['Portainer', 'portainer', 'docker'],   timeout: 10000 },
  'nginx-proxy-manager': { port: 81, path: '/',      signatures: ['Nginx Proxy Manager', 'NPM', 'Login'], timeout: 10000 },
  // Optional modules — only checked if enabled by the smoke test
  audiobookshelf:  { port: 13378, path: '/',         signatures: ['audiobookshelf', 'Audiobookshelf'],   timeout: 15000 },
  budget:          { port: 5006,  path: '/',         signatures: ['Actual', 'budget'],                    timeout: 10000 },
  backup:          { port: 8200,  path: '/ngax/',    signatures: ['Duplicati'],                           timeout: 10000 },
  ebooks:          { port: 8083,  path: '/',         signatures: ['calibre', 'Calibre'],                  timeout: 15000 },
  navidrome:       { port: 4533,  path: '/',         signatures: ['Navidrome'],                           timeout: 10000 },
  freshrss:        { port: 8010,  path: '/',         signatures: ['FreshRSS', 'freshrss'],                timeout: 10000 },
  gitea:           { port: 3001,  path: '/',         signatures: ['Gitea', 'gitea'],                      timeout: 15000 },
  gotify:          { port: 8070,  path: '/',         signatures: ['Gotify'],                              timeout: 10000 },
  linkding:        { port: 9925,  path: '/',         signatures: ['linkding', 'Linkding'],                timeout: 10000 },
  mealie:          { port: 9000,  path: '/',         signatures: ['Mealie'],                              timeout: 10000 },
  n8n:             { port: 5678,  path: '/',         signatures: ['n8n'],                                 timeout: 10000 },
  paperless:       { port: 8010,  path: '/',         signatures: ['Paperless'],                           timeout: 15000 },
  speedtest:       { port: 8765,  path: '/',         signatures: ['Speedtest'],                           timeout: 10000 },
  'stirling-pdf':  { port: 8080,  path: '/',         signatures: ['Stirling'],                            timeout: 10000 },
};

// --- Main ---

// Drive the dashboard's first-login UI click-through exactly as a real
// user would. This is the test we missed before 1.3.4: the server was
// returning "missing bootstrap token" on claim because compose wasn't
// forwarding SB_BOOTSTRAP_TOKEN. HTTP-level checks still passed (the
// dashboard was healthy, /api/auth/status returned 200) so nothing
// tripped until someone actually clicked through.
//
// Opts into this test when SB_BOOTSTRAP_TOKEN is set in the environment.
// DESTRUCTIVE: this claims the box and sets an admin password.
async function testFirstLogin(context) {
  const token = process.env.SB_BOOTSTRAP_TOKEN;
  if (!token) {
    console.log('[first-login] SB_BOOTSTRAP_TOKEN not set — skipping first-login UI test');
    return { status: 'skipped' };
  }
  const password = process.env.SB_TEST_PASSWORD || 'test-password-12345';
  console.log(`[first-login] driving real click-through against ${DASHBOARD_URL}`);

  const page = await context.newPage();
  const result = { scenario: 'first-login', status: 'unknown', error: null, durationMs: 0 };
  const start = Date.now();

  try {
    const resp = await page.goto(DASHBOARD_URL, { timeout: 15000, waitUntil: 'domcontentloaded' });
    if (!resp || resp.status() >= 400) {
      throw new Error(`dashboard returned HTTP ${resp && resp.status()}`);
    }
    await page.waitForSelector('#login-screen:not(.hidden)', { timeout: 10000 });

    // Dashboard's UX: the bootstrap-token field is HIDDEN on initial
    // load. The JS reveals it only after the first submit attempt comes
    // back with { bootstrapRequired: true }. We drive that flow exactly.
    await page.fill('#login-password', password);
    await page.click('#login-btn');

    // Wait for either the token field to appear (expected happy path
    // on a fresh install) OR for the dashboard to appear (impossible
    // here because a fresh install has no password). A visible error
    // message means the server gave us something other than the
    // expected bootstrap-required response.
    const tokenFieldVisible = await page.waitForSelector('#login-bootstrap-token:not(.hidden)', { timeout: 10000 }).catch(() => null);
    if (!tokenFieldVisible) {
      const errText = await page.textContent('#login-error').catch(() => '');
      throw new Error(`bootstrap token field never appeared. Login error UI said: "${(errText || '').trim() || '(empty)'}"`);
    }

    // Happy path: token field is now visible. Fill it and resubmit.
    await page.fill('#login-bootstrap-token', token);
    await page.fill('#login-password', password);
    await page.click('#login-btn');

    // After a successful claim, the dashboard screen replaces the login.
    // The login-screen element gets the 'hidden' class added, and
    // #dashboard loses it. Wait for the transition.
    await page.waitForSelector('#dashboard:not(.hidden)', { timeout: 15000 });

    // Extra sanity: the URL should still be the dashboard root (not
    // a 404 or an error redirect) and the session cookie should be set.
    const cookies = await context.cookies(DASHBOARD_URL);
    const hasSession = cookies.some(c => c.name && (c.name.includes('sid') || c.name.includes('session')));
    if (!hasSession) {
      throw new Error('dashboard UI loaded but no session cookie was set');
    }

    result.status = 'pass';
    console.log('[first-login] ✓ claimed, password set, dashboard visible, session cookie present');
  } catch (err) {
    result.status = 'fail';
    result.error = err.message.substring(0, 500);
    console.log(`[first-login] ✗ ${err.message.substring(0, 200)}`);
    await page.screenshot({ path: path.join(SCREENSHOTS_DIR, 'first-login-fail.png') }).catch(() => {});
  } finally {
    result.durationMs = Date.now() - start;
    await page.close();
  }
  return result;
}

async function runTests() {
  fs.mkdirSync(SCREENSHOTS_DIR, { recursive: true });

  console.log(`SparkBox Browser Test`);
  console.log(`Target: ${DASHBOARD_URL}`);
  console.log(`Results: ${RESULTS_FILE}`);
  console.log(`Screenshots: ${SCREENSHOTS_DIR}`);
  console.log('');

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    ignoreHTTPSErrors: true,
    viewport: { width: 1280, height: 800 },
  });

  // Run the first-login click-through BEFORE the service checks so
  // a successful claim seeds the session that subsequent tests can
  // use. When SB_BOOTSTRAP_TOKEN is not set, this is a no-op.
  const firstLogin = await testFirstLogin(context);

  const results = [];

  for (const [name, cfg] of Object.entries(SERVICES)) {
    const url = `http://${NAS_IP}:${cfg.port}${cfg.path}`;
    console.log(`[test] ${name.padEnd(22)} ${url}`);

    const result = {
      service: name,
      url,
      port: cfg.port,
      status: 'unknown',
      httpStatus: null,
      matchedSignature: null,
      title: null,
      error: null,
      durationMs: 0,
    };

    const start = Date.now();
    const page = await context.newPage();

    try {
      const response = await page.goto(url, {
        timeout: cfg.timeout,
        waitUntil: 'domcontentloaded',
      });

      result.httpStatus = response ? response.status() : null;
      result.title = await page.title().catch(() => null);

      // Wait a moment for JS-rendered content
      await page.waitForTimeout(2000);

      const bodyText = await page.evaluate(() => document.body.innerText || '').catch(() => '');
      const htmlText = await page.content();

      // Check content signatures
      const combined = `${bodyText}\n${htmlText}\n${result.title || ''}`.toLowerCase();
      for (const sig of cfg.signatures) {
        if (combined.includes(sig.toLowerCase())) {
          result.matchedSignature = sig;
          break;
        }
      }

      if (result.httpStatus && result.httpStatus < 400 && result.matchedSignature) {
        result.status = 'pass';
        console.log(`       ✓ HTTP ${result.httpStatus}, matched "${result.matchedSignature}", title: ${result.title || '(none)'}`);
      } else if (result.httpStatus && result.httpStatus < 400) {
        result.status = 'no-signature-match';
        result.error = `HTTP ${result.httpStatus} but no signature matched. Title: ${result.title}`;
        console.log(`       ! HTTP ${result.httpStatus} but no signature match`);
        // Screenshot for debugging
        await page.screenshot({ path: path.join(SCREENSHOTS_DIR, `${name}-no-match.png`) }).catch(() => {});
      } else {
        result.status = 'http-error';
        result.error = `HTTP ${result.httpStatus || 'null'}`;
        console.log(`       ✗ HTTP ${result.httpStatus || 'null'}`);
        await page.screenshot({ path: path.join(SCREENSHOTS_DIR, `${name}-http-error.png`) }).catch(() => {});
      }
    } catch (err) {
      result.status = 'unreachable';
      result.error = err.message.substring(0, 300);
      console.log(`       ✗ ${err.message.substring(0, 100)}`);
    } finally {
      result.durationMs = Date.now() - start;
      await page.close();
    }

    results.push(result);
  }

  await browser.close();

  // Write results
  fs.writeFileSync(RESULTS_FILE, JSON.stringify({
    timestamp: new Date().toISOString(),
    target: DASHBOARD_URL,
    firstLogin,
    total: results.length,
    passed: results.filter(r => r.status === 'pass').length,
    results,
  }, null, 2));

  // Summary
  console.log('');
  console.log('='.repeat(60));
  console.log('Summary');
  console.log('='.repeat(60));
  const byStatus = results.reduce((acc, r) => {
    acc[r.status] = (acc[r.status] || 0) + 1;
    return acc;
  }, {});
  for (const [status, count] of Object.entries(byStatus)) {
    console.log(`  ${status}: ${count}`);
  }

  console.log('');
  const failures = results.filter(r => r.status !== 'pass');
  if (failures.length > 0) {
    console.log('Failed services:');
    for (const r of failures) {
      console.log(`  ${r.service}: ${r.status} — ${r.error || ''}`);
    }
  }

  const firstLoginFailed = firstLogin.status === 'fail';
  if (firstLoginFailed) {
    console.log(`First-login UI test FAILED: ${firstLogin.error}`);
  }

  process.exit(failures.length > 0 || firstLoginFailed ? 1 : 0);
}

runTests().catch(err => {
  console.error('Fatal error:', err);
  process.exit(2);
});
