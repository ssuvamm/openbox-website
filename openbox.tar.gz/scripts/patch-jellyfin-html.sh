#!/usr/bin/env bash
# ============================================================
# patch-jellyfin-html.sh — drop stale cached server entries
# from Jellyfin's localStorage so users don't land on the
# "Select Server" screen when connecting from a different URL
# than they previously used.
# ============================================================
# Symptom: customer accesses Jellyfin at http://192.168.0.17:8096
# (or via NPM domain, or after IP change), gets the "Select
# Server" picker showing a cached server that doesn't match.
# Error message: "We're unable to connect to the selected
# server right now."
#
# Root cause: Jellyfin's web app stores a Servers[] array in
# localStorage key 'apiclient'. If the user has connected from
# multiple URLs, all are remembered. The app prefers the cached
# entry over the current origin, hits a stale URL, fails.
#
# Fix: inject a tiny <script> at the top of <head> that runs
# BEFORE Jellyfin's main bundle. If the cached apiclient JSON
# doesn't reference the current origin, drop the cache. The
# app then re-discovers the current origin's server fresh on
# next API call. User's auth token (stored under a separate
# key) is preserved so they don't have to re-login.
#
# Idempotent: marker comment prevents double-injection.
#
# When to run:
#   - From openbox CLI's cmd_up post-hook (re-applied every
#     time the media stack comes up — safe because of marker)
#   - Manually: sudo /opt/openbox/scripts/patch-jellyfin-html.sh
# ============================================================

set -uo pipefail

log() { printf '[patch-jellyfin-html] %s\n' "$*" >&2; }

if ! docker ps --format '{{.Names}}' 2>/dev/null | grep -qE '^ob-jellyfin-media$'; then
    log "ob-jellyfin-media not running, skipping patch"
    exit 0
fi

INDEX=/jellyfin/jellyfin-web/index.html

if ! docker exec ob-jellyfin-media test -f "${INDEX}" 2>/dev/null; then
    log "could not locate ${INDEX} inside container, skipping"
    exit 0
fi

# Idempotency check (v3 also unregisters service workers + clears
# CacheStorage when a server-ID mismatch is detected).
if docker exec ob-jellyfin-media grep -q "openbox-jellyfin-cache-v3" "${INDEX}" 2>/dev/null; then
    log "${INDEX} already at v3, skipping"
    exit 0
fi

# Strip any prior version markers before applying v3.
for prev in v1 v2; do
    if docker exec ob-jellyfin-media grep -q "openbox-jellyfin-cache-${prev}" "${INDEX}" 2>/dev/null; then
        log "stripping prior ${prev} inject"
        docker exec ob-jellyfin-media sh -c "sed -i 's#<script>/\\*openbox-jellyfin-cache-${prev}\\*/[^<]*</script>##' ${INDEX}"
    fi
done

log "patching ${INDEX} (v3: SW unregister + CacheStorage clear on Id mismatch)"

# v3 extends v2 to also nuke the service worker + Cache Storage when
# a server-ID mismatch is detected. v2 only cleared localStorage; if
# Jellyfin's service worker had stale resources cached (responses,
# script bundles), those would persist and continue serving the old
# state. Tom hit this on UGREEN — v2 fired but the SW kept serving
# the old picker UI.
#
# v3 sequence on Id mismatch:
#   1. localStorage.removeItem('apiclient')
#   2. Unregister all service worker registrations (async)
#   3. Delete all CacheStorage caches (async)
#   4. location.reload() — fetches fresh resources from origin
#
# sessionStorage 'sb-jf-chk' flag prevents reload loops within a tab.
# Sync XHR for the Id check (same-origin, ~50ms) keeps the decision
# point before defer-loaded bundles start executing.
read -r -d '' INJECT <<'JS'
<script>/*openbox-jellyfin-cache-v3*/(function(){try{var k="apiclient",raw=localStorage.getItem(k);if(!raw)return;var p;try{p=JSON.parse(raw)}catch(e){localStorage.removeItem(k);return}var cid=p&&p.Servers&&p.Servers[0]&&p.Servers[0].Id;if(!cid)return;if(sessionStorage.getItem("sb-jf-chk"))return;sessionStorage.setItem("sb-jf-chk","1");var x=new XMLHttpRequest();x.open("GET","/system/info/public",false);try{x.send()}catch(e){return}if(x.status!==200)return;var info;try{info=JSON.parse(x.responseText)}catch(e){return}if(info.Id&&info.Id!==cid){localStorage.removeItem(k);(async function(){try{if("serviceWorker" in navigator){var rs=await navigator.serviceWorker.getRegistrations();await Promise.all(rs.map(function(r){return r.unregister()}))}if("caches" in window){var ns=await caches.keys();await Promise.all(ns.map(function(n){return caches.delete(n)}))}}catch(e){}location.reload()})()}}catch(e){}})();</script>
JS

docker exec ob-jellyfin-media sh -c "sed -i 's#</head>#${INJECT}</head>#' ${INDEX}"

if docker exec ob-jellyfin-media grep -q "openbox-jellyfin-cache-v3" "${INDEX}" 2>/dev/null; then
    log "v3 patch verified — Id mismatches will clear apiclient + SW + caches, then reload"
else
    log "WARN: v3 patch did not land; ${INDEX} unchanged"
fi
