#!/usr/bin/env bash
# ==========================================
# OpenBox - Health Check Script
# Checks container health and service availability
# Supports NAS-specific checks
# ==========================================

set -euo pipefail

OB_ROOT="${OB_ROOT:-/opt/openbox}"

# Try to resolve OB_ROOT from install metadata
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "${SCRIPT_DIR}/../state/install-meta.conf" ]]; then
    meta_root=$(grep '^INSTALL_DIR=' "${SCRIPT_DIR}/../state/install-meta.conf" 2>/dev/null | cut -d= -f2 || echo "")
    [[ -n "${meta_root}" ]] && OB_ROOT="${meta_root}"
fi

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# Detect environment
IS_NAS=false
NAS_TYPE=""
if [[ -f "${OB_ROOT}/state/install-meta.conf" ]]; then
    IS_NAS=$(grep '^IS_NAS=' "${OB_ROOT}/state/install-meta.conf" 2>/dev/null | cut -d= -f2 || echo "false")
    NAS_TYPE=$(grep '^NAS_TYPE=' "${OB_ROOT}/state/install-meta.conf" 2>/dev/null | cut -d= -f2 || echo "")
fi

check_container() {
    local name="$1"
    local port="${2:-}"

    local status
    status=$(docker inspect --format='{{.State.Status}}' "${name}" 2>/dev/null || echo "not found")

    case "${status}" in
        running)
            local health
            health=$(docker inspect --format='{{if .State.Health}}{{.State.Health.Status}}{{else}}no healthcheck{{end}}' "${name}" 2>/dev/null || echo "unknown")

            if [[ "${health}" == "unhealthy" ]]; then
                echo -e "  ${YELLOW}!${NC} ${name}: running (unhealthy)"
                return 1
            else
                echo -e "  ${GREEN}+${NC} ${name}: running"
            fi

            if [[ -n "${port}" ]]; then
                if curl -sf -o /dev/null --connect-timeout 3 "http://localhost:${port}" 2>/dev/null; then
                    echo -e "      Port ${port}: ${GREEN}responding${NC}"
                else
                    echo -e "      Port ${port}: ${YELLOW}not responding${NC}"
                fi
            fi
            return 0
            ;;
        *)
            echo -e "  ${RED}x${NC} ${name}: ${status}"
            return 1
            ;;
    esac
}

echo "OpenBox Health Check"
echo "====================="
if [[ "${IS_NAS}" == "true" ]]; then
    echo "Environment: NAS (${NAS_TYPE})"
fi
echo ""

errors=0

# Docker daemon check
echo "Docker:"
if docker info &>/dev/null 2>&1; then
    echo -e "  ${GREEN}+${NC} Docker daemon: running"
else
    echo -e "  ${RED}x${NC} Docker daemon: not accessible"
    ((errors++))
    echo ""
    echo "Cannot continue without Docker access."
    if [[ "${IS_NAS}" == "true" ]]; then
        echo "Check that Docker is running on your NAS and you have permissions."
    fi
    exit ${errors}
fi

if docker compose version &>/dev/null 2>&1; then
    echo -e "  ${GREEN}+${NC} Docker Compose: $(docker compose version --short 2>/dev/null)"
else
    echo -e "  ${RED}x${NC} Docker Compose v2: not found"
    ((errors++))
fi
echo ""

# Core
echo "Core:"
check_container "ob-npm" "81" || ((errors++))
check_container "ob-portainer" "9000" || ((errors++))
check_container "ob-homepage" "3000" || ((errors++))
echo ""

# Dashboard
echo "Dashboard:"
check_container "ob-dashboard" "8443" || ((errors++))
echo ""

# Check optional modules based on running containers
if docker inspect ob-pihole &>/dev/null 2>&1; then
    echo "Privacy:"
    check_container "ob-pihole" "8053" || ((errors++))
    check_container "ob-vaultwarden" "8222" || ((errors++))
    check_container "ob-authelia" "9091" || ((errors++))
    echo ""
fi

if docker inspect ob-nextcloud &>/dev/null 2>&1; then
    echo "Cloud:"
    check_container "ob-nextcloud" || ((errors++))
    check_container "ob-nextcloud-db" || ((errors++))
    check_container "ob-nextcloud-redis" || ((errors++))
    echo ""
fi

if docker inspect ob-uptime-kuma &>/dev/null 2>&1; then
    echo "Monitoring:"
    check_container "ob-uptime-kuma" "3001" || ((errors++))
    echo ""
fi

if docker inspect ob-wg-easy &>/dev/null 2>&1; then
    echo "VPN Access:"
    check_container "ob-wg-easy" "51821" || ((errors++))
    echo ""
fi

# Media module containers (full media stack uses ob-jellyfin-media)
if docker inspect ob-jellyfin-media &>/dev/null 2>&1; then
    echo "Media - Jellyfin (Media Module):"
    check_container "ob-jellyfin-media" "8096" || ((errors++))
    echo ""
elif docker inspect ob-jellyfin &>/dev/null 2>&1; then
    echo "Media - Jellyfin (Standalone):"
    check_container "ob-jellyfin" "8096" || ((errors++))
    echo ""
fi

if docker inspect ob-sonarr &>/dev/null 2>&1; then
    echo "Media - Arr Stack:"
    check_container "ob-sonarr" "8989" || ((errors++))
    check_container "ob-radarr" "7878" || ((errors++))
    check_container "ob-prowlarr" "8181" || ((errors++))
    check_container "ob-qbittorrent" "8080" || ((errors++))
    echo ""
fi

if docker inspect ob-gluetun &>/dev/null 2>&1; then
    echo "Download VPN:"
    check_container "ob-gluetun" || ((errors++))
    echo ""
fi

if docker inspect ob-immich-server &>/dev/null 2>&1; then
    echo "Photos - Immich:"
    check_container "ob-immich-server" "2283" || ((errors++))

    # Check if immich-ml is running but models are missing
    if docker inspect ob-immich-ml &>/dev/null 2>&1; then
        ml_status=$(docker inspect --format='{{.State.Status}}' ob-immich-ml 2>/dev/null || echo "not found")
        if [[ "${ml_status}" == "running" ]]; then
            model_dir="${OB_ROOT}/modules/immich/config/model-cache"
            if [[ -d "${model_dir}" ]]; then
                model_count=$(find "${model_dir}" -type f 2>/dev/null | head -1)
                if [[ -z "${model_count}" ]]; then
                    echo -e "  ${YELLOW}!${NC} immich-ml: running but model cache is empty"
                    echo -e "      ML features (face recognition, smart search) will not work."
                    echo -e "      Temporarily allow internet access so models can download."
                    ((errors++))
                fi
            else
                echo -e "  ${YELLOW}!${NC} immich-ml: model cache directory not found"
                echo -e "      Temporarily allow internet access so models can download."
                ((errors++))
            fi
        fi
    fi
    echo ""
fi

# --- NAS-specific health checks ---

if [[ "${IS_NAS}" == "true" ]]; then
    echo "NAS-Specific:"

    # Docker socket access
    if [[ -S /var/run/docker.sock ]]; then
        if [[ -r /var/run/docker.sock ]]; then
            echo -e "  ${GREEN}+${NC} Docker socket: accessible"
        else
            echo -e "  ${YELLOW}!${NC} Docker socket: not readable (permission issue)"
            ((errors++))
        fi
    else
        echo -e "  ${YELLOW}!${NC} Docker socket: not at default path"
    fi

    # Hardware transcoding
    if [[ -f "${OB_ROOT}/.env" ]]; then
        hw_accel=$(grep '^JELLYFIN_HW_ACCEL=' "${OB_ROOT}/.env" 2>/dev/null | cut -d= -f2 || echo "")
        if [[ "${hw_accel}" == "intel" || "${hw_accel}" == "auto" ]]; then
            if [[ -e /dev/dri/renderD128 ]]; then
                echo -e "  ${GREEN}+${NC} GPU transcoding: device available"
            else
                echo -e "  ${YELLOW}!${NC} GPU transcoding: enabled but /dev/dri/renderD128 not found"
                ((errors++))
            fi
        fi
    fi

    # PUID/PGID match
    if [[ -f "${OB_ROOT}/.env" ]]; then
        env_puid=$(grep '^PUID=' "${OB_ROOT}/.env" 2>/dev/null | cut -d= -f2 || echo "")
        current_uid=$(id -u)
        if [[ -n "${env_puid}" && "${env_puid}" != "${current_uid}" && "${current_uid}" != "0" ]]; then
            echo -e "  ${YELLOW}!${NC} PUID mismatch: .env=${env_puid}, current user=$(id -u)"
            ((errors++))
        else
            echo -e "  ${GREEN}+${NC} PUID: consistent"
        fi
    fi

    # Media root check
    if [[ -f "${OB_ROOT}/.env" ]]; then
        media_root=$(grep '^MEDIA_ROOT=' "${OB_ROOT}/.env" 2>/dev/null | cut -d= -f2 || echo "")
        if [[ -n "${media_root}" ]]; then
            if [[ -d "${media_root}" && -w "${media_root}" ]]; then
                echo -e "  ${GREEN}+${NC} Media root: ${media_root} (accessible)"
            elif [[ -d "${media_root}" ]]; then
                echo -e "  ${YELLOW}!${NC} Media root: ${media_root} (not writable)"
                ((errors++))
            else
                echo -e "  ${RED}x${NC} Media root: ${media_root} (does not exist)"
                ((errors++))
            fi
        fi
    fi
    echo ""
fi

# Summary
echo "====================="
if [[ ${errors} -eq 0 ]]; then
    echo -e "${GREEN}All services healthy.${NC}"
else
    echo -e "${YELLOW}${errors} issue(s) detected.${NC}"
fi

exit ${errors}
