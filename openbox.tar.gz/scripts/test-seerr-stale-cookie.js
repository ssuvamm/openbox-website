// Reproduces Tom's exact symptom: stale Secure-flag connect.sid cookie
// from before the v5 fix. Browser refuses to overwrite Secure attrs
// even though server now sends non-Secure cookies.

const { chromium } = require('playwright');

const SEERR_URL = process.env.SEERR_URL || 'http://192.168.0.17:5055';

(async () => {
  console.log('=== Stale-cookie reproduction test ===');
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();

  // Pre-seed a fake Secure connect.sid cookie BEFORE any page load.
  // Simulates Tom's browser state from pre-v5 fix where Seerr issued
  // Secure cookies that Chrome remembered.
  await context.addCookies([{
    name: 'connect.sid',
    value: 's%3Astale-fake-prev-secure.session',
    domain: '192.168.0.17',
    path: '/',
    secure: true,    // ← the killer attribute
    httpOnly: true,
    sameSite: 'Lax',
    expires: Math.floor(Date.now() / 1000) + 86400 * 30,
  }]).catch(e => console.log('  could not pre-seed Secure cookie:', e.message));

  const page = await context.newPage();

  console.log(`[1] open ${SEERR_URL}/ with stale Secure cookie pre-seeded`);
  await page.goto(`${SEERR_URL}/`, { waitUntil: 'networkidle' });

  // Check what cookies are sent / present after first navigation
  const cookies = await context.cookies();
  const sid = cookies.find(c => c.name === 'connect.sid');
  console.log('  cookies present after first GET:', cookies.map(c => `${c.name}(secure=${c.secure})`).join(', '));
  console.log('  url after redirect:', page.url());

  // Now login fresh
  console.log('[2] perform fresh login');
  if (page.url().includes('/login')) {
    await page.locator('input#username').fill('sparkbox');
    await page.locator('input#password').fill('gpBIVC5azPIyk5LWPb8T');
    await page.locator('button[type="submit"]').click();
    await page.waitForURL(url => !url.toString().includes('/login'), { timeout: 20000 });
  }

  const cookiesAfterLogin = await context.cookies();
  const sidAfter = cookiesAfterLogin.find(c => c.name === 'connect.sid');
  console.log('  connect.sid after login: secure=' + (sidAfter?.secure ?? 'MISSING'));

  // Idle + reload (Tom's flow)
  console.log('[3] idle 30s + reload');
  await page.waitForTimeout(30000);
  await page.reload({ waitUntil: 'networkidle' });
  const finalUrl = page.url();
  console.log('  final url:', finalUrl);
  const finalCookies = await context.cookies();
  const finalSid = finalCookies.find(c => c.name === 'connect.sid');
  console.log('  connect.sid present after idle+reload:', !!finalSid, '(secure=' + finalSid?.secure + ')');

  await browser.close();
  process.exit(finalUrl.includes('/login') ? 1 : 0);
})();
