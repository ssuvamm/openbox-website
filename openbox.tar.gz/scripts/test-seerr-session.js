// Headless Seerr session-persistence test.
// Simulates: log in via Jellyfin → navigate around → idle → re-navigate.
// Asserts user stays logged in throughout (never lands on /login).
//
// Run: NODE_PATH=/tmp/ob-qa-deps/node_modules node seerr-session-test.js
//
// Args via env:
//   SEERR_URL  (default http://192.168.0.17:5055)
//   USERNAME   (default sparkbox)
//   PASSWORD   (default gpBIVC5azPIyk5LWPb8T)
//   IDLE_SEC   (default 30)

const { chromium } = require('playwright');

const SEERR_URL = process.env.SEERR_URL || 'http://192.168.0.17:5055';
const USERNAME  = process.env.USERNAME  || 'sparkbox';
const PASSWORD  = process.env.PASSWORD  || 'gpBIVC5azPIyk5LWPb8T';
const IDLE_SEC  = parseInt(process.env.IDLE_SEC || '30', 10);

function log(msg) { console.log(`[${new Date().toISOString()}] ${msg}`); }

async function getConnectSidCookie(context) {
  const cookies = await context.cookies();
  return cookies.find(c => c.name === 'sb.sid');
}

async function logCookieState(context, label) {
  const cookies = await context.cookies();
  const sid = cookies.find(c => c.name === 'sb.sid');
  const others = cookies.filter(c => c.name !== 'sb.sid').map(c => c.name);
  if (sid) {
    log(`  ${label}: sb.sid PRESENT (Secure=${sid.secure}, SameSite=${sid.sameSite}, Path=${sid.path}, expires in ${Math.round((sid.expires - Date.now()/1000) / 60)}min)`);
  } else {
    log(`  ${label}: sb.sid MISSING ❌  other cookies: [${others.join(', ')}]`);
  }
}

async function isOnLoginPage(page) {
  const url = page.url();
  if (url.includes('/login')) return true;
  // Check if the page title or body indicates login
  const hasJellyfinLogin = await page.locator('text=Use your Jellyfin account').count().catch(() => 0);
  const hasSignIn = await page.locator('button:has-text("Sign In")').count().catch(() => 0);
  return hasJellyfinLogin > 0 || hasSignIn > 0;
}

(async () => {
  log(`=== Seerr session-persistence test ===`);
  log(`URL: ${SEERR_URL}`);
  log(`Idle window: ${IDLE_SEC}s`);

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  let pass = true;
  const fail = (msg) => { log(`❌ FAIL: ${msg}`); pass = false; };

  try {
    // 1. Open root, expect redirect to /login
    log(`[1] open ${SEERR_URL}/`);
    await page.goto(`${SEERR_URL}/`, { waitUntil: 'networkidle' });
    await logCookieState(context, 'after first GET');

    if (!(await isOnLoginPage(page))) {
      log(`  unexpectedly already logged in (cookies from prior run?)`);
    } else {
      // Login page on UGREEN Seerr goes straight to Jellyfin form
      // (it's the only configured auth backend). No mode-picker button.
      log(`[2] fill jellyfin login form`);
      await page.locator('input#username').waitFor({ timeout: 10000 });
      await page.locator('input#username').fill(USERNAME);
      await page.locator('input#password').fill(PASSWORD);
      await page.locator('button[type="submit"]').click();

      log(`[3] wait for post-login redirect`);
      await page.waitForURL(url => !url.toString().includes('/login'), { timeout: 20000 });
      log(`  landed on ${page.url()}`);
      await logCookieState(context, 'after login');
    }

    const sidAfterLogin = await getConnectSidCookie(context);
    if (!sidAfterLogin) fail('sb.sid not set after login');

    // 5. Navigate around — exercise SSR pages
    log(`[5] navigate /discover/movies`);
    await page.goto(`${SEERR_URL}/discover/movies`, { waitUntil: 'networkidle' });
    if (await isOnLoginPage(page)) fail('bounced to /login after navigating /discover/movies');
    await logCookieState(context, 'after /discover/movies');

    log(`[6] navigate /movie/550 (Fight Club)`);
    await page.goto(`${SEERR_URL}/movie/550`, { waitUntil: 'networkidle' });
    if (await isOnLoginPage(page)) fail('bounced to /login after navigating /movie/550');
    await logCookieState(context, 'after /movie/550');

    // 7. Idle the tab — simulating user leaving page open
    log(`[7] idle for ${IDLE_SEC}s (simulating user leaving page open)`);
    await page.waitForTimeout(IDLE_SEC * 1000);
    await logCookieState(context, `after ${IDLE_SEC}s idle`);

    // 8. Now navigate to a new page after idle — this is when the bug fires
    log(`[8] navigate /tv/1399 (GoT) after idle`);
    await page.goto(`${SEERR_URL}/tv/1399`, { waitUntil: 'networkidle' });
    if (await isOnLoginPage(page)) fail('bounced to /login after idle + navigate (THE BUG)');
    await logCookieState(context, 'after post-idle navigate');

    // 9. Reload current page after idle
    log(`[9] reload after idle`);
    await page.reload({ waitUntil: 'networkidle' });
    if (await isOnLoginPage(page)) fail('bounced to /login after reload post-idle');
    await logCookieState(context, 'after post-idle reload');

    // 10. Click into search (simulates Tom's actual action)
    log(`[10] go to search-style page /search?query=fight`);
    await page.goto(`${SEERR_URL}/search?query=fight`, { waitUntil: 'networkidle' });
    if (await isOnLoginPage(page)) fail('bounced to /login on search page');
    await logCookieState(context, 'after search');

    // 11. Type into the search bar (simulates ABO's "looking for a movie")
    log(`[11] navigate home + type in search`);
    await page.goto(`${SEERR_URL}/`, { waitUntil: 'networkidle' });
    const searchBox = page.locator('input[type="search"], input[placeholder*="Search" i]').first();
    if (await searchBox.count() > 0) {
      await searchBox.click();
      await searchBox.fill('fight club');
      await page.waitForTimeout(1500); // SWR fires
      if (await isOnLoginPage(page)) fail('bounced to /login on search-as-you-type');
      await logCookieState(context, 'after search-as-you-type');

      // Click first result (this is what Tom did when he got bounced)
      const firstResult = page.locator('a[href*="/movie/"]').first();
      const resultCount = await firstResult.count().catch(() => 0);
      if (resultCount > 0) {
        log(`[12] click first search result`);
        await firstResult.click();
        await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
        if (await isOnLoginPage(page)) fail('bounced to /login on clicking search result');
        await logCookieState(context, 'after click result');
      }
    } else {
      log(`  no search box found — skipping search-as-you-type test`);
    }

    // 13. Multi-tab test: open a second tab, share cookies, navigate
    log(`[13] open second tab + navigate concurrently`);
    const page2 = await context.newPage();
    await page2.goto(`${SEERR_URL}/discover/tv`, { waitUntil: 'networkidle' });
    if (await isOnLoginPage(page2)) fail('bounced to /login in second tab');
    await page2.close();

    // 14. Final: longer idle (60s) + post-idle nav. Captures slower-firing bugs.
    if (process.env.LONG_IDLE === '1') {
      log(`[14] long idle (60s)`);
      await page.waitForTimeout(60000);
      log(`[15] navigate after long idle`);
      await page.goto(`${SEERR_URL}/movie/550`, { waitUntil: 'networkidle' });
      if (await isOnLoginPage(page)) fail('bounced to /login after 60s idle');
      await logCookieState(context, 'after 60s idle');
    }

  } catch (err) {
    fail(`exception: ${err.message}`);
    log(err.stack);
  } finally {
    await browser.close();
  }

  log(`=== ${pass ? 'PASS ✅' : 'FAIL ❌'} ===`);
  process.exit(pass ? 0 : 1);
})();
