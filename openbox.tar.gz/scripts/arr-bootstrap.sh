#!/usr/bin/env bash
# ============================================================
# OpenBox ARR auto-config bootstrap
# ============================================================
# After the media module is installed, this script wires up
# Sonarr / Radarr / Prowlarr / Bazarr / qBittorrent so the user
# doesn't have to copy-paste API keys between five web UIs.
#
# What it does:
#   1. Generates a stable API key per *arr app (deterministic from
#      the OpenBox install ID, persisted to state/arr-api-keys.json)
#   2. Pre-writes each app's config.xml with the known API key +
#      LAN-only auth defaults (so we don't have to scrape keys
#      from a running app's API)
#   3. Restarts each *arr to pick up the new config
#   4. Waits for each app to be HTTP-reachable
#   5. POSTs to Sonarr + Radarr to register qBittorrent as the
#      download client (host=gluetun, port=8089, password from
#      state/qbittorrent-admin-password.txt)
#   6. POSTs to Prowlarr to register Sonarr + Radarr as
#      "applications" — Prowlarr then auto-pushes any indexer
#      added in its UI to both *arr apps
#   7. Marks state/arr-bootstrapped with a timestamp so we don't
#      re-run on every install/upgrade
#
# Idempotent: if state/arr-bootstrapped exists, the script exits
# without doing anything. To force re-run: delete state/arr-bootstrapped.
#
# Doesn't touch Bazarr in this version — Bazarr's config is INI,
# not XML, and it has different first-run requirements. Add later.
# ============================================================

set -uo pipefail

OB_ROOT="${OB_ROOT:-/opt/openbox}"
STATE_DIR="${OB_ROOT}/state"
KEYS_FILE="${STATE_DIR}/arr-api-keys.json"
DONE_MARKER="${STATE_DIR}/arr-bootstrapped"
LOG_FILE="${STATE_DIR}/arr-bootstrap.log"

# Hostname + port map we reach the /arr APIs at.
#
# On the host: 127.0.0.1:<APPS_PORT_HOST>. Gluetun publishes each /arr
# container port to a specific host port (some remapped like prowlarr
# 9696→8181 to avoid collisions).
#
# From a helper container on sparkbox_ob-media (ARR_USE_DOCKER_DNS=1,
# used by the dashboard-spawned auto-fire): ob-gluetun:<APPS_PORT_INTERNAL>.
# Docker publish-ports are HOST-only — from inside the media network we
# have to use the container's actual listening port (9696 for prowlarr,
# not 8181). Otherwise connects refuse silently.
if [[ "${ARR_USE_DOCKER_DNS:-}" == "1" ]]; then
    ARR_HOST="ob-gluetun"
    ARR_USE_INTERNAL_PORTS=1
else
    ARR_HOST="127.0.0.1"
    ARR_USE_INTERNAL_PORTS=0
fi

# arr_port_for <app> — returns the port to reach the /arr at, given the
# current network context (host vs docker network).
arr_port_for() {
    local app="$1"
    if [[ "${ARR_USE_INTERNAL_PORTS}" == "1" ]]; then
        echo "${APPS_PORT_INTERNAL[$app]}"
    else
        echo "${APPS_PORT_HOST[$app]}"
    fi
}

# Apps the script knows how to wire.
#
# Two port maps because gluetun's port forwarding sometimes
# remaps internal→host (e.g. prowlarr internal 9696 → host 8181):
#   - APPS_PORT_INTERNAL: what the app listens on inside its
#     network namespace. Used for the app's own config.xml AND
#     for service-to-service calls (Sonarr → qBit, Prowlarr →
#     Sonarr) since *arr + qBit all share gluetun's namespace.
#   - APPS_PORT_HOST: what gluetun forwards to the host. Used
#     when this script (running on the host) curls the apps.
declare -A APPS_PORT_INTERNAL=(
    [sonarr]=8989
    [radarr]=7878
    [prowlarr]=9696
)
declare -A APPS_PORT_HOST=(
    [sonarr]=8989
    [radarr]=7878
    [prowlarr]=8181
)
# qBittorrent: internal port (used by *arr → qBit config) is 8080,
# host-exposed port is 8089. Only the internal value matters for
# the bootstrap script.
QBIT_PORT_INTERNAL=8080

declare -A APPS_DIR=(
    [sonarr]="modules/media/config/sonarr"
    [radarr]="modules/media/config/radarr"
    [prowlarr]="modules/media/config/prowlarr"
)

log() { printf '[arr-bootstrap] %s\n' "$*" | tee -a "${LOG_FILE}" >&2; }
die() { log "ERROR: $*"; exit 1; }

# Already bootstrapped — usually exit cleanly, but first run a quick
# self-heal pass for root folders. The 2026-04-30 paid-beta test
# caught a class of customer where bootstrap ran but skipped root
# folder registration (qBit pw file wasn't ready at bootstrap time,
# and the old script gated rootfolder behind that). On next bootstrap
# attempt, the marker existed and the buggy branch never re-ran. Now
# we re-attempt rootfolder on EVERY bootstrap invocation — it's
# idempotent (skips if already registered) and costs ~2 API calls.
# Customers who already ran the buggy version get healed silently
# without needing a manual `rm /opt/openbox/state/arr-bootstrapped`.
if [[ -f "${DONE_MARKER}" ]]; then
    log "Already bootstrapped at $(cat "${DONE_MARKER}" 2>/dev/null). Running re-runnable self-heal passes before exit."
    if [[ -f "${KEYS_FILE}" ]]; then
        # Pull keys from the persisted JSON written by step 1 below.
        SONARR_KEY=$(grep -oE '"sonarr"[ ]*:[ ]*"[a-f0-9]{32}"' "${KEYS_FILE}" 2>/dev/null | grep -oE '[a-f0-9]{32}')
        RADARR_KEY=$(grep -oE '"radarr"[ ]*:[ ]*"[a-f0-9]{32}"' "${KEYS_FILE}" 2>/dev/null | grep -oE '[a-f0-9]{32}')
        PROWLARR_KEY=$(grep -oE '"prowlarr"[ ]*:[ ]*"[a-f0-9]{32}"' "${KEYS_FILE}" 2>/dev/null | grep -oE '[a-f0-9]{32}')
        if [[ -n "${SONARR_KEY}" && -n "${RADARR_KEY}" ]]; then
            heal_rootfolder() {
                local app="$1" key="$2" port="$3" path="$4"
                local existing
                existing=$(curl -sS -m 8 -H "X-Api-Key: ${key}" "http://${ARR_HOST}:${port}/api/v3/rootfolder" 2>/dev/null || echo '[]')
                if echo "${existing}" | grep -q "\"path\":\"${path}\""; then
                    return 0
                fi
                local resp
                resp=$(curl -sS -m 10 -X POST -H "X-Api-Key: ${key}" -H 'Content-Type: application/json' \
                    -d "{\"path\":\"${path}\"}" "http://${ARR_HOST}:${port}/api/v3/rootfolder" 2>&1)
                if echo "${resp}" | grep -qE '"id":[0-9]+'; then
                    log "self-heal: ${app}: root folder ${path} registered."
                fi
            }
            heal_rootfolder radarr "${RADARR_KEY}" "$(arr_port_for radarr)" "/data/Movies"
            heal_rootfolder sonarr "${SONARR_KEY}" "$(arr_port_for sonarr)" "/data/TV"
        fi
        # Self-heal pass 2: FlareSolverr proxy registration. v1.6.4 fix —
        # if customer enables the flaresolverr module AFTER the initial
        # arr-bootstrap finished (module is opt-in), the proxy registration
        # never fired and Cloudflare-protected indexers can't bypass.
        # This re-runs the registration on every 'openbox up' if
        # ob-flaresolverr is now live but the proxy isn't registered yet.
        register_flaresolverr_self_heal() {
            local prowlarr_key="$1"
            local pwl_url="http://${ARR_HOST}:$(arr_port_for prowlarr)"
            local existing_proxy
            existing_proxy=$(curl -sS -m 8 -H "X-Api-Key: ${prowlarr_key}" "${pwl_url}/api/v1/indexerproxy" 2>/dev/null || echo '[]')
            if echo "${existing_proxy}" | grep -q '"implementation":"FlareSolverr"'; then
                return 0
            fi
            log "self-heal: ob-flaresolverr is live but Prowlarr proxy isn't registered. Registering now."
            local existing_tag tag_id
            existing_tag=$(curl -sS -m 8 -H "X-Api-Key: ${prowlarr_key}" "${pwl_url}/api/v1/tag" 2>/dev/null || echo '[]')
            tag_id=$(echo "${existing_tag}" | python3 -c "import sys,json
try:
    d=json.load(sys.stdin)
    m=[t['id'] for t in d if t.get('label')=='flaresolverr']
    print(m[0] if m else '')
except Exception:
    print('')" 2>/dev/null)
            if [[ -z "${tag_id}" ]]; then
                local tag_resp
                tag_resp=$(curl -sS -m 10 -X POST -H "X-Api-Key: ${prowlarr_key}" -H 'Content-Type: application/json' \
                    -d '{"label":"flaresolverr"}' "${pwl_url}/api/v1/tag" 2>/dev/null)
                tag_id=$(echo "${tag_resp}" | python3 -c "import sys,json
try:
    print(json.load(sys.stdin).get('id',''))
except Exception:
    print('')" 2>/dev/null)
                log "self-heal: created flaresolverr tag (id=${tag_id})."
            fi
            if [[ -n "${tag_id}" ]]; then
                curl -sS -m 10 -X POST -H "X-Api-Key: ${prowlarr_key}" -H 'Content-Type: application/json' \
                    -d "{\"name\":\"FlareSolverr\",\"implementation\":\"FlareSolverr\",\"configContract\":\"FlareSolverrSettings\",\"onHealthIssue\":false,\"includeHealthWarnings\":false,\"fields\":[{\"name\":\"host\",\"value\":\"http://localhost:8191/\"},{\"name\":\"requestTimeout\",\"value\":60}],\"tags\":[${tag_id}]}" \
                    "${pwl_url}/api/v1/indexerproxy" >/dev/null 2>&1 \
                    && log "self-heal: FlareSolverr proxy registered. Tag indexers with 'flaresolverr' to route via the bypass."
            fi
        }
        if [[ -n "${PROWLARR_KEY}" ]] && docker ps --format '{{.Names}}' 2>/dev/null | grep -qx 'ob-flaresolverr'; then
            register_flaresolverr_self_heal "${PROWLARR_KEY}"
        fi
        # Self-heal pass 3: suppress in-app 'update available' UI on
        # *arr apps. v1.6.4 fix — Prowlarr/Sonarr/Radarr's internal
        # updaters point at upstream packages we don't ship; clicking
        # them inside the Docker container fails or breaks state.
        # Setting updateMechanism=Docker tells the *arr app to stop
        # showing the misleading prompt. Idempotent — only PUTs if the
        # current value is wrong.
        suppress_internal_updater() {
            local app="$1" key="$2" port="$3" api_version="$4"
            local cur
            cur=$(curl -sS -m 8 -H "X-Api-Key: ${key}" "http://${ARR_HOST}:${port}/api/${api_version}/config/host" 2>/dev/null || echo '{}')
            if echo "${cur}" | grep -q '"updateMechanism":"docker"'; then
                return 0
            fi
            # PUT requires the full host-config payload back; mutate just the field
            local patched
            patched=$(echo "${cur}" | python3 -c "import sys,json; d=json.load(sys.stdin); d['updateMechanism']='docker'; print(json.dumps(d))" 2>/dev/null)
            if [[ -z "${patched}" ]]; then
                return 0
            fi
            curl -sS -m 10 -X PUT -H "X-Api-Key: ${key}" -H 'Content-Type: application/json' \
                -d "${patched}" "http://${ARR_HOST}:${port}/api/${api_version}/config/host" >/dev/null 2>&1 \
                && log "self-heal: ${app}: in-app 'update available' UI suppressed (updateMechanism=docker)."
        }
        [[ -n "${SONARR_KEY}" ]]   && suppress_internal_updater sonarr   "${SONARR_KEY}"   "$(arr_port_for sonarr)"   v3
        [[ -n "${RADARR_KEY}" ]]   && suppress_internal_updater radarr   "${RADARR_KEY}"   "$(arr_port_for radarr)"   v3
        [[ -n "${PROWLARR_KEY}" ]] && suppress_internal_updater prowlarr "${PROWLARR_KEY}" "$(arr_port_for prowlarr)" v1
    fi
    exit 0
fi

mkdir -p "${STATE_DIR}"

# Ensure the dashboard's container user (uid 1000) can chmod state files
# it writes. arr-bootstrap runs via sudo (root), so any state file it
# creates is root-owned. The dashboard's permission-migration step runs
# as uid 1000 inside the container and needs to chmod those files to
# 0600 — a non-root user can't chmod root-owned files (EPERM).
# Caught 2026-05-01 deep test pass: dashboard logged 24× "could not
# chmod ... EPERM: operation not permitted" on every restart until
# state was chowned to 1000:1000.
PUID_VAL=$(grep '^PUID=' "${OB_ROOT}/.env" 2>/dev/null | tail -1 | cut -d= -f2)
PGID_VAL=$(grep '^PGID=' "${OB_ROOT}/.env" 2>/dev/null | tail -1 | cut -d= -f2)
chown -R "${PUID_VAL:-1000}:${PGID_VAL:-1000}" "${STATE_DIR}" 2>/dev/null || true

# ---- Step 1: API keys ----
# Generate or load per-app API keys. Each is a 32-char hex string,
# matching the format the *arr apps use natively (so they look
# native if the user later inspects them in the UI).
gen_key() {
    if command -v openssl >/dev/null 2>&1; then
        openssl rand -hex 16
    elif [[ -r /dev/urandom ]]; then
        head -c 16 /dev/urandom | xxd -p 2>/dev/null || head -c 16 /dev/urandom | od -An -tx1 | tr -d ' \n'
    else
        die "Need openssl or /dev/urandom to generate API keys"
    fi
}

if [[ ! -f "${KEYS_FILE}" ]]; then
    log "Generating new API keys for sonarr, radarr, prowlarr."
    cat > "${KEYS_FILE}" <<EOF
{
  "sonarr": "$(gen_key)",
  "radarr": "$(gen_key)",
  "prowlarr": "$(gen_key)"
}
EOF
    chmod 600 "${KEYS_FILE}"
fi

# Tiny JSON reader — pulls a top-level key. Avoids jq dependency.
get_key() {
    grep -oE "\"$1\":[[:space:]]*\"[^\"]+\"" "${KEYS_FILE}" | sed -E 's/.*"([^"]+)".*$/\1/'
}

SONARR_KEY="$(get_key sonarr)"
RADARR_KEY="$(get_key radarr)"
PROWLARR_KEY="$(get_key prowlarr)"

[[ -z "${SONARR_KEY}" || -z "${RADARR_KEY}" || -z "${PROWLARR_KEY}" ]] \
    && die "Failed to read API keys from ${KEYS_FILE}"

log "API keys loaded."

# ---- Step 2: Pre-write each *arr's config.xml ----
# Each app reads /config/config.xml on startup. We pre-write it with our
# known API key + a LAN-trust auth posture so the customer doesn't see
# a login wall on first click.
#
# v1.6.56 reverted v1.6.40's switch to Forms+Enabled. Tom's call after
# extended customer-feel testing: the per-app login wall on first visit
# is annoying enough to undermine OpenBox's "1-shot automated" UX
# promise, even with the v1.6.42 seeded admin + v1.6.44 launcher modal
# surfacing creds. For a single-operator home NAS the LAN-exposure that
# v1.6.40 closed is a paper threat — the realistic attacker pool is
# small, the practical cost (every fresh install demands three logins)
# is daily.
#
# Default is back to External + DisabledForLocalAddresses: anyone on
# the LAN walks straight in. The seeded admin user (v1.6.42) stays
# in each *arr's Users table — harmless when External is the default,
# and lets the user opt in to Forms-with-login at any time via Settings
# → General → "Trust my LAN" (toggle OFF = require login). That toggle's
# /api/arr-auth/state POST flips both AuthenticationMethod values atomically
# and recreates the *arr containers so the change actually takes effect.
write_config_xml() {
    local app="$1" key="$2" port="$3"
    local cfg="${OB_ROOT}/${APPS_DIR[$app]}/config.xml"
    mkdir -p "$(dirname "${cfg}")"
    cat > "${cfg}" <<EOF
<Config>
  <BindAddress>*</BindAddress>
  <Port>${port}</Port>
  <SslPort>$((port + 1000))</SslPort>
  <EnableSsl>False</EnableSsl>
  <LaunchBrowser>False</LaunchBrowser>
  <ApiKey>${key}</ApiKey>
  <AuthenticationMethod>External</AuthenticationMethod>
  <AuthenticationRequired>DisabledForLocalAddresses</AuthenticationRequired>
  <Branch>main</Branch>
  <LogLevel>info</LogLevel>
  <SslCertHash></SslCertHash>
  <UrlBase></UrlBase>
  <InstanceName>${app^}</InstanceName>
</Config>
EOF
    chown 1000:1000 "${cfg}" 2>/dev/null || true
    chmod 600 "${cfg}"
    log "Wrote ${cfg}"
}

write_config_xml sonarr   "${SONARR_KEY}"   "${APPS_PORT_INTERNAL[sonarr]}"
write_config_xml radarr   "${RADARR_KEY}"   "${APPS_PORT_INTERNAL[radarr]}"
write_config_xml prowlarr "${PROWLARR_KEY}" "${APPS_PORT_INTERNAL[prowlarr]}"

# ---- Step 3: Restart each *arr so it picks up the new key ----
# Containers were already started by `openbox up` earlier; we just
# bounce them. If a container doesn't exist, skip silently — the
# user may have only enabled some of the *arr apps.
for app in sonarr radarr prowlarr; do
    if docker ps -a --format '{{.Names}}' | grep -q "^ob-${app}$"; then
        log "Restarting ob-${app} to pick up new config."
        docker restart "sb-${app}" >/dev/null 2>&1 || log "WARN: restart ob-${app} failed (continuing)"
    fi
done

# ---- Step 4: Wait for each app's HTTP API to come up ----
# We hit /ping (Sonarr/Radarr/Prowlarr all expose this unauthenticated)
# and consider an HTTP 200 as ready. Cap at 90s per app.
wait_for_app() {
    local app="$1" port="$2" deadline=$(( $(date +%s) + 90 ))
    while [[ $(date +%s) -lt ${deadline} ]]; do
        local code
        code=$(curl -sS -m 5 -o /dev/null -w '%{http_code}' "http://${ARR_HOST}:${port}/ping" 2>/dev/null || echo 000)
        if [[ "${code}" == "200" ]]; then
            log "${app} ready."
            return 0
        fi
        sleep 3
    done
    log "WARN: ${app} didn't respond on /ping within 90s — continuing anyway"
    return 1
}

wait_for_app sonarr   "$(arr_port_for sonarr)"
wait_for_app radarr   "$(arr_port_for radarr)"
wait_for_app prowlarr "$(arr_port_for prowlarr)"

# ---- Step 4.5: Seed an admin user in each *arr's Users table ----
# v1.6.40 set AuthenticationMethod=Forms+Enabled in config.xml to close
# a LAN-exposure gap, but Sonarr/Radarr/Prowlarr don't expose a self-
# service "first user" UI when Forms is set in config.xml — so every
# fresh install shipped three apps with login forms and no way to log
# in. Caught 2026-05-05 during pre-launch headless testing on the
# UGREEN test box: live curl confirmed `SELECT count(*) FROM Users` =
# 0 in all three DBs while /login enforced auth, locking the operator
# out completely. Fix: seed an admin user directly in the Users SQLite
# table after the *arr is up, surface the plaintext via state/ so the
# dashboard launcher modal (the same flow that already serves qBit /
# Pi-hole / Vaultwarden / Portainer creds) shows it on first click.
#
# Servarr's Users schema is identical across Sonarr 4 / Radarr 6 /
# Prowlarr 2: (Identifier, Username, Password, Salt, Iterations) using
# PBKDF2-HMAC-SHA512, 10000 iterations, 32-byte output, both Password
# and Salt base64-encoded. Verified end-to-end against a live Prowlarr
# (POST /login → 302 + ProwlarrAuth cookie → GET / → 200) before
# this commit.
#
# Idempotent: if the table already has any user (operator created
# their own via Settings → General → Security in a previous session),
# leave it alone — only seed an empty table. Same idempotency posture
# as the rest of arr-bootstrap.
seed_arr_user() {
    local app="$1"
    local db="${OB_ROOT}/${APPS_DIR[$app]}/${app}.db"
    local state_file="${STATE_DIR}/${app}-admin-password.txt"

    if [[ ! -f "${db}" ]]; then
        log "WARN: ${app} db not found at ${db} — skipping user seed"
        return 1
    fi

    # Single Python call: count + maybe-insert + return plaintext (or
    # __SKIP__ marker). Plaintext stays inside one process; never
    # crosses a shell argument list.
    local pw
    pw=$(DB="${db}" python3 - <<'PY'
import os, sqlite3, hashlib, base64, secrets, string, uuid
db = os.environ["DB"]
con = sqlite3.connect(db)
try:
    n = con.execute("SELECT count(*) FROM Users").fetchone()[0]
    if n > 0:
        print("__SKIP__")
    else:
        alpha = string.ascii_letters + string.digits
        pw = "".join(secrets.choice(alpha) for _ in range(16))
        salt = secrets.token_bytes(16)
        h = hashlib.pbkdf2_hmac("sha512", pw.encode(), salt, 10000, 32)
        con.execute(
            "INSERT INTO Users (Identifier, Username, Password, Salt, Iterations) "
            "VALUES (?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), "admin",
             base64.b64encode(h).decode(),
             base64.b64encode(salt).decode(),
             10000))
        con.commit()
        print(pw)
finally:
    con.close()
PY
)

    if [[ "${pw}" == "__SKIP__" ]]; then
        log "${app}: Users table already populated — skipping seed (operator-managed)"
        return 0
    fi
    if [[ -z "${pw}" ]]; then
        log "ERROR: ${app} user seed failed (python returned empty)"
        return 1
    fi

    # Match qBittorrent's two-line state-file format (set 2026-04-23)
    # so the dashboard launcher's first-login-creds modal surfaces
    # username + password identically across all auto-seeded apps.
    umask 077
    cat > "${state_file}" <<EOF
username: admin
password: ${pw}
EOF
    chown 1000:1000 "${state_file}" 2>/dev/null || true
    chmod 600 "${state_file}"
    log "${app}: seeded admin user (creds at state/${state_file##*/})"
}

# v1.6.50: track seed failures so the done-marker isn't written if any
# *arr ends up with no admin user. Previously the three calls were
# unconditional and their exit codes ignored — a failed seed would
# leave an empty Users table, no state-file, and an "all done" marker
# (script self-skips on retry). Codex audit caught this.
seed_failures=0
seed_arr_user sonarr   || seed_failures=$((seed_failures + 1))
seed_arr_user radarr   || seed_failures=$((seed_failures + 1))
seed_arr_user prowlarr || seed_failures=$((seed_failures + 1))

# ---- Step 5: Register qBittorrent as download client in Sonarr + Radarr ----
QBIT_PW=""
if [[ -r "${STATE_DIR}/qbittorrent-admin-password.txt" ]]; then
    # Two supported formats for this file:
    #   1. Legacy (pre-v1.5.74): just the raw password on the first line.
    #   2. Current: "username: admin\npassword: XXXX" so the launcher
    #      modal can show both fields — Tom asked for this 2026-04-23.
    # Grep for "password: " first; fall back to first-line for legacy.
    QBIT_PW=$(grep -oE '^password:[[:space:]]+\S+' "${STATE_DIR}/qbittorrent-admin-password.txt" 2>/dev/null | head -n1 | awk '{print $2}')
    if [[ -z "${QBIT_PW}" ]]; then
        QBIT_PW=$(head -n1 "${STATE_DIR}/qbittorrent-admin-password.txt" | tr -d '\r\n')
    fi
fi

# Pre-flight: media download dir + perms.
# qBit (and Sonarr/Radarr) all bind-mount the host's data/media
# directory as /data inside the container. qBit defaults to a
# /downloads save path that doesn't exist, and even when we point
# it at /data/downloads the dir is root-owned while qBit runs as
# uid 1000 — first-real-download fails with a write error.
# Pre-create the dirs and chown to PUID:PGID so this just works.
#
# Path naming: /data/Movies and /data/TV (no /media/ middle segment).
# v1.6.81: docker-compose binds MEDIA_ROOT:/data for the *arr stack
# AND MEDIA_ROOT:/data for Jellyfin (was MEDIA_ROOT/media:/data/media,
# which silently broke Jellyfin discovery on every fresh install since
# v1.6.74). Container paths must match the bind: MEDIA_ROOT/Movies on
# host = /data/Movies in container. Anything with a /data/media/ prefix
# resolves to MEDIA_ROOT/media/Movies on host which doesn't exist.
MEDIA_DATA_DIR="${MEDIA_ROOT:-${OB_ROOT}/data/media}"
mkdir -p "${MEDIA_DATA_DIR}/downloads" "${MEDIA_DATA_DIR}/incomplete" \
         "${MEDIA_DATA_DIR}/Movies" "${MEDIA_DATA_DIR}/TV" "${MEDIA_DATA_DIR}/Music"
PUID_VAL=$(grep '^PUID=' "${OB_ROOT}/.env" 2>/dev/null | tail -1 | cut -d= -f2)
PGID_VAL=$(grep '^PGID=' "${OB_ROOT}/.env" 2>/dev/null | tail -1 | cut -d= -f2)
chown -R "${PUID_VAL:-1000}:${PGID_VAL:-1000}" "${MEDIA_DATA_DIR}" 2>/dev/null || true
chmod -R u+rwX,g+rwX "${MEDIA_DATA_DIR}" 2>/dev/null || true
log "Pre-created /data/downloads + chowned ${MEDIA_DATA_DIR} to ${PUID_VAL:-1000}:${PGID_VAL:-1000}"

if [[ -z "${QBIT_PW}" ]]; then
    log "WARN: no qbittorrent-admin-password.txt — skipping download client registration. Set qBit's password manually then re-run."
else
    # qBit password sync. If install.sh's password-injection
    # custom-cont-init.d script didn't fire (we've seen this on
    # /opt installs where the dir wasn't pre-created), qBit boots
    # with a random temp password printed to its logs and the
    # saved file's password gets rejected. Auto-detect + sync
    # via qBit's REST API.
    qbit_check=$(docker exec ob-sonarr curl -sS -m 5 -X POST \
        -d "username=admin&password=${QBIT_PW}" \
        http://localhost:${QBIT_PORT_INTERNAL}/api/v2/auth/login 2>/dev/null || echo Fails.)
    if [[ "${qbit_check}" != "Ok." ]]; then
        log "qBit doesn't accept saved password — trying to sync via temp password from logs..."
        temp_pw=$(docker logs ob-qbittorrent 2>&1 | grep -oE 'temporary password is provided[^:]*: [A-Za-z0-9+/=]+' | tail -1 | awk -F': ' '{print $NF}')
        if [[ -z "${temp_pw}" ]]; then
            log "WARN: couldn't find temp password in qBit logs. Restart ob-qbittorrent and re-run, or set its password in qBit's UI to: ${QBIT_PW}"
        else
            log "Found temp password in logs. Logging in + setting saved password via API."
            # Codex cmd-injection audit (2026-05-01): pass passwords via
            # docker exec -e instead of interpolating them into sh -c
            # strings. A malicious value in qbittorrent-admin-password.txt
            # (write requires root, so threat is small) could otherwise
            # break out of the single quotes inside `sh -c "...'$pw'..."`.
            docker exec -e _QBIT_TMP_PW="${temp_pw}" -e _QBIT_NEW_PW="${QBIT_PW}" -e _QBIT_PORT="${QBIT_PORT_INTERNAL}" ob-sonarr sh -c '
                curl -sS -m 5 -X POST -c /tmp/qc.txt --data-urlencode "username=admin" --data-urlencode "password=${_QBIT_TMP_PW}" "http://localhost:${_QBIT_PORT}/api/v2/auth/login" >/dev/null 2>&1
                curl -sS -m 5 -X POST -b /tmp/qc.txt --data-urlencode "json={\"web_ui_password\":\"${_QBIT_NEW_PW}\"}" "http://localhost:${_QBIT_PORT}/api/v2/app/setPreferences" >/dev/null 2>&1
                rm -f /tmp/qc.txt
            ' 2>/dev/null || true
            sleep 2
            log "qBit password synced to saved value."
        fi
    fi

    # Disable qBit's HostHeaderValidation + CSRF-protection so the WebUI
    # is reachable from the LAN IP (http://<nas-ip>:8089), not just
    # localhost. Default qBit rejects LAN-IP requests with "Unauthorized"
    # even with the correct password because the Host header doesn't
    # match the whitelisted set. Caught 2026-04-22 on a UGREEN install —
    # customer couldn't log in through their browser but saved password
    # was correct. CSRF protection is also safe to disable on a LAN-only
    # WebUI and prevents API auth from cross-port requests breaking.
    # Same call sets the default save path so ad-hoc magnet adds (not
    # via the *arr stack) land in /data/downloads instead of the default
    # /downloads (which doesn't exist).
    docker exec -e _QBIT_PW="${QBIT_PW}" -e _QBIT_PORT="${QBIT_PORT_INTERNAL}" ob-sonarr sh -c '
        curl -sS -m 5 -X POST -c /tmp/qb.txt --data-urlencode "username=admin" --data-urlencode "password=${_QBIT_PW}" "http://localhost:${_QBIT_PORT}/api/v2/auth/login" >/dev/null 2>&1
        curl -sS -m 5 -X POST -b /tmp/qb.txt --data-urlencode "json={\"save_path\":\"/data/downloads\",\"temp_path\":\"/data/downloads/incomplete\",\"temp_path_enabled\":true,\"web_ui_host_header_validation_enabled\":false,\"web_ui_csrf_protection_enabled\":false}" "http://localhost:${_QBIT_PORT}/api/v2/app/setPreferences" >/dev/null 2>&1
        rm -f /tmp/qb.txt
    ' 2>/dev/null && log "qBit default save path + LAN-access settings applied."

    register_qbit() {
        local app="$1" key="$2" port="$3"
        # Idempotency: if a download client named "qBittorrent" already exists, skip.
        local existing
        existing=$(curl -sS -m 8 -H "X-Api-Key: ${key}" "http://${ARR_HOST}:${port}/api/v3/downloadclient" 2>/dev/null || echo '[]')
        if echo "${existing}" | grep -q '"name":"qBittorrent"'; then
            log "${app}: qBittorrent already registered, skipping."
            return 0
        fi
        # Schema-fetched payload (Phase 18 of 2026-05-01 deep audit).
        # Top recommendation #2 from Phase 10 upstream-projects research:
        # don't hand-code Sonarr/Radarr download-client JSON; ask the *arr
        # for its current schema for the QBittorrent implementation, mutate
        # canonical defaults, POST it back. Same pattern we already use for
        # Prowlarr indexer seeding.
        #
        # Why: when Sonarr/Radarr add a new field to QBittorrentSettings
        # (which they do regularly — `contentLayout`, new priorities, etc.)
        # our hardcoded payload either silently misses the new field
        # (missing default) or 400s if the field is required. Schema-
        # fetched payloads always have the current field set.
        local schema
        schema=$(curl -sS -m 8 -H "X-Api-Key: ${key}" \
            "http://${ARR_HOST}:${port}/api/v3/downloadclient/schema" 2>/dev/null || echo '[]')
        local payload
        payload=$(printf '%s' "$schema" | QBIT_PORT_INTERNAL="${QBIT_PORT_INTERNAL}" QBIT_PW="${QBIT_PW}" APP="${app}" python3 -c '
import json, os, sys
schema = json.load(sys.stdin)
qbit = next((s for s in schema if s.get("implementation") == "QBittorrent"), None)
if not qbit:
    sys.stderr.write("[arr-bootstrap] schema fetch did not include QBittorrent — falling back to hardcoded.\n")
    sys.exit(2)
# Mutate the canonical schema entry: enable, set fields by NAME (so the
# script keeps working when *arr reorders fields), set non-default
# values (host=localhost — qBit shares gluetun netns; port=internal qBit
# WebUI port; password from env; category=app name).
qbit["enable"] = True
qbit["priority"] = 1
qbit["removeCompletedDownloads"] = True
qbit["removeFailedDownloads"] = True
qbit["name"] = "qBittorrent"
overrides = {
    "host": "localhost",
    "port": int(os.environ["QBIT_PORT_INTERNAL"]),
    "useSsl": False,
    "urlBase": "",
    "username": "admin",
    "password": os.environ["QBIT_PW"],
    "tvCategory": os.environ["APP"],
    "movieCategory": os.environ["APP"],  # Radarr uses movieCategory
    "musicCategory": os.environ["APP"],  # Lidarr — harmless on Sonarr/Radarr
    "recentTvPriority": 0,
    "olderTvPriority": 0,
    "recentMoviePriority": 0,
    "olderMoviePriority": 0,
    "initialState": 0,
    "sequentialOrder": False,
    "firstAndLast": False,
}
for f in qbit.get("fields", []):
    n = f.get("name")
    if n in overrides:
        f["value"] = overrides[n]
print(json.dumps(qbit))
')
        local payload_rc=$?
        if [[ ${payload_rc} -eq 2 ]] || [[ -z "${payload}" ]]; then
            # Schema fetch failed or QBittorrent not in schema — fall back
            # to the historical hardcoded payload as a safety net.
            log "${app}: WARN — schema fetch failed, using hardcoded fallback payload"
            payload=$(cat <<JSON
{
  "enable": true,
  "protocol": "torrent",
  "priority": 1,
  "removeCompletedDownloads": true,
  "removeFailedDownloads": true,
  "name": "qBittorrent",
  "fields": [
    {"name": "host", "value": "localhost"},
    {"name": "port", "value": ${QBIT_PORT_INTERNAL}},
    {"name": "useSsl", "value": false},
    {"name": "urlBase", "value": ""},
    {"name": "username", "value": "admin"},
    {"name": "password", "value": "${QBIT_PW}"},
    {"name": "tvCategory", "value": "${app}"},
    {"name": "tvImportedCategory", "value": ""},
    {"name": "recentTvPriority", "value": 0},
    {"name": "olderTvPriority", "value": 0},
    {"name": "initialState", "value": 0},
    {"name": "sequentialOrder", "value": false},
    {"name": "firstAndLast", "value": false}
  ],
  "implementationName": "qBittorrent",
  "implementation": "QBittorrent",
  "configContract": "QBittorrentSettings",
  "tags": []
}
JSON
)
        fi
        local resp
        resp=$(curl -sS -m 10 -X POST -H "X-Api-Key: ${key}" -H 'Content-Type: application/json' \
            -d "${payload}" "http://${ARR_HOST}:${port}/api/v3/downloadclient" 2>&1)
        # Use python to parse the response — more robust than regex against
        # the schema-fetched payload's pretty-printed multi-line JSON.
        local created_id
        created_id=$(printf '%s' "${resp}" | python3 -c '
import sys, json
try:
    d = json.load(sys.stdin)
    print(d.get("id", 0) if isinstance(d, dict) else 0)
except Exception:
    print(0)
' 2>/dev/null)
        if [[ "${created_id:-0}" -ge 1 ]] 2>/dev/null; then
            log "${app}: qBittorrent registered (id=${created_id})."
        else
            log "WARN: ${app}: qBittorrent register returned: $(echo "${resp}" | head -c 200)"
        fi
    }
    register_qbit sonarr "${SONARR_KEY}" "$(arr_port_for sonarr)"
    register_qbit radarr "${RADARR_KEY}" "$(arr_port_for radarr)"

fi

# ---- Step 5a-bis: Auto-register SABnzbd as a download client in Sonarr + Radarr ----
# Only fires when SAB is configured (the user has run SAB's first-run
# wizard with their Usenet provider creds). Skips otherwise so we don't
# create a broken-on-test download-client entry that would confuse Seerr
# fallback logic.
#
# Detection: SAB writes its API key to /config/sabnzbd.ini after first
# run AND has at least one [server*] section once a provider is configured.
# Bind-mounted from ${OB_ROOT}/modules/media/config/sabnzbd/sabnzbd.ini.
SAB_INI="${OB_ROOT}/modules/media/config/sabnzbd/sabnzbd.ini"
if [[ -r "${SAB_INI}" ]] && grep -q "^\[servers\]" "${SAB_INI}" 2>/dev/null; then
    # Pull SAB's nzb_key (the API key Sonarr/Radarr need). nzb_key is the
    # one for /api?mode=addurl etc. — same key SAB's own UI shows under
    # Config → General. Fall back to api_key if nzb_key isn't set yet.
    SAB_API_KEY=$(grep -oE '^nzb_key\s*=\s*\S+' "${SAB_INI}" 2>/dev/null | head -1 | awk '{print $3}')
    if [[ -z "${SAB_API_KEY}" ]]; then
        SAB_API_KEY=$(grep -oE '^api_key\s*=\s*\S+' "${SAB_INI}" 2>/dev/null | head -1 | awk '{print $3}')
    fi
    # Confirm at least one [serverN] section exists (= provider configured)
    if grep -qE "^\[servers?\][[:space:]]*$" "${SAB_INI}" && [[ -n "${SAB_API_KEY}" ]] && [[ "${SAB_API_KEY}" != "0" ]]; then
        register_sab() {
            local app="$1" key="$2" port="$3"
            local existing
            existing=$(curl -sS -m 8 -H "X-Api-Key: ${key}" "http://${ARR_HOST}:${port}/api/v3/downloadclient" 2>/dev/null || echo '[]')
            if echo "${existing}" | grep -q '"name":"SABnzbd"'; then
                log "${app}: SABnzbd already registered, skipping."
                return 0
            fi
            # Schema-fetched payload — same pattern as register_qbit. SAB's
            # implementation in *arr is "Sabnzbd" (lower-b).
            local schema
            schema=$(curl -sS -m 8 -H "X-Api-Key: ${key}" \
                "http://${ARR_HOST}:${port}/api/v3/downloadclient/schema" 2>/dev/null || echo '[]')
            local payload
            payload=$(printf '%s' "$schema" | SAB_API_KEY="${SAB_API_KEY}" APP="${app}" python3 -c '
import json, os, sys
schema = json.load(sys.stdin)
sab = next((s for s in schema if s.get("implementation") == "Sabnzbd"), None)
if not sab:
    sys.stderr.write("[arr-bootstrap] schema fetch did not include Sabnzbd implementation.\n")
    sys.exit(2)
sab["enable"] = True
sab["priority"] = 1
sab["removeCompletedDownloads"] = True
sab["removeFailedDownloads"] = True
sab["name"] = "SABnzbd"
overrides = {
    "host": "localhost",
    "port": 8081,
    "useSsl": False,
    "urlBase": "",
    "apiKey": os.environ["SAB_API_KEY"],
    "username": "",
    "password": "",
    "tvCategory": os.environ["APP"],
    "movieCategory": os.environ["APP"],
    "musicCategory": os.environ["APP"],
    "recentTvPriority": -100,    # SAB priority: -100 = default
    "olderTvPriority": -100,
    "recentMoviePriority": -100,
    "olderMoviePriority": -100,
}
for f in sab.get("fields", []):
    n = f.get("name")
    if n in overrides:
        f["value"] = overrides[n]
print(json.dumps(sab))
')
            local payload_rc=$?
            if [[ ${payload_rc} -eq 2 ]] || [[ -z "${payload}" ]]; then
                log "${app}: WARN — Sabnzbd schema fetch failed; skipping auto-register"
                return 0
            fi
            local resp
            resp=$(curl -sS -m 10 -X POST -H "X-Api-Key: ${key}" -H 'Content-Type: application/json' \
                -d "${payload}" "http://${ARR_HOST}:${port}/api/v3/downloadclient" 2>&1)
            local created_id
            created_id=$(printf '%s' "${resp}" | python3 -c '
import sys, json
try:
    d = json.load(sys.stdin)
    print(d.get("id", 0) if isinstance(d, dict) else 0)
except Exception:
    print(0)
' 2>/dev/null)
            if [[ "${created_id:-0}" -ge 1 ]] 2>/dev/null; then
                log "${app}: SABnzbd registered (id=${created_id})."
            else
                log "WARN: ${app}: SABnzbd register returned: $(echo "${resp}" | head -c 200)"
            fi
        }
        register_sab sonarr "${SONARR_KEY}" "$(arr_port_for sonarr)"
        register_sab radarr "${RADARR_KEY}" "$(arr_port_for radarr)"
    else
        log "SAB API key not yet generated or no Usenet provider configured — skipping SAB download-client auto-register. Customer can finish SAB setup then run 'sudo /opt/openbox/openbox restart media' to retrigger."
    fi
else
    log "SABnzbd not configured (no sabnzbd.ini or no [servers] section) — skipping SAB auto-register. Run SAB's first-run wizard at http://<host>:8186 then 'sudo /opt/openbox/openbox restart media' to retrigger."
fi

# ---- Step 5b: Register root folders in Sonarr + Radarr ----
# This step is INTENTIONALLY OUTSIDE the qBit if/else above. Root
# folder registration has nothing to do with qBittorrent — but a
# 2026-04-30 paid-beta test caught the entire block being skipped
# when state/qbittorrent-admin-password.txt wasn't ready in time
# (the script's qBit branch logs "no qbittorrent-admin-password.txt
# — skipping download client registration" and exits the if/else
# without doing anything else). Result: Seerr request → Radarr 400
# "Root folder '/data/movies' does not exist", and the customer
# couldn't actually request anything despite the UI showing
# everything green. Caught originally 2026-04-22 (Seerr-approved
# but never-reaching-Radarr); the qBit-coupling regression was
# caught again on 2026-04-30 with the same symptom for a different
# reason. Keeping rootfolder registration as its own step removes
# both failure modes.
register_rootfolder() {
    local app="$1" key="$2" port="$3" path="$4"
    local existing
    existing=$(curl -sS -m 8 -H "X-Api-Key: ${key}" "http://${ARR_HOST}:${port}/api/v3/rootfolder" 2>/dev/null || echo '[]')
    if echo "${existing}" | grep -q "\"path\":\"${path}\""; then
        log "${app}: root folder ${path} already registered, skipping."
        return 0
    fi
    local resp
    resp=$(curl -sS -m 10 -X POST -H "X-Api-Key: ${key}" -H 'Content-Type: application/json' \
        -d "{\"path\":\"${path}\"}" "http://${ARR_HOST}:${port}/api/v3/rootfolder" 2>&1)
    if echo "${resp}" | grep -qE '"id":[0-9]+'; then
        log "${app}: root folder ${path} registered."
    else
        log "WARN: ${app}: root folder register for ${path} returned: $(echo "${resp}" | head -c 200)"
    fi
}
register_rootfolder radarr "${RADARR_KEY}" "$(arr_port_for radarr)" "/data/Movies"
register_rootfolder sonarr "${SONARR_KEY}" "$(arr_port_for sonarr)" "/data/TV"

# ---- Step 6: Register Sonarr + Radarr as Applications in Prowlarr ----
# Once registered, any indexer added in Prowlarr's UI gets pushed
# automatically to both *arr apps with their API keys.
register_prowlarr_app() {
    local app="$1" port="$2" key="$3" impl="$4" sync_cats="$5"
    local existing
    existing=$(curl -sS -m 8 -H "X-Api-Key: ${PROWLARR_KEY}" \
        "http://${ARR_HOST}:$(arr_port_for prowlarr)/api/v1/applications" 2>/dev/null || echo '[]')
    if echo "${existing}" | grep -q "\"name\":\"${impl}\""; then
        log "prowlarr: ${impl} already registered, skipping."
        return 0
    fi
    local payload
    payload=$(cat <<JSON
{
  "syncLevel": "fullSync",
  "name": "${impl}",
  "fields": [
    {"name": "prowlarrUrl", "value": "http://127.0.0.1:${APPS_PORT_INTERNAL[prowlarr]}"},
    {"name": "baseUrl", "value": "http://127.0.0.1:${port}"},
    {"name": "apiKey", "value": "${key}"},
    {"name": "syncCategories", "value": [${sync_cats}]}
  ],
  "implementationName": "${impl}",
  "implementation": "${impl}",
  "configContract": "${impl}Settings",
  "tags": []
}
JSON
)
    local resp
    resp=$(curl -sS -m 10 -X POST -H "X-Api-Key: ${PROWLARR_KEY}" -H 'Content-Type: application/json' \
        -d "${payload}" "http://${ARR_HOST}:$(arr_port_for prowlarr)/api/v1/applications" 2>&1)
    if echo "${resp}" | grep -qE '"id":[0-9]+'; then
        log "prowlarr: ${impl} registered."
    else
        log "WARN: prowlarr: ${impl} register returned: $(echo "${resp}" | head -c 200)"
    fi
}

# Sonarr categories: 5000 (TV), 5010 (TV/WEB-DL), 5020 (TV/Foreign), 5030 (TV/SD), 5040 (TV/HD), 5045 (TV/UHD), 5050 (TV/Other), 5070 (TV/Anime), 5080 (TV/Documentary)
register_prowlarr_app sonarr "${APPS_PORT_INTERNAL[sonarr]}" "${SONARR_KEY}" "Sonarr" \
    "5000,5010,5020,5030,5040,5045,5050,5070,5080"
# Radarr categories: 2000 (Movies), 2010 (Movies/Foreign), 2020 (Movies/Other), 2030 (Movies/SD), 2040 (Movies/HD), 2045 (Movies/UHD), 2050 (Movies/BluRay), 2060 (Movies/3D)
register_prowlarr_app radarr "${APPS_PORT_INTERNAL[radarr]}" "${RADARR_KEY}" "Radarr" \
    "2000,2010,2020,2030,2040,2045,2050,2060"

# ---- Seerr (request UI) — auto-seed Sonarr+Radarr, log Jellyfin pointer ----
# Seerr (seerr-team fork of Overseerr + Jellyseerr) runs a wizard on
# first launch. We auto-populate Sonarr and Radarr in its settings.json
# so the only step left is Jellyfin pairing (which requires an API key
# Jellyfin generates during its own first-run wizard — we don't have it
# at install time). Seed script runs after ob-seerr is up and retries
# waiting for settings.json to appear.
# Track per-stage success. The done marker (state/arr-bootstrapped) is
# only written if EVERY customer-visible stage succeeded. Codex audit
# finding #3 (2026-05-01): the previous single-marker design wrote
# arr-bootstrapped even when seerr-seed/media-autoseed/media-finish
# failed silently — the customer ended up with a "complete" install
# missing Jellyfin credentials or broken Seerr request routing.
seerr_seed_ok=1
media_autoseed_ok=1
media_finish_ok=1

if docker ps --format '{{.Names}}' | grep -qE '^ob-seerr$'; then
    # Run Recyclarr FIRST so seerr-seed picks up the curated TRaSH
    # quality profile (HD Bluray + WEB / WEB-1080p) by name. Otherwise
    # seerr-seed falls back to stock 'HD-1080p' id=1, and the customer
    # has to manually fix Seerr's profile selection later.
    # Recyclarr is idempotent (skips on its own marker).
    if [[ -x "${OB_ROOT}/scripts/recyclarr-sync.sh" ]]; then
        log "Recyclarr: applying TRaSH-Guides defaults before seerr-seed..."
        "${OB_ROOT}/scripts/recyclarr-sync.sh" >/dev/null 2>&1 || \
            log "Recyclarr: sync had issues (see state/recyclarr-sync.log) — Seerr will fall back to stock profile"
    fi

    log "Seerr: seeding Sonarr + Radarr entries via scripts/seerr-seed.sh..."
    if [[ -x "${OB_ROOT}/scripts/seerr-seed.sh" ]]; then
        if ! "${OB_ROOT}/scripts/seerr-seed.sh"; then
            log "Seerr: seed script exited non-zero (see state/seerr-seed.log) — marker will NOT be written"
            seerr_seed_ok=0
        fi
    else
        log "Seerr: scripts/seerr-seed.sh not executable. Falling back to manual-pairing pointer."
        seerr_seed_ok=0
    fi
    log "Seerr: open http://<your-box>:5055 — Sonarr and Radarr are pre-wired."
    log "Seerr: still need to connect Jellyfin manually when asked:"
    log "Seerr:   Jellyfin URL   → http://ob-jellyfin-media:8096 (or your LAN IP + :8096)"
    log "Seerr:   Jellyfin API key → generate inside Jellyfin at Dashboard → API Keys → '+'"
fi

# ---- Jellyfin + Seerr full auto-seed ----
# Two-stage automation for the customer-zero-credential experience:
#
# Stage 1: media-autoseed drives Jellyfin's first-run wizard via
# headless Chromium (because Jellyfin 10.10's /Startup/User API
# 500s on a fresh DB — upstream bug), creates a `openbox` admin
# user with a generated password, mints a persistent API key, and
# signs Seerr in via its /api/v1/auth/jellyfin endpoint. Customer
# does ZERO credential typing.
#
# Stage 2: media-finish creates the Jellyfin libraries (Movies, TV
# Shows) via its REST API using Seerr's stored Jellyfin key, syncs
# them into Seerr, and marks Seerr initialized. Customer opens
# Seerr and lands on the discover page, no wizard.
#
# Both stages are idempotent. autoseed short-circuits if the state
# marker exists. media-finish is always-safe to re-run. Playwright
# + Chromium are auto-bootstrapped into .autoseed-cache on first
# run (~200MB one-time download).
if docker ps --format '{{.Names}}' | grep -qE '^ob-jellyfin(-media)?$' \
   && docker ps --format '{{.Names}}' | grep -qE '^ob-seerr$'; then
    if [[ -x "${OB_ROOT}/scripts/media-autoseed.sh" ]]; then
        log "Media auto-seed: driving Jellyfin wizard + Seerr sign-in..."
        if ! "${OB_ROOT}/scripts/media-autoseed.sh"; then
            log "media-autoseed had issues (see state/media-autoseed.log) — marker will NOT be written"
            media_autoseed_ok=0
        fi
    else
        media_autoseed_ok=0
    fi
    if [[ -x "${OB_ROOT}/scripts/media-finish.sh" ]]; then
        log "Media finish: creating Jellyfin libraries + finalizing Seerr..."
        if ! "${OB_ROOT}/scripts/media-finish.sh"; then
            log "media-finish exited non-zero (see state/media-finish.log) — marker will NOT be written"
            media_finish_ok=0
        fi
    else
        media_finish_ok=0
    fi
fi

# ---- Step 7: (opt-in) FlareSolverr wiring — NO default indexer seeding ----
#
# 2026-05-02 LEGAL/TERMS COMPLIANCE — DO NOT RE-INTRODUCE.
# Earlier versions auto-seeded YTS (a public torrent indexer) so that
# Prowlarr was usable out of the box. That contradicted Terms §6:
# "OpenBox does not provide media content, indexers, trackers, or
# sources of any kind." Auto-populating ANY indexer is the literal
# thing the disclaimer says we don't do.
#
# Prowlarr now ships with zero indexers. Customers add what they want
# in Prowlarr's UI. They are responsible for the legality of any
# indexer/tracker they configure under their jurisdiction's laws.
#
# FlareSolverr opt-in stays: if the customer enabled the flaresolverr
# profile (ob-flaresolverr container present), this script auto-
# registers it as a Prowlarr indexer-proxy + creates a 'flaresolverr'
# tag so that ANY CF-protected indexer THEY add later gets routed
# through the bypass without manual API key fiddling. We're providing
# infrastructure, not picking content.
#
# Idempotent: ensures the proxy + tag exist exactly once when
# FlareSolverr is enabled.

# Detect FlareSolverr opt-in. Container shares gluetun's net namespace,
# so reachable at the same ARR_HOST. Quick probe (10s) — only worth
# waiting if the customer explicitly opted in via the profile.
flare_present=0
if docker ps --format '{{.Names}}' 2>/dev/null | grep -qE '^ob-flaresolverr$'; then
    flare_deadline=$(( $(date +%s) + 30 ))
    while [[ $(date +%s) -lt ${flare_deadline} ]]; do
        if curl -sS -m 3 "http://${ARR_HOST}:8191/" 2>/dev/null | grep -q "FlareSolverr is ready"; then
            flare_present=1; break
        fi
        sleep 3
    done
    if [[ "${flare_present}" == "1" ]]; then
        log "FlareSolverr detected (opt-in); will auto-register as Prowlarr indexer-proxy."
    else
        log "WARN: ob-flaresolverr container present but didn't respond on :8191 within 30s — skipping proxy registration"
    fi
fi

if command -v python3 >/dev/null 2>&1; then
    log "Setting up Prowlarr (FlareSolverr proxy if opt-in; no default indexers)..."
    env PROWLARR_KEY="${PROWLARR_KEY}" \
        PROWLARR_HOST="${ARR_HOST}" \
        PROWLARR_PORT="$(arr_port_for prowlarr)" \
        FLARESOLVERR_PRESENT="${flare_present}" \
        python3 - <<'PYEOF' 2>&1 | while read -r line; do log "$line"; done
import os, json, urllib.request, urllib.error

API = "http://" + os.environ["PROWLARR_HOST"] + ":" + os.environ["PROWLARR_PORT"] + "/api/v1"
HDR = {"X-Api-Key": os.environ["PROWLARR_KEY"], "Content-Type": "application/json"}

def req(method, path, body=None):
    r = urllib.request.Request(API + path, method=method, headers=HDR,
        data=(json.dumps(body).encode() if body is not None else None))
    try:
        with urllib.request.urlopen(r, timeout=15) as resp:
            return resp.status, resp.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()
    except Exception as e:
        return 0, str(e)

# --- Step A: opt-in FlareSolverr proxy + tag (only if container is live) ---
flare_tag_id = None
if os.environ.get("FLARESOLVERR_PRESENT") == "1":
    st, body = req("GET", "/tag")
    if st == 200:
        for t in json.loads(body):
            if t.get("label") == "flaresolverr":
                flare_tag_id = t.get("id"); break
    if flare_tag_id is None:
        st, body = req("POST", "/tag", {"label": "flaresolverr"})
        if 200 <= st < 300:
            flare_tag_id = json.loads(body).get("id")
            print("prowlarr: tag 'flaresolverr' created (id=" + str(flare_tag_id) + ").")
        else:
            print("WARN: prowlarr: could not create flaresolverr tag (status " + str(st) + ")")
    else:
        print("prowlarr: tag 'flaresolverr' already exists (id=" + str(flare_tag_id) + ").")

    # Both Prowlarr and FlareSolverr share gluetun's net namespace,
    # so Prowlarr reaches FlareSolverr at http://localhost:8191/.
    if flare_tag_id is not None:
        st, body = req("GET", "/indexerproxy")
        proxy_id = None
        if st == 200:
            for p in json.loads(body):
                if p.get("implementation") == "FlareSolverr":
                    proxy_id = p.get("id"); break
        if proxy_id is None:
            proxy_payload = {
                "name": "FlareSolverr",
                "implementation": "FlareSolverr",
                "configContract": "FlareSolverrSettings",
                "onHealthIssue": False,
                "includeHealthWarnings": False,
                "fields": [
                    {"name": "host", "value": "http://localhost:8191/"},
                    {"name": "requestTimeout", "value": 60},
                ],
                "tags": [flare_tag_id],
            }
            st, body = req("POST", "/indexerproxy", proxy_payload)
            if 200 <= st < 300:
                print("prowlarr: FlareSolverr proxy registered + tagged.")
            else:
                print("WARN: prowlarr: FlareSolverr proxy register failed (status " + str(st) + "): " + body[:160].replace("\n", " "))
        else:
            print("prowlarr: FlareSolverr proxy already registered.")

# --- Step B: removed in v1.6.x. ---
# Earlier versions seeded YTS (a public torrent indexer) so the
# Media stack worked out of the box. That contradicted the Terms §6
# disclaimer that OpenBox does not provide indexers, trackers, or
# content sources. Per legal review 2026-05-02, default indexer
# seeding was removed entirely. Customer adds their own indexers in
# Prowlarr's UI. The FlareSolverr proxy + tag we set up in Step A
# above ensures CF-protected indexers route through the bypass when
# the customer adds them.
PYEOF
else
    log "WARN: python3 not available, skipping FlareSolverr proxy registration."
fi

# ---- Hard postconditions before claiming success ----
# Don't write the done marker until we've verified every critical wiring
# step actually landed. The 2026-04-30 paid-beta dress rehearsal caught
# this exact failure mode: bootstrap "completed" with WARN-only logs for
# missing qBit registration + missing rootfolder, marker got written, and
# 18 release commits later Tom hit the bug live during a customer test.
# Now: if a postcondition fails, we DO NOT write the marker. Next time
# arr-bootstrap runs (next openbox up), the script will re-attempt the
# work fresh instead of skipping with "already bootstrapped."
postcondition_fail=0
# post_check verifies a SPECIFIC field value, not just "non-empty
# response." Codex audit finding #4 (2026-05-01): previous version
# accepted any non-empty JSON, so a stale Sonarr root folder pointing
# at /old/path would certify as healthy and the marker would block
# future retries.
#
# Args: <label> <url> <key> <field> <expected_value>
#   field         - which top-level field to look at on each array entry
#                   (e.g. "path" for rootfolder, "implementation" for
#                   downloadclient)
#   expected_value - regex matched against that field; substring match
#                    if a literal, regex if anchored
post_check() {
    local label="$1" url="$2" key="$3" field="$4" expected="$5"
    local body
    body=$(curl --silent --max-time 8 -H "X-Api-Key: ${key}" "${url}" 2>/dev/null || echo '[]')
    local n
    n=$(printf '%s' "$body" | python3 -c "
import sys, json, re
field = '${field}'
expected = r'${expected}'
try:
    d = json.load(sys.stdin)
    items = d if isinstance(d, list) else [d] if d else []
    n = sum(1 for x in items if re.search(expected, str(x.get(field, '')), re.IGNORECASE))
except Exception:
    n = 0
print(n)" 2>/dev/null)
    if [[ "${n:-0}" -ge 1 ]]; then
        log "postcondition ✓ ${label} (matched ${field}~='${expected}', n=${n})"
    else
        log "postcondition ✗ ${label} — no entry matched ${field}~='${expected}', marker will NOT be written"
        log "  body excerpt: $(echo "$body" | head -c 200)"
        postcondition_fail=$((postcondition_fail+1))
    fi
}
post_check "Radarr root folder"    "http://${ARR_HOST}:$(arr_port_for radarr)/api/v3/rootfolder"    "${RADARR_KEY}" 'path'           '/data/Movies'
post_check "Sonarr root folder"    "http://${ARR_HOST}:$(arr_port_for sonarr)/api/v3/rootfolder"    "${SONARR_KEY}" 'path'           '/data/TV'
post_check "Radarr download client" "http://${ARR_HOST}:$(arr_port_for radarr)/api/v3/downloadclient" "${RADARR_KEY}" 'implementation' 'QBittorrent'
post_check "Sonarr download client" "http://${ARR_HOST}:$(arr_port_for sonarr)/api/v3/downloadclient" "${SONARR_KEY}" 'implementation' 'QBittorrent'
# Prowlarr should have BOTH Sonarr and Radarr registered. Run a check
# per app so a half-wired state (only Sonarr, missing Radarr) doesn't
# certify as healthy.
post_check "Prowlarr → Sonarr application" "http://${ARR_HOST}:$(arr_port_for prowlarr)/api/v1/applications" "${PROWLARR_KEY}" 'implementation' 'Sonarr'
post_check "Prowlarr → Radarr application" "http://${ARR_HOST}:$(arr_port_for prowlarr)/api/v1/applications" "${PROWLARR_KEY}" 'implementation' 'Radarr'

if [[ ${postcondition_fail} -gt 0 ]]; then
    log "ERROR: ${postcondition_fail} postcondition(s) failed. NOT writing ${DONE_MARKER}."
    log "       Re-running 'openbox up' will trigger another bootstrap attempt."
    log "       If this keeps failing, check 'docker logs ob-qbittorrent' and 'state/qbittorrent-admin-password.txt'."
    exit 1
fi

# v1.6.50: seed_arr_user failures must also block the done-marker.
# Without this, a fresh install where any *arr DB schema migration is
# mid-flight ends up with an empty Users table + no state-file + a
# "done" marker — the user can't log in and the script self-skips
# next time. Codex audit catch.
if [[ ${seed_failures:-0} -gt 0 ]]; then
    log "ERROR: ${seed_failures} *arr user seed(s) failed. NOT writing ${DONE_MARKER}."
    log "       Check 'docker logs ob-{sonarr,radarr,prowlarr}' for DB-init errors,"
    log "       then re-run 'openbox restart media' to retry the bootstrap."
    exit 1
fi

# Customer-visible setup also has to succeed before we mark this
# install fully bootstrapped. Per-stage state markers are still
# tracked individually (state/seerr-seeded, state/media-autoseeded,
# state/media-finished) but the top-level arr-bootstrapped marker
# requires ALL of them. Codex finding #3.
if [[ ${seerr_seed_ok} -eq 0 ]]; then
    log "ERROR: Seerr seeding failed — Sonarr/Radarr will not be pre-wired in Seerr."
    log "       NOT writing ${DONE_MARKER}. Next 'openbox up' retries."
    exit 1
fi
if [[ ${media_autoseed_ok} -eq 0 ]]; then
    log "ERROR: media-autoseed failed — Jellyfin admin password not generated, Seerr not signed in."
    log "       NOT writing ${DONE_MARKER}. Next 'openbox up' retries."
    exit 1
fi
if [[ ${media_finish_ok} -eq 0 ]]; then
    log "ERROR: media-finish failed — Jellyfin libraries not created."
    log "       NOT writing ${DONE_MARKER}. Next 'openbox up' retries."
    exit 1
fi

# ---- Suppress *arr in-app 'update available' UI ----
# v1.6.4: stop the misleading "update available" prompt inside
# Prowlarr/Sonarr/Radarr from confusing customers. The internal
# updater would either fail (no perms) or break state. Setting
# updateMechanism=docker tells the app to defer to the container
# image. Same logic re-runs in the self-heal block above for
# already-bootstrapped installs.
suppress_internal_updater_post() {
    local app="$1" key="$2" port="$3" api_version="$4"
    local cur
    cur=$(curl -sS -m 8 -H "X-Api-Key: ${key}" "http://${ARR_HOST}:${port}/api/${api_version}/config/host" 2>/dev/null || echo '{}')
    if echo "${cur}" | grep -q '"updateMechanism":"docker"'; then return 0; fi
    local patched
    patched=$(echo "${cur}" | python3 -c "import sys,json; d=json.load(sys.stdin); d['updateMechanism']='docker'; print(json.dumps(d))" 2>/dev/null)
    [[ -z "${patched}" ]] && return 0
    curl -sS -m 10 -X PUT -H "X-Api-Key: ${key}" -H 'Content-Type: application/json' \
        -d "${patched}" "http://${ARR_HOST}:${port}/api/${api_version}/config/host" >/dev/null 2>&1 \
        && log "${app}: in-app 'update available' UI suppressed (updateMechanism=docker)."
}
[[ -n "${SONARR_KEY:-}" ]]   && suppress_internal_updater_post sonarr   "${SONARR_KEY}"   "$(arr_port_for sonarr)"   v3
[[ -n "${RADARR_KEY:-}" ]]   && suppress_internal_updater_post radarr   "${RADARR_KEY}"   "$(arr_port_for radarr)"   v3
[[ -n "${PROWLARR_KEY:-}" ]] && suppress_internal_updater_post prowlarr "${PROWLARR_KEY}" "$(arr_port_for prowlarr)" v1

# ---- Done ----
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "${DONE_MARKER}"
# Re-chown after final write — keeps the dashboard's perm-migration
# step happy on next restart (see top-of-script comment).
chown -R "${PUID_VAL:-1000}:${PGID_VAL:-1000}" "${STATE_DIR}" 2>/dev/null || true
log "ARR auto-config complete (all postconditions verified). Open Sonarr/Radarr — qBittorrent is wired. Open Prowlarr to add indexers (none seeded by default — add what you want under your jurisdiction's laws)."
