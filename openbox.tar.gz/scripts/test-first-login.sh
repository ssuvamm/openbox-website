﻿#!/usr/bin/env bash
# ==========================================
# OpenBox first-login smoke test
# ==========================================
#
# Drives the actual first-login HTTP flow against a running install:
#
#   1. GET  /api/auth/status       → expect hasPassword:false
#   2. POST /api/login with bootstrap token + password → expect 200
#   3. GET  /api/auth/status (auth) → expect isAuthenticated:true
#   4. GET  /api/state (auth)       → expect 200
#
# Why: 1.3.4 shipped with first-login completely broken on every fresh
# install because the bootstrap token wasn't forwarded from .env into
# the dashboard container's process.env. "Container is healthy, HTTP
# 200" checks passed; nobody tried to actually claim the box. This
# script IS that missing test.
#
# Usage:
#
#   OPENBOX_URL=http://<your-test-host>:8443 \
#   OB_BOOTSTRAP_TOKEN=<token-from-.env> \
#   bash scripts/test-first-login.sh
#
# Optional:
#   SB_TEST_PASSWORD=<plaintext>   default: "test-password-12345"
#
# Exits 0 on success, 1 on any failure with a clear diagnostic.
#
# WARNING: this test CLAIMS the dashboard and sets an admin password.
# Only run against a wipe-and-reinstall test box, never a production
# install that already has a real password.

set -euo pipefail

URL="${OPENBOX_URL:-}"
TOKEN="${OB_BOOTSTRAP_TOKEN:-}"
PASSWORD="${SB_TEST_PASSWORD:-test-password-12345}"
COOKIE_JAR="$(mktemp)"
trap 'rm -f "${COOKIE_JAR}"' EXIT

if [[ -z "${URL}" ]]; then
    echo "FAIL: OPENBOX_URL not set (e.g. http://<your-test-host>:8443)" >&2
    exit 1
fi
if [[ -z "${TOKEN}" ]]; then
    echo "FAIL: OB_BOOTSTRAP_TOKEN not set" >&2
    exit 1
fi

fail() {
    echo "FAIL: $1" >&2
    [[ -n "${2:-}" ]] && echo "  response: $2" >&2
    exit 1
}

# 1. GET /api/auth/status — expect firstRun:true on a fresh install.
# Response shape: { authenticated, firstRun, needsSetup }
# firstRun is derived from !hasPassword on the server side.
echo "=> GET ${URL}/api/auth/status"
status_body=$(curl -sS -f -m 10 "${URL}/api/auth/status") \
    || fail "/api/auth/status did not return 200"
echo "   ${status_body}"
if ! echo "${status_body}" | grep -q '"firstRun":true'; then
    fail "expected firstRun:true (unclaimed dashboard). Box already has a password — refusing to overwrite" "${status_body}"
fi

# 2. POST /api/login with { bootstrapToken, password } — claim the box.
echo ""
echo "=> POST ${URL}/api/login (first-run claim)"
claim_body=$(curl -sS -m 10 -c "${COOKIE_JAR}" \
    -H 'Content-Type: application/json' \
    -d "{\"bootstrapToken\":\"${TOKEN}\",\"password\":\"${PASSWORD}\"}" \
    "${URL}/api/login") || fail "claim POST failed"
echo "   ${claim_body}"
if ! echo "${claim_body}" | grep -q '"success":true'; then
    fail "claim did not return success:true. This is the 1.3.4 bug class" "${claim_body}"
fi

# 3. Re-check /api/auth/status with the new session cookie — expect authenticated.
echo ""
echo "=> GET ${URL}/api/auth/status (with session)"
auth_body=$(curl -sS -f -m 10 -b "${COOKIE_JAR}" "${URL}/api/auth/status") \
    || fail "/api/auth/status with cookie did not return 200"
echo "   ${auth_body}"
if ! echo "${auth_body}" | grep -q '"authenticated":true'; then
    fail "session cookie did not carry authentication" "${auth_body}"
fi

# 4. GET /api/state — this is the real authenticated endpoint the UI
#    hits right after login. If this 200s, the whole chain works.
echo ""
echo "=> GET ${URL}/api/state (authenticated)"
state_code=$(curl -sS -o /dev/null -w '%{http_code}' -m 10 \
    -b "${COOKIE_JAR}" "${URL}/api/state")
echo "   HTTP ${state_code}"
if [[ "${state_code}" != "200" ]]; then
    fail "authenticated /api/state did not return 200 (got ${state_code})"
fi

echo ""
echo "OK: first-login flow works end-to-end."
echo "    Bootstrap token was accepted, password was set, session is live."
