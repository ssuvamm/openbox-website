#!/usr/bin/env bash
# ============================================================
# OpenBox Media — finish setup (Jellyfin + Seerr auto-wire)
# ============================================================
# Ties together the last-mile gaps the v1.5.22 Seerr auto-wire
# and v1.5.33 arr-bootstrap left behind:
#
#   1. Pre-create Movies / TV / Music subdirs under MEDIA_ROOT
#      (chowned to PUID:PGID).
#   2. If Seerr has a Jellyfin API key stored in settings.json
#      (which it only has AFTER the user has signed in to Seerr
#      with a Jellyfin user), use it to create the two standard
#      libraries in Jellyfin via /Library/VirtualFolders.
#   3. Tell Seerr to sync the library list from Jellyfin, enable
#      both libraries, and mark itself initialized. This skips
#      the whole step-3 "Configure Media Server" wizard page.
#
# Prerequisites (user still does these manually):
#   - Jellyfin first-run wizard (Jellyfin 10.10's /Startup/User
#     endpoint 500s on a fresh DB — documented in arr-bootstrap.sh).
#   - Seerr's step-2 "Sign in with Jellyfin user" — that's what
#     gets Seerr a Jellyfin API key we can then read from its
#     settings.json. Everything after that is automated here.
#
# Idempotent:
#   - Jellyfin library creation checks existing VirtualFolders first
#   - Seerr enable + initialize are no-ops if already applied
#   - Creates state/media-finished marker to short-circuit re-runs
#
# Usage:
#   OB_ROOT=/opt/openbox bash scripts/media-finish.sh
#   sudo /opt/openbox/openbox media-finish     # via CLI
# ============================================================

set -uo pipefail

OB_ROOT="${OB_ROOT:-/opt/openbox}"
STATE_DIR="${OB_ROOT}/state"
DONE_MARKER="${STATE_DIR}/media-finished"
LOG_FILE="${STATE_DIR}/media-finish.log"
SEERR_SETTINGS="${OB_ROOT}/modules/media/config/seerr/settings.json"

log() { printf '[media-finish] %s\n' "$*" | tee -a "${LOG_FILE}" >&2; }
die() { log "ERROR: $*"; exit 1; }

mkdir -p "${STATE_DIR}"

# --- Step 1: media subdirs ------------------------------------
# Jellyfin libraries point at /data/media/Movies and /data/media/TV
# inside the container. Host paths derive from MEDIA_ROOT in .env.
MEDIA_ROOT=$(grep '^MEDIA_ROOT=' "${OB_ROOT}/.env" 2>/dev/null | tail -1 | cut -d= -f2-)
MEDIA_ROOT="${MEDIA_ROOT:-${OB_ROOT}/data/media}"
PUID=$(grep '^PUID=' "${OB_ROOT}/.env" 2>/dev/null | tail -1 | cut -d= -f2)
PGID=$(grep '^PGID=' "${OB_ROOT}/.env" 2>/dev/null | tail -1 | cut -d= -f2)
PUID="${PUID:-1000}"
PGID="${PGID:-1000}"

log "Creating Movies/TV/Music under ${MEDIA_ROOT}/media/ (PUID=${PUID} PGID=${PGID})"
mkdir -p "${MEDIA_ROOT}/media/Movies" "${MEDIA_ROOT}/media/TV" "${MEDIA_ROOT}/media/Music"
chown -R "${PUID}:${PGID}" "${MEDIA_ROOT}/media" 2>/dev/null || true
chmod -R u+rwX,g+rwX "${MEDIA_ROOT}/media" 2>/dev/null || true

# --- Moonfin plugin (opt-in) — runs first so it works regardless of
# whether the Seerr-gated Steps 2 + 3 below proceed. The plugin
# extract only needs filesystem access to the Jellyfin plugins
# folder (not a running Jellyfin) — Jellyfin loads the plugin on
# next start whether it was already running or comes up later.
moonfin_enabled_pre=$(grep '^MOONFIN_ENABLED=' "${OB_ROOT}/.env" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"' | tr -d "'")
if [[ "${moonfin_enabled_pre}" == "true" ]]; then
    log "Moonfin: opt-in enabled — fetching latest release..."
    # v1.6.67: parse via node -e instead of python3. The dashboard
    # container (where media-finish.sh runs when fired by the
    # /api/media-finish/run endpoint) is alpine-based with node but
    # NO python3. Earlier python3-based parsing returned empty
    # silently, making the script log "no .zip asset found" on
    # every run. node is guaranteed to exist in any context that
    # can run media-finish.
    release_json=$(curl -sS -m 15 -H "Accept: application/vnd.github+json" \
        "https://api.github.com/repos/Moonfin-Client/Plugin/releases/latest" 2>/dev/null || echo '{}')
    moonfin_zip_url=$(echo "${release_json}" | node -e "
let s=''; process.stdin.on('data',d=>s+=d); process.stdin.on('end',()=>{
  try {
    const r = JSON.parse(s);
    for (const a of (r.assets||[])) {
      const n = (a.name||'').toLowerCase();
      if (n.endsWith('.zip') && n.includes('moonfin')) { console.log(a.browser_download_url||''); break; }
    }
  } catch(e) {}
});
" 2>/dev/null)
    moonfin_version=$(echo "${release_json}" | node -e "
let s=''; process.stdin.on('data',d=>s+=d); process.stdin.on('end',()=>{
  try { console.log(JSON.parse(s).tag_name||''); } catch(e) {}
});
" 2>/dev/null)

    if [[ -z "${moonfin_zip_url}" ]]; then
        log "WARN: Moonfin: no .zip asset found in latest release."
    else
        plugins_dir="${OB_ROOT}/modules/media/config/jellyfin/plugins"
        moonfin_dir="${plugins_dir}/Moonfin"
        version_marker="${moonfin_dir}/.openbox-installed-version"

        if [[ -f "${version_marker}" ]] && [[ "$(cat "${version_marker}" 2>/dev/null)" == "${moonfin_version}" ]]; then
            log "Moonfin: version ${moonfin_version} already installed at ${moonfin_dir}, skipping."
        else
            mkdir -p "${plugins_dir}"
            tmp_zip=$(mktemp --suffix=.zip)
            log "Moonfin: downloading ${moonfin_zip_url}"
            if ! curl -fsSL -m 60 -o "${tmp_zip}" "${moonfin_zip_url}"; then
                log "WARN: Moonfin: download failed."
                rm -f "${tmp_zip}"
            elif ! command -v unzip &>/dev/null; then
                log "WARN: Moonfin: unzip missing on host. Install it and re-run openbox media-finish."
                rm -f "${tmp_zip}"
            else
                rm -rf "${moonfin_dir}"
                mkdir -p "${moonfin_dir}"
                if ! unzip -q -o "${tmp_zip}" -d "${moonfin_dir}"; then
                    log "WARN: Moonfin: unzip failed."
                    rm -rf "${moonfin_dir}"
                else
                    echo "${moonfin_version}" > "${version_marker}"
                    chown -R "${PUID}:${PGID}" "${moonfin_dir}" 2>/dev/null || true
                    log "Moonfin: extracted version ${moonfin_version} to ${moonfin_dir}"

                    jf_container=$(docker ps --format '{{.Names}}' 2>/dev/null \
                        | grep -E '^ob-jellyfin(-media)?$' | head -1)
                    if [[ -n "${jf_container}" ]]; then
                        if docker restart "${jf_container}" >/dev/null 2>&1; then
                            log "Moonfin: ${jf_container} restarted to load plugin."
                        else
                            log "WARN: Moonfin: docker restart ${jf_container} failed — restart manually."
                        fi
                    else
                        log "Moonfin: no ob-jellyfin* container running — plugin will load on next Jellyfin start."
                    fi
                fi
                rm -f "${tmp_zip}"
            fi
        fi
    fi
else
    log "Moonfin: opt-in disabled (MOONFIN_ENABLED!=true in .env). Skipping."
fi

# --- Step 2: Jellyfin libraries via its REST API --------------
# We read Jellyfin's API key out of Seerr's settings.json.
# Seerr stored it during the user's "Sign in with Jellyfin user"
# step. If Seerr hasn't been signed in yet, the key is absent
# and we log a pointer + exit successfully (installer not stuck).
if [[ ! -f "${SEERR_SETTINGS}" ]]; then
    log "Seerr settings.json not found at ${SEERR_SETTINGS} — Seerr probably hasn't started yet."
    log "Skipping Jellyfin library auto-wire. Re-run after Seerr is up + signed in:"
    log "    sudo ${OB_ROOT}/openbox media-finish"
    exit 0
fi

# Extract Jellyfin apiKey from the jellyfin: block in settings.json.
# Avoid jq dependency; pull the second "apiKey" (the first is
# Seerr's own top-level API key).
JF_API_KEY=$(grep '"apiKey"' "${SEERR_SETTINGS}" | grep -vE '^\s*"apiKey":\s*"[A-Za-z0-9+/=]{40,}"' | sed -E 's/.*"apiKey":[[:space:]]*"([^"]+)".*$/\1/' | head -1)
if [[ -z "${JF_API_KEY}" ]]; then
    # Fallback: grab the last apiKey in the file (jellyfin block
    # appears AFTER the top-level one).
    JF_API_KEY=$(grep -oE '"apiKey":[[:space:]]*"[^"]+"' "${SEERR_SETTINGS}" | sed -E 's/.*"([^"]+)".*$/\1/' | tail -1)
fi
if [[ -z "${JF_API_KEY}" || ${#JF_API_KEY} -lt 20 ]]; then
    log "No Jellyfin API key in Seerr settings — user hasn't signed in to Seerr yet."
    log "Open http://<your-box>:5055, sign in with a Jellyfin user, then re-run:"
    log "    sudo ${OB_ROOT}/openbox media-finish"
    exit 0
fi

# Discover Jellyfin host. Prefer internal docker network name;
# fall back to SB_HOST_IP from .env.
JF_HOST=$(grep '^SB_HOST_IP=' "${OB_ROOT}/.env" 2>/dev/null | tail -1 | cut -d= -f2-)
JF_HOST="${JF_HOST:-127.0.0.1}"
JF_URL="http://${JF_HOST}:8096"

# Check existing libraries to stay idempotent.
existing=$(curl -sS -m 8 "${JF_URL}/Library/VirtualFolders?api_key=${JF_API_KEY}" 2>/dev/null || echo '[]')
add_library() {
    local name="$1" collection="$2" path_in_container="$3"
    if echo "${existing}" | grep -q "\"Name\":\"${name}\""; then
        log "Jellyfin: ${name} library already present, skipping."
        return 0
    fi
    local resp_code
    resp_code=$(curl -sS -m 10 -o /dev/null -w '%{http_code}' -X POST \
        "${JF_URL}/Library/VirtualFolders?api_key=${JF_API_KEY}&name=${name// /%20}&collectionType=${collection}&refreshLibrary=true" \
        -H 'Content-Type: application/json' \
        -d "{\"LibraryOptions\":{\"PathInfos\":[{\"Path\":\"${path_in_container}\"}],\"EnablePhotos\":false,\"EnableRealtimeMonitor\":true}}" \
        2>/dev/null || echo 000)
    if [[ "${resp_code}" == "204" || "${resp_code}" == "200" ]]; then
        log "Jellyfin: added ${name} library -> ${path_in_container}"
    else
        log "WARN: Jellyfin AddVirtualFolder ${name} returned HTTP ${resp_code}"
    fi
}

add_library "Movies"    "movies"  "/data/media/Movies"
add_library "TV Shows"  "tvshows" "/data/media/TV"

# --- Step 3: Seerr — sync + enable libraries + mark initialized
SEERR_KEY=$(grep -oE '^\s*"apiKey":[[:space:]]*"[^"]+"' "${SEERR_SETTINGS}" | head -1 | sed -E 's/.*"([^"]+)".*$/\1/')
if [[ -z "${SEERR_KEY}" ]]; then
    log "WARN: couldn't read Seerr's own apiKey from settings.json; skipping Seerr finalize."
    exit 0
fi

SEERR_URL="http://${JF_HOST}:5055"

# Sync library list from Jellyfin. Returns JSON array of libraries.
libs_json=$(curl -sS -m 15 -H "X-Api-Key: ${SEERR_KEY}" \
    "${SEERR_URL}/api/v1/settings/jellyfin/library?sync=true" 2>/dev/null || echo '[]')
log "Seerr: sync returned $(echo "${libs_json}" | head -c 200)"

# Extract all library IDs and enable them. Seerr's enable endpoint
# is GET (not POST — POST returns 405) and expects comma-separated ids.
lib_ids=$(echo "${libs_json}" | grep -oE '"id":"[^"]+"' | sed -E 's/"id":"([^"]+)"/\1/' | paste -sd, -)
if [[ -n "${lib_ids}" ]]; then
    curl -sS -m 10 -H "X-Api-Key: ${SEERR_KEY}" \
        "${SEERR_URL}/api/v1/settings/jellyfin/library?enable=${lib_ids}" >/dev/null 2>&1
    log "Seerr: enabled libraries ${lib_ids}"
else
    log "Seerr: no libraries to enable (Jellyfin may be empty — ok, user can add later)."
fi

# Mark Seerr initialized so the /setup wizard doesn't re-trigger.
init_resp=$(curl -sS -m 10 -X POST -H "X-Api-Key: ${SEERR_KEY}" \
    "${SEERR_URL}/api/v1/settings/initialize" 2>/dev/null || echo '')
if echo "${init_resp}" | grep -q '"initialized":true'; then
    log "Seerr: initialized=true, wizard complete."
else
    log "WARN: Seerr initialize returned: $(echo "${init_resp}" | head -c 200)"
fi


echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "${DONE_MARKER}"
log "Media finish complete. Open ${SEERR_URL} — main app (no wizard)."
