﻿#!/usr/bin/env bash
# ==========================================
# OpenBox - Interactive Setup Wizard
# Configures modules, generates .env, deploys stack
# Dynamically reads module metadata from x-openbox
# Supports VPS and NAS environments
# ==========================================

set -euo pipefail

OB_ROOT="${OB_ROOT:-/opt/openbox}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OB_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

source "${SCRIPT_DIR}/tui.sh"

# Environment detection from installer
IS_NAS="${IS_NAS:-false}"
NAS_TYPE="${NAS_TYPE:-}"

# Detect NAS if not passed from installer
if [[ "${IS_NAS}" == "false" ]] && [[ -f "${OB_ROOT}/state/install-meta.conf" ]]; then
    IS_NAS=$(grep '^IS_NAS=' "${OB_ROOT}/state/install-meta.conf" 2>/dev/null | cut -d= -f2 || echo "false")
    NAS_TYPE=$(grep '^NAS_TYPE=' "${OB_ROOT}/state/install-meta.conf" 2>/dev/null | cut -d= -f2 || echo "")
fi

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log_info() { echo -e "${CYAN}[Setup]${NC} $*"; }
log_ok() { echo -e "${GREEN}[Setup]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[Setup]${NC} $*"; }
log_error() { echo -e "${RED}[Setup]${NC} $*"; }

# Generate a random secret
gen_secret() {
    openssl rand -hex 32
}

gen_password() {
    openssl rand -base64 16 | tr -d '/+=' | head -c 16
}

# Hash password using bcrypt via Node.js (if available) or Python
hash_password() {
    local password="$1"
    if command -v node &>/dev/null && [[ -f "${OB_ROOT}/dashboard/node_modules/bcryptjs/index.js" ]]; then
        OB_HASH_INPUT="$password" OB_BCRYPT_PATH="${OB_ROOT}/dashboard/node_modules/bcryptjs" \
            node -e "const b=require(process.env.OB_BCRYPT_PATH);console.log(b.hashSync(process.env.OB_HASH_INPUT,12))"
        return
    fi
    if python3 -c "import bcrypt" &>/dev/null; then
        OB_HASH_INPUT="$password" \
            python3 -c "import os,bcrypt;print(bcrypt.hashpw(os.environ['OB_HASH_INPUT'].encode(),bcrypt.gensalt(12)).decode())"
        return
    fi
    if command -v htpasswd &>/dev/null; then
        htpasswd -nbBC 12 "" "${password}" | cut -d: -f2
        return
    fi
    log_warn "bcrypt not available - using SHA-256 (will be upgraded on first login)"
    echo -n "${password}" | openssl dgst -sha256 | awk '{print $2}'
}

# Read a scalar field from x-openbox metadata
read_openbox_field() {
    local compose="$1"
    local field="$2"
    sed -n '/^x-openbox:/,/^[a-z]/p' "${compose}" | \
        grep -E "^  ${field}:" | head -1 | \
        sed "s/^  ${field}:[[:space:]]*//" | \
        sed 's/^"\(.*\)"$/\1/' | sed "s/^'\(.*\)'$/\1/"
}

# Parse env_vars from x-openbox using Node.js + js-yaml
parse_env_vars() {
    local compose="$1"
    if command -v node &>/dev/null && [[ -f "${OB_ROOT}/dashboard/node_modules/js-yaml/index.js" ]]; then
        OB_COMPOSE_PATH="${compose}" OB_YAML_PATH="${OB_ROOT}/dashboard/node_modules/js-yaml" \
            node -e "
const yaml=require(process.env.OB_YAML_PATH);
const fs=require('fs');
const doc=yaml.load(fs.readFileSync(process.env.OB_COMPOSE_PATH,'utf8'));
const ev=(doc['x-openbox']||{}).env_vars||{};
const result=Object.entries(ev).map(([k,v])=>({key:k,type:v.type||'text',label:v.label||k,prompt:v.prompt||'',default:v.default||''}));
console.log(JSON.stringify(result));
"
    else
        echo "[]"
    fi
}

# Parse setup.templates from x-openbox using Node.js
parse_setup_templates() {
    local compose="$1"
    if command -v node &>/dev/null && [[ -f "${OB_ROOT}/dashboard/node_modules/js-yaml/index.js" ]]; then
        OB_COMPOSE_PATH="${compose}" OB_YAML_PATH="${OB_ROOT}/dashboard/node_modules/js-yaml" \
            node -e "
const yaml=require(process.env.OB_YAML_PATH);
const fs=require('fs');
const doc=yaml.load(fs.readFileSync(process.env.OB_COMPOSE_PATH,'utf8'));
const setup=(doc['x-openbox']||{}).setup||{};
const templates=setup.templates||[];
console.log(JSON.stringify(templates));
"
    else
        echo "[]"
    fi
}

# --- Auto-detect PUID/PGID ---

detect_puid() {
    id -u 2>/dev/null || echo "1000"
}

detect_pgid() {
    id -g 2>/dev/null || echo "1000"
}

# --- Detect hardware transcoding ---

detect_hw_accel() {
    if [[ -d /dev/dri ]]; then
        if [[ -e /dev/dri/renderD128 ]]; then
            echo "intel"
        else
            echo "available"
        fi
    else
        echo "none"
    fi
}

# --- Suggest media root for NAS ---

suggest_media_root() {
    if [[ "${IS_NAS}" == "true" ]]; then
        case "${NAS_TYPE}" in
            ugreen)
                for vol in /volume1/data /volume1/media /mnt/media; do
                    if [[ -d "${vol}" ]]; then
                        echo "${vol}"
                        return
                    fi
                done
                echo "/volume1/data"
                ;;
            synology)
                echo "/volume1/data"
                ;;
            qnap)
                echo "/share/data"
                ;;
            *)
                echo "/data"
                ;;
        esac
    else
        echo "/data"
    fi
}

# --- Welcome ---

if [[ "${IS_NAS}" == "true" ]]; then
    tui_msgbox "OpenBox Setup" "Welcome to OpenBox!

This wizard will set up your self-hosted stack step by step.

Detected environment: NAS (${NAS_TYPE:-auto-detected})

You'll choose a profile, pick modules, and enter a few settings.
Don't worry - you can change everything later.
All passwords will be auto-generated if you leave them blank.

Press OK to get started."
else
    tui_msgbox "OpenBox Setup" "Welcome to OpenBox!

This wizard will set up your private server step by step.

You'll choose which features to turn on and enter a few settings
like your domain name and VPN credentials.

Don't worry - you can change everything later from the dashboard.
All passwords will be auto-generated if you leave them blank.

Press OK to get started."
fi

# --- Profile Selection ---

log_info "Select your server profile..."

PROFILE=$(tui_menu "Server Profile" \
    "What will you use this server for?" \
    "privacy"  "Privacy Server (VPS) - VPN, ad-blocking, passwords, 2FA" \
    "media"    "Media Server (NAS) - Jellyfin, Sonarr/Radarr, Immich" \
    "full"     "Full Stack - Everything (privacy + media + extras)" \
    "custom"   "Custom - Pick exactly which modules you want")

log_ok "Profile selected: ${PROFILE}"

# --- System Settings ---

log_info "Configuring system settings..."

if [[ "${IS_NAS}" == "true" ]]; then
    SB_DOMAIN=$(tui_input "Server Address" \
        "Enter your NAS IP address or local hostname.

This is used for generating service URLs.
On a NAS, this is typically your local IP.

Example: 192.168.1.100
Example: mynas.local" \
        "localhost")
else
    SB_DOMAIN=$(tui_input "Server Address" \
        "Enter your server's IP address or domain name.

If you don't have a domain yet, enter your VPS IP address.
(Find it in your hosting provider's control panel.)

Example IP: 203.0.113.42
Example domain: myserver.com" \
        "localhost")
fi

TZ=$(tui_input "Timezone" \
    "Enter your timezone (Continent/City format).

Common examples:
  America/New_York     (US Eastern)
  America/Chicago      (US Central)
  America/Los_Angeles  (US Pacific)
  Europe/London        (UK)
  Europe/Berlin        (Central Europe)
  Asia/Tokyo           (Japan)
  Australia/Sydney     (Australia)" \
    "UTC")

# --- PUID/PGID ---

PUID=$(detect_puid)
PGID=$(detect_pgid)

log_info "Detected user IDs: PUID=${PUID}, PGID=${PGID}"
if [[ "${PUID}" == "0" ]]; then
    # Running as root (via sudo). Try to detect the real user's UID/GID.
    # SUDO_UID is set when using 'sudo' and gives us the original user's ID.
    # On NAS devices the admin user might not be UID 1000.
    if [[ -n "${SUDO_UID:-}" && "${SUDO_UID}" != "0" ]]; then
        PUID="${SUDO_UID}"
        PGID="${SUDO_GID:-${SUDO_UID}}"
        log_info "Running as root via sudo. Using original user IDs: PUID=${PUID}, PGID=${PGID}"
    else
        log_warn "Running as root (PUID=0). Containers will use PUID=1000 for safety."
        log_warn "If your NAS admin user is not UID 1000, edit PUID/PGID in .env after setup."
        log_warn "Find your user's IDs by running: id your-username"
        PUID="1000"
        PGID="1000"
    fi
fi

# --- Module Selection based on Profile ---

log_info "Selecting modules..."

# Build the list of all optional module IDs
ALL_OPTIONAL_MODS=()
for dir in "${OB_ROOT}/modules"/*/; do
    compose="${dir}docker-compose.yml"
    [[ -f "${compose}" ]] || continue
    mod_id=$(read_openbox_field "${compose}" "id")
    [[ -z "${mod_id}" ]] && mod_id=$(basename "${dir}")
    required=$(read_openbox_field "${compose}" "required")
    [[ "${required}" == "true" ]] && continue
    ALL_OPTIONAL_MODS+=("${mod_id}")
done

# Define profile module sets
# v1.6.35: `privacy` was split into pihole + vaultwarden + authelia.
# Default privacy profile picks pihole + vaultwarden (the common case);
# authelia stays opt-in because it requires NPM forward-auth wiring
# to be useful — preselecting it just makes a dead container.
PRIVACY_MODULES="pihole vaultwarden vpn cloud files monitoring"
MEDIA_MODULES="media immich"
FULL_MODULES="${PRIVACY_MODULES} ${MEDIA_MODULES}"

# Pre-select modules based on profile
case "${PROFILE}" in
    privacy)
        PRESELECT="${PRIVACY_MODULES}"
        ;;
    media)
        PRESELECT="${MEDIA_MODULES}"
        ;;
    full)
        PRESELECT="${FULL_MODULES}"
        ;;
    custom)
        PRESELECT=""
        ;;
esac

# Build checklist with profile-based defaults
CHECKLIST_ARGS=()
for dir in "${OB_ROOT}/modules"/*/; do
    compose="${dir}docker-compose.yml"
    [[ -f "${compose}" ]] || continue

    mod_id=$(read_openbox_field "${compose}" "id")
    [[ -z "${mod_id}" ]] && mod_id=$(basename "${dir}")
    required=$(read_openbox_field "${compose}" "required")
    [[ "${required}" == "true" ]] && continue  # Skip core modules

    title=$(read_openbox_field "${compose}" "title")
    tagline=$(read_openbox_field "${compose}" "tagline")

    [[ -z "${title}" ]] && title="${mod_id}"
    local_desc="${tagline:-${title}}"

    # Determine ON/OFF based on profile
    local_state="OFF"
    if [[ "${PROFILE}" != "custom" ]]; then
        for premod in ${PRESELECT}; do
            if [[ "${mod_id}" == "${premod}" ]]; then
                local_state="ON"
                break
            fi
        done
    else
        # Custom: use module default
        default_val=$(read_openbox_field "${compose}" "default")
        [[ "${default_val}" == "true" ]] && local_state="ON"
    fi

    CHECKLIST_ARGS+=("${mod_id}" "${local_desc}" "${local_state}")
done

SELECTED_MODULES=""
if [[ ${#CHECKLIST_ARGS[@]} -gt 0 ]]; then
    SELECTED_MODULES=$(tui_checklist "Choose Your Features" \
        "Profile '${PROFILE}' pre-selected modules below.
Toggle any on/off, then press OK:" \
        "${CHECKLIST_ARGS[@]}")
fi

# Clean up whiptail output (removes quotes)
SELECTED_MODULES=$(echo "${SELECTED_MODULES}" | tr -d '"')

# Check if media module is selected
HAS_MEDIA=false
for mod in ${SELECTED_MODULES}; do
    if [[ "${mod}" == "media" ]]; then
        HAS_MEDIA=true
        break
    fi
done

# Write modules.conf
mkdir -p "${OB_ROOT}/state"
{
    echo "core"
    echo "dashboard"
    for module in ${SELECTED_MODULES}; do
        echo "${module}"
    done
} > "${OB_ROOT}/state/modules.conf"

log_ok "Modules configured: core dashboard ${SELECTED_MODULES}"

# --- NAS / Media-specific Questions ---

MEDIA_ROOT=""
JELLYFIN_HW_ACCEL="none"
VPN_SERVICE_PROVIDER=""
VPN_TYPE=""
WIREGUARD_PRIVATE_KEY=""
WIREGUARD_ADDRESSES=""
OPENVPN_USER=""
OPENVPN_PASSWORD=""
SERVER_COUNTRIES=""

if [[ "${HAS_MEDIA}" == "true" ]]; then
    log_info "Configuring media settings..."

    # Media root
    default_media_root=$(suggest_media_root)
    MEDIA_ROOT=$(tui_input "Media Storage" \
        "Where is your media storage root?

This directory will contain subdirectories for:
  movies/, tv/, music/, downloads/, books/

On NAS, this should be on your data volume.
The directory will be created if it doesn't exist." \
        "${default_media_root}")

    # Create media subdirectories
    log_info "Media root: ${MEDIA_ROOT}"

    # Hardware transcoding
    hw_detect=$(detect_hw_accel)
    if [[ "${hw_detect}" == "intel" ]]; then
        if tui_yesno "Hardware Transcoding" "Intel Quick Sync detected at /dev/dri/renderD128.

Enable hardware-accelerated video transcoding for Jellyfin?
This significantly improves streaming performance."; then
            JELLYFIN_HW_ACCEL="intel"
        fi
    elif [[ "${hw_detect}" == "available" ]]; then
        if tui_yesno "Hardware Transcoding" "GPU device detected at /dev/dri.

Enable hardware-accelerated video transcoding for Jellyfin?"; then
            JELLYFIN_HW_ACCEL="auto"
        fi
    else
        log_info "No GPU detected -- software transcoding will be used."
    fi

    # VPN for media downloads
    if tui_yesno "Download VPN" "Do you want to route media downloads through a VPN?

This is strongly recommended to protect your privacy when
using torrent clients (qBittorrent via the media module).

You'll need credentials from a VPN provider that supports
WireGuard or OpenVPN (e.g., Mullvad, ProtonVPN, NordVPN)."; then

        VPN_SERVICE_PROVIDER=$(tui_input "VPN Provider" \
            "Enter your VPN provider name.

Supported: mullvad, nordvpn, protonvpn, private_internet_access,
surfshark, windscribe, custom

See https://github.com/qdm12/gluetun-wiki for full list." \
            "mullvad")

        VPN_TYPE=$(tui_menu "VPN Protocol" \
            "Which VPN protocol do you want to use?" \
            "wireguard" "WireGuard (faster, recommended)" \
            "openvpn"   "OpenVPN (wider compatibility)")

        if [[ "${VPN_TYPE}" == "wireguard" ]]; then
            WIREGUARD_PRIVATE_KEY=$(tui_input "WireGuard Key" \
                "Enter your WireGuard private key.

Get this from your VPN provider's dashboard.
For Mullvad: https://mullvad.net/account/wireguard-config" \
                "")

            WIREGUARD_ADDRESSES=$(tui_input "WireGuard Address" \
                "Enter your WireGuard interface address.

This is provided by your VPN provider along with the key.
Example: 10.66.212.34/32" \
                "")
        else
            OPENVPN_USER=$(tui_input "OpenVPN Username" \
                "Enter your OpenVPN username from your VPN provider." "")
            OPENVPN_PASSWORD=$(tui_password "OpenVPN Password" \
                "Enter your OpenVPN password:")
        fi

        SERVER_COUNTRIES=$(tui_input "VPN Server Country" \
            "Which country should the VPN connect to?

Examples: us, uk, de, nl, ch, se
Leave blank for automatic selection." \
            "")
    fi
fi

# --- Configurable Ports ---

HTTP_PORT="80"
HTTPS_PORT="443"
PIHOLE_DNS_PORT="53"
PORTAINER_PORT="9000"

if [[ "${IS_NAS}" == "true" ]]; then
    log_info "Checking for port conflicts on NAS..."

    # Check if common ports are already in use
    for port_check in 80 443 53 9000; do
        if ss -tlnp 2>/dev/null | grep -q ":${port_check} "; then
            log_warn "Port ${port_check} is already in use on this NAS."
        fi
    done

    if tui_yesno "Port Configuration" "On a NAS, default ports (80, 443, 53) may conflict
with the NAS web interface or built-in DNS.

Do you want to customize port numbers?"; then

        HTTP_PORT=$(tui_input "HTTP Port" \
            "HTTP port for Nginx Proxy Manager (default: 80).
If your NAS uses port 80, try 8080." \
            "8080")

        HTTPS_PORT=$(tui_input "HTTPS Port" \
            "HTTPS port for Nginx Proxy Manager (default: 443).
If your NAS uses port 443, try 8444 (8443 is used by the dashboard)." \
            "8444")

        # Only ask about DNS port if Pi-hole is selected (post-v1.6.35
        # split — Pi-hole is its own module now, not buried in `privacy`).
        if echo "${SELECTED_MODULES}" | grep -qE '\bpihole\b'; then
            PIHOLE_DNS_PORT=$(tui_input "DNS Port" \
                "DNS port for Pi-hole (default: 53).
If another DNS service runs on 53, try 5353." \
                "5353")
        fi

        PORTAINER_PORT=$(tui_input "Portainer Port" \
            "Portainer web UI port (default: 9000)." \
            "9000")
    fi
fi

# --- Dashboard Password ---

log_info "Setting up dashboard access..."

ADMIN_PASSWORD=$(tui_password "Dashboard Password" "Set a password for your OpenBox Dashboard (leave blank to auto-generate):")

if [[ -z "${ADMIN_PASSWORD}" ]]; then
    ADMIN_PASSWORD=$(gen_password)
fi

SB_ADMIN_PASSWORD_HASH=$(hash_password "${ADMIN_PASSWORD}")
OB_SESSION_SECRET=$(gen_secret)
OB_BACKUP_KEY=$(gen_secret)

# --- Module-specific Configuration (Dynamic) ---

declare -A ENV_VALUES

for module in ${SELECTED_MODULES}; do
    compose="${OB_ROOT}/modules/${module}/docker-compose.yml"
    [[ -f "${compose}" ]] || continue

    title=$(read_openbox_field "${compose}" "title")
    [[ -z "${title}" ]] && title="${module}"

    env_vars_json=$(parse_env_vars "${compose}")
    [[ "${env_vars_json}" == "[]" ]] && continue

    log_info "Configuring ${title}..."

    while IFS= read -r var_line; do
        var_key=$(echo "${var_line}" | sed 's/^"\(.*\)"$/\1/')
        [[ -z "${var_key}" ]] && continue

        var_type=$(OB_COMPOSE_PATH="${compose}" OB_YAML_PATH="${OB_ROOT}/dashboard/node_modules/js-yaml" SB_VAR_KEY="${var_key}" \
            node -e "
const yaml=require(process.env.OB_YAML_PATH);
const fs=require('fs');
const doc=yaml.load(fs.readFileSync(process.env.OB_COMPOSE_PATH,'utf8'));
const ev=(doc['x-openbox']||{}).env_vars||{};
const v=ev[process.env.SB_VAR_KEY]||{};
console.log(v.type||'text');
" 2>/dev/null || echo "text")

        var_prompt=$(OB_COMPOSE_PATH="${compose}" OB_YAML_PATH="${OB_ROOT}/dashboard/node_modules/js-yaml" SB_VAR_KEY="${var_key}" \
            node -e "
const yaml=require(process.env.OB_YAML_PATH);
const fs=require('fs');
const doc=yaml.load(fs.readFileSync(process.env.OB_COMPOSE_PATH,'utf8'));
const ev=(doc['x-openbox']||{}).env_vars||{};
const v=ev[process.env.SB_VAR_KEY]||{};
console.log(v.prompt||'');
" 2>/dev/null || echo "")

        var_default=$(OB_COMPOSE_PATH="${compose}" OB_YAML_PATH="${OB_ROOT}/dashboard/node_modules/js-yaml" SB_VAR_KEY="${var_key}" \
            node -e "
const yaml=require(process.env.OB_YAML_PATH);
const fs=require('fs');
const doc=yaml.load(fs.readFileSync(process.env.OB_COMPOSE_PATH,'utf8'));
const ev=(doc['x-openbox']||{}).env_vars||{};
const v=ev[process.env.SB_VAR_KEY]||{};
console.log(v.default||'');
" 2>/dev/null || echo "")

        case "${var_type}" in
            secret)
                ENV_VALUES["${var_key}"]=$(gen_secret)
                ;;
            password)
                pw_val=""
                if [[ -n "${var_prompt}" ]]; then
                    pw_val=$(tui_password "${var_key}" "${var_prompt}")
                fi
                if [[ -z "${pw_val}" ]]; then
                    if [[ "${var_key}" == "WG_PASSWORD_HASH" ]]; then
                        raw_pw=$(gen_password)
                        if command -v docker &>/dev/null; then
                            ENV_VALUES["${var_key}"]=$(docker run --rm ghcr.io/wg-easy/wg-easy wgpw "${raw_pw}" 2>/dev/null | tail -1 || echo "${raw_pw}")
                        else
                            ENV_VALUES["${var_key}"]="${raw_pw}"
                        fi
                        ENV_VALUES["_WG_PASSWORD_RAW"]="${raw_pw}"
                    else
                        ENV_VALUES["${var_key}"]=$(gen_password)
                    fi
                else
                    if [[ "${var_key}" == "WG_PASSWORD_HASH" ]]; then
                        if command -v docker &>/dev/null; then
                            ENV_VALUES["${var_key}"]=$(docker run --rm ghcr.io/wg-easy/wg-easy wgpw "${pw_val}" 2>/dev/null | tail -1 || echo "${pw_val}")
                        else
                            ENV_VALUES["${var_key}"]="${pw_val}"
                        fi
                        ENV_VALUES["_WG_PASSWORD_RAW"]="${pw_val}"
                    else
                        ENV_VALUES["${var_key}"]="${pw_val}"
                    fi
                fi
                ;;
            text|path)
                if [[ -n "${var_prompt}" ]]; then
                    ENV_VALUES["${var_key}"]=$(tui_input "${var_key}" "${var_prompt}" "${var_default}")
                elif [[ -n "${var_default}" ]]; then
                    expanded=$(echo "${var_default}" | sed "s/\${SB_DOMAIN}/${SB_DOMAIN}/g")
                    ENV_VALUES["${var_key}"]="${expanded}"
                fi
                ;;
            boolean)
                ENV_VALUES["${var_key}"]="${var_default:-false}"
                ;;
        esac
    done < <(echo "${env_vars_json}" | node -e "
const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8'));
d.forEach(v=>console.log(JSON.stringify(v.key)));
" 2>/dev/null || true)

    log_ok "${title} configured."
done

# --- Process setup templates ---

for module in ${SELECTED_MODULES}; do
    compose="${OB_ROOT}/modules/${module}/docker-compose.yml"
    [[ -f "${compose}" ]] || continue

    templates_json=$(parse_setup_templates "${compose}")
    [[ "${templates_json}" == "[]" ]] && continue

    while IFS= read -r tmpl_line; do
        [[ -z "${tmpl_line}" ]] && continue
        tmpl_source=$(echo "${tmpl_line}" | node -e "const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8'));console.log(d.source||'')" 2>/dev/null || echo "")
        tmpl_dest=$(echo "${tmpl_line}" | node -e "const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8'));console.log(d.dest||'')" 2>/dev/null || echo "")

        [[ -z "${tmpl_source}" || -z "${tmpl_dest}" ]] && continue

        src_path="${OB_ROOT}/${tmpl_source}"
        dest_path="${OB_ROOT}/${tmpl_dest}"

        if [[ -f "${src_path}" ]]; then
            mkdir -p "$(dirname "${dest_path}")"
            content=$(cat "${src_path}")

            content=$(echo "${content}" | sed \
                -e "s|{{SB_DOMAIN}}|${SB_DOMAIN}|g")

            for key in "${!ENV_VALUES[@]}"; do
                [[ "${key}" == _* ]] && continue
                content=$(echo "${content}" | sed "s|{{${key}}}|${ENV_VALUES[${key}]}|g")
            done

            echo "${content}" > "${dest_path}"
            log_ok "Template rendered: ${tmpl_dest}"
        fi
    done < <(echo "${templates_json}" | node -e "
const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8'));
d.forEach(t=>console.log(JSON.stringify(t)));
" 2>/dev/null || true)
done

# --- Generate .env ---

log_info "Generating configuration file..."

# Determine OB_DATA_DIR for safe FileBrowser mount
OB_DATA_DIR="${OB_ROOT}/data"

{
    echo "# =========================================="
    echo "# OPENBOX - Generated Configuration"
    echo "# Generated: $(date)"
    echo "# DO NOT share this file - it contains secrets!"
    echo "# =========================================="
    echo ""
    echo "# --- SYSTEM ---"
    echo "TZ=${TZ}"
    echo "OB_ROOT=${OB_ROOT}"
    echo "SB_DOMAIN=${SB_DOMAIN}"
    echo ""
    echo "# User/group IDs for container file ownership"
    echo "# Find yours with: id -u (PUID) and id -g (PGID)"
    echo "PUID=${PUID}"
    echo "PGID=${PGID}"
    echo ""
    echo "# --- PORTS ---"
    echo "# Customize if defaults conflict with NAS services"
    echo "HTTP_PORT=${HTTP_PORT}"
    echo "HTTPS_PORT=${HTTPS_PORT}"
    echo "PIHOLE_DNS_PORT=${PIHOLE_DNS_PORT}"
    echo "PORTAINER_PORT=${PORTAINER_PORT}"
    echo ""
    echo "# --- PATHS ---"
    echo "# FileBrowser safe mount directory"
    echo "OB_DATA_DIR=${OB_DATA_DIR}"
    if [[ -n "${MEDIA_ROOT}" ]]; then
        echo "# Media storage root (movies, tv, music, downloads, etc.)"
        echo "MEDIA_ROOT=${MEDIA_ROOT}"
    fi
    echo ""
    echo "# --- DASHBOARD ---"
    echo "SB_ADMIN_PASSWORD_HASH=${SB_ADMIN_PASSWORD_HASH}"
    echo "OB_SESSION_SECRET=${OB_SESSION_SECRET}"
    echo "# Backup encryption key - keep this safe! Without it, encrypted backups are unrecoverable."
    echo "OB_BACKUP_KEY=${OB_BACKUP_KEY}"

    # --- Media / VPN vars ---
    if [[ "${HAS_MEDIA}" == "true" ]]; then
        echo ""
        echo "# --- MEDIA ---"
        echo "JELLYFIN_HW_ACCEL=${JELLYFIN_HW_ACCEL}"
        if [[ -n "${VPN_SERVICE_PROVIDER}" ]]; then
            echo ""
            echo "# --- DOWNLOAD VPN (Gluetun) ---"
            echo "# VPN_PROVIDER maps to Gluetun's VPN_SERVICE_PROVIDER env var"
            echo "VPN_PROVIDER=${VPN_SERVICE_PROVIDER}"
            echo "VPN_TYPE=${VPN_TYPE}"
            if [[ "${VPN_TYPE}" == "wireguard" ]]; then
                echo "WIREGUARD_PRIVATE_KEY=${WIREGUARD_PRIVATE_KEY}"
                echo "WIREGUARD_ADDRESSES=${WIREGUARD_ADDRESSES}"
            else
                echo "VPN_USER=${OPENVPN_USER}"
                echo "VPN_PASSWORD=${OPENVPN_PASSWORD}"
            fi
            [[ -n "${SERVER_COUNTRIES}" ]] && echo "SERVER_COUNTRIES=${SERVER_COUNTRIES}"
        fi
    fi

    # Write module-specific env vars
    for module in ${SELECTED_MODULES}; do
        compose="${OB_ROOT}/modules/${module}/docker-compose.yml"
        [[ -f "${compose}" ]] || continue

        title=$(read_openbox_field "${compose}" "title")
        [[ -z "${title}" ]] && title="${module}"

        env_vars_json=$(parse_env_vars "${compose}")
        [[ "${env_vars_json}" == "[]" ]] && continue

        echo ""
        echo "# --- ${title^^} ---"
        while IFS= read -r var_key; do
            var_key=$(echo "${var_key}" | sed 's/^"\(.*\)"$/\1/')
            [[ -z "${var_key}" || "${var_key}" == _* ]] && continue
            echo "${var_key}=${ENV_VALUES[${var_key}]:-}"
        done < <(echo "${env_vars_json}" | node -e "
const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8'));
d.forEach(v=>console.log(JSON.stringify(v.key)));
" 2>/dev/null || true)
    done
} > "${OB_ROOT}/.env"

chmod 600 "${OB_ROOT}/.env"
log_ok "Configuration saved to ${OB_ROOT}/.env"

# --- Create media directories if needed ---

if [[ -n "${MEDIA_ROOT}" ]]; then
    log_info "Creating media directories..."
    for subdir in movies tv music downloads books photos; do
        mkdir -p "${MEDIA_ROOT}/${subdir}" 2>/dev/null || true
    done
    # Set ownership if we can
    if [[ $EUID -eq 0 ]] && [[ "${PUID}" != "0" ]]; then
        chown -R "${PUID}:${PGID}" "${MEDIA_ROOT}" 2>/dev/null || true
    fi
    log_ok "Media directories created at ${MEDIA_ROOT}"
fi

# --- Save credentials to a secure file ---

CREDS_FILE="${OB_ROOT}/state/initial-credentials.txt"
{
    echo "================================================"
    echo "  OpenBox Credentials - SAVE THESE SECURELY!"
    echo "  Generated: $(date)"
    echo "  Delete this file after saving your passwords."
    echo "================================================"
    echo ""
    echo "Dashboard: https://${SB_DOMAIN}"
    echo "Password:  ${ADMIN_PASSWORD}"
    echo ""
    if [[ -n "${ENV_VALUES[PIHOLE_PASSWORD]:-}" ]]; then
        echo "Pi-hole Admin: https://pihole.${SB_DOMAIN}/admin"
        echo "Password: ${ENV_VALUES[PIHOLE_PASSWORD]}"
        echo ""
    fi
    if [[ -n "${ENV_VALUES[_WG_PASSWORD_RAW]:-}" ]]; then
        echo "WireGuard VPN UI: https://wg.${SB_DOMAIN}"
        echo "Password: ${ENV_VALUES[_WG_PASSWORD_RAW]}"
        echo ""
    fi
    if [[ -n "${VPN_SERVICE_PROVIDER}" ]]; then
        echo "Download VPN: ${VPN_SERVICE_PROVIDER} (${VPN_TYPE:-wireguard})"
        echo ""
    fi
    echo "PUID: ${PUID}"
    echo "PGID: ${PGID}"
    if [[ -n "${MEDIA_ROOT}" ]]; then
        echo "Media Root: ${MEDIA_ROOT}"
    fi
} > "${CREDS_FILE}"
chmod 600 "${CREDS_FILE}"

# --- Generate Homepage Config ---

if [[ -f "${OB_ROOT}/templates/homepage-services.yml.tmpl" ]]; then
    mkdir -p "${OB_ROOT}/modules/core/config/homepage"
    echo "# Auto-generated by OpenBox setup" > "${OB_ROOT}/modules/core/config/homepage/services.yaml"
    echo "# Homepage will auto-discover services via Docker labels" >> "${OB_ROOT}/modules/core/config/homepage/services.yaml"
fi

# --- Deploy ---

if tui_yesno "Deploy" "Configuration complete! Deploy OpenBox now?"; then
    log_info "Deploying OpenBox..."
    echo ""
    "${OB_ROOT}/openbox" up
else
    log_info "Setup complete. Run 'openbox up' when ready to deploy."
fi

# --- Summary ---

echo ""
echo -e "${BOLD}============================================${NC}"
echo -e "${BOLD}  OpenBox Setup Complete!${NC}"
echo -e "${BOLD}============================================${NC}"
echo ""
echo -e "  ${BOLD}Profile:${NC} ${PROFILE}"
if [[ "${IS_NAS}" == "true" ]]; then
    echo -e "  ${BOLD}Environment:${NC} NAS (${NAS_TYPE})"
fi
echo -e "  ${BOLD}Modules:${NC} core dashboard ${SELECTED_MODULES}"
echo ""
echo -e "  ${BOLD}Your credentials have been saved to:${NC}"
echo -e "  ${CREDS_FILE}"
echo ""
echo -e "  ${YELLOW}Read that file, save the passwords somewhere safe,${NC}"
echo -e "  ${YELLOW}then delete it: rm ${CREDS_FILE}${NC}"
echo ""
echo -e "  ${BOLD}Dashboard:${NC} https://${SB_DOMAIN}"
echo -e "  ${BOLD}CLI:${NC} openbox status | openbox help"
if [[ "${IS_NAS}" == "true" ]]; then
    echo -e "  ${BOLD}Diagnostics:${NC} openbox doctor"
fi
echo ""

# Log install
mkdir -p "${OB_ROOT}/state"
echo "[$(date)] Setup completed. Profile: ${PROFILE}. Modules: core dashboard ${SELECTED_MODULES}" >> "${OB_ROOT}/state/install.log"
