#!/usr/bin/env bash
# scripts/recyclarr-sync.sh
#
# Imports TRaSH-Guides quality profiles + custom formats into Sonarr
# and Radarr via the recyclarr docker image. OpenBox without this
# ships stock "HD-1080p" — Reddit will tell anyone that's junk for
# automated downloads. Recyclarr fetches the current TRaSH-Guides
# recommendations and applies them for us.
#
# Closes the "good defaults" gap surfaced by Phase 10 of the
# 2026-05-01 deep-audit pass (upstream-projects research).
#
# Idempotent. Marker: state/recyclarr-synced. Re-runnable by
# deleting the marker.
#
# Customer opt-out:
# - export SB_RECYCLARR_DISABLED=1 in /opt/openbox/.env
# - or rm state/recyclarr-synced after a successful sync (so it
#   won't auto-re-run from cmd_up; manual re-runs still work)
#
# Customer customization:
# - Edit modules/media/config/recyclarr.yml on the host (the script
#   copies qa/recyclarr.yml there on first sync, and then never
#   overwrites it — customer edits persist).

set -uo pipefail

OB_ROOT="${OB_ROOT:-/opt/openbox}"
STATE_DIR="${OB_ROOT}/state"
DONE_MARKER="${STATE_DIR}/recyclarr-synced"
LOG_FILE="${STATE_DIR}/recyclarr-sync.log"
RECYCLARR_DIR="${OB_ROOT}/modules/media/config/recyclarr"
RECYCLARR_CONF="${RECYCLARR_DIR}/recyclarr.yml"
RECYCLARR_TEMPLATE="${OB_ROOT}/qa/recyclarr.yml"
KEYS_FILE="${STATE_DIR}/arr-api-keys.json"

log() { printf '[recyclarr-sync] %s\n' "$*" | tee -a "${LOG_FILE}" >&2; }

# Opt-out check
if [[ -f "${OB_ROOT}/.env" ]] && grep -q '^SB_RECYCLARR_DISABLED=1' "${OB_ROOT}/.env" 2>/dev/null; then
    exit 0
fi

# Idempotency check
if [[ -f "${DONE_MARKER}" ]]; then
    exit 0
fi

# Need the *arr API keys
if [[ ! -r "${KEYS_FILE}" ]]; then
    log "no ${KEYS_FILE} — arr-bootstrap.sh hasn't generated keys yet. Skipping."
    exit 0
fi
SONARR_KEY=$(python3 -c "import json,sys; print(json.load(open('${KEYS_FILE}')).get('sonarr',''))" 2>/dev/null)
RADARR_KEY=$(python3 -c "import json,sys; print(json.load(open('${KEYS_FILE}')).get('radarr',''))" 2>/dev/null)
if [[ -z "${SONARR_KEY}" ]] || [[ -z "${RADARR_KEY}" ]]; then
    log "API keys missing from ${KEYS_FILE} — skipping."
    exit 0
fi

# Containers must be up + reachable
if ! docker ps --format '{{.Names}}' 2>/dev/null | grep -qE '^sb-(sonarr|radarr)$' 2>/dev/null; then
    log "ob-sonarr or ob-radarr not running — skipping."
    exit 0
fi

# Render the config from template (substituting API keys).
# Recyclarr's image runs as a non-root user (uid 1000 by default) and
# tries to create /config/cache + /config/log. Need the bind-mount
# directory writable by uid 1000. Chown after mkdir prevents the
# "Access to the path '/config/cache' is denied" failure on first run.
mkdir -p "${RECYCLARR_DIR}"
chown -R 1000:1000 "${RECYCLARR_DIR}" 2>/dev/null || true
if [[ ! -f "${RECYCLARR_CONF}" ]]; then
    if [[ ! -r "${RECYCLARR_TEMPLATE}" ]]; then
        log "ERROR: template ${RECYCLARR_TEMPLATE} not present in this install."
        log "       This usually means OpenBox was upgraded but qa/recyclarr.yml didn't get included."
        exit 1
    fi
    sed -e "s/__SONARR_API_KEY__/${SONARR_KEY}/g" \
        -e "s/__RADARR_API_KEY__/${RADARR_KEY}/g" \
        "${RECYCLARR_TEMPLATE}" > "${RECYCLARR_CONF}"
    chown 1000:1000 "${RECYCLARR_CONF}" 2>/dev/null || true
    chmod 600 "${RECYCLARR_CONF}"
    log "rendered ${RECYCLARR_CONF} from template"
else
    log "${RECYCLARR_CONF} already exists (customer may have customized) — using as-is."
fi

# Run recyclarr sync. Image is ~30MB. Joins sparkbox_sb_media so it
# can reach ob-gluetun (where the *arr APIs are).
log "running recyclarr sync (Sonarr + Radarr)..."
sync_out=$(docker run --rm \
    --user 1000:1000 \
    --network sparkbox_sb_media \
    -v "${RECYCLARR_DIR}:/config" \
    ghcr.io/recyclarr/recyclarr:7.4.1 sync 2>&1)
sync_rc=$?

# Recyclarr exit codes: 0 = success, 1 = soft-fail with warnings, 2 = hard fail
case ${sync_rc} in
    0)
        log "recyclarr sync OK."
        echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "${DONE_MARKER}"
        chmod 600 "${DONE_MARKER}" 2>/dev/null || true
        ;;
    1)
        log "recyclarr sync completed with warnings (likely some templates didn't match upstream); marker NOT written."
        echo "${sync_out}" | head -50 >> "${LOG_FILE}"
        exit 1
        ;;
    *)
        log "ERROR: recyclarr sync failed (exit ${sync_rc})"
        echo "${sync_out}" | head -50 >> "${LOG_FILE}"
        log "  See ${LOG_FILE} for full output. Re-run: sudo bash ${OB_ROOT}/scripts/recyclarr-sync.sh"
        exit 1
        ;;
esac
