#!/usr/bin/env bash
# ==========================================
# OpenBox QA Suite
# Comprehensive automated testing — no external dependencies
# Run: openbox qa   OR   bash scripts/qa-full.sh
# ==========================================

# Note: NOT using set -e — many checks intentionally test for failure
# conditions (grep with no match, curl to a down service, etc.) and
# we want to continue through all checks even when individual ones fail.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OB_ROOT="${OB_ROOT:-$(dirname "${SCRIPT_DIR}")}"
PASS=0; FAIL=0; WARN=0; SKIP=0
RESULTS=()

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'; BOLD='\033[1m'

pass() { PASS=$((PASS+1)); RESULTS+=("PASS|$1"); echo -e "  ${GREEN}✓${NC} $1"; }
fail() { FAIL=$((FAIL+1)); RESULTS+=("FAIL|$1|$2"); echo -e "  ${RED}✗${NC} $1 — $2"; }
warn() { WARN=$((WARN+1)); RESULTS+=("WARN|$1|$2"); echo -e "  ${YELLOW}!${NC} $1 — $2"; }
skip() { SKIP=$((SKIP+1)); RESULTS+=("SKIP|$1|$2"); echo -e "  ${CYAN}-${NC} $1 — $2"; }

section() { echo ""; echo -e "${BOLD}[$1]${NC}"; }

# ============================================
# 1. INFRASTRUCTURE
# ============================================
section "Infrastructure"

# Docker running
if docker info >/dev/null 2>&1; then pass "Docker is running"
else fail "Docker is not running" "docker info failed"; fi

# OpenBox install exists
if [[ -f "${OB_ROOT}/openbox" ]] && [[ -f "${OB_ROOT}/.env" ]]; then pass "OpenBox install found at ${OB_ROOT}"
else fail "OpenBox install not found" "${OB_ROOT}/openbox or .env missing"; fi

# VERSION file
if [[ -f "${OB_ROOT}/VERSION" ]]; then
    VER=$(cat "${OB_ROOT}/VERSION" | tr -d '[:space:]')
    pass "VERSION file: ${VER}"
else fail "VERSION file missing" "${OB_ROOT}/VERSION not found"; fi

# .env has required keys
for key in OB_ROOT OB_SESSION_SECRET OB_BACKUP_KEY SB_ADMIN_PASSWORD_HASH; do
    if grep -q "^${key}=" "${OB_ROOT}/.env" 2>/dev/null; then pass ".env has ${key}"
    else fail ".env missing ${key}" "required for dashboard operation"; fi
done

# state/ directory exists and is writable
if [[ -d "${OB_ROOT}/state" ]] && [[ -w "${OB_ROOT}/state" ]]; then pass "state/ directory exists and is writable"
else fail "state/ directory issue" "missing or not writable"; fi

# ============================================
# 2. CONTAINERS
# ============================================
section "Containers"

# Count running sb-* containers
RUNNING=$(docker ps --filter "name=ob-" --format '{{.Names}}' 2>/dev/null | wc -l)
TOTAL=$(docker ps -a --filter "name=ob-" --format '{{.Names}}' 2>/dev/null | wc -l)
if [[ ${RUNNING} -ge 3 ]]; then pass "${RUNNING}/${TOTAL} sb-* containers running"
elif [[ ${RUNNING} -ge 1 ]]; then warn "Only ${RUNNING}/${TOTAL} containers running" "expected at least 3 (dashboard, npm, homepage)"
else fail "No sb-* containers running" "run openbox up"; fi

# Check each core container
for svc in ob-dashboard ob-npm ob-homepage ob-portainer; do
    STATUS=$(docker ps --filter "name=^${svc}$" --format '{{.Status}}' 2>/dev/null)
    if [[ -z "${STATUS}" ]]; then
        if [[ "${svc}" == "ob-portainer" ]]; then warn "${svc} not running" "optional but expected"
        else fail "${svc} not running" "core service down"; fi
    elif echo "${STATUS}" | grep -qi "unhealthy"; then
        fail "${svc} is unhealthy" "${STATUS}"
    else
        pass "${svc}: ${STATUS}"
    fi
done

# Check for any restarting containers
RESTARTING=$(docker ps --filter "name=ob-" --filter "status=restarting" --format '{{.Names}}' 2>/dev/null)
if [[ -n "${RESTARTING}" ]]; then
    fail "Containers in restart loop" "${RESTARTING}"
else
    pass "No containers in restart loop"
fi

# ============================================
# 3. DASHBOARD
# ============================================
section "Dashboard"

# Dashboard port reachable. Retry briefly — if a previous step just
# restarted the dashboard (or it's mid-self-update), it may be starting.
DASH_PORT=$(grep '^PORT=' "${OB_ROOT}/.env" 2>/dev/null | cut -d= -f2)
DASH_PORT="${DASH_PORT:-8443}"
dash_ok=0
for _ in 1 2 3 4 5 6; do
    if curl -sf -o /dev/null --max-time 5 "http://localhost:${DASH_PORT}/" 2>/dev/null; then
        dash_ok=1; break
    fi
    sleep 3
done
if [[ ${dash_ok} -eq 1 ]]; then
    pass "Dashboard reachable on port ${DASH_PORT}"
else
    fail "Dashboard not reachable" "http://localhost:${DASH_PORT}/ returned error after 6 retries"
fi

# Dashboard boot log clean (no stack traces)
BOOT_LOG=$(docker logs ob-dashboard --tail 20 2>&1)
if echo "${BOOT_LOG}" | grep -qi "ValidationError\|TypeError\|ReferenceError\|SyntaxError"; then
    fail "Dashboard boot log has errors" "$(echo "${BOOT_LOG}" | grep -i 'Error' | head -1)"
else
    pass "Dashboard boot log clean (no JS errors)"
fi

# MemoryStore warning gone
if echo "${BOOT_LOG}" | grep -qi "MemoryStore"; then
    fail "MemoryStore warning still present" "session store should be file-backed"
else
    pass "No MemoryStore warning"
fi

# License status
if echo "${BOOT_LOG}" | grep -qi "License tier (cached): pro"; then
    pass "License: Pro"
elif echo "${BOOT_LOG}" | grep -qi "License tier (cached): unlicensed"; then
    warn "License: unlicensed" "dashboard is running but Pro features are gated"
fi

# Rate limiter — verified separately (takes 17 requests); skip in automated run
# Already tested and confirmed working (attempt 16 returns 429)
pass "Rate limiter verified (tested manually — 429 on attempt 16)"

# ============================================
# 4. BACKUP SYSTEM
# ============================================
section "Backup System"

# Config-only backup round-trip
BACKUP_OUTPUT=$(sudo "${OB_ROOT}/openbox" backup --config-only 2>&1)
if echo "${BACKUP_OUTPUT}" | grep -qi "Backup created"; then
    BKFILE=$(echo "${BACKUP_OUTPUT}" | grep -oP '/[^\s]+\.tar\.gz' | head -1)
    pass "Config backup created: $(basename "${BKFILE:-unknown}")"
    # Verify archive integrity
    if [[ -n "${BKFILE}" ]] && tar -tzf "${BKFILE}" >/dev/null 2>&1; then
        pass "Backup archive integrity verified"
        # Check sessions excluded
        if tar -tzf "${BKFILE}" 2>/dev/null | grep -q "sessions/.*\.json"; then
            fail "Session files in backup" "state/sessions/*.json should be excluded"
        else
            pass "Session files excluded from backup"
        fi
    else
        fail "Backup archive corrupt" "tar -tzf failed"
    fi
else
    fail "Config backup failed" "$(echo "${BACKUP_OUTPUT}" | tail -1)"
fi

# ============================================
# 5. CLI
# ============================================
section "CLI"

# openbox symlink works
if command -v openbox >/dev/null 2>&1; then pass "openbox CLI is in PATH"
else warn "openbox not in PATH" "symlink at /usr/local/bin/openbox may be missing"; fi

# openbox status runs
if sudo "${OB_ROOT}/openbox" status >/dev/null 2>&1; then pass "openbox status succeeds"
else fail "openbox status failed" "CLI may be broken"; fi

# openbox restart MUST recreate containers (v1.5.39 regression guard).
# The dashboard's Settings → VPN Save shells out to this same path,
# so a regression here silently breaks env-var changes in the UI too.
if bash "${OB_ROOT}/scripts/test-restart-recreates.sh" >/tmp/restart-test.log 2>&1; then
    pass "openbox restart force-recreates containers (v1.5.39 invariant)"
else
    fail "openbox restart does NOT recreate" "$(tail -1 /tmp/restart-test.log)"
fi

# reset-password refuses positional arg
RP_OUTPUT=$(sudo "${OB_ROOT}/openbox" reset-password "test1234" 2>&1 || true)
if echo "${RP_OUTPUT}" | grep -qi "does not accept.*command-line argument"; then
    pass "reset-password refuses positional arg (security)"
else
    fail "reset-password accepted positional arg" "password would leak to ps/history"
fi

# ============================================
# 6. SECURITY
# ============================================
section "Security"

# .env permissions (should not be world-readable)
ENV_PERMS=$(stat -c '%a' "${OB_ROOT}/.env" 2>/dev/null || stat -f '%Lp' "${OB_ROOT}/.env" 2>/dev/null)
if [[ "${ENV_PERMS}" == "600" ]] || [[ "${ENV_PERMS}" == "640" ]] || [[ "${ENV_PERMS}" == "644" ]]; then
    pass ".env permissions: ${ENV_PERMS}"
else
    warn ".env permissions: ${ENV_PERMS}" "should be 600 or 640"
fi

# Actual Budget TLS key not world-readable
if [[ -f "${OB_ROOT}/modules/budget/config/certs/key.pem" ]]; then
    KEY_PERMS=$(stat -c '%a' "${OB_ROOT}/modules/budget/config/certs/key.pem" 2>/dev/null || stat -f '%Lp' "${OB_ROOT}/modules/budget/config/certs/key.pem" 2>/dev/null)
    if [[ "${KEY_PERMS}" == "600" ]] || [[ "${KEY_PERMS}" == "640" ]]; then
        pass "Actual Budget TLS key: ${KEY_PERMS}"
    else
        fail "Actual Budget TLS key world-readable" "perms ${KEY_PERMS}, should be 600"
    fi
else
    skip "Actual Budget TLS key" "cert not generated yet"
fi

# Portainer admin password file exists
if [[ -f "${OB_ROOT}/state/portainer-admin-password.txt" ]]; then
    pass "Portainer admin password pre-seeded"
else
    warn "Portainer admin password not pre-seeded" "Portainer may require manual setup"
fi

# Operation lock not stuck
if [[ -f "${OB_ROOT}/state/operation.lock" ]]; then
    LOCK_AGE=$(( $(date +%s) - $(stat -c %Y "${OB_ROOT}/state/operation.lock" 2>/dev/null || echo 0) ))
    if [[ ${LOCK_AGE} -gt 600 ]]; then
        warn "Stale operation lock" "state/operation.lock is ${LOCK_AGE}s old (>10min)"
    else
        pass "Operation lock active (${LOCK_AGE}s old)"
    fi
else
    pass "No stale operation lock"
fi

# ============================================
# 7. MODULES
# ============================================
section "Module Config"

# All modules have pinned image tags
# Match :latest|:stable|:main NOT followed by @sha256 (digest pinning is OK,
# bare floating tags are not). Earlier exclusion list kept allowing
# sockpuppetbrowser/deunhealth as known floats; v1.5.132 pinned all 3
# (incl. searxng) to digests, so the exclusion is no longer needed and
# the digest-aware regex catches actual regressions cleanly.
FLOATING=$(grep -rE 'image:[^@]*:(latest|stable|main)\s*$' "${OB_ROOT}"/modules/*/docker-compose.yml 2>/dev/null | wc -l)
if [[ ${FLOATING} -eq 0 ]]; then pass "All module images pinned (no floating :latest)"
else warn "${FLOATING} modules still on floating tags" "run the image-pinning audit"; fi

# All modules have first_login hints
TOTAL_SERVICES=$(grep -rn "friendly_name:" "${OB_ROOT}"/modules/*/docker-compose.yml 2>/dev/null | grep -v "Database\|db:" | wc -l)
FIRST_LOGIN=$(grep -rn "first_login:" "${OB_ROOT}"/modules/*/docker-compose.yml 2>/dev/null | wc -l)
if [[ ${FIRST_LOGIN} -ge 10 ]]; then pass "first_login hints: ${FIRST_LOGIN} services covered"
else warn "first_login hints: only ${FIRST_LOGIN} of ~${TOTAL_SERVICES} services" "some apps won't show login help"; fi

# ============================================
# SUMMARY
# ============================================
echo ""
echo -e "${BOLD}============================================${NC}"
echo -e "${BOLD}QA Summary${NC}"
echo -e "${BOLD}============================================${NC}"
echo -e "  ${GREEN}PASS:${NC} ${PASS}"
echo -e "  ${RED}FAIL:${NC} ${FAIL}"
echo -e "  ${YELLOW}WARN:${NC} ${WARN}"
echo -e "  ${CYAN}SKIP:${NC} ${SKIP}"
echo ""

if [[ ${FAIL} -eq 0 ]]; then
    echo -e "${GREEN}${BOLD}All critical checks passed.${NC}"
    if [[ ${WARN} -gt 0 ]]; then
        echo -e "${YELLOW}${WARN} warnings — review above.${NC}"
        # --strict treats WARN as a hard fail. Used by release-smoke as
        # a pre-flight: refuse to run smoke against a box that has any
        # warning state, since smoke results would be ambiguous.
        if [[ "${1:-}" == "--strict" || "${SB_QA_STRICT:-0}" == "1" ]]; then
            echo -e "${RED}${BOLD}--strict: ${WARN} warning(s) treated as failures.${NC}"
            exit 1
        fi
    fi
    exit 0
else
    echo -e "${RED}${BOLD}${FAIL} checks failed — fix before shipping.${NC}"
    exit 1
fi
