#!/usr/bin/env python3
"""
Auto-bump module image pins to upstream latest stable.

Used by the daily auto-bump workflow. Reads every modules/*/docker-compose.yml,
queries Docker Hub / GitHub Releases for the latest stable tag, and applies
patch + minor bumps in place. MAJOR bumps are skipped — those need
individual test passes.

Output: writes the modified compose files + prints a summary table to stdout.
Exit 0 always (no bumps available is not an error). Exit 2 if a network
failure prevented the audit from running cleanly.

Read-only against the network. Modifies the local repo only.
"""

import json
import os
import re
import sys
import urllib.error
import urllib.request


def hub_latest(repo: str) -> str | None:
    try:
        url = f"https://hub.docker.com/v2/repositories/{repo}/tags?page_size=100&ordering=last_updated"
        req = urllib.request.Request(url, headers={"User-Agent": "openbox-auto-bump/1.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            d = json.load(r)
        cands = []
        for t in d.get("results", []):
            n = t.get("name", "")
            if any(x in n.lower() for x in ("nightly", "develop", "beta", "rc", "alpha", "test", "dev", "snapshot", "main", "master", "head", "preview", "edge")):
                continue
            m = re.match(r"^v?(\d+)\.(\d+)\.(\d+)$", n)
            if m:
                cands.append((tuple(int(x) for x in m.groups()), n))
        cands.sort(reverse=True)
        return cands[0][1] if cands else None
    except Exception:
        return None


def gh_latest(owner_repo: str) -> str | None:
    try:
        url = f"https://api.github.com/repos/{owner_repo}/releases/latest"
        req = urllib.request.Request(url, headers={"User-Agent": "openbox-auto-bump/1.0"})
        # If GITHUB_TOKEN is in env, use it to dodge the unauth rate limit
        token = os.environ.get("GITHUB_TOKEN")
        if token:
            req.add_header("Authorization", f"Bearer {token}")
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.load(r).get("tag_name")
    except Exception:
        return None


def latest_for(image: str) -> str | None:
    if image.startswith("ghcr.io/"):
        return gh_latest(image[len("ghcr.io/"):])
    if image.startswith("lscr.io/"):
        return hub_latest(image[len("lscr.io/"):])
    if "/" not in image:
        return hub_latest(f"library/{image}")
    return hub_latest(image)


def parse_semver(tag: str) -> tuple[int, int, int] | None:
    m = re.match(r"^v?(\d+)\.(\d+)\.(\d+)", tag)
    return tuple(int(x) for x in m.groups()) if m else None  # type: ignore


def classify(cur: str, new: str) -> str:
    """Return 'patch' | 'minor' | 'major' | 'unknown' for the bump category."""
    cv = parse_semver(cur)
    nv = parse_semver(new)
    if not cv or not nv or nv <= cv:
        return "unknown"
    if cv[0] != nv[0]:
        return "major"
    if cv[1] != nv[1]:
        return "minor"
    return "patch"


def find_pins(root: str) -> list[tuple[str, str, str, str]]:
    """Return list of (module, compose_path, image, tag) tuples."""
    out = []
    modules_dir = os.path.join(root, "modules")
    for module in sorted(os.listdir(modules_dir)):
        cf = os.path.join(modules_dir, module, "docker-compose.yml")
        if not os.path.isfile(cf):
            continue
        with open(cf) as f:
            content = f.read()
        for m in re.finditer(r"^\s*image:\s*([^\s#]+)", content, re.MULTILINE):
            full = m.group(1).strip()
            if "${" in full or "@sha256:" in full:
                continue
            base, _, tag = full.rpartition(":")
            if not base:
                base, tag = full, "latest"
            out.append((module, cf, base, tag))
    return out


def apply_bump(compose_path: str, image: str, old_tag: str, new_tag: str) -> bool:
    with open(compose_path) as f:
        content = f.read()
    pat = re.escape(f"{image}:{old_tag}")
    new_content, n = re.subn(pat, f"{image}:{new_tag}", content)
    if n == 0:
        return False
    with open(compose_path, "w") as f:
        f.write(new_content)
    return True


def main() -> int:
    root = os.environ.get("OB_ROOT", os.getcwd())
    pins = find_pins(root)
    seen = set()
    bumps_applied = []
    drift_skipped = []  # (module, image, old, new, category, reason)
    network_failures = 0
    total_checked = 0

    for module, cf, image, tag in pins:
        if (image, tag) in seen:
            continue
        seen.add((image, tag))
        if "sha256" in tag:
            continue
        total_checked += 1
        new = latest_for(image)
        if not new:
            network_failures += 1
            continue
        if new == tag:
            continue
        cat = classify(tag, new)
        if cat in ("patch", "minor"):
            if apply_bump(cf, image, tag, new):
                bumps_applied.append((module, image, tag, new, cat))
        elif cat == "major":
            drift_skipped.append((module, image, tag, new, cat, "major bump — manual review"))
        else:
            # Unparseable version format. Log but don't auto-bump.
            drift_skipped.append((module, image, tag, new, cat, "non-semver tag — manual review"))

    print("=== Auto-bump summary ===")
    print(f"Pins checked: {total_checked}")
    print(f"Network failures: {network_failures}")
    print(f"Bumps applied: {len(bumps_applied)}")
    print(f"Drift skipped (manual review): {len(drift_skipped)}")
    print()
    if bumps_applied:
        print("--- Applied ---")
        for module, image, old, new, cat in bumps_applied:
            short = image.split("/")[-1]
            print(f"  [{cat:5}] {module}: {short} {old} → {new}")
    if drift_skipped:
        print()
        print("--- Skipped (manual review needed) ---")
        for module, image, old, new, cat, reason in drift_skipped:
            short = image.split("/")[-1]
            print(f"  [{cat:7}] {module}: {short} {old} → {new}  ({reason})")

    # Emit a JSON summary so the workflow can decide what to do next
    summary = {
        "checked": total_checked,
        "network_failures": network_failures,
        "applied": [
            {"module": m, "image": i, "from": o, "to": n, "category": c}
            for (m, i, o, n, c) in bumps_applied
        ],
        "skipped": [
            {"module": m, "image": i, "from": o, "to": n, "category": c, "reason": r}
            for (m, i, o, n, c, r) in drift_skipped
        ],
    }
    summary_path = os.environ.get("SB_AUTO_BUMP_SUMMARY", "/tmp/sb-auto-bump-summary.json")
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nWrote summary: {summary_path}")

    # If too many network failures (>50% of checks), exit 2 so CI can retry
    if total_checked and network_failures > total_checked / 2:
        print("ERROR: too many network failures during version checks", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
