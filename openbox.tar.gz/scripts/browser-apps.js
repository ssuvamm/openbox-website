// SparkBox App-UI QA — exercises real module web UIs.
//
// For each module in the APPS list: enable it via the dashboard API,
// wait for its container to reach running state, wait extra for the
// HTTP port to actually accept connections, load the module's URL in
// headless Chromium, look for a content signature that proves the
// real service is responding (not a 502 or nginx default), then
// disable the module and move on. Serial execution keeps us under
// the Starter tier's 3-module cap.
//
// Scope: fast-starting, no-config modules bound to 0.0.0.0. Skips
// anything that needs a DB bootstrap (nextcloud, immich, paperless),
// VPN creds (media stack), real data dirs (jellyfin, files), or
// external service setup (matrix, gitea, bookstack).
//
// Usage:
//
//   NODE_PATH=/tmp/ob-qa-deps/node_modules \
//   SPARKBOX_IP=<your-test-host> \
//   SB_DASHBOARD_PASSWORD=test-password-12345 \
//   node scripts/browser-apps.js

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const IP = process.env.SPARKBOX_IP || '192.168.0.17';
const DASHBOARD_PORT = parseInt(process.env.SPARKBOX_PORT || '8443', 10);
const DASHBOARD_BASE = `http://${IP}:${DASHBOARD_PORT}`;
const HOST_BASE = `http://${IP}`;
const PASSWORD = process.env.SB_DASHBOARD_PASSWORD || 'test-password-12345';
const SCREENSHOT_DIR = path.join(__dirname, '..', 'browser-apps-screenshots');
const RESULTS_FILE = path.join(__dirname, '..', `browser-apps-results-${IP.replace(/\./g, '-')}.json`);

// Per-module config: module id (for enable API), container name (for
// health polling), host port, URL path, content signatures to look for,
// and how long to wait before giving up on the container coming up and
// on the HTTP endpoint responding. Signatures are matched case-insensitive
// against the full rendered HTML and the page title.
const APPS = [
  {
    id: 'linkding',
    container: 'ob-linkding',
    port: 9090,
    path: '/',
    signatures: ['linkding', 'Login', 'Username'],
    containerTimeout: 240_000,
    httpTimeout: 30_000,
  },
  {
    id: 'gotify',
    container: 'ob-gotify',
    port: 8880,
    path: '/',
    signatures: ['Gotify', 'gotify'],
    containerTimeout: 240_000,
    httpTimeout: 30_000,
  },
  {
    id: 'monitoring',
    container: 'ob-uptime-kuma',
    port: 3001,
    path: '/',
    signatures: ['Uptime Kuma', 'uptime-kuma', 'Dashboard', 'Sign Up'],
    containerTimeout: 240_000,
    httpTimeout: 60_000,
  },
  {
    id: 'budget',
    container: 'ob-actual',
    port: 5006,
    path: '/',
    https: true,
    signatures: ['Actual', 'actual', 'budget'],
    containerTimeout: 240_000,
    httpTimeout: 30_000,
  },
  {
    id: 'homarr',
    container: 'ob-homarr',
    port: 7575,
    path: '/',
    signatures: ['Homarr', 'homarr'],
    containerTimeout: 240_000,
    httpTimeout: 60_000,
  },
  {
    id: 'navidrome',
    container: 'ob-navidrome',
    port: 4533,
    path: '/',
    signatures: ['Navidrome', 'navidrome'],
    containerTimeout: 240_000,
    httpTimeout: 30_000,
  },
];

fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });

const results = [];
function record(name, status, detail) {
  results.push({ name, status, detail: detail || null, ts: new Date().toISOString() });
  const icon = status === 'pass' ? '✓' : status === 'fail' ? '✗' : '…';
  const color = status === 'pass' ? '\x1b[32m' : status === 'fail' ? '\x1b[31m' : '\x1b[33m';
  console.log(`${color}${icon}\x1b[0m ${name}${detail ? ' — ' + detail : ''}`);
}

async function snap(page, label) {
  const safe = label.replace(/[^a-z0-9]+/gi, '_').toLowerCase();
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, `${IP}-${safe}.png`), fullPage: false }).catch(() => {});
}

// --- Helpers ---
async function csrfHeader(context) {
  const cookies = await context.cookies(DASHBOARD_BASE);
  const csrf = cookies.find(c => c.name === '_csrf');
  return csrf ? { 'X-CSRF-Token': csrf.value } : {};
}
async function apiGet(context, p) {
  const resp = await context.request.get(`${DASHBOARD_BASE}${p}`);
  if (!resp.ok()) throw new Error(`GET ${p} → HTTP ${resp.status()}`);
  return resp.json();
}
async function apiPost(context, p, body) {
  const resp = await context.request.post(`${DASHBOARD_BASE}${p}`, {
    data: body,
    headers: { 'Content-Type': 'application/json', ...(await csrfHeader(context)) },
  });
  return { status: resp.status(), body: await resp.json().catch(() => ({})) };
}

async function listContainers(context) {
  const body = await apiGet(context, '/api/containers');
  return Array.isArray(body) ? body : (body.containers || []);
}

// Wait for a named container to be reported as running by the dashboard.
// Returns the container object or null on timeout.
async function waitForContainer(context, containerName, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const arr = await listContainers(context);
      const found = arr.find(c => (c.name || c.Name || '').includes(containerName));
      if (found && (found.state === 'running' || found.State === 'running')) return found;
    } catch {}
    await new Promise(r => setTimeout(r, 3000));
  }
  return null;
}

async function waitForContainerGone(context, containerName, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const arr = await listContainers(context);
      const found = arr.find(c => (c.name || c.Name || '').includes(containerName));
      if (!found) return true;
    } catch {}
    await new Promise(r => setTimeout(r, 2000));
  }
  return false;
}

// --- The test ---
(async () => {
  console.log(`\nSparkBox App-UI QA: ${DASHBOARD_BASE}`);
  console.log(`Testing ${APPS.length} modules serially (Starter tier cap is 3).\n`);

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    ignoreHTTPSErrors: true,
    viewport: { width: 1280, height: 800 },
  });
  const page = await context.newPage();

  try {
    // --- Login ---
    await page.goto(DASHBOARD_BASE, { waitUntil: 'domcontentloaded', timeout: 15000 });
    await page.waitForSelector('#login-screen:not(.hidden)', { timeout: 10000 });
    await page.fill('#login-password', PASSWORD);
    await page.click('#login-btn');
    await page.waitForSelector('#dashboard:not(.hidden)', { timeout: 10000 });
    record('login', 'pass');

    // Skip the wizard if it popped up — mirrors browser-qa.js
    await apiPost(context, '/api/wizard/skip', {}).catch(() => {});

    // --- Per-module tests ---
    for (const app of APPS) {
      console.log(`\n── ${app.id} ──────────────`);

      // 1. Enable via API
      try {
        const enableResp = await apiPost(context, `/api/modules/${app.id}/enable`, {});
        // Dashboard returns 202 (operation kicked off, poll for completion)
        // for async enable; older builds returned 200 sync. Accept both.
        if (enableResp.status !== 200 && enableResp.status !== 202) {
          throw new Error(`enable → ${enableResp.status}: ${JSON.stringify(enableResp.body)}`);
        }
        record(`${app.id}: enable`, 'pass');
      } catch (e) {
        record(`${app.id}: enable`, 'fail', e.message.substring(0, 200));
        continue; // skip the rest of this app
      }

      // 2. Wait for container
      const container = await waitForContainer(context, app.container, app.containerTimeout);
      if (!container) {
        record(`${app.id}: container running`, 'fail', `${app.container} not running within ${app.containerTimeout/1000}s`);
        // Attempt cleanup before moving on
        await apiPost(context, `/api/modules/${app.id}/disable`, {}).catch(() => {});
        await waitForContainerGone(context, app.container, 30_000);
        continue;
      }
      record(`${app.id}: container running`, 'pass', container.name || container.Name);

      // 3. Give the app extra time to bind its port — many apps report
      //    "running" before their HTTP server is accepting connections.
      //    Poll the port with a quick HTTP request until it answers.
      const scheme = app.https ? 'https' : 'http';
      const url = `${scheme}://${IP}:${app.port}${app.path}`;
      const deadline = Date.now() + app.httpTimeout;
      let httpOk = false;
      let lastStatus = null;
      while (Date.now() < deadline) {
        try {
          const resp = await context.request.get(url, { timeout: 5000 });
          lastStatus = resp.status();
          if (lastStatus < 500) { httpOk = true; break; }
        } catch {}
        await new Promise(r => setTimeout(r, 2000));
      }
      if (!httpOk) {
        record(`${app.id}: http reachable`, 'fail', `last status ${lastStatus || '(refused)'} after ${app.httpTimeout/1000}s`);
        await apiPost(context, `/api/modules/${app.id}/disable`, {}).catch(() => {});
        await waitForContainerGone(context, app.container, 30_000);
        continue;
      }
      record(`${app.id}: http reachable`, 'pass', `HTTP ${lastStatus}`);

      // 4. Playwright visit + signature check
      try {
        const resp = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: app.httpTimeout });
        // Let JS-rendered content populate
        await page.waitForTimeout(2000);
        const title = (await page.title().catch(() => '')) || '';
        const html = await page.content();
        const bodyText = await page.evaluate(() => document.body?.innerText || '').catch(() => '');
        const haystack = `${title}\n${html}\n${bodyText}`.toLowerCase();
        const hit = app.signatures.find(s => haystack.includes(s.toLowerCase()));
        if (!hit) {
          await snap(page, `${app.id}-no-match`);
          record(`${app.id}: UI signature`, 'fail', `HTTP ${resp.status()}, no signature in page (title="${title.substring(0,60)}")`);
        } else {
          record(`${app.id}: UI signature`, 'pass', `matched "${hit}", title="${title.substring(0,60)}"`);
        }
      } catch (e) {
        await snap(page, `${app.id}-load-fail`);
        record(`${app.id}: UI signature`, 'fail', e.message.substring(0, 200));
      }

      // 5. Disable and wait for cleanup so the next module fits under
      //    the 3-module cap
      try {
        const disableResp = await apiPost(context, `/api/modules/${app.id}/disable`, {});
        if (disableResp.status !== 200 && disableResp.status !== 202) throw new Error(`disable → ${disableResp.status}`);
        const gone = await waitForContainerGone(context, app.container, 30_000);
        record(`${app.id}: disable`, gone ? 'pass' : 'fail', gone ? 'container removed' : 'still present');
      } catch (e) {
        record(`${app.id}: disable`, 'fail', e.message.substring(0, 200));
      }
    }

    await page.close();
    await browser.close();
  } catch (e) {
    console.error('Fatal error:', e.message);
    record('fatal', 'fail', e.message);
    await browser.close().catch(() => {});
  }

  const passed = results.filter(r => r.status === 'pass').length;
  const failed = results.filter(r => r.status === 'fail').length;

  // Group by app for a clean summary
  const appSummary = {};
  for (const r of results) {
    const appId = r.name.split(':')[0];
    if (!appSummary[appId]) appSummary[appId] = { pass: 0, fail: 0 };
    appSummary[appId][r.status === 'pass' ? 'pass' : 'fail']++;
  }

  fs.writeFileSync(RESULTS_FILE, JSON.stringify({
    target: DASHBOARD_BASE,
    timestamp: new Date().toISOString(),
    passed,
    failed,
    byApp: appSummary,
    results,
  }, null, 2));

  console.log(`\n${'='.repeat(44)}`);
  console.log(`  ${DASHBOARD_BASE}`);
  console.log(`  passed: ${passed}`);
  console.log(`  failed: ${failed}`);
  console.log('');
  for (const [appId, s] of Object.entries(appSummary)) {
    if (appId === 'login' || appId === 'fatal') continue;
    const icon = s.fail === 0 ? '✓' : '✗';
    console.log(`  ${icon} ${appId.padEnd(20)} ${s.pass} pass / ${s.fail} fail`);
  }
  console.log(`  results: ${RESULTS_FILE}`);
  console.log('='.repeat(44));

  process.exit(failed > 0 ? 1 : 0);
})();
