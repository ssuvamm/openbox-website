#!/usr/bin/env node
//
// Long-session reauth test.
//
// Catches the v1.6.9 class of bug: an endpoint guarded by
// requireRecentReauth() server-side that the client doesn't recognize as
// a reauth-required path. Result is a silent 401 with no UI feedback —
// "save just appears to do nothing."
//
// HOW THE TEST WORKS
//
// 1. Fetch dashboard/server.js + dashboard/public/js/app.js from the
//    repo (or read them locally if SB_REPO_ROOT is set).
// 2. Parse out every (method, path) pair guarded by requireRecentReauth
//    on the server.
// 3. Parse the client-side needsRecentReauth() whitelist.
// 4. For each server-gated path, assert there's a matching client
//    whitelist entry. Report any mismatches.
//
// 5. Then exercise each gated endpoint live against a real install:
//    - Log in (sets session.reauthAt)
//    - Sleep past the configured short window (SB_REAUTH_WINDOW_SEC=5)
//    - Hit each endpoint with a method that should trip the gate
//    - Server MUST respond 401 + error:reauth_required (proves gate fires)
//    - If server returns silently 2xx, the gate didn't fire — fail
//    - If server returns 401 but with a different error shape, fail
//
// REQUIREMENTS
//
//   On the dashboard host:
//     SB_REAUTH_WINDOW_SEC=5 environment variable on ob-dashboard
//     (so we don't have to wait 10 real minutes per assertion)
//
//   Local:
//     SB_URL=http://192.168.0.17:8443
//     SB_PASSWORD=<admin password>
//
// USAGE
//
//   SB_URL=http://192.168.0.17:8443 SB_PASSWORD=xxx \
//     node scripts/test-reauth-long-session.js
//
// EXIT CODES
//   0 — all assertions pass
//   1 — at least one endpoint has missing client coverage or silent 401
//   2 — test couldn't run (no SB_URL, login failed, network error)

'use strict';

const fs = require('fs');
const path = require('path');

const SB_URL = process.env.SB_URL || 'http://192.168.0.17:8443';
const SB_PASSWORD = process.env.SB_PASSWORD;
const REPO_ROOT = process.env.SB_REPO_ROOT || path.resolve(__dirname, '..');
const REAUTH_WINDOW_SEC = parseInt(process.env.SB_REAUTH_WINDOW_SEC, 10) || 5;
const SLEEP_PAST_WINDOW_SEC = REAUTH_WINDOW_SEC + 2;

if (!SB_PASSWORD) {
  console.error('ERROR: SB_PASSWORD env var required');
  process.exit(2);
}

let pass = 0;
let fail = 0;
const failures = [];

function ok(msg)   { console.log('  \x1b[32m✓\x1b[0m ' + msg); pass++; }
function err(msg)  { console.log('  \x1b[31m✗\x1b[0m ' + msg); fail++; failures.push(msg); }
function info(msg) { console.log('  \x1b[34m▸\x1b[0m ' + msg); }
function step(msg) { console.log('\n\x1b[34m▶\x1b[0m ' + msg); }

// --- Phase 1: static analysis ----------------------------------------------

function parseServerReauthRoutes() {
  const src = fs.readFileSync(path.join(REPO_ROOT, 'dashboard', 'server.js'), 'utf8');
  // Match: app.<method>('<path>', ..., requireRecentReauth(...), ...)
  const re = /app\.(get|post|put|delete|patch)\(\s*['"`]\/api(\/[^'"`]+)['"`][^)]*requireRecentReauth/gm;
  const out = [];
  let m;
  while ((m = re.exec(src)) !== null) {
    out.push({ method: m[1].toUpperCase(), path: m[2] });
  }
  return out;
}

function parseClientWhitelist() {
  const src = fs.readFileSync(path.join(REPO_ROOT, 'dashboard', 'public', 'js', 'app.js'), 'utf8');
  // Grab the body of needsRecentReauth() — single function, easy regex
  const m = src.match(/function needsRecentReauth\(path\) \{([\s\S]*?)return false;\s*\}/);
  if (!m) throw new Error('Could not locate needsRecentReauth in app.js');
  const body = m[1];
  // We'll reuse the function logic by eval-ing a wrapped copy. Safer than
  // re-implementing the matcher and risking drift.
  /* eslint-disable no-new-func */
  return new Function('path', body + 'return false;');
}

// Normalize a server-side path with :id-style params to test against the
// client matcher (which matches generic prefixes).
function paramFreePath(p) {
  return p.replace(/:[A-Za-z_][A-Za-z0-9_]*/g, 'X');
}

function staticAnalysis() {
  step('Phase 1 — static analysis: server routes vs client whitelist');
  const serverRoutes = parseServerReauthRoutes();
  const needsReauth = parseClientWhitelist();
  info(`Found ${serverRoutes.length} server-side reauth-guarded routes.`);

  // Build unique set of server paths (some duplicate paths with different methods)
  const seen = new Set();
  const uniq = [];
  for (const r of serverRoutes) {
    const key = r.path;
    if (seen.has(key)) continue;
    seen.add(key);
    uniq.push(r);
  }
  info(`${uniq.length} unique paths.`);

  for (const r of uniq) {
    const probe = paramFreePath(r.path);
    if (needsReauth(probe)) {
      ok(`whitelist covers ${r.method} ${r.path}`);
    } else {
      err(`MISSING from client whitelist: ${r.method} ${r.path}  (probed as "${probe}")`);
    }
  }
}

// --- Phase 2: live probe ---------------------------------------------------

function decodeCookies(setCookieHeader) {
  if (!setCookieHeader) return [];
  // node-fetch returns set-cookie as either string or array depending on version
  const arr = Array.isArray(setCookieHeader) ? setCookieHeader : [setCookieHeader];
  return arr.map(c => c.split(';')[0]).join('; ');
}

async function login() {
  step('Phase 2 — login + capture session cookie');
  const r = await fetch(SB_URL + '/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: SB_PASSWORD }),
  });
  if (!r.ok) {
    err(`login failed: HTTP ${r.status} — ${await r.text()}`);
    process.exit(2);
  }
  // node 18+ fetch headers.getSetCookie() — fallback to header.get
  let cookies;
  if (r.headers.getSetCookie) {
    cookies = r.headers.getSetCookie().map(c => c.split(';')[0]).join('; ');
  } else {
    cookies = decodeCookies(r.headers.get('set-cookie'));
  }
  if (!cookies) {
    err('login returned no Set-Cookie header — session probably not created');
    process.exit(2);
  }
  ok('login OK; session cookie captured');
  return cookies;
}

async function probeOne(cookies, method, p) {
  // Send a body-shaped request that's likely to *reach* the gate before
  // hitting payload validation. For most endpoints an empty JSON body works.
  const url = SB_URL + '/api' + paramFreePath(p);
  const opts = {
    method,
    headers: { Cookie: cookies, 'Content-Type': 'application/json' },
  };
  if (method !== 'GET' && method !== 'DELETE') {
    opts.body = '{}';
  }
  let r;
  try {
    r = await fetch(url, opts);
  } catch (e) {
    err(`${method} ${p}: network error — ${e.message}`);
    return;
  }
  let body = {};
  try { body = await r.json(); } catch { /* non-JSON response */ }

  if (r.status === 401 && body && body.error === 'reauth_required') {
    ok(`${method} ${p} → 401 reauth_required ✓ (gate fired correctly)`);
  } else if (r.status === 401) {
    err(`${method} ${p} → 401 but error=${JSON.stringify(body.error)} (silent 401 — same shape as the v1.6.9 bug)`);
  } else if (r.status >= 200 && r.status < 300) {
    err(`${method} ${p} → ${r.status} OK (gate didn't fire — reauth window not enforced?)`);
  } else if (r.status === 400 && body && /payload|body|missing|invalid/i.test(body.error || body.message || '')) {
    // Some endpoints validate body before reauth — that's fine, gate is downstream
    info(`${method} ${p} → 400 (validation fired before reauth gate; not testable from this layer)`);
  } else {
    info(`${method} ${p} → ${r.status} ${JSON.stringify(body).slice(0, 100)}`);
  }
}

async function probeAfterWindow(cookies) {
  step(`Phase 3 — sleep ${SLEEP_PAST_WINDOW_SEC}s past reauth window, then probe`);
  await new Promise(r => setTimeout(r, SLEEP_PAST_WINDOW_SEC * 1000));
  ok(`slept ${SLEEP_PAST_WINDOW_SEC}s — reauth window (${REAUTH_WINDOW_SEC}s) should be expired`);

  const routes = parseServerReauthRoutes();
  // Only POST /api/setup/complete actually MUTATES — probing it would advance
  // the wizard. Use GET endpoints + safe-to-probe POSTs only.
  const SAFE_TO_PROBE = new Set([
    'GET /wizard/backup-key',
    'GET /passwords',
    'GET /backups/X',
    'POST /license/activate',  // empty body → fails validation OR reauth, never actually activates
    'POST /license',           // same as above
    'DELETE /license',         // would deactivate — but with empty cookie+window expired it should reauth-fail first
    'PUT /config',             // empty body → reauth fires before merge logic
    'POST /domains/setup',     // empty body → reauth fires before validation
    'POST /support/enable',
    'POST /server/soft-reset',
    'POST /modules/X/clean-slate',
    'POST /backup/restore',
    'POST /update',
    'POST /updates/apply',
    'POST /updates/rollback',
    'POST /self-update/apply',
    'POST /remote-access/wireguard/client',
    'POST /migrate/import',
    'GET /migrate/export',
    'GET /containers/X/first-login-creds',
  ]);
  // Don't probe /server/factory-reset or /server/reset-defaults — even with
  // expected 401 there's residual risk if the gate has a bug.

  for (const r of routes) {
    const k = `${r.method} ${r.path}`;
    if (!SAFE_TO_PROBE.has(k)) {
      info(`${k} → SKIPPED (not in safe-to-probe set)`);
      continue;
    }
    await probeOne(cookies, r.method, r.path);
  }
}

// --- Main ------------------------------------------------------------------

(async () => {
  console.log(`SparkBox reauth long-session test`);
  console.log(`  target:        ${SB_URL}`);
  console.log(`  reauth window: ${REAUTH_WINDOW_SEC}s (server SB_REAUTH_WINDOW_SEC)`);
  console.log(`  repo root:     ${REPO_ROOT}\n`);

  staticAnalysis();
  const cookies = await login();
  await probeAfterWindow(cookies);

  console.log('');
  if (fail === 0) {
    console.log(`\x1b[32m✓ reauth test PASSED — ${pass} assertions\x1b[0m`);
    process.exit(0);
  } else {
    console.log(`\x1b[31m✗ reauth test FAILED — ${fail} of ${fail + pass} assertions\x1b[0m`);
    for (const f of failures) console.log('    ' + f);
    process.exit(1);
  }
})();
