#!/usr/bin/env bash
# ==========================================
# Regression test: `openbox restart` MUST recreate containers
#
# Context: v1.5.39 fixed a silent failure where any user who
#   (a) enabled a module with empty env vars, then
#   (b) set those env vars in .env, then
#   (c) called `openbox restart` / clicked Settings → VPN → Save
# saw the new .env values IGNORED because docker-compose's plain
# `restart` reuses the existing container with its original env.
# Gluetun in particular died with "Wireguard settings: private
# key is not set" even though .env had the key.
#
# The fix switched `openbox restart` (both whole-stack and
# per-module paths) from `docker compose restart` to
# `docker compose up -d --force-recreate`.
#
# This test asserts that invariant directly:
#   - Container's `Created` timestamp only changes on recreate.
#   - Plain `restart` leaves it untouched.
#   - `up --force-recreate` bumps it.
#
# Run after `openbox up` has brought the stack online.
#
# Usage:
#   sudo bash scripts/test-restart-recreates.sh
# ==========================================

set -uo pipefail

OB_ROOT="${OB_ROOT:-/opt/openbox}"
SUBJECT_CONTAINER="${SUBJECT_CONTAINER:-ob-dashboard}"
SUBJECT_MODULE="${SUBJECT_MODULE:-dashboard}"

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'
pass() { echo -e "  ${GREEN}✓${NC} $1"; }
fail() { echo -e "  ${RED}✗${NC} $1"; exit 1; }
info() { echo -e "  ${YELLOW}→${NC} $1"; }

echo "Regression test: openbox restart force-recreates containers"

# Preflight: target container is up
if ! docker ps --filter "name=${SUBJECT_CONTAINER}" --format '{{.Names}}' | grep -q "^${SUBJECT_CONTAINER}$"; then
    fail "${SUBJECT_CONTAINER} is not running — run 'openbox up' first"
fi

created_before=$(docker inspect "${SUBJECT_CONTAINER}" --format '{{.Created}}' 2>/dev/null || true)
id_before=$(docker inspect "${SUBJECT_CONTAINER}" --format '{{.Id}}' 2>/dev/null || true)
if [[ -z "${created_before}" || -z "${id_before}" ]]; then
    fail "Could not inspect ${SUBJECT_CONTAINER}"
fi
info "Before restart: ${SUBJECT_CONTAINER} id=${id_before:0:12} created=${created_before}"

# Exercise the code path
info "Running: openbox restart ${SUBJECT_MODULE}"
if ! "${OB_ROOT}/openbox" restart "${SUBJECT_MODULE}" >/tmp/restart-test.log 2>&1; then
    cat /tmp/restart-test.log
    fail "openbox restart ${SUBJECT_MODULE} exited non-zero"
fi

# Give docker a beat to finish
sleep 3

created_after=$(docker inspect "${SUBJECT_CONTAINER}" --format '{{.Created}}' 2>/dev/null || true)
id_after=$(docker inspect "${SUBJECT_CONTAINER}" --format '{{.Id}}' 2>/dev/null || true)
info "After restart:  ${SUBJECT_CONTAINER} id=${id_after:0:12} created=${created_after}"

# The assertion: a container that was truly recreated has a new ID
# and a new Created timestamp. Plain `restart` leaves both unchanged,
# which is the bug we're guarding against.
if [[ "${id_before}" == "${id_after}" ]]; then
    fail "Container ID unchanged — openbox restart used plain 'docker compose restart' instead of --force-recreate. New .env values will NOT take effect on restart. See v1.5.39 fix."
fi

if [[ "${created_before}" == "${created_after}" ]]; then
    fail "Created timestamp unchanged — container was not recreated."
fi

pass "Container was recreated (id + timestamp both changed)"
pass "openbox restart picks up fresh .env values (v1.5.39 invariant holds)"
exit 0
