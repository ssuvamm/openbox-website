#!/usr/bin/env bash
# scripts/test-backup-restore.sh
#
# Backup + restore round-trip smoke. The biggest untested data-loss surface
# in OpenBox per Codex's QA review (2026-05-01): if a customer ever runs
# `openbox restore` and the file isn't actually replayable, their config
# is gone — there's no second chance.
#
# What this test does:
#   1. SSH to the test NAS
#   2. Plant a sentinel value in a backed-up location (a marker comment
#      in state/.env, since .env is part of every backup)
#   3. Run `openbox backup --config-only` — config-only round-trip is
#      fast (~15s, ~20KB), and the same restore code path handles full
#      backups, so config-only catches the most likely failure modes
#   4. Mutate / delete the sentinel
#   5. Run `openbox restore <file>` against the just-created backup
#   6. Assert the sentinel is back
#   7. Run a tiny container-health probe to confirm services still up
#
# On success: writes state/last-backup-restore.json with timestamp + commit.
# On failure: dumps relevant diagnostics and exits 1.
#
# Usage:
#   scripts/test-backup-restore.sh                 # uses ~/.openbox-rehearsal.env
#   scripts/test-backup-restore.sh --config /path/to/env

set -uo pipefail

# --- paint ---
RED=$'\e[31m'; GRN=$'\e[32m'; YLW=$'\e[33m'; BLU=$'\e[34m'; DIM=$'\e[2m'; OFF=$'\e[0m'
say()  { printf '%s\n' "$*"; }
step() { printf '\n%s▶%s %s\n' "$BLU" "$OFF" "$*"; }
ok()   { printf '%s✓%s %s\n' "$GRN" "$OFF" "$*"; }
warn() { printf '%s!%s %s\n' "$YLW" "$OFF" "$*"; }
fail() { printf '%s✗%s %s\n' "$RED" "$OFF" "$*" >&2; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "${SCRIPT_DIR}")"
START_TIME=$(date +%s)
FAILS=0
RESULTS_FILE="${PROJECT_ROOT}/state/last-backup-restore.json"
mkdir -p "${PROJECT_ROOT}/state"

CONFIG_FILE="${HOME}/.openbox-rehearsal.env"
if [[ "${1:-}" == "--config" && -n "${2:-}" ]]; then
    CONFIG_FILE="$2"; shift 2
fi
[[ -f "${CONFIG_FILE}" ]] && source "${CONFIG_FILE}"

TARGET_HOST="${TARGET_HOST:-}"
SSH_USER="${TARGET_USER:-${SSH_USER:-}}"
SSH_KEY="${TARGET_SSH_KEY:-${SSH_KEY:-}}"
if [[ -z "${TARGET_HOST}" || -z "${SSH_USER}" || -z "${SSH_KEY}" ]]; then
    fail "Missing TARGET_HOST / SSH_USER / SSH_KEY (set in ${CONFIG_FILE})"
    exit 1
fi
SSH="ssh -i ${SSH_KEY} -o ConnectTimeout=8 -o StrictHostKeyChecking=accept-new ${SSH_USER}@${TARGET_HOST}"

say "${DIM}target:  ${SSH_USER}@${TARGET_HOST}${OFF}"
SENTINEL_KEY="SB_BACKUP_RESTORE_TEST_$(date +%s)"
SENTINEL_VAL="openbox-roundtrip-$(date +%s)-$$"

# ============================================================
# STEP — Plant sentinel
# ============================================================
step "Plant sentinel in /opt/openbox/.env"
if ! ${SSH} "sudo -n tee -a /opt/openbox/.env >/dev/null <<EOF

# ${SENTINEL_KEY}=${SENTINEL_VAL}  (test-backup-restore sentinel; safe to remove)
EOF
" 2>&1; then
    fail "Could not append sentinel to .env"
    exit 1
fi
ok "sentinel ${SENTINEL_KEY}=${SENTINEL_VAL} added"

# ============================================================
# STEP — Run openbox backup --config-only
# ============================================================
step "openbox backup --config-only"
backup_path=$(${SSH} "sudo -n /opt/openbox/openbox backup --config-only 2>&1 | grep -oE 'Backup created: /[^ ]*\.tar\.gz(\.enc)?' | grep -oE '/[^ ]*' | head -1" 2>/dev/null || echo "")
if [[ -z "${backup_path}" ]]; then
    # Fall back: list latest, either encrypted or plain
    backup_path=$(${SSH} "sudo -n ls -t /opt/openbox/backups/openbox-config-*.tar.gz* 2>/dev/null | head -1" 2>/dev/null || echo "")
fi
if [[ -z "${backup_path}" ]]; then
    fail "Could not locate created backup file"
    FAILS=$((FAILS+1))
else
    backup_size=$(${SSH} "sudo -n stat -c %s ${backup_path} 2>/dev/null" || echo 0)
    if [[ "${backup_size:-0}" -lt 1024 ]]; then
        fail "Backup file unexpectedly small (${backup_size} bytes) — likely empty or corrupted: ${backup_path}"
        FAILS=$((FAILS+1))
    else
        ok "backup created: ${backup_path} (${backup_size} bytes)"
    fi
fi

# ============================================================
# STEP — Mutate the sentinel
# ============================================================
step "Mutate sentinel (so restore has something to recover)"
if ${SSH} "sudo -n sed -i '/${SENTINEL_KEY}/d' /opt/openbox/.env" 2>&1; then
    if ${SSH} "sudo -n grep -q '${SENTINEL_KEY}' /opt/openbox/.env" 2>/dev/null; then
        fail "Sentinel still present after deletion attempt"
        FAILS=$((FAILS+1))
    else
        ok "sentinel deleted from live .env"
    fi
else
    fail "Could not mutate .env"
    FAILS=$((FAILS+1))
fi

# ============================================================
# STEP — Restore
# ============================================================
if [[ -n "${backup_path}" && ${FAILS} -eq 0 ]]; then
    step "openbox restore ${backup_path}"
    # Pipe 'y' to handle both old (interactive prompt) and new (--yes flag)
    # openbox CLI versions. Falls through whether --yes is supported or not.
    restore_out=$(${SSH} "echo y | sudo -n /opt/openbox/openbox restore ${backup_path} 2>&1" 2>&1 || echo "FAILED")
    if echo "${restore_out}" | grep -qiE "(restore complete|restored|success)"; then
        ok "restore reported success"
    else
        fail "restore did not report success"
        say "${DIM}--- restore stderr/stdout (last 25 lines) ---${OFF}"
        echo "${restore_out}" | tail -25
        FAILS=$((FAILS+1))
    fi
fi

# ============================================================
# STEP — Verify sentinel is back
# ============================================================
step "Verify sentinel restored"
if ${SSH} "sudo -n grep -q '${SENTINEL_KEY}=${SENTINEL_VAL}' /opt/openbox/.env" 2>/dev/null; then
    ok "sentinel restored: ${SENTINEL_KEY}=${SENTINEL_VAL}"
else
    fail "Sentinel NOT restored. Round-trip BROKEN — customer restore would lose data."
    FAILS=$((FAILS+1))
fi

# ============================================================
# STEP — Cleanup sentinel (only on success)
# ============================================================
if [[ ${FAILS} -eq 0 ]]; then
    step "Cleanup sentinel"
    ${SSH} "sudo -n sed -i '/${SENTINEL_KEY}/d' /opt/openbox/.env" >/dev/null 2>&1 || true
    ok "test sentinel cleaned"
fi

# ============================================================
# STEP — Containers still healthy after restore
# ============================================================
step "Container health post-restore"
unhealthy=$(${SSH} "sudo -n docker ps --format '{{.Names}}|{{.Status}}' | grep -iE 'unhealthy|restarting|exited' | head -5" 2>/dev/null || echo "")
if [[ -z "${unhealthy}" ]]; then
    ok "no unhealthy containers"
else
    warn "post-restore unhealthy containers detected:"
    echo "${unhealthy}"
fi

# ============================================================
# Summary + state file
# ============================================================
ELAPSED=$(($(date +%s) - START_TIME))
COMMIT_SHA=$(git -C "${PROJECT_ROOT}" rev-parse HEAD 2>/dev/null || echo unknown)
COMMIT_SHORT=$(git -C "${PROJECT_ROOT}" rev-parse --short HEAD 2>/dev/null || echo unknown)
TIMESTAMP_UTC=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

if [[ ${FAILS} -eq 0 ]]; then
    say ""
    ok "backup-restore round-trip PASSED in ${ELAPSED}s"
    cat > "${RESULTS_FILE}" <<JSON
{
  "pass": true,
  "fails": 0,
  "elapsed_seconds": ${ELAPSED},
  "commit": "${COMMIT_SHA}",
  "commit_short": "${COMMIT_SHORT}",
  "target_host": "${TARGET_HOST}",
  "timestamp_utc": "${TIMESTAMP_UTC}",
  "backup_path": "${backup_path:-unknown}"
}
JSON
    exit 0
else
    say ""
    fail "backup-restore FAILED: ${FAILS} hard failure(s) in ${ELAPSED}s"
    cat > "${RESULTS_FILE}" <<JSON
{
  "pass": false,
  "fails": ${FAILS},
  "elapsed_seconds": ${ELAPSED},
  "commit": "${COMMIT_SHA}",
  "commit_short": "${COMMIT_SHORT}",
  "target_host": "${TARGET_HOST}",
  "timestamp_utc": "${TIMESTAMP_UTC}"
}
JSON
    exit 1
fi
