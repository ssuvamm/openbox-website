// media-autoseed.js
//
// Prototype for the full "customer zero credential typing" media setup.
// Runs AFTER `sparkbox enable media` + gluetun healthy. Performs:
//
//   1. Generate strong random admin password for Jellyfin
//   2. Drive Jellyfin's 10.10.6 first-run wizard via headless chromium
//      (the /Startup/User API is broken upstream; the web wizard works)
//   3. Sign into Jellyfin HTTP API to get an access token
//   4. Create a long-lived Jellyfin API key (survives session expiry)
//   5. Save creds+key to <sbRoot>/state/jellyfin-admin-password.txt
//   6. Tell Seerr to sign in as that Jellyfin user via /api/v1/auth/jellyfin
//      — Seerr stores its own copy of the Jellyfin API key in settings.json
//   7. Trigger Seerr library sync, enable Movies + TV, mark initialized
//
// Output: nothing on success. Exits 0. Non-zero on any failure with
// a clear error message.
//
// Env:
//   SB_ROOT                default /opt/sparkbox
//   SPARKBOX_IP            default 192.168.0.17
//   JELLYFIN_ADMIN_USER    default "sparkbox"

const { chromium } = require('playwright');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const http = require('http');

// When the wrapper runs this in a Playwright container, it sets
// SB_ROOT=/sb and bind-mounts state/ at /ob-state. On a dev host
// run directly with node, SB_ROOT is the install dir and state/
// is derived under it.
const SB_ROOT = process.env.SB_ROOT || '/opt/sparkbox';
const STATE_DIR = process.env.SB_STATE_DIR
  || (SB_ROOT === '/sb' ? '/ob-state' : path.join(SB_ROOT, 'state'));

// Jellyfin + Seerr URLs. Containerized path reaches services by
// docker name on sb_proxy; dev-host path uses LAN IP:port.
const JF = process.env.SPARKBOX_JELLYFIN_URL
  || `http://${process.env.SPARKBOX_IP || '192.168.0.17'}:8096`;
const SEERR = process.env.SPARKBOX_SEERR_URL
  || `http://${process.env.SPARKBOX_IP || '192.168.0.17'}:5055`;
// What hostname Seerr should use to reach Jellyfin from ITS container.
// Defaults to the internal docker name when both run on sb_proxy.
const SEERR_JF_HOST = process.env.SPARKBOX_SEERR_PUBLIC_HOST
  || process.env.SPARKBOX_IP
  || 'ob-jellyfin-media';

const USER = process.env.JELLYFIN_ADMIN_USER || 'sparkbox';
const PASS = process.env.JELLYFIN_ADMIN_PASSWORD
  || crypto.randomBytes(15).toString('base64').replace(/[+/=]/g, 'a').slice(0, 20);

const log = (m) => console.log(`[autoseed] ${m}`);
const die = (m) => { console.error(`[autoseed] FAIL: ${m}`); process.exit(1); };

async function httpPostJson(url, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const buf = Buffer.from(JSON.stringify(body));
    const req = http.request({
      method: 'POST',
      hostname: u.hostname, port: u.port || 80, path: u.pathname + u.search,
      headers: { 'content-type': 'application/json', 'content-length': buf.length, ...headers },
      timeout: 15000,
    }, (res) => {
      let data = ''; res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('http timeout')); });
    req.write(buf); req.end();
  });
}

async function httpGetJson(url, headers = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const req = http.request({
      method: 'GET', hostname: u.hostname, port: u.port || 80,
      path: u.pathname + u.search, headers, timeout: 15000,
    }, (res) => {
      let data = ''; res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('http timeout')); });
    req.end();
  });
}

async function waitForReachable(url, timeoutMs = 90000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await httpGetJson(url);
      if (r.status >= 200 && r.status < 500) return;
    } catch {}
    await new Promise(r => setTimeout(r, 2000));
  }
  throw new Error(`${url} not reachable within ${timeoutMs}ms`);
}

(async () => {
  log(`Starting auto-seed for Jellyfin (${JF}) + Seerr (${SEERR})`);
  log(`Jellyfin admin: ${USER} / <${PASS.length}-char pw>`);

  // === Step 1: Wait for Jellyfin + check state ===
  log('Waiting for Jellyfin to be reachable...');
  await waitForReachable(`${JF}/System/Info/Public`);
  const info = JSON.parse((await httpGetJson(`${JF}/System/Info/Public`)).body);
  if (info.StartupWizardCompleted) {
    log('Jellyfin wizard already complete — skipping wizard drive');
  } else {
    // === Step 2: Drive Jellyfin wizard via Playwright ===
    log('Driving Jellyfin wizard headlessly...');
    const browser = await chromium.launch({ headless: true });
    try {
      const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
      const page = await ctx.newPage();
      await page.goto(JF, { waitUntil: 'networkidle', timeout: 30000 });
      await page.waitForTimeout(1500);

      for (let step = 0; step < 10; step++) {
        await page.waitForTimeout(1000);
        const url = page.url();
        log(`  wizard step ${step}: ${url.split('#').pop()}`);

        // Fill user form if present
        const userInput = page.locator('input[name="Name"], #txtUsername').first();
        const pwInput = page.locator('input[name="Password"], #txtManualPassword, input[type="password"]').first();
        if (await pwInput.count() && await userInput.count() && await pwInput.isVisible().catch(() => false) && await userInput.isVisible().catch(() => false)) {
          await userInput.fill(USER);
          await pwInput.fill(PASS);
          const pwConfirm = page.locator('input[name="PasswordConfirm"], #txtPasswordConfirm').first();
          if (await pwConfirm.count() && await pwConfirm.isVisible().catch(() => false)) {
            await pwConfirm.fill(PASS);
          }
        }

        // Check if wizard completed
        const postInfo = await page.evaluate(async () => {
          const r = await fetch('/System/Info/Public');
          return await r.json().catch(() => null);
        });
        if (postInfo && postInfo.StartupWizardCompleted) { log('  wizard completed'); break; }

        // Click Next / Finish
        const labels = ['Finish', 'Next', 'Continue', 'OK'];
        let clicked = false;
        for (const l of labels) {
          const btn = page.locator(`button:has-text("${l}"), a:has-text("${l}")`).filter({ visible: true }).first();
          if (await btn.count() && await btn.isVisible().catch(() => false)) {
            await btn.click().catch(() => {});
            clicked = true;
            break;
          }
        }
        if (!clicked) { log('  no more wizard buttons — stopping'); break; }
      }
    } finally {
      await browser.close();
    }

    // Verify wizard done
    const after = JSON.parse((await httpGetJson(`${JF}/System/Info/Public`)).body);
    if (!after.StartupWizardCompleted) die('Jellyfin wizard did not complete');
    log('Jellyfin wizard done, StartupWizardCompleted=true');
  }

  // === Step 3: Sign in via API to get access token ===
  log('Signing in to Jellyfin API to obtain access token...');
  const auth = await httpPostJson(
    `${JF}/Users/AuthenticateByName`,
    { Username: USER, Pw: PASS },
    { 'X-Emby-Authorization': `MediaBrowser Client="SparkBox", Device="autoseed", DeviceId="sb-autoseed-${Date.now()}", Version="1.0"` }
  );
  if (auth.status !== 200) die(`Jellyfin sign-in failed: HTTP ${auth.status} — ${auth.body.slice(0, 200)}`);
  const authJson = JSON.parse(auth.body);
  const accessToken = authJson.AccessToken;
  const userId = authJson.User.Id;
  log(`  got access token (user id ${userId.slice(0, 8)}...)`);

  // === Step 4: Create long-lived API key ===
  log('Creating persistent Jellyfin API key...');
  const keyRes = await httpPostJson(
    `${JF}/Auth/Keys?App=SparkBox`,
    {},
    { 'X-Emby-Token': accessToken }
  );
  if (keyRes.status !== 204 && keyRes.status !== 200) {
    die(`Jellyfin API key create failed: HTTP ${keyRes.status} — ${keyRes.body.slice(0, 200)}`);
  }
  // The key list endpoint tells us what we just created
  const keysList = await httpGetJson(`${JF}/Auth/Keys`, { 'X-Emby-Token': accessToken });
  const keys = JSON.parse(keysList.body);
  const sparkboxKey = (keys.Items || []).find(k => k.AppName === 'SparkBox');
  if (!sparkboxKey) die('Could not find the API key we just created');
  const apiKey = sparkboxKey.AccessToken;
  log(`  API key created: ${apiKey.slice(0, 8)}...`);

  // === Step 4b: Unhide the admin user ===
  // The wizard-created admin ships with IsHidden=true, which removes
  // them from Jellyfin's login avatar grid. Customers hitting the
  // Jellyfin login page still have to TYPE "sparkbox" instead of
  // clicking the avatar. Flip the flag off so they can just click.
  try {
    const userRes = await httpGetJson(`${JF}/Users/${userId}`, { 'X-Emby-Token': accessToken });
    const user = JSON.parse(userRes.body);
    if (user.Policy && user.Policy.IsHidden) {
      user.Policy.IsHidden = false;
      await httpPostJson(
        `${JF}/Users/${userId}/Policy`,
        user.Policy,
        { 'X-Emby-Token': accessToken }
      );
      log('  admin user unhidden (shows in Jellyfin login picker)');
    }
  } catch (err) {
    log(`  WARN: could not unhide admin (${err.message}) — customer can still type username manually`);
  }

  // === Step 5: Persist creds + API key ===
  const credsFile = path.join(STATE_DIR, 'jellyfin-admin-password.txt');
  fs.mkdirSync(STATE_DIR, { recursive: true });
  fs.writeFileSync(credsFile, `username: ${USER}\npassword: ${PASS}\napi_key: ${apiKey}\n`, { mode: 0o600 });
  log(`  saved creds to ${credsFile} (mode 600)`);

  // === Step 6: Sign Seerr in to Jellyfin ===
  log('Waiting for Seerr to be reachable...');
  await waitForReachable(`${SEERR}/api/v1/status`);

  log('Signing Seerr into Jellyfin...');
  const seerrAuth = await httpPostJson(`${SEERR}/api/v1/auth/jellyfin`, {
    username: USER,
    password: PASS,
    hostname: SEERR_JF_HOST,
    port: 8096,
    useSsl: false,
    urlBase: '',
    email: `${USER}@sparkbox.local`,
    serverType: 2, // Jellyfin (1=Plex, 2=Jellyfin, 4=Emby). Without this, Seerr returns NO_ADMIN_USER.
  });
  if (seerrAuth.status !== 200 && seerrAuth.status !== 201) {
    die(`Seerr Jellyfin sign-in failed: HTTP ${seerrAuth.status} — ${seerrAuth.body.slice(0, 300)}`);
  }
  log('  Seerr signed in to Jellyfin');

  log('Done. Run `sudo sparkbox media-finish` next to create libraries + finalize Seerr.');
})().catch(e => { console.error('[autoseed] uncaught:', e.stack || e.message); process.exit(1); });
