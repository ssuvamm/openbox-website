#!/usr/bin/env bash
# scripts/lib/dump-artifacts.sh
#
# Common failure-artifact dumper. Sourced by test scripts to standardize
# the diagnostic bundle on FAIL — instead of every test inventing its
# own debug output. Per Codex QA review (2026-05-01): "every QA failure
# should collect docker ps, last logs, relevant state JSON, screenshots,
# test result JSON."
#
# Usage from a test:
#   source "$(dirname "$0")/lib/dump-artifacts.sh"
#   ARTIFACT_TARGET_HOST="$TARGET_HOST"  # exported
#   ARTIFACT_SSH="$SSH"                  # exported (full ssh command string)
#   trap 'dump_artifacts "$0"' ERR EXIT
#
# Or call directly:
#   bash scripts/lib/dump-artifacts.sh <test-name>
#
# Writes to: state/artifacts/<test-name>-<timestamp>/

set -uo pipefail

dump_artifacts() {
    local test_name="${1:-unknown-test}"
    test_name="$(basename "${test_name}" .sh)"
    local ts
    ts="$(date -u +%Y%m%dT%H%M%SZ)"
    local PROJECT_ROOT
    PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
    local out="${PROJECT_ROOT}/state/artifacts/${test_name}-${ts}"
    mkdir -p "${out}"

    printf 'dumping artifacts to %s\n' "${out}" >&2

    # If we have SSH access to a target, dump remote diagnostics
    local ssh_cmd="${ARTIFACT_SSH:-${SSH:-}}"
    if [[ -n "${ssh_cmd}" ]]; then
        ${ssh_cmd} "sudo -n docker ps -a --format '{{.Names}}|{{.Image}}|{{.Status}}'" > "${out}/docker-ps.txt" 2>&1 || true
        ${ssh_cmd} "sudo -n docker compose -f /opt/openbox/docker-compose.yml ps 2>/dev/null" > "${out}/compose-ps.txt" 2>&1 || true
        ${ssh_cmd} "sudo -n cat /opt/openbox/VERSION 2>/dev/null" > "${out}/openbox-version.txt" 2>&1 || true
        ${ssh_cmd} "sudo -n /opt/openbox/openbox doctor 2>&1" > "${out}/openbox-doctor.txt" 2>&1 || true

        # Last 100 lines of every unhealthy container
        local unhealthy
        unhealthy=$(${ssh_cmd} "sudo -n docker ps --format '{{.Names}}|{{.Status}}' | grep -iE 'unhealthy|restarting|exited' | cut -d'|' -f1" 2>/dev/null || echo "")
        if [[ -n "${unhealthy}" ]]; then
            mkdir -p "${out}/logs"
            while IFS= read -r container; do
                [[ -z "${container}" ]] && continue
                ${ssh_cmd} "sudo -n docker logs --tail 100 ${container} 2>&1" > "${out}/logs/${container}.log" 2>&1 || true
            done <<< "${unhealthy}"
        fi

        # State JSON files (if present, redact-safe)
        local state_files=(
            "/opt/openbox/state/license.json"
            "/opt/openbox/state/arr-bootstrap.log"
            "/opt/openbox/state/seerr-seed.log"
            "/opt/openbox/state/media-finish.log"
            "/opt/openbox/state/operation.lock"
            "/opt/openbox/state/last-update.log"
        )
        mkdir -p "${out}/state-files"
        for sf in "${state_files[@]}"; do
            local base
            base="$(basename "${sf}")"
            ${ssh_cmd} "sudo -n cat ${sf} 2>/dev/null | head -200" > "${out}/state-files/${base}" 2>&1 || true
        done
    fi

    # Local stamps
    for stamp in "${PROJECT_ROOT}/state/last-smoke.json" \
                 "${PROJECT_ROOT}/state/last-rehearsal.json" \
                 "${PROJECT_ROOT}/state/last-backup-restore.json" \
                 "${PROJECT_ROOT}/state/release-audit.log"; do
        [[ -f "${stamp}" ]] && cp "${stamp}" "${out}/" || true
    done

    # Git context
    git -C "${PROJECT_ROOT}" rev-parse HEAD > "${out}/git-head.txt" 2>/dev/null || true
    git -C "${PROJECT_ROOT}" status --short > "${out}/git-status.txt" 2>/dev/null || true

    printf '\nartifact bundle: %s\n' "${out}" >&2
    printf '   files: %d\n' "$(find "${out}" -type f | wc -l)" >&2
}

# When invoked directly, run with passed test name
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    dump_artifacts "${1:-manual}"
fi
