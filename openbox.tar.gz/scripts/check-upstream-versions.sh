#!/usr/bin/env bash
# scripts/check-upstream-versions.sh
#
# Audit every module's pinned image against upstream latest stable.
# Run weekly to spot drift before customers do. Output is a table
# showing patch/minor/major drift for each pin.
#
# Doesn't modify anything. Read-only inspection.
#
# Usage:
#   bash scripts/check-upstream-versions.sh

set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "${SCRIPT_DIR}")"
cd "${PROJECT_ROOT}"

if ! command -v python3 >/dev/null 2>&1; then
    echo "python3 required for upstream-version checks" >&2
    exit 1
fi

python3 - "${PROJECT_ROOT}" <<'PYEOF'
import os, re, json, sys, urllib.request

ROOT = sys.argv[1]
pins = []
for module in sorted(os.listdir(os.path.join(ROOT, 'modules'))):
    cf = os.path.join(ROOT, 'modules', module, 'docker-compose.yml')
    if not os.path.isfile(cf): continue
    with open(cf) as f: c = f.read()
    for m in re.finditer(r'^\s*image:\s*([^\s#]+)', c, re.MULTILINE):
        full = m.group(1).strip()
        if '${' in full or '@sha256:' in full: continue
        base, _, tag = full.rpartition(':')
        if not base: base, tag = full, 'latest'
        pins.append((module, base, tag))

def hub_latest(repo):
    try:
        url = f'https://hub.docker.com/v2/repositories/{repo}/tags?page_size=100&ordering=last_updated'
        req = urllib.request.Request(url, headers={'User-Agent':'ob-version-audit/1.0'})
        with urllib.request.urlopen(req, timeout=10) as r:
            d = json.load(r)
        cands = []
        for t in d.get('results', []):
            n = t.get('name', '')
            if any(x in n.lower() for x in ('nightly','develop','beta','rc','alpha','test','dev','snapshot')): continue
            m = re.match(r'^v?(\d+)\.(\d+)\.(\d+)$', n)
            if m: cands.append((tuple(int(x) for x in m.groups()), n))
        cands.sort(reverse=True)
        return cands[0][1] if cands else None
    except Exception: return None

def gh_latest(owner_repo):
    try:
        url = f'https://api.github.com/repos/{owner_repo}/releases/latest'
        req = urllib.request.Request(url, headers={'User-Agent':'ob-version-audit/1.0'})
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.load(r).get('tag_name')
    except Exception: return None

def latest_for(image):
    if image.startswith('ghcr.io/'):
        return gh_latest(image.replace('ghcr.io/', '', 1))
    if image.startswith('lscr.io/'):
        return hub_latest(image.replace('lscr.io/', '', 1))
    if '/' not in image:
        return hub_latest(f'library/{image}')
    return hub_latest(image)

print(f'\n{"Module":<14} {"Pin":<14} {"Latest":<14} Drift')
print('-' * 80)
seen = set(); summary = {'current': 0, 'patch': 0, 'minor': 0, 'major': 0, 'unknown': 0}
for module, base, tag in pins:
    if (base, tag) in seen: continue
    seen.add((base, tag))
    if 'sha256' in tag: continue
    latest = latest_for(base)
    drift = '?'; cat = 'unknown'
    if not latest: drift = '? (manual check)'
    elif latest == tag: drift = '✓ current'; cat = 'current'
    else:
        try:
            cv = tuple(int(x) for x in re.match(r'^v?(\d+)\.(\d+)\.(\d+)', tag).groups())
            nv = tuple(int(x) for x in re.match(r'^v?(\d+)\.(\d+)\.(\d+)', latest).groups())
            if nv > cv:
                if nv[0] != cv[0]: drift = '⚠ MAJOR'; cat = 'major'
                elif nv[1] != cv[1]: drift = '+ minor'; cat = 'minor'
                else: drift = '· patch'; cat = 'patch'
            else:
                drift = '✓ current'; cat = 'current'
        except Exception:
            drift = f'? ({tag} → {latest})'
    summary[cat] += 1
    print(f'{module:<14} {tag[-12:]:<14} {(latest or "?")[-12:]:<14} {drift}')

print('\nSummary:')
for k, v in summary.items():
    print(f'  {k}: {v}')
PYEOF
