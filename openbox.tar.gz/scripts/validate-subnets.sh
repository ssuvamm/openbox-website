#!/usr/bin/env bash
# Fail if any two OpenBox modules share a /24 subnet.
#
# Every module compose file gets its own ipam subnet so two modules can be
# enabled together without Docker network creation failing. The cost of a
# silent collision is a broken user — the module just fails to come up with
# "Pool overlaps with other one on this address space." This validator runs
# from CI and (ideally) any release pipeline to make sure a drive-by edit
# to a compose file can't regress the set.
#
# Exit codes:
#   0 — all subnets unique
#   1 — at least one collision
#   2 — could not find any module compose files
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

declare -A seen_subnet   # subnet -> owning module
collisions=0
total=0

shopt -s nullglob
compose_files=(modules/*/docker-compose.yml)
if (( ${#compose_files[@]} == 0 )); then
    echo "validate-subnets: no modules/*/docker-compose.yml files found" >&2
    exit 2
fi

for f in "${compose_files[@]}"; do
    mod="$(basename "$(dirname "$f")")"
    # Every `- subnet: X.X.X.X/YY` line in the ipam config section.
    while IFS= read -r subnet; do
        [[ -z "$subnet" ]] && continue
        total=$((total + 1))
        if [[ -n "${seen_subnet[$subnet]+set}" ]]; then
            printf 'COLLISION: %s — already owned by %s\n' \
                "$subnet: $mod" "${seen_subnet[$subnet]}"
            collisions=$((collisions + 1))
        else
            seen_subnet[$subnet]="$mod"
        fi
    done < <(grep -E '^\s*-\s*subnet:' "$f" | awk '{print $NF}')
done

if (( collisions > 0 )); then
    echo "validate-subnets: $collisions collision(s) across $total subnet declaration(s)" >&2
    exit 1
fi

echo "validate-subnets: $total unique subnet(s), no collisions"
