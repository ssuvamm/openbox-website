#!/usr/bin/env node
//
// Full app sweep — proves every enabled module is HTTP-reachable and
// returns the expected branding signal in its response body.
//
// Designed to run against any SparkBox install — UGREEN, VPS, or WSL2 —
// by passing SB_URL + SB_PASSWORD. Auto-discovers which modules are
// enabled via /api/modules, then probes each one's known HTTP surface.
//
// USAGE
//
//   SB_URL=http://192.168.0.17:8443 SB_PASSWORD=xxx \
//     node scripts/test-full-app-sweep.js
//
// What "passing" means per app:
//
//   1. The app's host port is open
//   2. HTTP 200/302/401 (anything non-5xx that isn't a connection refused)
//   3. The response body contains the expected branding signature
//      (e.g. Jellyfin's 'jellyfin', Sonarr's 'sonarr', Prowlarr's 'prowlarr')
//
// This catches:
//   - Container failed to start
//   - Container started but app crashed
//   - Wrong port mapping
//   - Reverse proxy returning a generic page (signature mismatch)
//   - VPN-tunneled apps unreachable because gluetun is down
//
// What it does NOT catch (and shouldn't try to):
//   - App-internal logic bugs (use per-app tests for those)
//   - Auth flows (those need cookies / login state)
//   - Data correctness
//
// EXIT CODES
//   0 — every enabled module passed
//   1 — at least one enabled module failed
//   2 — couldn't run (no SB_URL, login failed, /api/modules unreachable)

'use strict';

const SB_URL = process.env.SB_URL || 'http://192.168.0.17:8443';
const SB_PASSWORD = process.env.SB_PASSWORD;
const HOST = new URL(SB_URL).hostname;
const TIMEOUT_MS = 15000;

if (!SB_PASSWORD) {
  console.error('ERROR: SB_PASSWORD env var required');
  process.exit(2);
}

// --- App probe map ---------------------------------------------------------
//
// For each module (compose dir name), what host-side URL to probe and what
// substring the response body must contain (case-insensitive). When a
// module exposes multiple apps (the media bundle), each app gets its own
// entry keyed off the module name.
//
// VPN-routed apps (sonarr, radarr, etc.) are exposed on host ports via the
// gluetun container's port mappings — so we probe those direct host ports.
//
// Add new entries when you ship a new module. To verify the map matches
// reality: bash scripts/test-full-app-sweep.js --list-targets.

const PROBES = {
  // Always running
  core: [
    { name: 'Dashboard',     port: 8443, path: '/',                 sig: 'sparkbox' },
    { name: 'Homepage',      port: 3000, path: '/',                 sig: 'homepage' },
    { name: 'NPM (proxy)',   port: 81,   path: '/',                 sig: '(nginx|login)', optional: true },
  ],

  // Media bundle (one module → 8 apps, all VPN-routed via gluetun)
  media: [
    { name: 'Jellyfin',      port: 8096, path: '/web/index.html',   sig: 'jellyfin' },
    { name: 'Seerr',         port: 5055, path: '/login',            sig: '(jellyseerr|overseerr)' },
    { name: 'Prowlarr',      port: 8181, path: '/',                 sig: 'prowlarr' },
    { name: 'Sonarr',        port: 8989, path: '/',                 sig: 'sonarr' },
    { name: 'Radarr',        port: 7878, path: '/',                 sig: 'radarr' },
    { name: 'qBittorrent',   port: 8089, path: '/',                 sig: 'qbittorrent' },
    { name: 'Bazarr',        port: 6767, path: '/',                 sig: 'bazarr' },
    { name: 'Lidarr',        port: 8686, path: '/',                 sig: 'lidarr', optional: true },
  ],

  // Standalone modules — each one app
  jellyfin:        [{ name: 'Jellyfin (standalone)', port: 8097, path: '/web/index.html', sig: 'jellyfin' }],
  emby:            [{ name: 'Emby',              port: 8092, path: '/',          sig: 'emby' }],
  audiobookshelf:  [{ name: 'Audiobookshelf',    port: 13378, path: '/',         sig: 'audiobookshelf' }],
  navidrome:       [{ name: 'Navidrome',         port: 4533, path: '/',          sig: 'navidrome' }],
  ebooks:          [{ name: 'Calibre-Web',       port: 8083, path: '/',          sig: '(calibre|login)' }],
  immich:          [{ name: 'Immich',            port: 2283, path: '/',          sig: 'immich' }],
  photoprism:      [{ name: 'PhotoPrism',        port: 2342, path: '/',          sig: 'photoprism' }],

  cloud:           [{ name: 'Nextcloud',         port: 8445, path: '/login',     sig: 'nextcloud',  https: true }],
  files:           [{ name: 'Filebrowser',       port: 8086, path: '/',          sig: '(filebrowser|file browser)' }],
  paperless:       [{ name: 'Paperless-ngx',     port: 8010, path: '/',          sig: 'paperless' }],
  bookstack:       [{ name: 'BookStack',         port: 6875, path: '/',          sig: 'bookstack' }],

  privacy:         [
    { name: 'Pi-hole',         port: 8053, path: '/admin/',    sig: '(pi-hole|pihole)' },
    { name: 'Vaultwarden',     port: 8222, path: '/',          sig: '(vaultwarden|bitwarden)' },
  ],
  adguard:         [{ name: 'AdGuard Home',     port: 3053, path: '/',          sig: 'adguard' }],

  vpn:             [{ name: 'wg-easy',          port: 51821, path: '/',         sig: '(wireguard|wg-easy|login)' }],

  metrics:         [
    { name: 'Prometheus',      port: 9092, path: '/',          sig: 'prometheus' },
    { name: 'Grafana',         port: 3030, path: '/',          sig: 'grafana' },
  ],
  monitoring:      [{ name: 'Uptime Kuma',      port: 3001, path: '/',          sig: 'uptime-kuma' }],

  homarr:          [{ name: 'Homarr',           port: 7575, path: '/',          sig: 'homarr' }],
  homeassistant:   [{ name: 'Home Assistant',   port: 8123, path: '/',          sig: '(home assistant|hass)' }],

  gitea:           [{ name: 'Gitea',            port: 3300, path: '/',          sig: 'gitea' }],
  n8n:             [{ name: 'n8n',              port: 5678, path: '/',          sig: 'n8n' }],
  mealie:          [{ name: 'Mealie',           port: 9925, path: '/',          sig: 'mealie' }],
  budget:          [{ name: 'Actual Budget',    port: 5006, path: '/',          sig: 'actual' }],
  vikunja:         [{ name: 'Vikunja',          port: 3456, path: '/',          sig: 'vikunja', optional: true }],
  linkding:        [{ name: 'Linkding',         port: 9090, path: '/',          sig: 'linkding' }],
  freshrss:        [{ name: 'FreshRSS',         port: 8070, path: '/',          sig: 'freshrss' }],
  searxng:         [{ name: 'SearXNG',          port: 8088, path: '/',          sig: 'searxng' }],
  matrix:          [{ name: 'Element',          port: 8182, path: '/',          sig: '(element|matrix)' }],

  changedetection: [{ name: 'changedetection',  port: 5000, path: '/',          sig: 'changedetection' }],
  speedtest:       [{ name: 'OpenSpeedTest',    port: 8765, path: '/',          sig: 'speedtest' }],
  librespeed:      [{ name: 'LibreSpeed',       port: 8085, path: '/',          sig: 'speedtest' }],
  gotify:          [{ name: 'Gotify',           port: 8880, path: '/',          sig: 'gotify' }],
  'stirling-pdf':  [{ name: 'Stirling-PDF',     port: 8084, path: '/',          sig: 'stirling' }],
  backup:          [{ name: 'Duplicati',        port: 8200, path: '/',          sig: 'duplicati' }],
};

// --- HTTP probe ------------------------------------------------------------

async function probe(p) {
  const url = `${p.https ? 'https' : 'http'}://${HOST}:${p.port}${p.path}`;
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    // For HTTPS with self-signed certs (Nextcloud etc), we need to allow
    // unauthorized — node fetch follows env NODE_TLS_REJECT_UNAUTHORIZED.
    if (p.https) process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const r = await fetch(url, { signal: ctrl.signal, redirect: 'follow' });
    const body = await r.text();
    clearTimeout(t);
    if (r.status >= 500) {
      return { ok: false, reason: `HTTP ${r.status}` };
    }
    if (!new RegExp(p.sig, 'i').test(body)) {
      return {
        ok: false,
        reason: `signature missing (expected /${p.sig}/i, body[0..120]="${body.slice(0, 120).replace(/\n/g, ' ')}")`,
      };
    }
    return { ok: true, reason: `HTTP ${r.status} (${body.length}B, signature ✓)` };
  } catch (e) {
    clearTimeout(t);
    return {
      ok: false,
      reason: e.name === 'AbortError'
        ? `timeout after ${TIMEOUT_MS}ms`
        : `fetch error — ${e.message}`,
    };
  }
}

// --- Main ------------------------------------------------------------------

async function login() {
  const r = await fetch(SB_URL + '/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: SB_PASSWORD }),
  });
  if (!r.ok) {
    console.error(`login failed: HTTP ${r.status} — ${await r.text()}`);
    process.exit(2);
  }
  const cookies = r.headers.getSetCookie
    ? r.headers.getSetCookie().map(c => c.split(';')[0]).join('; ')
    : (r.headers.get('set-cookie') || '').split(',').map(s => s.split(';')[0]).join('; ');
  if (!cookies) { console.error('login returned no Set-Cookie'); process.exit(2); }
  return cookies;
}

async function getEnabledModules(cookies) {
  const r = await fetch(SB_URL + '/api/modules', { headers: { Cookie: cookies } });
  if (!r.ok) {
    console.error(`/api/modules → HTTP ${r.status} — ${await r.text()}`);
    process.exit(2);
  }
  const d = await r.json();
  // Returns list of { id, enabled, ... } — both shapes seen in the wild
  if (Array.isArray(d)) {
    return d.filter(m => m.enabled).map(m => m.id);
  }
  if (Array.isArray(d.enabled)) return d.enabled;
  if (Array.isArray(d.modules)) {
    return d.modules.filter(m => m.enabled).map(m => m.id);
  }
  console.error('Unexpected /api/modules shape:', JSON.stringify(d).slice(0, 200));
  process.exit(2);
}

(async () => {
  console.log(`SparkBox full app sweep`);
  console.log(`  target: ${SB_URL}`);
  console.log(`  host:   ${HOST}\n`);

  if (process.argv.includes('--list-targets')) {
    for (const [m, list] of Object.entries(PROBES)) {
      for (const p of list) console.log(`  ${m.padEnd(16)} ${p.name.padEnd(24)} ${HOST}:${p.port}${p.path}  /${p.sig}/i`);
    }
    return;
  }

  const cookies = await login();
  const enabled = await getEnabledModules(cookies);
  console.log(`Enabled modules (${enabled.length}): ${enabled.join(', ')}\n`);

  let pass = 0, fail = 0, skipped = 0;
  const failures = [];

  for (const moduleId of enabled) {
    const probes = PROBES[moduleId];
    if (!probes) {
      console.log(`  \x1b[33m∘\x1b[0m ${moduleId.padEnd(16)} (no probe map entry — skipped)`);
      skipped++;
      continue;
    }
    for (const p of probes) {
      const r = await probe(p);
      const tag = r.ok ? '\x1b[32m✓\x1b[0m' : (p.optional ? '\x1b[33m⊘\x1b[0m' : '\x1b[31m✗\x1b[0m');
      const line = `  ${tag} ${moduleId.padEnd(16)} ${p.name.padEnd(24)} ${r.reason}`;
      console.log(line);
      if (r.ok) pass++;
      else if (p.optional) skipped++;
      else { fail++; failures.push(`${moduleId} → ${p.name}: ${r.reason}`); }
    }
  }

  console.log('');
  console.log(`Summary: ${pass} pass, ${fail} fail, ${skipped} skipped/optional`);
  if (fail === 0) {
    console.log(`\x1b[32m✓ Full app sweep PASSED\x1b[0m`);
    process.exit(0);
  } else {
    console.log(`\x1b[31m✗ Full app sweep FAILED\x1b[0m`);
    for (const f of failures) console.log(`    ${f}`);
    process.exit(1);
  }
})();
