// Headless test: simulate user with stale Jellyfin server cache,
// load Jellyfin's web UI, assert we DON'T land on the "Select Server"
// picker (which is the symptom of the bug). After patch, the inject
// script should drop the stale cache before the main bundle loads.
//
// Run: NODE_PATH=/tmp/ob-qa-deps/node_modules node jellyfin-cache-test.js

const { chromium } = require('playwright');
const JELLYFIN_URL = 'http://192.168.0.17:8096';

(async () => {
  console.log('=== Jellyfin stale-cache test ===');
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();

  // First navigate to set the origin in localStorage scope
  await page.goto(JELLYFIN_URL, { waitUntil: 'load' });

  // Reproduce Tom's exact scenario: cache has CORRECT URL but
  // WRONG server Id (post Jellyfin wipe+reinstall). Plus pre-seed
  // a fake CacheStorage entry so we can verify v3 also clears
  // SW caches.
  await page.evaluate(async () => {
    const stale = {
      Servers: [{
        Id: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',  // wrong Id
        ServerName: 'stale-bogus-server',
        ManualAddress: 'http://192.168.0.17:8096',  // correct URL
        LocalAddress: 'http://172.20.4.5:8096',
        UserId: '00000000000000000000000000000000',
        AccessToken: 'fake-token',
      }],
    };
    localStorage.setItem('apiclient', JSON.stringify(stale));
    sessionStorage.removeItem('sb-jf-chk');  // reset reload-loop guard
    // Pre-seed a CacheStorage entry — v3 should delete it on mismatch
    if ('caches' in window) {
      try {
        const c = await caches.open('sb-test-stale-cache');
        await c.put(new Request('/sb-test-marker'), new Response('stale'));
      } catch {}
    }
  });
  console.log('[1] pre-seeded cache with WRONG Id + sb-test-stale-cache CacheStorage');

  // Reload — this is when the SparkBox patch script should fire
  // and drop the stale cache because location.origin doesn't match.
  await page.reload({ waitUntil: 'networkidle' });
  console.log('[2] reloaded');

  // Inspect localStorage state after reload
  const cacheState = await page.evaluate(() => localStorage.getItem('apiclient'));
  console.log('[3] apiclient after reload:', cacheState ? cacheState.substring(0, 80) + '...' : 'CLEARED ✅');

  // Wait for bundle to load + UI to render
  await page.waitForTimeout(3000);

  const title = await page.title().catch(() => '');
  const url = page.url();
  const hasServerPicker = await page.locator('text=/Select Server|Add Server/i').count().catch(() => 0);
  const hasLoginForm = await page.locator('input[type="password"]').count().catch(() => 0);

  console.log('[4] page title:', title);
  console.log('    page url:', url);
  console.log('    server-picker visible?', hasServerPicker > 0);
  console.log('    login form visible?', hasLoginForm > 0);

  // Verify v3 also cleared the pre-seeded CacheStorage entry.
  const cacheStorageState = await page.evaluate(async () => {
    if (!('caches' in window)) return 'no-caches-api';
    const names = await caches.keys();
    return names.includes('sb-test-stale-cache') ? 'still-present' : 'cleared';
  });
  console.log('    pre-seeded CacheStorage:', cacheStorageState);

  // PASS criteria: user-facing behavior. CacheStorage check is
  // optional (only runs when the API is available — secure contexts:
  // HTTPS or localhost. Plain-HTTP origins like SparkBox's default
  // LAN access have no caches API → the v3 nuke is a silent no-op,
  // which is correct).
  const cacheCheckOk = cacheStorageState === 'cleared' || cacheStorageState === 'no-caches-api';
  const pass = (hasServerPicker === 0) && (hasLoginForm > 0) && cacheCheckOk;
  console.log(`\n=== ${pass ? 'PASS ✅' : 'FAIL ❌'} ===`);

  await browser.close();
  process.exit(pass ? 0 : 1);
})();
