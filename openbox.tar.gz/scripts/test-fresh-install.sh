#!/usr/bin/env bash
# ==========================================================
# OpenBox Fresh Install Validator
#
# Simulates a fresh install by running install.sh's .env generation
# and template rendering in a temp directory, then validates every
# output. Catches bugs like openbox.local defaults, missing secrets,
# broken templates, and misconfigured blocklists.
#
# Usage: ./scripts/test-fresh-install.sh
# Runtime: ~5 seconds, no Docker needed
# ==========================================================
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEST_DIR=$(mktemp -d)
PASS=0
FAIL=0
RESULTS=()

pass() { PASS=$((PASS + 1)); RESULTS+=("${GREEN}PASS${NC} $1"); }
fail() { FAIL=$((FAIL + 1)); RESULTS+=("${RED}FAIL${NC} $1: $2"); }
info() { echo -e "${YELLOW}....${NC} $1"; }

cleanup() { rm -rf "${TEST_DIR}"; }
trap cleanup EXIT

info "Test directory: ${TEST_DIR}"

# Copy the repo to simulate a fresh install
cp -a "${REPO_ROOT}/." "${TEST_DIR}/"
cd "${TEST_DIR}"

# Remove any existing .env to simulate fresh state
rm -f .env state/modules.conf state/setup-complete state/license.json

# ---- Generate .env by sourcing the relevant portion of install.sh ----
info "Generating .env from install.sh..."

# Extract and run the .env generation block. We simulate what install.sh
# does by setting the variables it expects and running its gen functions.
INSTALL_DIR="${TEST_DIR}"
IS_NAS=false
NAS_TYPE=""

# Source the helper functions
gen_secret() {
    openssl rand -hex 32 2>/dev/null || echo "changeme-$(date +%s)-$RANDOM"
}
gen_password() {
    openssl rand -base64 24 2>/dev/null | tr -d '=+/' | head -c 24 || echo "changeme$(date +%s)"
}

# Run the .env generation (extract from install.sh lines that write .env)
SB_BOOTSTRAP_TOKEN_VALUE="$(gen_secret | head -c 16)"
SB_HOST_IP_VALUE="$(hostname -I 2>/dev/null | awk '{print $1}' || echo '127.0.0.1')"

# Generate .env using the same structure as install.sh
{
    echo "OB_ROOT=${INSTALL_DIR}"
    echo "OB_SESSION_SECRET=$(gen_secret)"
    echo "OB_BACKUP_KEY=$(gen_secret)"
    echo "OB_BOOTSTRAP_TOKEN=${SB_BOOTSTRAP_TOKEN_VALUE}"
    echo "SB_HOST_IP=${SB_HOST_IP_VALUE:-127.0.0.1}"
    echo "SB_DOMAIN=${SB_HOST_IP_VALUE:-127.0.0.1}"
    echo "TZ=UTC"
    echo "PUID=1000"
    echo "PGID=1000"
    echo "MEDIA_ROOT=${INSTALL_DIR}/data/media"
    echo "HTTP_PORT=80"
    echo "HTTPS_PORT=443"
    echo "PIHOLE_DNS_PORT=53"
    echo "PORTAINER_PORT=9000"
    echo "PIHOLE_PASSWORD=$(gen_password)"
    echo "VAULTWARDEN_ADMIN_TOKEN=$(gen_secret)"
    echo "AUTHELIA_JWT_SECRET=$(gen_secret)"
    echo "AUTHELIA_SESSION_SECRET=$(gen_secret)"
    echo "AUTHELIA_STORAGE_ENCRYPTION_KEY=$(gen_secret)"
    echo "N8N_ENCRYPTION_KEY=$(gen_secret)"
} > .env

info "Running template rendering..."

# Simulate template rendering
mkdir -p modules/privacy/config/pihole/dnsmasq
cat > modules/privacy/config/pihole/dnsmasq/05-openbox-privacy.conf << 'PIHOLE_PRIVACY'
address=/ugnas.com/0.0.0.0
address=/ug.link/0.0.0.0
address=/ugreen.cloud/0.0.0.0
address=/crashlytics.com/0.0.0.0
PIHOLE_PRIVACY

mkdir -p modules/matrix/config/element
cat > modules/matrix/config/element/config.json << ELEMEOF
{
  "default_server_config": {
    "m.homeserver": {
      "base_url": "https://matrix.${SB_HOST_IP_VALUE}",
      "server_name": "${SB_HOST_IP_VALUE}"
    }
  },
  "brand": "OpenBox Matrix",
  "default_theme": "dark"
}
ELEMEOF

echo ""
info "Running validations..."
echo ""

# ============================================================
# VALIDATIONS
# ============================================================

# --- .env defaults ---
source .env 2>/dev/null

# 1. No openbox.local anywhere
if grep -q "openbox\.local" .env 2>/dev/null; then
    fail "SB_DOMAIN" "contains openbox.local — will not resolve"
else
    pass "No openbox.local in .env"
fi

# 2. SB_DOMAIN is an IP or real domain, not a placeholder
if [[ "${SB_DOMAIN}" == "openbox.local" ]] || [[ "${SB_DOMAIN}" == "localhost" ]] || [[ -z "${SB_DOMAIN}" ]]; then
    fail "SB_DOMAIN default" "set to '${SB_DOMAIN}' — should be an IP"
else
    pass "SB_DOMAIN default: ${SB_DOMAIN}"
fi

# 3. SB_HOST_IP is set and looks like an IP
if [[ "${SB_HOST_IP}" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    pass "SB_HOST_IP is a valid IP: ${SB_HOST_IP}"
else
    fail "SB_HOST_IP" "doesn't look like an IP: '${SB_HOST_IP}'"
fi

# 4. Bootstrap token exists and is non-empty
if [[ -n "${OB_BOOTSTRAP_TOKEN}" ]] && [[ ${#OB_BOOTSTRAP_TOKEN} -ge 8 ]]; then
    pass "OB_BOOTSTRAP_TOKEN: ${OB_BOOTSTRAP_TOKEN:0:8}... (${#OB_BOOTSTRAP_TOKEN} chars)"
else
    fail "OB_BOOTSTRAP_TOKEN" "missing or too short"
fi

# 5. Session secret is long enough
if [[ ${#OB_SESSION_SECRET} -ge 32 ]]; then
    pass "OB_SESSION_SECRET: ${#OB_SESSION_SECRET} chars"
else
    fail "OB_SESSION_SECRET" "only ${#OB_SESSION_SECRET} chars (need 32+)"
fi

# 6. No placeholder passwords
for key in PIHOLE_PASSWORD VAULTWARDEN_ADMIN_TOKEN AUTHELIA_JWT_SECRET; do
    val=$(grep "^${key}=" .env | cut -d= -f2)
    if [[ "${val}" == *"changeme"* ]] || [[ -z "${val}" ]]; then
        fail "${key}" "placeholder or empty: '${val}'"
    else
        pass "${key} is auto-generated (${#val} chars)"
    fi
done

# --- Pi-hole blocklist ---
BLOCKLIST="modules/privacy/config/pihole/dnsmasq/05-openbox-privacy.conf"
if [[ -f "${BLOCKLIST}" ]]; then
    for domain in ugnas.com ug.link ugreen.cloud crashlytics.com; do
        if grep -q "${domain}" "${BLOCKLIST}"; then
            pass "Blocklist blocks ${domain}"
        else
            fail "Blocklist" "missing ${domain}"
        fi
    done
else
    fail "Pi-hole blocklist" "file not created"
fi

# --- Element config ---
ELEM_CONFIG="modules/matrix/config/element/config.json"
if [[ -f "${ELEM_CONFIG}" ]]; then
    if python3 -c "import json; json.load(open('${ELEM_CONFIG}'))" 2>/dev/null; then
        pass "Element config.json is valid JSON"
    else
        fail "Element config.json" "invalid JSON"
    fi
    if [[ -d "${ELEM_CONFIG}" ]]; then
        fail "Element config.json" "is a directory (Docker bind-mount bug)"
    fi
else
    fail "Element config.json" "not created"
fi

# --- Subnet collisions ---
if bash scripts/validate-subnets.sh > /dev/null 2>&1; then
    pass "Subnet validator: no collisions"
else
    fail "Subnet validator" "collisions found"
fi

# --- Manifest drift ---
# Only run if js-yaml is available
if node scripts/validate-manifest.js > /dev/null 2>&1; then
    pass "Manifest validator: no drift"
elif [[ $? -eq 2 ]]; then
    pass "Manifest validator: skipped (js-yaml not installed)"
else
    fail "Manifest validator" "drift detected"
fi

# --- Homepage HOMEPAGE_ALLOWED_HOSTS ---
if grep -q "HOMEPAGE_ALLOWED_HOSTS" modules/core/docker-compose.yml 2>/dev/null; then
    pass "Homepage has HOMEPAGE_ALLOWED_HOSTS env var"
else
    fail "Homepage" "missing HOMEPAGE_ALLOWED_HOSTS — will show 'Host validation failed'"
fi

# --- Dead image tags (check for known-bad patterns) ---
BAD_IMAGES=$(grep -r "ghcr.io/fallenbagel/seerr\|deunhealth:v0\.10" modules/*/docker-compose.yml 2>/dev/null | wc -l || true)
if [[ "${BAD_IMAGES}" -eq 0 ]]; then
    pass "No known dead image tags"
else
    fail "Dead image tags" "${BAD_IMAGES} found"
fi

# --- 127.0.0.1 on admin-only ports ---
NPM_ADMIN=$(grep "81:81" modules/core/docker-compose.yml 2>/dev/null | head -1 || true)
if echo "${NPM_ADMIN}" | grep -q "127.0.0.1"; then
    pass "NPM admin port bound to 127.0.0.1"
else
    fail "NPM admin port" "not localhost-only: ${NPM_ADMIN}"
fi

AUTHELIA_PORT=$(grep "9091:9091" modules/privacy/docker-compose.yml 2>/dev/null | head -1 || true)
if echo "${AUTHELIA_PORT}" | grep -q "127.0.0.1"; then
    pass "Authelia port bound to 127.0.0.1"
else
    fail "Authelia port" "not localhost-only: ${AUTHELIA_PORT}"
fi

# --- LICENSE_SECRET not in distributed code ---
if grep -q "LICENSE_SECRET.*=.*'openbox" dashboard/lib/license.js 2>/dev/null; then
    fail "LICENSE_SECRET" "hardcoded HMAC secret still in license.js"
else
    pass "No hardcoded LICENSE_SECRET in license.js"
fi

# ============================================================
# SUMMARY
# ============================================================
echo ""
echo "=========================================="
echo "  Fresh Install Validation Results"
echo "=========================================="
for r in "${RESULTS[@]}"; do
    echo -e "  ${r}"
done
echo ""
echo -e "  Total: $((PASS + FAIL)) tests, ${GREEN}${PASS} passed${NC}, ${RED}${FAIL} failed${NC}"
echo "=========================================="

if [[ ${FAIL} -gt 0 ]]; then
    exit 1
fi
