#!/usr/bin/env bash
# ==========================================
# OpenBox - Docker Auto-Installer
# Installs Docker Engine + Compose v2 on Ubuntu/Debian
# On NAS systems, verifies Docker is available
# ==========================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() { echo -e "${CYAN}[Docker]${NC} $*"; }
log_ok() { echo -e "${GREEN}[Docker]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[Docker]${NC} $*"; }
log_error() { echo -e "${RED}[Docker]${NC} $*"; }

# --- Detect NAS ---

IS_NAS=false
if [[ -f /etc/ugos ]] || [[ -f /etc/ugos-release ]] || \
   [[ -d /etc/ugos.d ]] || grep -qi "ugos\|ugreen" /etc/os-release 2>/dev/null; then
    IS_NAS=true
    log_info "UGREEN NAS detected (UGOS Pro is Debian-based but Docker should be installed via UGOS App Center)."
elif [[ -f /etc/synoinfo.conf ]] || [[ -d /volume1 ]]; then
    IS_NAS=true
    log_info "Synology NAS detected."
elif [[ -f /etc/config/qpkg.conf ]]; then
    IS_NAS=true
    log_info "QNAP NAS detected."
elif command -v docker &>/dev/null && ! command -v apt-get &>/dev/null; then
    IS_NAS=true
    log_info "NAS-like environment detected (Docker present, no apt-get)."
fi

# --- Check if Docker is already installed ---

if command -v docker &>/dev/null; then
    log_ok "Docker is already installed: $(docker --version)"
    if docker compose version &>/dev/null; then
        log_ok "Docker Compose: $(docker compose version --short)"
    else
        log_warn "Docker Compose v2 not found."
        if [[ "${IS_NAS}" == true ]]; then
            log_error "Install Docker Compose through your NAS package manager."
        else
            log_error "Please install Docker Compose plugin."
        fi
        exit 1
    fi

    # Verify Docker daemon access
    if docker info &>/dev/null 2>&1; then
        log_ok "Docker daemon is accessible."
    else
        log_error "Docker is installed but the daemon is not accessible."
        if [[ $EUID -ne 0 ]]; then
            log_info "Try: sudo usermod -aG docker \$(whoami) && newgrp docker"
        fi
        exit 1
    fi

    exit 0
fi

# --- NAS: Docker must be installed via NAS package manager ---

if [[ "${IS_NAS}" == true ]]; then
    log_error "Docker is not installed."
    log_error "On a NAS, install Docker through your NAS package manager:"
    echo ""
    echo "  UGREEN: UGOS App Center -> Docker"
    echo "  Synology: Package Center -> Docker"
    echo "  QNAP: App Center -> Container Station"
    echo ""
    log_error "Then re-run this script."
    exit 1
fi

# --- VPS: Install Docker ---

if [[ $EUID -ne 0 ]]; then
    log_error "Must be run as root."
    exit 1
fi

log_info "Installing Docker Engine..."

# Remove old versions
apt-get remove -y docker docker-engine docker.io containerd runc 2>/dev/null || true

# Install via convenience script
curl -fsSL https://get.docker.com | sh

# Enable and start Docker
systemctl enable docker
systemctl start docker

# Verify installation
if command -v docker &>/dev/null; then
    log_ok "Docker installed: $(docker --version)"
else
    log_error "Docker installation failed."
    exit 1
fi

if docker compose version &>/dev/null; then
    log_ok "Docker Compose: $(docker compose version --short)"
else
    log_error "Docker Compose v2 not available."
    exit 1
fi

log_ok "Docker is ready."
