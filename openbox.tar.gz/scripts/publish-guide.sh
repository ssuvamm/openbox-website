#!/usr/bin/env bash
# Publish a guide: removes noindex, adds to sitemap, links on index page.
#
# Usage: ./scripts/publish-guide.sh <slug>
# Example: ./scripts/publish-guide.sh block-ads-pihole
#
# Prerequisites:
#   1. Guide HTML exists at website/guides/<slug>.html
#   2. Guide has <meta name="robots" content="noindex"> (draft state)
#   3. Guide is listed as "coming soon" on website/guides/index.html
#
# What this script does:
#   1. Removes the noindex meta tag (makes it indexable by Google)
#   2. Adds the guide to sitemap.xml
#   3. Updates schedule.json status to "published"
#   4. Reminds you to update the index page link manually
#      (the "coming soon" → live link swap is HTML-specific)
#
# After running this, commit + push + deploy to make it live.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SLUG="${1:-}"

if [[ -z "${SLUG}" ]]; then
    echo "Usage: $0 <guide-slug>"
    echo "Example: $0 block-ads-pihole"
    exit 1
fi

GUIDE="${REPO_ROOT}/website/guides/${SLUG}.html"
SITEMAP="${REPO_ROOT}/website/sitemap.xml"
SCHEDULE="${REPO_ROOT}/website/guides/schedule.json"

if [[ ! -f "${GUIDE}" ]]; then
    echo "ERROR: Guide not found at ${GUIDE}"
    exit 1
fi

echo "Publishing guide: ${SLUG}"

# 1. Remove noindex
if grep -q 'content="noindex"' "${GUIDE}"; then
    sed -i '/<meta name="robots" content="noindex">/d' "${GUIDE}"
    echo "  ✓ Removed noindex tag"
else
    echo "  - No noindex tag found (already indexable)"
fi

# 2. Add to sitemap if not already there
if ! grep -q "${SLUG}" "${SITEMAP}"; then
    sed -i "/<\/urlset>/i\\  <url>\\n    <loc>https://crushcodeworks.com/guides/${SLUG}.html</loc>\\n    <changefreq>monthly</changefreq>\\n    <priority>0.8</priority>\\n  </url>" "${SITEMAP}"
    echo "  ✓ Added to sitemap.xml"
else
    echo "  - Already in sitemap"
fi

# 3. Update schedule.json
if command -v python3 &>/dev/null; then
    python3 -c "
import json, sys
with open('${SCHEDULE}') as f:
    data = json.load(f)
for g in data['guides']:
    if g['slug'] == '${SLUG}':
        g['status'] = 'published'
with open('${SCHEDULE}', 'w') as f:
    json.dump(data, f, indent=2)
print('  ✓ Updated schedule.json')
"
else
    echo "  - python3 not available, update schedule.json manually"
fi

echo ""
echo "DONE. Next steps:"
echo "  1. Update website/guides/index.html — change the '${SLUG}' card from"
echo "     coming-soon (div) to a live link (a href)"
echo "  2. git add -A && git commit && git push"
echo "  3. Deploy: npx wrangler pages deploy website --project-name=openbox-site"
