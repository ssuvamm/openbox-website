﻿#!/usr/bin/env node
// Fail if any module manifest (x-openbox.services) declares a port_map
// that no service in the same compose file actually publishes.
//
// Drift is the class of bug the dashboard's "Open" button builds from:
// it reads port_map from the manifest, builds http(s)://host:<port>,
// and if that port is wrong the user lands on a 400, SSL error, or
// connection-refused. This script walks every module compose file and
// rejects the diff when the manifest port doesn't match a real binding.
//
// Gateway-routed services (e.g. media/jellyseerr behind gluetun) have
// no ports: block of their own because the gateway publishes everything.
// We treat the set of ALL host-side ports declared anywhere in the
// compose as the valid set, not just the service's own ports array.
//
// Run: node scripts/validate-manifest.js
// Exit 0 on clean, 1 on drift, 2 on usage/setup errors.
const fs = require('fs');
const path = require('path');
// Try a few paths before giving up — this script runs in CI, in the
// dashboard container (WORKDIR=/app), and from a bare repo checkout,
// each of which has a different resolve path for js-yaml.
let yaml;
const candidates = [
  'js-yaml',
  path.join(__dirname, '..', 'dashboard', 'node_modules', 'js-yaml'),
  path.join(__dirname, 'node_modules', 'js-yaml'),
  '/app/node_modules/js-yaml', // when run inside ob-dashboard
];
for (const c of candidates) {
  try { yaml = require(c); break; } catch {}
}
if (!yaml) {
  console.error('validate-manifest: js-yaml not found. Run `cd dashboard && npm install` once, or run this script inside the ob-dashboard container.');
  process.exit(2);
}

// Locate the modules dir. When run from the repo, it's next to this
// script's parent (../modules). When run from anywhere else, fall back
// to $PWD/modules. Users can also override with SB_REPO_ROOT.
function findModulesDir() {
  const candidates = [];
  if (process.env.SB_REPO_ROOT) candidates.push(path.join(process.env.SB_REPO_ROOT, 'modules'));
  candidates.push(path.resolve(__dirname, '..', 'modules'));
  candidates.push(path.resolve(process.cwd(), 'modules'));
  for (const c of candidates) {
    try {
      const s = fs.statSync(c);
      if (s.isDirectory()) return c;
    } catch {}
  }
  return null;
}
const MODULES_DIR = findModulesDir();
if (!MODULES_DIR) {
  console.error('validate-manifest: could not locate modules/ directory. Run from the repo root or set SB_REPO_ROOT.');
  process.exit(2);
}

const modules = fs.readdirSync(MODULES_DIR).filter((d) => {
  try { return fs.statSync(path.join(MODULES_DIR, d)).isDirectory(); } catch { return false; }
});

const drift = [];
for (const m of modules) {
  const p = path.join(MODULES_DIR, m, 'docker-compose.yml');
  if (!fs.existsSync(p)) continue;
  let doc;
  try { doc = yaml.load(fs.readFileSync(p, 'utf8')); }
  catch (err) { drift.push(`${m}: YAML parse failed: ${err.message}`); continue; }
  if (!doc || !doc['x-openbox'] || !doc['x-openbox'].services) continue;

  const meta = doc['x-openbox'];
  const actualServices = doc.services || {};

  // Collect every host-side port declared in this compose, across every
  // service. Covers both literal `- "NNNN:NNNN"` and env-var forms like
  // `- "${PORT:-NNNN}:NNNN"`.
  const allHostPorts = new Set();
  for (const svc of Object.values(actualServices)) {
    for (const portEntry of (svc.ports || [])) {
      const s = String(portEntry);
      const match = s.match(/(?:^|:)(?:\$\{[A-Z0-9_]+(?::-([0-9]+))?\}|([0-9]+)):[0-9]+(\/[a-z]+)?$/);
      if (match) {
        const port = Number(match[1] || match[2]);
        if (!isNaN(port)) allHostPorts.add(port);
      }
    }
  }

  for (const [svcKey, svcMeta] of Object.entries(meta.services)) {
    if (svcMeta.port_map == null) continue;
    const declaredPort = Number(svcMeta.port_map);
    const svc = actualServices[svcKey];
    if (!svc) {
      drift.push(`${m}/${svcKey}: manifest references service that isn't in docker-compose`);
      continue;
    }
    if (!allHostPorts.has(declaredPort)) {
      drift.push(`${m}/${svcKey}: port_map=${declaredPort} not published anywhere in module (module hosts: ${[...allHostPorts].sort((a,b)=>a-b).join(',') || 'none'})`);
    }
  }
}

if (drift.length > 0) {
  console.error(`validate-manifest: ${drift.length} drift(s):`);
  for (const d of drift) console.error('  ' + d);
  process.exit(1);
}
console.log(`validate-manifest: ${modules.length} modules checked, no drift`);
