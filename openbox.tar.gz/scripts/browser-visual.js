﻿// OpenBox Visual/Wizard QA — captures screenshots of every user-facing
// surface for eyeball review, and drives the setup wizard step-by-step
// to catch broken fields, layout issues, hung transitions, bad copy.
//
// What it exercises:
//   1. Reopens the setup wizard via /api/wizard/reopen so we can drive
//      it on a box that's already been claimed + skipped
//   2. Clicks through every wizard page with a screenshot per step
//   3. Skips the wizard (without completing) so we can screenshot the
//      real dashboard underneath
//   4. Visits every top-level page + every settings sub-tab, full-page
//      screenshot of each
//   5. Toggles the theme and repeats the page grid
//
// Output: a grid of PNGs under browser-visual-screenshots/<ip>/ named
// by stage. Open them in a file explorer and scan for anything that
// looks obviously broken.
//
// Usage:
//
//   NODE_PATH=/tmp/ob-qa-deps/node_modules \
//   OPENBOX_IP=<your-test-host> \
//   SB_DASHBOARD_PASSWORD=test-password-12345 \
//   node scripts/browser-visual.js

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const IP = process.env.OPENBOX_IP || '192.168.0.17';
const PORT = parseInt(process.env.OPENBOX_PORT || '8443', 10);
const BASE = `http://${IP}:${PORT}`;
const PASSWORD = process.env.SB_DASHBOARD_PASSWORD || 'test-password-12345';
const OUT_DIR = path.join(__dirname, '..', 'browser-visual-screenshots', IP.replace(/\./g, '-'));

fs.mkdirSync(OUT_DIR, { recursive: true });

const results = [];
function record(name, status, detail) {
  results.push({ name, status, detail: detail || null });
  const icon = status === 'pass' ? '✓' : status === 'fail' ? '✗' : '…';
  const color = status === 'pass' ? '\x1b[32m' : status === 'fail' ? '\x1b[31m' : '\x1b[33m';
  console.log(`${color}${icon}\x1b[0m ${name}${detail ? ' — ' + detail : ''}`);
}

async function snap(page, label) {
  const safe = label.replace(/[^a-z0-9]+/gi, '_').toLowerCase();
  const p = path.join(OUT_DIR, `${safe}.png`);
  await page.screenshot({ path: p, fullPage: true }).catch(() => {});
  return p;
}

async function csrfHeader(context) {
  const cookies = await context.cookies(BASE);
  const csrf = cookies.find(c => c.name === '_csrf');
  return csrf ? { 'X-CSRF-Token': csrf.value } : {};
}
async function apiPost(context, p, body) {
  const resp = await context.request.post(`${BASE}${p}`, {
    data: body,
    headers: { 'Content-Type': 'application/json', ...(await csrfHeader(context)) },
  });
  return { status: resp.status(), body: await resp.json().catch(() => ({})) };
}

const WIZARD_PAGES = ['wiz-welcome', 'wiz-basics', 'wiz-profile', 'wiz-vpn', 'wiz-community', 'wiz-done'];

(async () => {
  console.log(`\nOpenBox Visual QA: ${BASE}`);
  console.log(`Output:              ${OUT_DIR}\n`);

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    ignoreHTTPSErrors: true,
    viewport: { width: 1440, height: 900 },
  });
  const page = await context.newPage();
  page.on('console', msg => { if (msg.type() === 'error') console.log(`[browser console] ${msg.text()}`); });
  page.on('pageerror', err => console.log(`[page error] ${err.message}`));

  try {
    // === Login ===
    await page.goto(BASE, { waitUntil: 'domcontentloaded', timeout: 15000 });
    await page.waitForSelector('#login-screen:not(.hidden)', { timeout: 10000 });
    await snap(page, '00-login');
    await page.fill('#login-password', PASSWORD);
    await page.click('#login-btn');
    await page.waitForSelector('#dashboard:not(.hidden)', { timeout: 10000 });
    await page.waitForTimeout(1000);
    record('login', 'pass');

    // === Reopen wizard and drive it step-by-step ===
    try {
      const reopenResp = await apiPost(context, '/api/wizard/reopen', {});
      if (reopenResp.status !== 200) throw new Error(`reopen → ${reopenResp.status}`);
      await page.reload({ waitUntil: 'domcontentloaded' });
      await page.waitForTimeout(1500);
      // After reload, needsSetup=true should trigger the wizard to auto-open.
      const wizardVisible = await page.isVisible('#setup-wizard:not(.hidden)').catch(() => false);
      if (!wizardVisible) {
        record('wizard: auto-open on reload', 'fail', 'wizard did not appear after /api/wizard/reopen');
      } else {
        record('wizard: auto-open on reload', 'pass');

        // Walk each wizard page in sequence. Wait for each page to
        // become visible (waitForSelector handles transition timing),
        // snap, interact, click Next, wait for the NEXT page's
        // selector before moving on. The VPN page gets auto-skipped
        // when profile isn't media/full — we pick privacy.
        //
        // The wizard has a header row of step dots — the visible
        // .wizard-page is the one without .hidden. Using the
        // :not(.hidden) selector lets waitForSelector block until
        // the transition completes.
        const expectedPages = ['wiz-welcome', 'wiz-basics', 'wiz-profile', 'wiz-community', 'wiz-done'];
        for (let i = 0; i < expectedPages.length; i++) {
          const pageId = expectedPages[i];
          try {
            await page.waitForSelector(`#${pageId}:not(.hidden)`, { timeout: 5000 });
            await page.waitForTimeout(400); // let any fade-in finish
            await snap(page, `10-wizard-${i.toString().padStart(2, '0')}-${pageId}`);
            record(`wizard: ${pageId}`, 'pass');
          } catch (e) {
            record(`wizard: ${pageId}`, 'fail', 'page did not become visible');
            await snap(page, `10-wizard-${i.toString().padStart(2, '0')}-${pageId}-fail`);
            break;
          }

          // Per-page interactions BEFORE clicking Next.
          if (pageId === 'wiz-basics') {
            await page.fill('#wiz-domain', '192.168.0.17').catch(() => {});
          }
          if (pageId === 'wiz-profile') {
            // Pick privacy so wiz-vpn gets skipped. The default selection
            // is "full" which forces the VPN page. Use programmatic
            // click via page.evaluate for the same reason wiz-next
            // needs it — the wizard-card layout makes Playwright's
            // event-stability check fail.
            await page.evaluate(() => {
              const card = document.querySelector('.wizard-profile-card[data-profile="privacy"]');
              if (card) card.click();
            }).catch(() => {});
            await page.waitForTimeout(300);
          }
          if (pageId === 'wiz-done') {
            // Terminal page — don't click Install, bail out here.
            break;
          }

          // Diagnostic: inspect button state + event listeners + visibility
          const diag = await page.evaluate(() => {
            const btn = document.getElementById('wiz-next');
            if (!btn) return { found: false };
            const rect = btn.getBoundingClientRect();
            const style = getComputedStyle(btn);
            return {
              found: true,
              text: btn.textContent.trim(),
              rect: { x: rect.x, y: rect.y, w: rect.width, h: rect.height },
              visibility: style.visibility,
              display: style.display,
              pointerEvents: style.pointerEvents,
              opacity: style.opacity,
              disabled: btn.disabled,
              parentClass: btn.parentElement?.className,
            };
          }).catch(e => ({ error: e.message }));
          console.log(`    [diag] wiz-next:`, JSON.stringify(diag));

          // Advance. Try programmatic click via JS — bypasses any
          // Playwright checks and dispatches a real click event.
          const clickResult = await page.evaluate(() => {
            const btn = document.getElementById('wiz-next');
            if (!btn) return 'button not found';
            btn.click();
            return 'clicked';
          }).catch(e => `error: ${e.message}`);
          console.log(`    [diag] JS click result: ${clickResult}`);
          await page.waitForTimeout(800);
        }

        // Dismiss wizard without running the install profile
        await apiPost(context, '/api/wizard/skip', {}).catch(() => {});
        await page.reload({ waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(1000);
      }
    } catch (e) {
      record('wizard click-through', 'fail', e.message.substring(0, 250));
      await snap(page, 'wizard-fatal');
    }

    // === Visual screenshot grid of every top-level page ===
    await page.waitForSelector('#dashboard:not(.hidden)', { timeout: 5000 });
    const pages = ['home', 'apps', 'updates', 'releases', 'logs', 'settings', 'help'];
    for (const p of pages) {
      try {
        await page.click(`.tab[data-page="${p}"]`);
        await page.waitForSelector(`#page-${p}:not(.hidden)`, { timeout: 5000 });
        await page.waitForTimeout(1200); // let lazy content render
        await snap(page, `20-page-${p}`);
        record(`screenshot: page ${p}`, 'pass');
      } catch (e) {
        record(`screenshot: page ${p}`, 'fail', e.message.substring(0, 150));
      }
    }

    // === Settings sub-tabs ===
    await page.click('.tab[data-page="settings"]');
    await page.waitForSelector('#page-settings:not(.hidden)', { timeout: 5000 });
    const stabs = ['general', 'server', 'network', 'tools'];
    for (const s of stabs) {
      try {
        await page.click(`.settings-tab[data-stab="${s}"]`);
        await page.waitForSelector(`[data-stab-panel="${s}"]:not(.hidden)`, { timeout: 3000 });
        await page.waitForTimeout(800);
        await snap(page, `30-settings-${s}`);
        record(`screenshot: settings/${s}`, 'pass');
      } catch (e) {
        record(`screenshot: settings/${s}`, 'fail', e.message.substring(0, 150));
      }
    }

    // === Theme toggle — find the theme button if one exists ===
    const themeToggle = await page.$('#theme-toggle, [data-action="toggle-theme"], .theme-toggle');
    if (themeToggle) {
      try {
        await themeToggle.click();
        await page.waitForTimeout(500);
        record('theme: toggle found', 'pass');

        // Re-screenshot every page in alternate theme
        for (const p of pages) {
          try {
            await page.click(`.tab[data-page="${p}"]`);
            await page.waitForSelector(`#page-${p}:not(.hidden)`, { timeout: 5000 });
            await page.waitForTimeout(800);
            await snap(page, `40-page-${p}-alt-theme`);
            record(`screenshot alt theme: page ${p}`, 'pass');
          } catch (e) {
            record(`screenshot alt theme: page ${p}`, 'fail', e.message.substring(0, 150));
          }
        }
      } catch (e) {
        record('theme: toggle', 'fail', e.message.substring(0, 150));
      }
    } else {
      record('theme: toggle found', 'skip', 'no theme toggle button found in DOM');
    }

    await page.close();
    await browser.close();
  } catch (e) {
    console.error('Fatal:', e.message);
    record('fatal', 'fail', e.message);
    await browser.close().catch(() => {});
  }

  const passed = results.filter(r => r.status === 'pass').length;
  const failed = results.filter(r => r.status === 'fail').length;
  const skipped = results.filter(r => r.status === 'skip').length;

  fs.writeFileSync(path.join(OUT_DIR, 'results.json'), JSON.stringify({
    target: BASE,
    timestamp: new Date().toISOString(),
    passed, failed, skipped,
    results,
  }, null, 2));

  const screenshots = fs.readdirSync(OUT_DIR).filter(f => f.endsWith('.png'));

  console.log(`\n${'='.repeat(44)}`);
  console.log(`  passed: ${passed}`);
  console.log(`  failed: ${failed}`);
  console.log(`  skipped: ${skipped}`);
  console.log(`  screenshots: ${screenshots.length}`);
  console.log(`  output: ${OUT_DIR}`);
  console.log('='.repeat(44));

  process.exit(failed > 0 ? 1 : 0);
})();
