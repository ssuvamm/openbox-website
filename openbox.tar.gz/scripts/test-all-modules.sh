#!/usr/bin/env bash
# ==========================================
# OpenBox Module Smoke Test
# Run on the NAS (via sudo). For each module:
#   1. Enable it via 'openbox enable <module>'
#   2. Wait for containers to start
#   3. Check container health status
#   4. Probe known HTTP endpoints
#   5. Capture any errors
#   6. Disable to free RAM before moving on
# ==========================================

set -uo pipefail

OB_ROOT="${OB_ROOT:-/volume1/docker/openbox}"
RESULTS_DIR="${OB_ROOT}/state/test-results"
RESULTS_FILE="${RESULTS_DIR}/module-test-$(date +%Y%m%d-%H%M%S).json"
LOG_FILE="${RESULTS_DIR}/module-test-$(date +%Y%m%d-%H%M%S).log"
WAIT_AFTER_ENABLE=45   # seconds to let containers start before probing
PULL_TIMEOUT=600       # seconds — max time per module (some images are big)

# Modules to skip (already running as core, or too resource-heavy for the N100)
SKIP_MODULES=(
    "core"               # already running
    "dashboard"          # already running
    "media"              # huge ARR stack, conflicts with gluetun — test separately
    "frigate"            # heavy, shm + devices required
    "localai"            # 2+ GB just for base image, models need extra
    "photoprism"         # heavy, could run but slow on smaller NAS
    "adguard"            # conflicts with any DNS module (port 53)
    "matrix"             # needs hostname setup first
    "metrics"            # needs prometheus config template rendered
    "bookstack"          # needs APP_KEY + DB
)

# Discover the host-side HTTP port from a module's compose file.
# Parses "127.0.0.1:HOSTPORT:CONTAINERPORT" lines and returns the first
# HTTP-looking host port. Skips: DNS (53), VPN (51820, 51821), RTSP (8554),
# HTTPS (443, 8444 — we only want plain HTTP for probing), and database
# ports (3306, 5432, 6379, 9091 auth).
discover_probe_port() {
    local mod="$1"
    local compose="${OB_ROOT}/modules/${mod}/docker-compose.yml"
    [[ -f "${compose}" ]] || return

    # Also read the HTTP_PORT / HTTPS_PORT from .env so we can recognize
    # them even if the compose uses variable substitution
    local http_port https_port
    http_port=$(grep '^HTTP_PORT=' "${OB_ROOT}/.env" 2>/dev/null | cut -d= -f2)
    https_port=$(grep '^HTTPS_PORT=' "${OB_ROOT}/.env" 2>/dev/null | cut -d= -f2)

    local found=""
    while read -r port; do
        [[ -z "${port}" ]] && continue
        # Skip non-HTTP / bad probe targets
        case "${port}" in
            53|51820|51821|8554|3306|5432|6379|443|8444|${https_port:-443}) continue ;;
            *) found="${port}"; break ;;
        esac
    done < <(grep -oP '"(127\.0\.0\.1|0\.0\.0\.0):\K[0-9]+(?=:[0-9]+)' "${compose}" 2>/dev/null)
    echo "${found}"
}

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

mkdir -p "${RESULTS_DIR}"

log() { echo "$@" | tee -a "${LOG_FILE}"; }
log_info() { echo -e "${CYAN}[test]${NC} $*" | tee -a "${LOG_FILE}"; }
log_ok() { echo -e "${GREEN}[pass]${NC} $*" | tee -a "${LOG_FILE}"; }
log_fail() { echo -e "${RED}[fail]${NC} $*" | tee -a "${LOG_FILE}"; }
log_warn() { echo -e "${YELLOW}[warn]${NC} $*" | tee -a "${LOG_FILE}"; }

is_skipped() {
    local mod="$1"
    for s in "${SKIP_MODULES[@]}"; do
        [[ "${s}" == "${mod}" ]] && return 0
    done
    return 1
}

# JSON escape a string
json_escape() {
    printf '%s' "$1" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'
}

# Test a single module
test_module() {
    local mod="$1"
    local start_time
    start_time=$(date +%s)

    log ""
    log_info "=========================================="
    log_info "Testing module: ${mod}"
    log_info "=========================================="

    local result_status="unknown"
    local result_error=""
    local containers_started=""
    local http_ok=""
    local unhealthy_list=""

    # --- Clean any leftover config/volume state from previous test runs ---
    # This prevents databases from refusing to start due to stale state.
    if [[ -d "${OB_ROOT}/modules/${mod}/config" ]]; then
        log_info "Cleaning stale config for ${mod}..."
        rm -rf "${OB_ROOT}/modules/${mod}/config" 2>/dev/null || true
    fi

    # --- Enable (adds to modules.conf) ---
    log_info "Enabling ${mod}..."
    if ! "${OB_ROOT}/openbox" enable "${mod}" > /tmp/ob-enable.log 2>&1; then
        result_status="enable-failed"
        result_error=$(tail -5 /tmp/ob-enable.log | tr '\n' '; ')
        log_fail "Enable failed: ${result_error}"
        save_result "${mod}" "${result_status}" "${result_error}" "" "" "$(($(date +%s) - start_time))"
        return
    fi
    log_ok "Enabled in config"

    # --- Actually start the module's containers via docker compose ---
    local compose_file="${OB_ROOT}/modules/${mod}/docker-compose.yml"
    log_info "Starting containers with timeout ${PULL_TIMEOUT}s..."
    if ! timeout "${PULL_TIMEOUT}" docker compose --env-file "${OB_ROOT}/.env" -p openbox -f "${compose_file}" up -d > /tmp/ob-up.log 2>&1; then
        result_status="up-failed"
        result_error=$(tail -10 /tmp/ob-up.log | tr '\n' '; ' | head -c 500)
        log_fail "Up failed: ${result_error}"
        # Cleanup before moving on
        docker compose --env-file "${OB_ROOT}/.env" -p openbox -f "${compose_file}" down 2>/dev/null || true
        "${OB_ROOT}/openbox" disable "${mod}" > /dev/null 2>&1 || true
        save_result "${mod}" "${result_status}" "${result_error}" "" "" "$(($(date +%s) - start_time))"
        return
    fi
    log_ok "Containers started"

    # --- Wait for containers to stabilize ---
    log_info "Waiting ${WAIT_AFTER_ENABLE}s for containers to stabilize..."
    sleep "${WAIT_AFTER_ENABLE}"

    # --- List containers from this specific compose file ---
    # Filter by the compose file label so we don't pick up core/dashboard/
    # other modules' containers (docker compose -p <name> ps returns all
    # containers in the project, not just the ones from -f <file>).
    local mod_containers
    mod_containers=$(docker ps --filter "label=com.docker.compose.project=openbox" \
                               --filter "label=com.docker.compose.project.config_files=${compose_file}" \
                               --format '{{.Names}}' 2>/dev/null | tr '\n' ',' | sed 's/,$//')
    containers_started="${mod_containers}"
    log_info "Containers started: ${mod_containers:-none}"

    # --- Check health ---
    if [[ -n "${mod_containers}" ]]; then
        IFS=',' read -ra container_arr <<< "${mod_containers}"
        for c in "${container_arr[@]}"; do
            [[ -z "${c}" ]] && continue
            local status
            status=$(docker inspect --format='{{.State.Health.Status}}' "${c}" 2>/dev/null || echo "no-healthcheck")
            if [[ "${status}" == "unhealthy" ]]; then
                unhealthy_list="${unhealthy_list}${c},"
                log_warn "${c} is unhealthy"
                # Capture last 10 log lines for unhealthy containers
                local container_log
                container_log=$(docker logs --tail 10 "${c}" 2>&1 | tr '\n' ' ' | head -c 500)
                log_warn "${c} logs: ${container_log}"
            elif [[ "${status}" == "healthy" ]] || [[ "${status}" == "no-healthcheck" ]]; then
                log_info "${c} status: ${status}"
            fi
        done
    fi

    # --- Probe HTTP (or HTTPS) endpoint — tries both, retries for slow starts ---
    local probe_port
    probe_port=$(discover_probe_port "${mod}")
    if [[ -n "${probe_port}" ]]; then
        log_info "Probing port ${probe_port} (with retries)"
        local http_code=""
        local scheme_used=""
        for attempt in 1 2 3 4 5 6 7 8 9 10 11 12; do
            # Try HTTP first
            http_code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "http://localhost:${probe_port}" 2>&1)
            if [[ "${http_code}" =~ ^(200|301|302|303|307|308|401|403)$ ]]; then
                scheme_used="http"
                break
            fi
            # Try HTTPS with self-signed cert acceptance
            http_code=$(curl -sk -o /dev/null -w "%{http_code}" --max-time 5 "https://localhost:${probe_port}" 2>&1)
            if [[ "${http_code}" =~ ^(200|301|302|303|307|308|401|403)$ ]]; then
                scheme_used="https"
                break
            fi
            [[ ${attempt} -lt 12 ]] && sleep 15
        done
        if [[ -n "${scheme_used}" ]]; then
            http_ok="true"
            log_ok "${scheme_used^^} ${http_code} on port ${probe_port}"
        else
            http_ok="false"
            log_fail "No response on port ${probe_port} (tried both HTTP and HTTPS, 12 retries)"
        fi
    fi

    # --- Determine overall status ---
    if [[ -z "${mod_containers}" ]]; then
        result_status="no-containers"
        result_error="Module enabled but no containers started"
    elif [[ -n "${unhealthy_list}" ]]; then
        result_status="unhealthy"
        result_error="Unhealthy containers: ${unhealthy_list}"
    elif [[ "${http_ok}" == "false" ]]; then
        result_status="http-unreachable"
        result_error="HTTP probe failed on port ${probe_port}"
    else
        result_status="pass"
    fi

    if [[ "${result_status}" == "pass" ]]; then
        log_ok "Module ${mod} PASSED"
    else
        log_fail "Module ${mod} ${result_status}: ${result_error}"
    fi

    # --- Take down the compose stack first, then disable in conf ---
    # Do NOT use --remove-orphans — it would kill core/dashboard/npm/portainer
    # since they belong to different compose files under the same project name.
    log_info "Stopping ${mod} containers..."
    docker compose --env-file "${OB_ROOT}/.env" -p openbox -f "${compose_file}" down > /tmp/ob-down.log 2>&1 || log_warn "Down had warnings"

    log_info "Disabling ${mod} in config..."
    "${OB_ROOT}/openbox" disable "${mod}" > /tmp/ob-disable.log 2>&1 || true

    # Extra safety: remove any lingering containers from this module
    if [[ -n "${containers_started}" ]]; then
        IFS=',' read -ra container_arr <<< "${containers_started}"
        for c in "${container_arr[@]}"; do
            [[ -z "${c}" ]] && continue
            docker rm -f "${c}" >/dev/null 2>&1 || true
        done
    fi

    # Free RAM by dropping caches
    sync && echo 1 > /proc/sys/vm/drop_caches 2>/dev/null || true

    local duration=$(($(date +%s) - start_time))
    save_result "${mod}" "${result_status}" "${result_error}" "${containers_started}" "${probe_port}" "${duration}"
}

save_result() {
    local mod="$1"
    local status="$2"
    local error="$3"
    local containers="$4"
    local port="$5"
    local duration="$6"

    python3 <<PYEOF >> "${RESULTS_FILE}"
import json
print(json.dumps({
    "module": "${mod}",
    "status": "${status}",
    "error": $(json_escape "${error}"),
    "containers": "${containers}",
    "probe_port": "${port}",
    "duration_sec": ${duration},
    "timestamp": "$(date -Iseconds)"
}))
PYEOF
}

# --- Discover modules ---

modules=()
for mod_dir in "${OB_ROOT}"/modules/*/; do
    mod=$(basename "${mod_dir}")
    is_skipped "${mod}" && continue
    modules+=("${mod}")
done

log ""
log "========================================"
log "OpenBox Module Test Suite"
log "========================================"
log "NAS: $(hostname)"
log "Install: ${OB_ROOT}"
log "Results: ${RESULTS_FILE}"
log "Log: ${LOG_FILE}"
log "Modules to test: ${#modules[@]}"
log "Skipped: ${#SKIP_MODULES[@]}"
log "========================================"
log ""

# --- Test each module ---

for mod in "${modules[@]}"; do
    test_module "${mod}"
done

# --- Summary ---

log ""
log "========================================"
log "Test complete. Results in:"
log "  ${RESULTS_FILE}"
log "========================================"
log ""
log "Quick summary:"

python3 <<PYEOF
import json
with open("${RESULTS_FILE}") as f:
    results = [json.loads(line) for line in f if line.strip()]

from collections import Counter
statuses = Counter(r["status"] for r in results)
print(f"Total: {len(results)}")
for status, count in statuses.most_common():
    print(f"  {status}: {count}")

print()
print("Failed modules:")
for r in results:
    if r["status"] != "pass":
        print(f"  {r['module']}: {r['status']} — {r['error'][:100]}")
PYEOF
