#!/usr/bin/with-contenv bash
# Custom init script bind-mounted into ob-sabnzbd's /custom-cont-init.d/.
# Runs before SABnzbd starts. Forces SAB to listen on port 8081 instead of
# the default 8080.
#
# Why: qBittorrent and SABnzbd both share Gluetun's network namespace
# (network_mode: service:gluetun). qBit defaults to internal port 8080
# (WEBUI_PORT=8080); SAB also defaults to 8080. If both try to bind 8080,
# whichever container starts second fails with "address already in use"
# and crashes. Caught 2026-05-04 — v1.6.23 made SAB on-by-default but
# missed this internal-port collision.
#
# Why 8081: must be unique inside gluetun's netns. Already-used internal
# ports inside gluetun: 8080 (qBit), 8181 (FlareSolverr-via-host? no — host
# 8181→9696 internal Prowlarr), 8989 (Sonarr), 7878 (Radarr), 8686 (Lidarr),
# 9696 (Prowlarr), 8191 (FlareSolverr), 6767 (Bazarr), 5055 (Seerr),
# 8000 (gluetun http), 9999 (gluetun health), 53 (gluetun DNS). 8081 is free.
#
# This script handles three states idempotently:
#   1. Fresh install — sabnzbd.ini doesn't exist yet. Pre-create it with
#      port=8081 + host=0.0.0.0 so SAB starts on the right port from
#      first run.
#   2. Existing install with port=8080 (the conflicting state from a
#      v1.6.23 fresh install before this fix) — rewrite to port=8081.
#   3. Existing install already on port=8081 — no-op.

set -e

INI=/config/sabnzbd.ini
TARGET_PORT=8081

mkdir -p /config

if [ ! -f "$INI" ]; then
  echo "[sab-preinit-port] sabnzbd.ini missing — pre-seeding minimal config with port=$TARGET_PORT"
  cat > "$INI" <<EOF
[misc]
port = $TARGET_PORT
host = 0.0.0.0
host_whitelist = ,
EOF
  # SAB's user (abc, uid 1000 in LSIO images) needs to own this so the
  # main process can rewrite it on first run.
  chown abc:abc "$INI" 2>/dev/null || true
  exit 0
fi

# .ini exists — check if port needs migrating.
current_port=$(grep -oE '^port[[:space:]]*=[[:space:]]*[0-9]+' "$INI" | head -n1 | grep -oE '[0-9]+$')
if [ "$current_port" = "$TARGET_PORT" ]; then
  echo "[sab-preinit-port] sabnzbd.ini already on port=$TARGET_PORT — no-op"
  exit 0
fi

echo "[sab-preinit-port] migrating port: $current_port → $TARGET_PORT"
# In-place sed (BSD/GNU compatible — LSIO's image is alpine so GNU sed)
sed -i -E "s/^port[[:space:]]*=[[:space:]]*[0-9]+/port = $TARGET_PORT/" "$INI"
echo "[sab-preinit-port] done"
