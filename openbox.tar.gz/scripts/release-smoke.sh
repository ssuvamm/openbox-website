#!/usr/bin/env bash
# scripts/release-smoke.sh
#
# Pre-release deep functionality smoke. Runs against a LIVE OpenBox.
# LOCAL_MODE: detects when running on the test NAS itself, skips SSH.
# install (no wipe, no reinstall) and validates the actual customer
# request path: Seerr → Radarr → ARR chain. Designed for the 5-min
# release-gate slot; the 30-min cold-install-rehearsal still exists
# for major changes / weekly cadence.
#
# What this catches that the existing tests don't:
#   - rootfolder NOT registered in Sonarr/Radarr (the 2026-04-30 bug —
#     where qBit pw timing skipped the whole rootfolder block)
#   - download client NOT registered (qBit not seen by *arrs)
#   - Prowlarr applications NOT wired (so indexers don't push to *arrs)
#   - Seerr → Radarr request silently failing with a 4xx
#
# What it intentionally does NOT do:
#   - Wipe + reinstall (use cold-install-rehearsal.sh for that, weekly)
#   - Drive the Jellyfin / Seerr UI (use rehearsal for full UI parity)
#   - Wait for an actual download to complete (no public domain torrent
#     of a known-stable indexer to count on; flake budget too low)
#
# On success: writes ${PROJECT_ROOT}/state/last-smoke.json locally with
# timestamp + git commit SHA. release.sh refuses to build a release
# tarball unless this file is present, green, and references HEAD or
# was generated within the last 24h.
#
# Usage:
#   scripts/release-smoke.sh              # uses ~/.openbox-rehearsal.env
#   scripts/release-smoke.sh --config /path/to/env
#   TARGET_HOST=192.168.0.17 SSH_KEY=~/.ssh/ugreen_key SSH_USER=youruser \
#     scripts/release-smoke.sh
#
# Exit code: 0 on full pass, 1 on any failure. Stdout is grep-able.

set -uo pipefail

# --- paint ---
RED=$'\e[31m'; GRN=$'\e[32m'; YLW=$'\e[33m'; BLU=$'\e[34m'; DIM=$'\e[2m'; OFF=$'\e[0m'
say()  { printf '%s\n' "$*"; }
step() { printf '\n%s▶%s %s\n' "$BLU" "$OFF" "$*"; }
ok()   { printf '%s✓%s %s\n' "$GRN" "$OFF" "$*"; }
warn() { printf '%s!%s %s\n' "$YLW" "$OFF" "$*"; }
fail() { printf '%s✗%s %s\n' "$RED" "$OFF" "$*" >&2; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "${SCRIPT_DIR}")"
START_TIME=$(date +%s)
FAILS=0
RESULTS_FILE="${PROJECT_ROOT}/state/last-smoke.json"
mkdir -p "${PROJECT_ROOT}/state"

# Failure-artifact dumper: on FAIL, collect docker ps, doctor, logs of
# unhealthy containers, state JSON. Standardized across QA scripts.
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/lib/dump-artifacts.sh" 2>/dev/null || true

# --- config load ---
CONFIG_FILE="${HOME}/.openbox-rehearsal.env"
if [[ "${1:-}" == "--config" && -n "${2:-}" ]]; then
    CONFIG_FILE="$2"; shift 2
fi
if [[ -f "${CONFIG_FILE}" ]]; then
    # shellcheck disable=SC1090
    source "${CONFIG_FILE}"
fi

TARGET_HOST="${TARGET_HOST:-${TARGET_HOST_OVERRIDE:-}}"
SSH_USER="${TARGET_USER:-${SSH_USER:-}}"
SSH_KEY="${TARGET_SSH_KEY:-${SSH_KEY:-}}"

# Detect "I'm running ON the target" — the self-hosted GitHub Actions
# runner lives on the test NAS, so it shouldn't try to SSH back to
# itself. If TARGET_HOST is unset OR if /opt/openbox/openbox is
# directly accessible AND we have local sudo, run locally instead.
LOCAL_MODE=0
if [[ -z "${TARGET_HOST}" ]] && [[ -f /opt/openbox/openbox ]] && sudo -n true 2>/dev/null; then
    LOCAL_MODE=1
elif [[ -n "${TARGET_HOST}" ]] && [[ -f /opt/openbox/openbox ]]; then
    # Resolve TARGET_HOST and compare against local interfaces. If
    # TARGET_HOST is one of our IPs, skip SSH.
    target_ip=$(getent hosts "${TARGET_HOST}" 2>/dev/null | awk '{print $1}' | head -1)
    [[ -z "$target_ip" ]] && target_ip="${TARGET_HOST}"
    if hostname -I 2>/dev/null | tr ' ' '\n' | grep -qF "${target_ip}"; then
        LOCAL_MODE=1
    fi
fi

if [[ ${LOCAL_MODE} -eq 1 ]]; then
    # Run commands directly with sudo, no SSH wrapper.
    SSH="sudo -n bash -c"
    say "${DIM}target:  localhost (running on test NAS itself)${OFF}"
else
    if [[ -z "${TARGET_HOST}" || -z "${SSH_USER}" || -z "${SSH_KEY}" ]]; then
        fail "Missing required: TARGET_HOST, SSH_USER (or TARGET_USER), SSH_KEY (or TARGET_SSH_KEY)"
        fail "Set them in ${CONFIG_FILE} or pass via env vars."
        exit 1
    fi
    SSH="ssh -i ${SSH_KEY} -o ConnectTimeout=8 -o StrictHostKeyChecking=accept-new ${SSH_USER}@${TARGET_HOST}"
    say "${DIM}target:  ${SSH_USER}@${TARGET_HOST}${OFF}"
fi
say "${DIM}commit:  $(git -C "${PROJECT_ROOT}" rev-parse --short HEAD 2>/dev/null || echo unknown)${OFF}"

# ============================================================
# STEP — Container health (basic)
# ============================================================
step "Containers healthy"
container_status=$(${SSH} "sudo -n docker ps --format '{{.Names}}|{{.Status}}'" 2>&1) || {
    fail "SSH or docker ps failed: ${container_status:0:200}"
    exit 1
}
required=(ob-dashboard ob-gluetun ob-jellyfin-media ob-seerr ob-bazarr ob-qbittorrent ob-radarr ob-sonarr ob-prowlarr)
for c in "${required[@]}"; do
    line=$(printf '%s\n' "$container_status" | grep "^${c}|" || true)
    if [[ -z "$line" ]]; then
        fail "${c}: not running"; FAILS=$((FAILS+1))
    elif echo "$line" | grep -qiE 'unhealthy|restarting|exited'; then
        fail "${c}: ${line#*|}"; FAILS=$((FAILS+1))
    else
        ok   "${c}: ${line#*|}"
    fi
done

# ============================================================
# STEP — Pull arr API keys from box
# ============================================================
step "API keys"
keys_json=$(${SSH} 'sudo -n cat /opt/openbox/state/arr-api-keys.json' 2>/dev/null || true)
if [[ -z "$keys_json" ]]; then
    fail "state/arr-api-keys.json missing on target"; exit 1
fi
SONARR_KEY=$(printf '%s' "$keys_json"  | python3 -c "import sys,json; print(json.load(sys.stdin).get('sonarr',''))")
RADARR_KEY=$(printf '%s' "$keys_json"  | python3 -c "import sys,json; print(json.load(sys.stdin).get('radarr',''))")
PROWLARR_KEY=$(printf '%s' "$keys_json" | python3 -c "import sys,json; print(json.load(sys.stdin).get('prowlarr',''))")
if [[ -z "$SONARR_KEY" || -z "$RADARR_KEY" || -z "$PROWLARR_KEY" ]]; then
    fail "API keys missing: sonarr=${#SONARR_KEY}c radarr=${#RADARR_KEY}c prowlarr=${#PROWLARR_KEY}c"
    exit 1
fi
ok "API keys: sonarr/radarr/prowlarr"

# Pull Seerr API key from settings.json on the box
seerr_settings=$(${SSH} 'sudo -n cat /opt/openbox/modules/media/config/jellyseerr/settings.json 2>/dev/null || sudo -n cat /opt/openbox/modules/media/config/seerr/settings.json 2>/dev/null' 2>/dev/null || true)
SEERR_KEY=$(printf '%s' "$seerr_settings" | python3 -c "import sys,json
try:
    d = json.load(sys.stdin); print(d.get('main',{}).get('apiKey',''))
except Exception: print('')")
if [[ -n "$SEERR_KEY" ]]; then ok "Seerr API key: present"
else warn "Seerr API key not found in settings.json — Seerr-request smoke will be skipped"; fi

# ============================================================
# STEP — Helpers
# ============================================================
arr_get() {
    curl --silent --max-time 12 -H "X-Api-Key: $2" "$1"
}
arr_post() {
    curl --silent --max-time 15 -X POST -H "X-Api-Key: $2" -H 'Content-Type: application/json' -d "$3" "$1"
}
arr_delete() {
    curl --silent --max-time 12 -X DELETE -H "X-Api-Key: $2" "$1"
}
arr_count_field() {
    # arr_count_field <body> <field> <value>  → number of array entries with field==value
    printf '%s' "$1" | python3 -c "
import sys, json
field, value = '$2', '$3'
try:
    d = json.load(sys.stdin)
    print(sum(1 for x in (d if isinstance(d, list) else []) if str(x.get(field, '')) == value))
except Exception:
    print(0)
"
}

# ============================================================
# STEP — Sonarr/Radarr: rootfolder + download client
# ============================================================
step "Sonarr/Radarr wiring"
body=$(arr_get "http://${TARGET_HOST}:7878/api/v3/rootfolder" "$RADARR_KEY")
n=$(arr_count_field "$body" path "/data/media/Movies")
if [[ "${n:-0}" -ge 1 ]]; then ok "Radarr: /data/media/Movies root folder set"
else fail "Radarr: /data/media/Movies root folder NOT set (this is the 2026-04-30 regression class)"; FAILS=$((FAILS+1)); fi

body=$(arr_get "http://${TARGET_HOST}:8989/api/v3/rootfolder" "$SONARR_KEY")
n=$(arr_count_field "$body" path "/data/media/TV")
if [[ "${n:-0}" -ge 1 ]]; then ok "Sonarr: /data/media/TV root folder set"
else fail "Sonarr: /data/media/TV root folder NOT set"; FAILS=$((FAILS+1)); fi

body=$(arr_get "http://${TARGET_HOST}:7878/api/v3/downloadclient" "$RADARR_KEY")
n=$(arr_count_field "$body" implementation "QBittorrent")
if [[ "${n:-0}" -ge 1 ]]; then ok "Radarr: qBittorrent download client wired"
else fail "Radarr: qBittorrent download client NOT wired"; FAILS=$((FAILS+1)); fi

body=$(arr_get "http://${TARGET_HOST}:8989/api/v3/downloadclient" "$SONARR_KEY")
n=$(arr_count_field "$body" implementation "QBittorrent")
if [[ "${n:-0}" -ge 1 ]]; then ok "Sonarr: qBittorrent download client wired"
else fail "Sonarr: qBittorrent download client NOT wired"; FAILS=$((FAILS+1)); fi

# ============================================================
# STEP — Prowlarr: apps registered + at least one indexer
# ============================================================
step "Prowlarr wiring"
body=$(arr_get "http://${TARGET_HOST}:8181/api/v1/applications" "$PROWLARR_KEY")
n_son=$(arr_count_field "$body" implementation "Sonarr")
n_rad=$(arr_count_field "$body" implementation "Radarr")
[[ "${n_son:-0}" -ge 1 ]] && ok "Prowlarr: Sonarr application registered" || { fail "Prowlarr: Sonarr application NOT registered"; FAILS=$((FAILS+1)); }
[[ "${n_rad:-0}" -ge 1 ]] && ok "Prowlarr: Radarr application registered" || { fail "Prowlarr: Radarr application NOT registered"; FAILS=$((FAILS+1)); }

# Indexer count is informational only. Default install seeds zero
# indexers (Terms §6 compliance — OpenBox does not provide
# indexers/trackers/sources). Customer adds their own in Prowlarr's UI.
body=$(arr_get "http://${TARGET_HOST}:8181/api/v1/indexer" "$PROWLARR_KEY")
n_idx=$(printf '%s' "$body" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin); print(len(d) if isinstance(d, list) else 0)
except Exception: print(0)")
ok "Prowlarr: ${n_idx} indexer(s) registered (customer-managed; 0 is expected on a fresh install)"

# ============================================================
# STEP — End-to-end: synthesize a Seerr request, verify Radarr accepts
# ============================================================
# This is the actual customer journey check. Pick a TMDB ID for a
# stable public-domain movie so the test doesn't drift if titles
# get reorganized. Night of the Living Dead 1968 (PD): tmdbId=10331.
# Rationale for using 1968 not 1990: 1968 is the actual public-domain
# original; 1990 is the remake (still under copyright). Same titles
# trip up indexers; 1968 is a cleaner test fixture.
step "End-to-end: Seerr → Radarr request flow"
TEST_TMDB_ID=10331  # Night of the Living Dead (1968), public domain
TEST_TITLE="Night of the Living Dead"

# Clean up any prior test movie before we start (idempotent)
existing=$(arr_get "http://${TARGET_HOST}:7878/api/v3/movie" "$RADARR_KEY")
prior_id=$(printf '%s' "$existing" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    for m in (d if isinstance(d, list) else []):
        if int(m.get('tmdbId', 0)) == ${TEST_TMDB_ID}:
            print(m.get('id', '')); break
except Exception: pass")
if [[ -n "$prior_id" ]]; then
    arr_delete "http://${TARGET_HOST}:7878/api/v3/movie/${prior_id}?deleteFiles=true&addImportListExclusion=false" "$RADARR_KEY" >/dev/null
    ok "  cleaned prior test movie (id=${prior_id}) from Radarr"
fi

# POST same payload Seerr would send. If this 400s with "Root folder
# does not exist", we're back in the 2026-04-30 regression — the
# rootfolder check above SHOULD have caught it, but this is the
# end-to-end belt-and-suspenders.
add_payload=$(cat <<JSON
{"profileId":1,"qualityProfileId":1,"rootFolderPath":"/data/media/Movies","title":"${TEST_TITLE}","tmdbId":${TEST_TMDB_ID},"year":1968,"monitored":true,"tags":[],"searchNow":false}
JSON
)
add_resp=$(arr_post "http://${TARGET_HOST}:7878/api/v3/movie" "$RADARR_KEY" "$add_payload")
new_id=$(printf '%s' "$add_resp" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    print(d.get('id','') if isinstance(d, dict) else '')
except Exception: print('')")

if [[ -n "$new_id" && "$new_id" != "0" ]]; then
    ok "Radarr accepted add-movie POST (id=${new_id}) — full request path is unblocked"
    # Cleanup: delete the test movie so we don't accumulate state
    arr_delete "http://${TARGET_HOST}:7878/api/v3/movie/${new_id}?deleteFiles=true&addImportListExclusion=false" "$RADARR_KEY" >/dev/null
    ok "  cleaned up test movie (id=${new_id})"
else
    err=$(printf '%s' "$add_resp" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    if isinstance(d, list) and d and isinstance(d[0], dict):
        print(d[0].get('errorMessage', '')[:200])
    elif isinstance(d, dict):
        print(str(d.get('message') or d.get('errorMessage') or '')[:200])
    else:
        print(str(d)[:200])
except Exception:
    pass" 2>/dev/null)
    fail "Radarr REJECTED add-movie POST: ${err}"
    fail "  raw response: ${add_resp:0:400}"
    FAILS=$((FAILS+1))
fi

# ============================================================
# STEP — Container health (Seerr session bundle is patched)
# ============================================================
# Quick sanity: the Seerr cookie patch (sb.sid not connect.sid) is
# applied. If someone resets the Seerr image without re-running the
# patch, we want to know before customers do.
step "Seerr cookie-name patch"
cookie_name=$(${SSH} "sudo -n docker exec ob-seerr grep -oE '(sb\.sid|connect\.sid)' /app/dist/index.js 2>/dev/null | sort -u | head -1" 2>/dev/null || true)
if [[ "${cookie_name}" == "sb.sid" ]]; then ok "Seerr session cookie name = sb.sid (patched)"
elif [[ "${cookie_name}" == "connect.sid" ]]; then fail "Seerr session cookie name = connect.sid — patch-seerr-bundle.sh did not run / regressed"; FAILS=$((FAILS+1))
else warn "Could not determine Seerr cookie name (image structure changed?)"; fi

# ============================================================
# STEP — Per-app functional checks (Tier-A/B modules)
# ============================================================
# Beyond "container healthy" — actually probe each app's native API for
# a meaningful invariant. Catches "container green but app broken" class
# (Jellyfin stale cache, Seerr session-loss). Run only against modules
# that are enabled on this box.
step "Per-app functional checks"

probe_endpoint() {
    # probe_endpoint <label> <port> <path> <expect_substring>
    # Follows redirects (-L) so apps that 302 from / to /login still
    # return their landing page body for signature matching.
    local label="$1" port="$2" path="$3" expect="$4"
    local body
    body=$(${SSH} "curl -sSL --max-time 6 'http://localhost:${port}${path}'" 2>/dev/null || echo "")
    if [[ -z "$body" ]]; then
        warn "${label}: no response on :${port}${path} (module may not be enabled)"
        return 0
    fi
    if echo "$body" | grep -qE "$expect"; then
        ok "${label}: ${path} contains '${expect}'"
    else
        fail "${label}: ${path} did NOT contain '${expect}' (got: $(echo "$body" | head -c 120))"
        FAILS=$((FAILS+1))
    fi
}

# Container-existence guard: only probe if container actually exists.
container_exists() {
    ${SSH} "sudo -n docker ps -a --format '{{.Names}}' | grep -q '^${1}$'" 2>/dev/null
}

# Jellyfin: catches stale-server-Id / cache class without driving UI
if container_exists ob-jellyfin-media; then
    probe_endpoint "Jellyfin" 8096 "/system/info/public" '"Id"'
fi

# qBittorrent: probe the landing page (signature match), not /api/v2/* —
# the API requires auth and returns 403 from an unauthed probe. We're
# verifying "qBit is up + serving its own UI", not "API works" (which is
# already covered by the *arr stack download-client check above).
if container_exists ob-qbittorrent; then
    probe_endpoint "qBittorrent" 8089 "/" "qBittorrent"
fi

# Vaultwarden: critical password-vault uptime
if container_exists ob-vaultwarden; then
    probe_endpoint "Vaultwarden" 8222 "/alive" "20"
fi

# AdGuard: blocklist + DNS daemon up
if container_exists ob-adguard; then
    probe_endpoint "AdGuard" 3000 "/" "AdGuard"
fi

# Audiobookshelf
if container_exists ob-audiobookshelf; then
    probe_endpoint "Audiobookshelf" 13378 "/ping" "ok"
fi

# Immich: server ping + version
if container_exists ob-immich-server; then
    probe_endpoint "Immich" 2283 "/api/server-info/ping" "res"
fi

# Nextcloud: status.php returns installed:true
if container_exists ob-nextcloud; then
    probe_endpoint "Nextcloud" 8080 "/status.php" '"installed":true'
fi

# Pi-hole admin
if container_exists ob-pihole; then
    probe_endpoint "Pi-hole" 8053 "/admin/" "Pi-hole|pihole"
fi

# ============================================================
# Summary + state file
# ============================================================
ELAPSED=$(($(date +%s) - START_TIME))
COMMIT_SHA=$(git -C "${PROJECT_ROOT}" rev-parse HEAD 2>/dev/null || echo unknown)
COMMIT_SHORT=$(git -C "${PROJECT_ROOT}" rev-parse --short HEAD 2>/dev/null || echo unknown)
TIMESTAMP_UTC=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

if [[ ${FAILS} -eq 0 ]]; then
    say ""
    ok "smoke PASSED in ${ELAPSED}s ($(date +%H:%M:%S))"
    cat > "${RESULTS_FILE}" <<JSON
{
  "pass": true,
  "fails": 0,
  "elapsed_seconds": ${ELAPSED},
  "commit": "${COMMIT_SHA}",
  "commit_short": "${COMMIT_SHORT}",
  "target_host": "${TARGET_HOST}",
  "timestamp_utc": "${TIMESTAMP_UTC}"
}
JSON
    say "${DIM}wrote ${RESULTS_FILE}${OFF}"
    exit 0
else
    say ""
    fail "smoke FAILED: ${FAILS} hard failure(s) in ${ELAPSED}s"
    cat > "${RESULTS_FILE}" <<JSON
{
  "pass": false,
  "fails": ${FAILS},
  "elapsed_seconds": ${ELAPSED},
  "commit": "${COMMIT_SHA}",
  "commit_short": "${COMMIT_SHORT}",
  "target_host": "${TARGET_HOST}",
  "timestamp_utc": "${TIMESTAMP_UTC}"
}
JSON
    # Auto-dump diagnostic artifacts so the failure is debuggable
    # without re-running. SSH var is set above; export so the helper sees it.
    ARTIFACT_SSH="${SSH}" dump_artifacts "release-smoke" 2>/dev/null || true
    exit 1
fi
