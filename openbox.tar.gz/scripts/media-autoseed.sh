#!/usr/bin/env bash
# ============================================================
# OpenBox media autoseed — zero-credential setup entry point
# ============================================================
# Wraps scripts/media-autoseed.js with a Playwright/Chromium
# bootstrap so the Node script can run on any OpenBox host
# without pre-installed dependencies.
#
# First invocation:
#   - Installs playwright + chromium via npm to
#     ${OB_ROOT}/scripts/.autoseed-cache/ (~200MB, one-time)
#   - Runs media-autoseed.js
#
# Subsequent invocations:
#   - Reuses the cache, runs in ~30-90s
#
# Invoked by:
#   - `openbox media-autoseed` CLI
#   - arr-bootstrap.sh after Seerr starts (idempotent auto-seed)
#
# Idempotent in the full chain — Jellyfin wizard already
# complete? Skips. Seerr already initialized? Skips.
# ============================================================

set -uo pipefail

OB_ROOT="${OB_ROOT:-/opt/openbox}"
LOG_FILE="${OB_ROOT}/state/media-autoseed.log"
DONE_MARKER="${OB_ROOT}/state/media-autoseeded"

# Pinned Playwright image. Ships Node + Chromium + all the Linux
# shared-lib deps pre-installed, so the NAS host doesn't need node,
# npm, chromium, or any of the 50 apt packages chromium wants.
# The v1.55.0 tag is pinned because Seerr's auth flow depends on
# Jellyfin wizard behavior we've validated; a tag bump could drift.
PLAYWRIGHT_VERSION="1.55.0"
PLAYWRIGHT_IMAGE="mcr.microsoft.com/playwright:v${PLAYWRIGHT_VERSION}-jammy"

log() { printf '[media-autoseed] %s\n' "$*" | tee -a "${LOG_FILE}" >&2; }

mkdir -p "$(dirname "${LOG_FILE}")"

# Short-circuit if we've already seeded. Delete marker to re-run.
if [[ -f "${DONE_MARKER}" ]]; then
    log "Already auto-seeded at $(cat "${DONE_MARKER}" 2>/dev/null). Delete ${DONE_MARKER} to re-run."
    exit 0
fi

# Sanity: we need Docker (which OpenBox requires anyway).
if ! command -v docker >/dev/null 2>&1; then
    log "ERROR: docker is required. Cannot auto-seed."
    log "Fallback: complete the Jellyfin + Seerr wizards manually, then run 'sudo openbox media-finish'."
    exit 1
fi

# Pull the Playwright image on first use (~2GB once, cached forever).
# Subsequent runs reuse from the Docker image cache in <5s.
if ! docker image inspect "${PLAYWRIGHT_IMAGE}" >/dev/null 2>&1; then
    log "First-run: pulling ${PLAYWRIGHT_IMAGE} (one-time, ~2GB, 60-180s)..."
    if ! docker pull "${PLAYWRIGHT_IMAGE}" >>"${LOG_FILE}" 2>&1; then
        log "ERROR: docker pull failed. See ${LOG_FILE}."
        exit 1
    fi
fi

# Derive the IP the seed script should hit. Containers on ob_proxy
# can reach each other by container name, so we can even run the
# seeder inside a container and target ob-jellyfin-media / ob-seerr
# directly — which is what we do.
log "Running media-autoseed.js in Playwright container..."

# The Playwright image ships Chromium pre-installed at /ms-playwright
# but NOT the `playwright` npm package itself (it's a browser-runtime
# image, not a dev-SDK image). We install playwright into a shared
# volume so the install only happens on the first run; subsequent
# runs reuse the same node_modules.
#
# Mounts:
#   scripts/  (ro) — the media-autoseed.js file
#   state/          — where jellyfin-admin-password.txt gets written
#   .autoseed-cache — persistent node_modules so `npm i` is one-time
# Network: ob_proxy so we reach ob-jellyfin-media / ob-seerr by name.
NPM_CACHE="${OB_ROOT}/scripts/.autoseed-cache"
mkdir -p "${NPM_CACHE}"

if docker run --rm \
    --network ob_proxy \
    -v "${OB_ROOT}/scripts:/ob-scripts:ro" \
    -v "${OB_ROOT}/state:/ob-state" \
    -v "${NPM_CACHE}:/ob-cache" \
    -e "OB_ROOT=/sb" \
    -e "NODE_PATH=/ob-cache/node_modules" \
    -e "SPARKBOX_JELLYFIN_URL=http://ob-jellyfin-media:8096" \
    -e "SPARKBOX_SEERR_URL=http://ob-seerr:5055" \
    -e "SPARKBOX_SEERR_PUBLIC_HOST=ob-jellyfin-media" \
    -w /ob-cache \
    "${PLAYWRIGHT_IMAGE}" \
    bash -c '
        if [ ! -d /ob-cache/node_modules/playwright ]; then
            echo "[autoseed] Installing playwright npm package..."
            cd /ob-cache
            [ -f package.json ] || echo "{\"name\":\"ob-autoseed\",\"private\":true}" > package.json
            # The image already has /ms-playwright browsers; tell npm
            # to skip the download step so install is ~5s not 60s.
            PLAYWRIGHT_BROWSERS_PATH=/ms-playwright \
            PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 \
            npm install --prefer-offline --no-audit --no-fund --loglevel=error "playwright@'"${PLAYWRIGHT_VERSION}"'"
        fi
        PLAYWRIGHT_BROWSERS_PATH=/ms-playwright \
        node /ob-scripts/media-autoseed.js
    ' >>"${LOG_FILE}" 2>&1; then
    echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "${DONE_MARKER}"
    # The Playwright container ran as root, so files it wrote to
    # /ob-state (bind-mounted from state/) are owned root:root 0600.
    # The dashboard runs as node (uid 1000) and silently returns
    # log-scrape garbage instead of the actual credentials when it
    # can't read the state file. Fix: take ownership back + set 0640
    # so both root (CLI) and the dashboard's node user can read.
    # Caught 2026-04-22 when Tom's launcher modal showed SessionManager
    # log lines instead of his openbox admin password.
    # Codex round 3 finding #9: the password file used to be 0640
    # (group-readable). Any host user in gid 10 could read the
    # Jellyfin admin password. Tightened to 0600 — the dashboard runs
    # as uid 1000 alone and doesn't need group read. The seeded-
    # marker file has no secrets so stays 0640.
    if [[ -f "${OB_ROOT}/state/jellyfin-admin-password.txt" ]]; then
        chown 1000:1000 "${OB_ROOT}/state/jellyfin-admin-password.txt" 2>/dev/null || true
        chmod 600 "${OB_ROOT}/state/jellyfin-admin-password.txt" 2>/dev/null || true
    fi
    if [[ -f "${OB_ROOT}/state/media-autoseeded" ]]; then
        chown 1000:10 "${OB_ROOT}/state/media-autoseeded" 2>/dev/null || true
        chmod 640 "${OB_ROOT}/state/media-autoseeded" 2>/dev/null || true
    fi
    log "Auto-seed complete. Jellyfin admin saved to state/jellyfin-admin-password.txt (owner 1000:1000, 0600)."
    log "Next: 'sudo openbox media-finish' to create libraries + finalize Seerr."
    exit 0
else
    log "ERROR: media-autoseed.js exited non-zero. See ${LOG_FILE}."
    log "Fallback: complete Jellyfin + Seerr wizards manually, then run 'sudo openbox media-finish'."
    exit 1
fi
