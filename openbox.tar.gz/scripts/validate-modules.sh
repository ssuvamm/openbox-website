#!/usr/bin/env bash
# ==========================================
# OpenBox Module Validator
# Checks every module for:
# - YAML syntax
# - Required x-openbox metadata
# - Port conflicts with other modules
# - Docker compose validity
# - Icon existence
# ==========================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "${SCRIPT_DIR}")"
MODULES_DIR="${PROJECT_ROOT}/modules"
ICONS_DIR="${PROJECT_ROOT}/dashboard/public/icons"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

FAIL_COUNT=0
WARN_COUNT=0
PASS_COUNT=0

fail() { echo -e "${RED}  ✗ $*${NC}"; FAIL_COUNT=$((FAIL_COUNT+1)); }
warn() { echo -e "${YELLOW}  ! $*${NC}"; WARN_COUNT=$((WARN_COUNT+1)); }
pass() { echo -e "${GREEN}  ✓ $*${NC}"; PASS_COUNT=$((PASS_COUNT+1)); }
info() { echo -e "${CYAN}$*${NC}"; }

# --- Collect all ports across all modules to detect conflicts ---

declare -A PORT_OWNERS
PORT_CONFLICTS=()

# Extract host ports from a compose file
# Format we're looking for: "127.0.0.1:PORT:INTERNAL" or "PORT:INTERNAL"
extract_ports() {
    local file="$1"
    grep -oP '(?:127\.0\.0\.1:)?\K[0-9]+(?=:[0-9]+)' "$file" 2>/dev/null | sort -u || true
}

# --- Per-module validation ---

validate_module() {
    local module="$1"
    local compose_file="${MODULES_DIR}/${module}/docker-compose.yml"

    info "\n[${module}]"

    if [[ ! -f "${compose_file}" ]]; then
        fail "No docker-compose.yml found"
        return 1
    fi

    # --- YAML syntax ---
    if command -v python3 &>/dev/null; then
        if python3 -c "import yaml; yaml.safe_load(open('${compose_file}'))" 2>/dev/null; then
            pass "YAML syntax valid"
        else
            fail "YAML syntax error: $(python3 -c "import yaml; yaml.safe_load(open('${compose_file}'))" 2>&1 | tail -1)"
            return 1
        fi
    fi

    # --- Required x-openbox metadata ---
    local required_fields=("id" "title" "description" "category" "services")
    for field in "${required_fields[@]}"; do
        if grep -qP "^\s{2,4}${field}:" "${compose_file}" || grep -qP "^${field}:" "${compose_file}"; then
            pass "x-openbox has '${field}'"
        else
            warn "x-openbox missing '${field}'"
        fi
    done

    # --- Docker compose validation (if docker available) ---
    if command -v docker &>/dev/null && docker compose version &>/dev/null 2>&1; then
        if docker compose -f "${compose_file}" config --quiet 2>/dev/null; then
            pass "docker compose config valid"
        else
            local err
            err=$(docker compose -f "${compose_file}" config 2>&1 | tail -3 | head -1)
            warn "docker compose config issues: ${err}"
        fi
    fi

    # --- Port conflict detection ---
    local ports
    ports=$(extract_ports "${compose_file}")
    if [[ -n "${ports}" ]]; then
        while IFS= read -r port; do
            [[ -z "${port}" ]] && continue
            # Skip internal container ports (53, 80, 443, 3306, 5432, etc.) — they're okay because we bind to 127.0.0.1
            if [[ -n "${PORT_OWNERS[${port}]:-}" ]]; then
                if [[ "${PORT_OWNERS[${port}]}" != "${module}" ]]; then
                    fail "Port ${port} conflicts with module '${PORT_OWNERS[${port}]}'"
                    PORT_CONFLICTS+=("${port}:${module}:${PORT_OWNERS[${port}]}")
                fi
            else
                PORT_OWNERS[${port}]="${module}"
            fi
        done <<< "${ports}"
        pass "Uses ports: $(echo "${ports}" | tr '\n' ' ')"
    fi

    # --- Icon check ---
    local module_id
    module_id=$(grep -oP '^\s+id:\s*"?\K[^"\s]+' "${compose_file}" | head -1)
    if [[ -n "${module_id}" ]]; then
        # Check each service for icons
        local services
        services=$(grep -oP '^\s+[a-z0-9_-]+:$' "${compose_file}" | grep -v "services:" | head -10 || true)
        # Just check if the module's primary icon exists
        if [[ -f "${ICONS_DIR}/${module_id}.svg" ]] || [[ -f "${ICONS_DIR}/${module}.svg" ]]; then
            pass "Icon present"
        else
            warn "No icon found at ${ICONS_DIR}/${module_id}.svg"
        fi
    fi
}

# --- Main ---

info "=== OpenBox Module Validator ==="
info "Scanning ${MODULES_DIR}..."

for module_dir in "${MODULES_DIR}"/*/; do
    module=$(basename "${module_dir}")
    validate_module "${module}" || true
done

# --- Summary ---

echo ""
info "=== Summary ==="
echo -e "${GREEN}  Passed: ${PASS_COUNT}${NC}"
echo -e "${YELLOW}  Warnings: ${WARN_COUNT}${NC}"
echo -e "${RED}  Failed: ${FAIL_COUNT}${NC}"

if [[ ${#PORT_CONFLICTS[@]} -gt 0 ]]; then
    echo ""
    echo -e "${RED}Port conflicts detected:${NC}"
    for conflict in "${PORT_CONFLICTS[@]}"; do
        IFS=':' read -r port mod1 mod2 <<< "${conflict}"
        echo "  Port ${port}: ${mod1} conflicts with ${mod2}"
    done
fi

echo ""
if [[ ${FAIL_COUNT} -gt 0 ]]; then
    echo -e "${RED}Validation FAILED${NC}"
    exit 1
else
    echo -e "${GREEN}Validation PASSED${NC}"
    exit 0
fi
