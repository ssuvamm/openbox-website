#!/usr/bin/env bash
# ==========================================
# OpenBox - Stack Validation Script
# Validates compose files, env vars, ports, and naming
# Includes NAS-specific validations
# Dynamically discovers modules from filesystem
# Run: bash scripts/validate.sh
# ==========================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OB_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

PASS=0
FAIL=0
WARN=0

pass() { echo -e "  ${GREEN}PASS${NC} $*"; PASS=$((PASS + 1)); }
fail() { echo -e "  ${RED}FAIL${NC} $*"; FAIL=$((FAIL + 1)); }
warn() { echo -e "  ${YELLOW}WARN${NC} $*"; WARN=$((WARN + 1)); }
section() { echo ""; echo -e "${BOLD}${CYAN}[$1]${NC}"; }

# --- Detect environment ---

IS_NAS=false
NAS_TYPE=""
if [[ -f "${OB_ROOT}/state/install-meta.conf" ]]; then
    IS_NAS=$(grep '^IS_NAS=' "${OB_ROOT}/state/install-meta.conf" 2>/dev/null | cut -d= -f2 || echo "false")
    NAS_TYPE=$(grep '^NAS_TYPE=' "${OB_ROOT}/state/install-meta.conf" 2>/dev/null | cut -d= -f2 || echo "")
fi

# --- Discover modules dynamically ---

DISCOVERED_MODULES=""
for dir in "${OB_ROOT}/modules"/*/; do
    mod=$(basename "${dir}")
    if [[ -f "${dir}docker-compose.yml" ]]; then
        DISCOVERED_MODULES="${DISCOVERED_MODULES} ${mod}"
    fi
done
DISCOVERED_MODULES=$(echo "${DISCOVERED_MODULES}" | xargs)  # trim

echo -e "${BOLD}Discovered modules:${NC} ${DISCOVERED_MODULES}"
if [[ "${IS_NAS}" == "true" ]]; then
    echo -e "${BOLD}Environment:${NC} NAS (${NAS_TYPE})"
fi

# --- Determine enabled modules ---

ENABLED_MODULES=""
if [[ -f "${OB_ROOT}/state/modules.conf" ]]; then
    ENABLED_MODULES=$(cat "${OB_ROOT}/state/modules.conf" 2>/dev/null | sort -u | xargs)
fi

# --- Generate test .env ---

TEST_ENV="${OB_ROOT}/.env.test"
generate_test_env() {
    cat > "${TEST_ENV}" << 'EOF'
TZ=UTC
OB_ROOT=/opt/openbox
SB_DOMAIN=test.example.com
SB_ADMIN_PASSWORD_HASH=$2a$12$testhashtesthasttesthash
OB_SESSION_SECRET=0000000000000000000000000000000000000000000000000000000000000000
OB_BACKUP_KEY=0000000000000000000000000000000000000000000000000000000000000001
PUID=1000
PGID=1000
HTTP_PORT=80
HTTPS_PORT=443
PIHOLE_DNS_PORT=53
PORTAINER_PORT=9000
OB_DATA_DIR=/opt/openbox/data
MEDIA_ROOT=/data
JELLYFIN_HW_ACCEL=none
VPN_PROVIDER=mullvad
VPN_TYPE=wireguard
WIREGUARD_PRIVATE_KEY=testkey
WIREGUARD_ADDRESSES=10.0.0.1/32
VPN_USER=testuser
VPN_PASSWORD=testpass
SERVER_COUNTRIES=us
EOF

    local compose_vars
    compose_vars=$(grep -rhE '\$\{[A-Z_]+' "${OB_ROOT}/modules/" --include='*.yml' 2>/dev/null | \
        grep -oE '\$\{[A-Z_]+' | sed 's/\${//' | sort -u || true)

    for var in ${compose_vars}; do
        if grep -q "^${var}=" "${TEST_ENV}" 2>/dev/null; then
            continue
        fi
        if grep -qE "\\\$\\{${var}:-" "${OB_ROOT}/modules/"*"/docker-compose.yml" 2>/dev/null; then
            continue
        fi
        echo "${var}=test_value_for_${var}" >> "${TEST_ENV}"
    done
}

cleanup() {
    rm -f "${TEST_ENV}"
}
trap cleanup EXIT

# ==========================================
# TEST 1: Module directories
# ==========================================
section "Module Directories"

for mod in ${DISCOVERED_MODULES}; do
    compose="${OB_ROOT}/modules/${mod}/docker-compose.yml"
    if [[ -f "${compose}" ]]; then
        pass "${mod}/docker-compose.yml exists"
    else
        fail "${mod}/docker-compose.yml MISSING"
    fi
done

# ==========================================
# TEST 2: YAML syntax validation
# ==========================================
section "YAML Syntax"

for mod in ${DISCOVERED_MODULES}; do
    compose="${OB_ROOT}/modules/${mod}/docker-compose.yml"
    [[ -f "${compose}" ]] || continue
    if python3 -c "import yaml; yaml.safe_load(open('${compose}'))" 2>/dev/null; then
        pass "${mod}/docker-compose.yml valid YAML"
    else
        fail "${mod}/docker-compose.yml INVALID YAML"
    fi
done

# ==========================================
# TEST 3: Docker Compose config validation
# ==========================================
section "Docker Compose Config"

generate_test_env

if command -v docker &>/dev/null && docker compose version &>/dev/null; then
    for mod in ${DISCOVERED_MODULES}; do
        compose="${OB_ROOT}/modules/${mod}/docker-compose.yml"
        [[ -f "${compose}" ]] || continue
        if docker compose --env-file "${TEST_ENV}" -f "${compose}" config -q 2>/dev/null; then
            pass "${mod} compose config OK"
        else
            fail "${mod} compose config FAILED"
        fi
    done

    # The former "combined compose" check is gone: docker compose's
    # x-* extension merging rejects two files both defining
    # x-openbox.tips, and every module defines that block, so the
    # check always failed. The CLI never runs combined compose —
    # run_compose_per_module uses a single -f per call — so this
    # check tested a non-existent code path. Codex 2026-04-24 round
    # 2 finding #2.
else
    warn "Docker not available -- skipping compose config validation"
    warn "Install Docker to enable full validation"
fi

# ==========================================
# TEST 4: Naming conventions (sb- prefix)
# ==========================================
section "Naming Conventions"

for mod in ${DISCOVERED_MODULES}; do
    compose="${OB_ROOT}/modules/${mod}/docker-compose.yml"
    [[ -f "${compose}" ]] || continue

    if grep -qE 'ms-|MS_|megastack|x-megastack|ms_' "${compose}" 2>/dev/null; then
        fail "${mod} contains megastack naming references"
        grep -nE 'ms-|MS_|megastack|x-megastack|ms_' "${compose}" | head -5
    else
        pass "${mod} no megastack naming leaks"
    fi

    while IFS= read -r line; do
        name=$(echo "$line" | awk '{print $2}')
        if [[ "${name}" != ob-* ]]; then
            fail "${mod} container '${name}' missing ob- prefix"
        fi
    done < <(grep 'container_name:' "${compose}" 2>/dev/null || true)
done

for mod in ${DISCOVERED_MODULES}; do
    compose="${OB_ROOT}/modules/${mod}/docker-compose.yml"
    [[ -f "${compose}" ]] || continue
    if grep -q 'x-openbox:' "${compose}" 2>/dev/null; then
        pass "${mod} has x-openbox metadata"
    else
        fail "${mod} MISSING x-openbox metadata"
    fi
done

# ==========================================
# TEST 5: Network subnet conflicts
# ==========================================
section "Network Subnets"

declare -A SUBNETS
CONFLICT=0
while IFS= read -r line; do
    file=$(echo "$line" | cut -d: -f1)
    subnet=$(echo "$line" | grep -oE '172\.20\.[0-9]+\.0/24')
    mod=$(echo "$file" | sed 's|.*/modules/||; s|/.*||')

    if [[ -n "${subnet}" ]]; then
        if [[ -n "${SUBNETS[$subnet]:-}" ]]; then
            fail "Subnet ${subnet} conflict: ${mod} vs ${SUBNETS[$subnet]}"
            CONFLICT=1
        else
            SUBNETS[$subnet]="${mod}"
            pass "Subnet ${subnet} -> ${mod}"
        fi
    fi
done < <(grep -r 'subnet:' "${OB_ROOT}/modules/" 2>/dev/null || true)

if [[ ${CONFLICT} -eq 0 ]]; then
    pass "No subnet conflicts (${#SUBNETS[@]} unique subnets)"
fi

# ==========================================
# TEST 6: Port conflicts (compose-level)
# ==========================================
section "Port Conflicts (Compose)"

# Pre-build the conflicts_with map so port collisions between
# modules that already declare they can't co-exist don't fire as
# validation failures. conflicts_with is enforced at enable-time by
# dashboard/lib/modules.js validateFinalModuleSet(); a shared port
# between two mutually-exclusive modules (Pi-hole + AdGuard both on
# :53) is EXPECTED, not a bug.
declare -A CONFLICTS_MAP || true
for mod in ${DISCOVERED_MODULES}; do
    compose="${OB_ROOT}/modules/${mod}/docker-compose.yml"
    [[ -f "${compose}" ]] || continue
    # Grep the conflicts_with line, extract bracketed names.
    line=$(grep -E '^\s*conflicts_with:' "${compose}" 2>/dev/null | head -1 || true)
    [[ -z "${line}" ]] && continue
    names=$(echo "${line}" | grep -oE '\[.*\]' | tr -d '[]' | tr ',' ' ' | tr -d '"')
    for other in ${names}; do
        CONFLICTS_MAP["${mod}:${other}"]=1
        CONFLICTS_MAP["${other}:${mod}"]=1
    done
done

declare -A PORTS || true
PORT_CONFLICT=0
PORT_COUNT=0
for mod in ${DISCOVERED_MODULES}; do
    compose="${OB_ROOT}/modules/${mod}/docker-compose.yml"
    [[ -f "${compose}" ]] || continue
    while IFS= read -r port; do
        [[ -z "${port}" ]] && continue
        if [[ -n "${PORTS[$port]:-}" && "${PORTS[$port]}" != "${mod}" ]]; then
            # If the two modules already declare conflicts_with each
            # other, the port collision is intended — the dashboard
            # prevents simultaneous enable. Downgrade to a warn.
            other="${PORTS[$port]}"
            if [[ -n "${CONFLICTS_MAP["${mod}:${other}"]:-}" ]]; then
                warn "Port ${port} intentionally shared by mutually-exclusive modules: ${mod} vs ${other}"
            else
                fail "Port ${port} conflict: ${mod} vs ${other}"
                PORT_CONFLICT=1
            fi
        else
            PORTS[$port]="${mod}"
            PORT_COUNT=$((PORT_COUNT + 1))
        fi
    # Codex round 3 finding #11: the prior `rev | cut -d: -f2 | rev`
    # extractor produced garbage like `-53}` for mappings that use
    # ${VAR:-default} syntax. Rewrite to parse the DEFAULT from brace-
    # expansions and fall through to the literal port otherwise.
    done < <(grep -E '^\s*-\s*".*:.*:' "${compose}" 2>/dev/null | grep -oE '"[^"]*"' | tr -d '"' | python3 -c '
import sys, re
for mapping in sys.stdin:
    m = mapping.strip()
    if not m:
        continue
    # Replace ${VAR:-default} with just `default` so the rest of the
    # parse sees concrete numbers.
    m = re.sub(r"\$\{[A-Za-z_][A-Za-z0-9_]*:-([^}]+)\}", r"\1", m)
    # ip:host:container/proto  -> host
    # host:container/proto     -> host
    parts = m.split(":")
    host = parts[-2] if len(parts) >= 2 else parts[0]
    # strip trailing /proto
    host = host.split("/")[0].strip()
    if host.isdigit():
        print(host)
' 2>/dev/null | sort -u || true)
done

if [[ ${PORT_CONFLICT} -eq 0 ]]; then
    pass "No port conflicts (${PORT_COUNT} port mappings checked)"
fi

# ==========================================
# TEST 7: Live port conflicts (NAS-aware)
# ==========================================
section "Live Port Conflicts"

if command -v ss &>/dev/null; then
    CRITICAL_PORTS=(53 80 443)
    for port in "${CRITICAL_PORTS[@]}"; do
        local_usage=$(ss -tlnp 2>/dev/null | grep ":${port} " | head -1 || true)
        if [[ -n "${local_usage}" ]]; then
            # Check if it's Docker
            if echo "${local_usage}" | grep -q "docker\|containerd"; then
                pass "Port ${port}: in use by Docker (likely OpenBox)"
            else
                if [[ "${IS_NAS}" == "true" ]]; then
                    warn "Port ${port}: in use by NAS service -- configure alternate port in .env"
                else
                    warn "Port ${port}: in use by another process"
                fi
            fi
        else
            pass "Port ${port}: available"
        fi
    done
else
    warn "ss command not available -- skipping live port check"
fi

# ==========================================
# TEST 8: Environment variable coverage
# ==========================================
section "Environment Variables"

COMPOSE_VARS=$(grep -rhE '\$\{[A-Z_]+' "${OB_ROOT}/modules/" --include='*.yml' 2>/dev/null | \
    grep -oE '\$\{[A-Z_]+' | sed 's/\${//' | sort -u)

ENV_EXAMPLE="${OB_ROOT}/.env.example"
if [[ -f "${ENV_EXAMPLE}" ]]; then
    for var in ${COMPOSE_VARS}; do
        if grep -q "^${var}=" "${ENV_EXAMPLE}" 2>/dev/null || grep -q "^# ${var}=" "${ENV_EXAMPLE}" 2>/dev/null; then
            pass "${var} documented in .env.example"
        else
            if grep -qE "\\\$\\{${var}:-" "${OB_ROOT}/modules/"*"/docker-compose.yml" 2>/dev/null; then
                pass "${var} has default in compose"
            else
                if grep -qE "^    ${var}:" "${OB_ROOT}/modules/"*"/docker-compose.yml" 2>/dev/null; then
                    pass "${var} managed via x-openbox.env_vars"
                else
                    warn "${var} not in .env.example (module-managed)"
                fi
            fi
        fi
    done
else
    fail ".env.example not found"
fi

# ==========================================
# TEST 9: Security (security_opt, resource limits)
# ==========================================
section "Security & Resources"

for mod in ${DISCOVERED_MODULES}; do
    compose="${OB_ROOT}/modules/${mod}/docker-compose.yml"
    [[ -f "${compose}" ]] || continue

    svc_count=$(grep -c 'container_name:' "${compose}" 2>/dev/null || echo 0)

    secopt_count=$(grep -c 'no-new-privileges' "${compose}" 2>/dev/null || echo 0)
    if [[ ${secopt_count} -ge ${svc_count} ]]; then
        pass "${mod} all ${svc_count} services have security_opt"
    else
        fail "${mod} only ${secopt_count}/${svc_count} services have security_opt"
    fi

    limit_count=$(grep -c 'memory:' "${compose}" 2>/dev/null || echo 0)
    if [[ ${limit_count} -ge ${svc_count} ]]; then
        pass "${mod} all services have memory limits"
    else
        warn "${mod} only ${limit_count}/${svc_count} services have memory limits"
    fi

    health_count=$(grep -c 'healthcheck:' "${compose}" 2>/dev/null || echo 0)
    if [[ ${health_count} -ge ${svc_count} ]]; then
        pass "${mod} all services have healthchecks"
    else
        warn "${mod} only ${health_count}/${svc_count} services have healthchecks"
    fi

    log_count=$(grep -c 'max-size:' "${compose}" 2>/dev/null || echo 0)
    if [[ ${log_count} -ge ${svc_count} ]]; then
        pass "${mod} all services have log rotation"
    else
        warn "${mod} only ${log_count}/${svc_count} services have log rotation"
    fi
done

# ==========================================
# TEST 10: Dashboard integration (dynamic)
# ==========================================
section "Dashboard Integration"

for mod in ${DISCOVERED_MODULES}; do
    compose="${OB_ROOT}/modules/${mod}/docker-compose.yml"
    [[ -f "${compose}" ]] || continue

    has_id=$(grep -c '  id:' "${compose}" 2>/dev/null || echo 0)
    has_title=$(grep -c '  title:' "${compose}" 2>/dev/null || echo 0)
    has_category=$(grep -c '  category:' "${compose}" 2>/dev/null || echo 0)

    if [[ ${has_id} -ge 1 && ${has_title} -ge 1 && ${has_category} -ge 1 ]]; then
        pass "${mod} x-openbox has id, title, category"
    else
        fail "${mod} x-openbox missing required fields (id/title/category)"
    fi

    if grep -q '  theme:' "${compose}" 2>/dev/null; then
        pass "${mod} has theme metadata"
    else
        warn "${mod} missing theme metadata"
    fi
done

# ==========================================
# TEST 11: CLI completeness
# ==========================================
section "CLI Completeness"

CLI="${OB_ROOT}/openbox"
if [[ -f "${CLI}" ]]; then
    if grep -q 'discover_modules' "${CLI}" 2>/dev/null; then
        pass "CLI uses dynamic module discovery"
    else
        if grep -q 'AVAILABLE_MODULES' "${CLI}" 2>/dev/null; then
            warn "CLI uses hardcoded AVAILABLE_MODULES (consider upgrading to dynamic)"
        else
            fail "CLI has no module discovery mechanism"
        fi
    fi

    if grep -q 'cmd_doctor' "${CLI}" 2>/dev/null; then
        pass "CLI has doctor command"
    else
        warn "CLI missing doctor command"
    fi

    if bash -n "${CLI}" 2>/dev/null; then
        pass "openbox CLI valid bash syntax"
    else
        fail "openbox CLI has bash syntax errors"
    fi
else
    fail "openbox CLI not found"
fi

SETUP="${OB_ROOT}/scripts/setup.sh"
if [[ -f "${SETUP}" ]]; then
    if bash -n "${SETUP}" 2>/dev/null; then
        pass "setup.sh valid bash syntax"
    else
        fail "setup.sh has bash syntax errors"
    fi

    # Check for profile selection
    if grep -q 'PROFILE' "${SETUP}" 2>/dev/null; then
        pass "setup.sh has profile selection"
    else
        warn "setup.sh missing profile selection"
    fi

    # Check for PUID/PGID
    if grep -q 'PUID' "${SETUP}" 2>/dev/null; then
        pass "setup.sh handles PUID/PGID"
    else
        warn "setup.sh missing PUID/PGID handling"
    fi
else
    fail "scripts/setup.sh not found"
fi

# ==========================================
# TEST 12: NAS-specific validations
# ==========================================
section "NAS Compatibility"

# Check .env if it exists
ENV_FILE="${OB_ROOT}/.env"
if [[ -f "${ENV_FILE}" ]]; then
    # Hardware transcoding
    hw_accel=$(grep '^JELLYFIN_HW_ACCEL=' "${ENV_FILE}" 2>/dev/null | cut -d= -f2 || echo "")
    if [[ "${hw_accel}" == "intel" || "${hw_accel}" == "auto" ]]; then
        if [[ -d /dev/dri ]]; then
            if [[ -e /dev/dri/renderD128 ]]; then
                pass "Hardware transcoding: GPU render device available"
            else
                warn "Hardware transcoding enabled but /dev/dri/renderD128 not found"
            fi
        else
            fail "Hardware transcoding enabled but /dev/dri does not exist"
        fi
    else
        pass "Hardware transcoding: not enabled (or software mode)"
    fi

    # PUID/PGID ownership check
    env_puid=$(grep '^PUID=' "${ENV_FILE}" 2>/dev/null | cut -d= -f2 || echo "")
    env_pgid=$(grep '^PGID=' "${ENV_FILE}" 2>/dev/null | cut -d= -f2 || echo "")
    if [[ -n "${env_puid}" && -n "${env_pgid}" ]]; then
        # Check if OB_ROOT files are owned by PUID:PGID
        sb_owner=$(stat -c '%u' "${OB_ROOT}" 2>/dev/null || echo "")
        if [[ -n "${sb_owner}" ]]; then
            if [[ "${sb_owner}" == "${env_puid}" || "${sb_owner}" == "0" ]]; then
                pass "OB_ROOT ownership compatible with PUID=${env_puid}"
            else
                warn "OB_ROOT owned by UID ${sb_owner}, but PUID=${env_puid} -- may cause permission issues"
            fi
        fi
    else
        warn "PUID/PGID not set in .env"
    fi

    # MEDIA_ROOT validation
    media_root=$(grep '^MEDIA_ROOT=' "${ENV_FILE}" 2>/dev/null | cut -d= -f2 || echo "")
    if [[ -n "${media_root}" ]]; then
        if [[ -d "${media_root}" ]]; then
            pass "MEDIA_ROOT=${media_root} exists"
            if [[ -w "${media_root}" ]]; then
                pass "MEDIA_ROOT is writable"
            else
                fail "MEDIA_ROOT is not writable by current user"
            fi
        else
            warn "MEDIA_ROOT=${media_root} does not exist (will be created on setup)"
        fi
    else
        pass "MEDIA_ROOT not set (media module may not be active)"
    fi
else
    warn ".env not found -- run 'openbox install' to generate"
fi

# ==========================================
# TEST 13: System resource check
# ==========================================
section "System Resources"

if [[ -f /proc/meminfo ]]; then
    total_ram_mb=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
    available_ram_mb=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)

    # Count enabled modules
    if [[ -n "${ENABLED_MODULES}" ]]; then
        mod_count=$(echo "${ENABLED_MODULES}" | wc -w)
    else
        mod_count=$(echo "${DISCOVERED_MODULES}" | wc -w)
    fi

    # RAM estimates based on deploy.resources.limits.memory in compose files
    # These are the maximum limits, not typical usage (typical is ~50-70% of limit)
    estimated_ram=0
    for mod in ${ENABLED_MODULES:-${DISCOVERED_MODULES}}; do
        case "${mod}" in
            core)       estimated_ram=$((estimated_ram + 768)) ;;  # npm(256)+portainer(256)+homepage(256)
            dashboard)  estimated_ram=$((estimated_ram + 128)) ;;
            media)      estimated_ram=$((estimated_ram + 3136)) ;; # gluetun+qbit+arr+jellyfin+seerr+deunhealth
            jellyfin)   estimated_ram=$((estimated_ram + 1024)) ;;
            immich)     estimated_ram=$((estimated_ram + 3712)) ;; # server(1G)+ml(2G)+db(512)+redis(128)
            cloud)      estimated_ram=$((estimated_ram + 1152)) ;; # nextcloud(512)+mariadb(512)+redis(128)
            privacy)    estimated_ram=$((estimated_ram + 640)) ;;  # pihole(256)+vaultwarden(256)+authelia(128)
            vpn)        estimated_ram=$((estimated_ram + 128)) ;;
            monitoring) estimated_ram=$((estimated_ram + 256)) ;;
            files)      estimated_ram=$((estimated_ram + 128)) ;;
            tailscale)  estimated_ram=$((estimated_ram + 128)) ;;
            *)          estimated_ram=$((estimated_ram + 256)) ;;
        esac
    done
    # Typical usage is ~60% of max limits
    estimated_typical=$((estimated_ram * 60 / 100))

    if [[ ${total_ram_mb} -ge ${estimated_ram} ]]; then
        pass "Total RAM ${total_ram_mb}MB sufficient for ~${estimated_typical}MB typical / ~${estimated_ram}MB max (${mod_count} modules)"
    elif [[ ${total_ram_mb} -ge ${estimated_typical} ]]; then
        warn "Total RAM ${total_ram_mb}MB may be tight -- typical usage ~${estimated_typical}MB, max limits ~${estimated_ram}MB (${mod_count} modules)"
    else
        fail "Total RAM ${total_ram_mb}MB likely insufficient -- typical usage ~${estimated_typical}MB, max limits ~${estimated_ram}MB (${mod_count} modules)"
    fi

    if [[ ${available_ram_mb} -lt 1024 ]]; then
        warn "Low available RAM: ${available_ram_mb}MB free"
    else
        pass "Available RAM: ${available_ram_mb}MB"
    fi
else
    warn "Cannot read /proc/meminfo -- skipping RAM check"
fi

# Disk space
sb_disk_free=$(df -BG "${OB_ROOT}" 2>/dev/null | awk 'NR==2 {print int($4)}')
if [[ -n "${sb_disk_free}" ]]; then
    if [[ ${sb_disk_free} -lt 10 ]]; then
        fail "Low disk space at OB_ROOT: ${sb_disk_free}GB free"
    elif [[ ${sb_disk_free} -lt 20 ]]; then
        warn "Disk space at OB_ROOT: ${sb_disk_free}GB free (20GB+ recommended)"
    else
        pass "Disk space at OB_ROOT: ${sb_disk_free}GB free"
    fi
fi

# ==========================================
# Summary
# ==========================================
echo ""
echo -e "${BOLD}============================================${NC}"
echo -e "${BOLD}  Validation Summary${NC}"
echo -e "${BOLD}============================================${NC}"
echo ""
echo -e "  ${GREEN}PASS: ${PASS}${NC}"
echo -e "  ${YELLOW}WARN: ${WARN}${NC}"
echo -e "  ${RED}FAIL: ${FAIL}${NC}"
echo ""

if [[ ${FAIL} -gt 0 ]]; then
    echo -e "  ${RED}${BOLD}VALIDATION FAILED${NC} -- ${FAIL} issue(s) need fixing"
    exit 1
else
    echo -e "  ${GREEN}${BOLD}VALIDATION PASSED${NC} -- all checks OK"
    exit 0
fi
