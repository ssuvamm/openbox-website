// SparkBox self-update E2E QA.
//
// Exercises the live self-update flow end-to-end:
//   1. Login
//   2. Open Updates page
//   3. Check SparkBox Core updates and assert the toast is outcome-aware
//   4. If an update is available, apply it and confirm the dialog
//   5. Assert the progress modal shows real log lines
//   6. Survive the dashboard restart, poll /api/auth/status back to 200
//   7. Re-login
//   8. Verify the running version and sb-* container health
//
// Usage:
//   NODE_PATH=/tmp/ob-qa-deps/node_modules \
//   SPARKBOX_IP=2.24.31.145 \
//   SB_DASHBOARD_PASSWORD=audit-test-pw-12345 \
//   node scripts/browser-update-test.js
//
// Optional:
//   SPARKBOX_PORT=8443
//   SB_QA_SCREENSHOT_DIR=./browser-update-screenshots
//   SB_EXPECTED_VERSION=1.4.7
//   SB_QA_HOST_LABEL=hostinger

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const IP = process.env.SPARKBOX_IP || '192.168.0.17';
const PORT = parseInt(process.env.SPARKBOX_PORT || '8443', 10);
const BASE = `http://${IP}:${PORT}`;
const PASSWORD = process.env.SB_DASHBOARD_PASSWORD || 'test-password-12345';
const EXPECTED_VERSION = (process.env.SB_EXPECTED_VERSION || '').trim();
const HOST_LABEL = process.env.SB_QA_HOST_LABEL || IP;
const SCREENSHOT_DIR = process.env.SB_QA_SCREENSHOT_DIR || path.join(__dirname, '..', 'browser-update-screenshots');
const RESULTS_FILE = path.join(__dirname, '..', `browser-update-results-${HOST_LABEL.replace(/[^a-z0-9._-]+/gi, '_')}.json`);

fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });

const results = [];
function record(name, status, detail) {
  results.push({ name, status, detail: detail || null, ts: new Date().toISOString() });
  const icon = status === 'pass' ? '✓' : status === 'fail' ? '✗' : '…';
  const color = status === 'pass' ? '\x1b[32m' : status === 'fail' ? '\x1b[31m' : '\x1b[33m';
  console.log(`${color}${icon}\x1b[0m ${name}${detail ? ' — ' + detail : ''}`);
}

async function snap(page, label) {
  const safe = label.replace(/[^a-z0-9]+/gi, '_').toLowerCase();
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, `${HOST_LABEL}-${safe}.png`), fullPage: true }).catch(() => {});
}

async function csrfHeader(context) {
  const cookies = await context.cookies(BASE);
  const csrf = cookies.find((c) => c.name === '_csrf');
  return csrf ? { 'X-CSRF-Token': csrf.value } : {};
}

async function apiGet(context, route, opts = {}) {
  const resp = await context.request.get(`${BASE}${route}`, {
    timeout: opts.timeout || 15000,
    failOnStatusCode: false,
  });
  const body = await resp.json().catch(() => null);
  return { status: resp.status(), ok: resp.ok(), body };
}

async function apiPost(context, route, body, opts = {}) {
  const resp = await context.request.post(`${BASE}${route}`, {
    data: body,
    timeout: opts.timeout || 15000,
    failOnStatusCode: false,
    headers: {
      'Content-Type': 'application/json',
      ...(await csrfHeader(context)),
    },
  });
  const parsed = await resp.json().catch(() => null);
  return { status: resp.status(), ok: resp.ok(), body: parsed };
}

async function waitForDashboardReady(context, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let lastStatus = 'no-response';
  while (Date.now() < deadline) {
    try {
      const resp = await context.request.get(`${BASE}/api/auth/status`, {
        timeout: 5000,
        failOnStatusCode: false,
      });
      lastStatus = String(resp.status());
      if (resp.status() === 200) return true;
    } catch (err) {
      lastStatus = err.message;
    }
    await new Promise((r) => setTimeout(r, 3000));
  }
  throw new Error(`dashboard did not return /api/auth/status 200 in time (last=${lastStatus})`);
}

async function waitForLoginOrDashboard(page, timeoutMs) {
  await page.waitForFunction(() => {
    const login = document.querySelector('#login-screen');
    const dash = document.querySelector('#dashboard');
    const visible = (el) => !!el && !el.classList.contains('hidden');
    return visible(login) || visible(dash);
  }, null, { timeout: timeoutMs });
}

async function login(page) {
  await page.waitForSelector('#login-screen:not(.hidden)', { timeout: 15000 });
  await page.fill('#login-password', PASSWORD);
  await page.click('#login-btn');
  await page.waitForSelector('#dashboard:not(.hidden)', { timeout: 15000 });
}

async function skipWizardIfPresent(context, page) {
  try {
    const resp = await apiPost(context, '/api/wizard/skip', {});
    if (resp.status === 200 || resp.status === 204) {
      await page.reload({ waitUntil: 'domcontentloaded' });
      await page.waitForSelector('#dashboard:not(.hidden)', { timeout: 10000 });
    }
  } catch {}
}

async function latestToastText(page, timeoutMs, matcher) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const texts = await page.locator('#toast-wrap .toast').evaluateAll((els) =>
      els.map((el) => (el.textContent || '').trim()).filter(Boolean)
    ).catch(() => []);
    const match = texts.find((text) => matcher.test(text));
    if (match) return match;
    await page.waitForTimeout(200);
  }
  throw new Error(`timed out waiting for toast ${matcher}`);
}

async function visibleText(page, selector) {
  return page.locator(selector).evaluate((el) => (el.textContent || '').trim()).catch(() => '');
}

async function waitForHealthyContainers(context, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let lastDetail = 'no container response';
  while (Date.now() < deadline) {
    const resp = await apiGet(context, '/api/containers', { timeout: 10000 });
    if (resp.ok && Array.isArray(resp.body)) {
      const sbContainers = resp.body.filter((c) => ((c.name || c.Name || '')).startsWith('sb-'));
      const bad = sbContainers.filter((c) => {
        const state = (c.state || c.State || '').toLowerCase();
        const health = (c.health || '').toLowerCase();
        return state !== 'running' || health === 'unhealthy' || health === 'starting';
      });
      if (sbContainers.length > 0 && bad.length === 0) {
        return sbContainers.map((c) => ({
          name: c.name || c.Name,
          state: c.state || c.State || '',
          health: c.health || '',
          status: c.status || c.Status || '',
        }));
      }
      lastDetail = bad.map((c) => `${c.name || c.Name}:${c.state || c.State}/${c.health || 'none'}`).join(', ') || 'no sb-* containers';
    } else {
      lastDetail = `HTTP ${resp.status}`;
    }
    await new Promise((r) => setTimeout(r, 4000));
  }
  throw new Error(`containers not healthy in time (${lastDetail})`);
}

(async () => {
  console.log(`\nSparkBox self-update QA: ${BASE}`);
  console.log(`Host label: ${HOST_LABEL}`);
  console.log(`Expected version: ${EXPECTED_VERSION || '(unset)'}`);
  console.log(`Password: ${PASSWORD ? '(set)' : '(missing)'}\n`);

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    ignoreHTTPSErrors: true,
    viewport: { width: 1440, height: 960 },
    acceptDownloads: true,
  });
  const page = await context.newPage();

  let initialStatus = null;
  let finalStatus = null;

  try {
    await page.goto(BASE, { waitUntil: 'domcontentloaded', timeout: 20000 });
    await login(page);
    record('login', 'pass');

    await skipWizardIfPresent(context, page);

    initialStatus = await apiGet(context, '/api/self-update/check');
    if (!initialStatus.ok) throw new Error(`self-update check API failed: HTTP ${initialStatus.status}`);
    record(
      'initial version probe',
      'pass',
      `current=${initialStatus.body.current} latest=${initialStatus.body.latest || 'unknown'} available=${!!initialStatus.body.updateAvailable}`
    );

    await page.click('.tab[data-page="updates"]');
    await page.waitForSelector('#page-updates:not(.hidden)', { timeout: 10000 });
    await page.waitForSelector('#btn-check-sb-update', { timeout: 10000 });
    await page.waitForTimeout(1000);

    await page.click('#btn-check-sb-update');
    const checkToast = await latestToastText(page, 10000, /(Update available|up to date)/i);
    if (/Checked for SparkBox updates/i.test(checkToast)) {
      throw new Error(`stale toast text returned: ${checkToast}`);
    }
    record('check toast', 'pass', checkToast);

    const currentVersionText = await visibleText(page, '#sb-current-version');
    record('updates page loaded', 'pass', `current=${currentVersionText || 'unknown'}`);

    if (initialStatus.body.updateAvailable) {
      await page.waitForSelector('#btn-apply-sb-update:not(.hidden)', { timeout: 10000 });
      await page.click('#btn-apply-sb-update');
      await page.waitForSelector('#confirm-overlay:not(.hidden)', { timeout: 5000 });
      const confirmTitle = await visibleText(page, '#confirm-title');
      if (!/Update SparkBox Core/i.test(confirmTitle)) {
        throw new Error(`unexpected confirm title: ${confirmTitle}`);
      }
      await page.click('#confirm-ok');

      await page.waitForSelector('#progress-overlay:not(.hidden)', { timeout: 10000 });
      await page.waitForFunction(() => {
        const el = document.querySelector('#progress-log');
        return !!el && (el.textContent || '').trim().length > 0;
      }, null, { timeout: 10000 });

      const initialLog = await visibleText(page, '#progress-log');
      if (!/Asking server to start self-update|Self-update started|Checking for updates/i.test(initialLog)) {
        throw new Error(`progress log did not contain kickoff text: ${initialLog}`);
      }
      record('update modal kickoff', 'pass');

      await page.waitForFunction(() => {
        const lines = ((document.querySelector('#progress-log')?.textContent) || '')
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean);
        return lines.length >= 2;
      }, null, { timeout: 120000 });

      const restartSignal = await Promise.race([
        latestToastText(page, 90000, /Dashboard restarting|updated .*→|Already up to date/i),
        page.waitForFunction(() => {
          const title = (document.querySelector('#progress-title')?.textContent || '').trim();
          const log = (document.querySelector('#progress-log')?.textContent || '').trim();
          return /Dashboard restarting|Updated to v|Already up to date/i.test(title) ||
                 /Connection lost|Update complete|Restarting dashboard container/i.test(log);
        }, null, { timeout: 90000 }).then(async () =>
          `${await visibleText(page, '#progress-title')} :: ${await visibleText(page, '#progress-log')}`),
      ]);
      record('restart signal', 'pass', String(restartSignal).slice(0, 180));
      await snap(page, 'self-update-progress');

      await waitForDashboardReady(context, 180000);
      record('dashboard returned', 'pass', '/api/auth/status is 200 again');

      await page.reload({ waitUntil: 'domcontentloaded', timeout: 20000 }).catch(async () => {
        await page.goto(BASE, { waitUntil: 'domcontentloaded', timeout: 20000 });
      });
      await waitForLoginOrDashboard(page, 20000);

      const dashboardVisible = await page.locator('#dashboard:not(.hidden)').count().catch(() => 0);
      if (dashboardVisible) {
        await page.click('#logout-btn').catch(() => {});
        await page.waitForSelector('#login-screen:not(.hidden)', { timeout: 10000 });
      }

      await login(page);
      record('re-login after update', 'pass');
      await skipWizardIfPresent(context, page);
    } else {
      record('self-update apply', 'pass', 'skipped because host is already on latest');
    }

    finalStatus = await apiGet(context, '/api/self-update/check');
    if (!finalStatus.ok) throw new Error(`final self-update check API failed: HTTP ${finalStatus.status}`);

    const finalCurrent = (finalStatus.body.current || '').trim();
    const finalLatest = (finalStatus.body.latest || '').trim();
    if (EXPECTED_VERSION && finalCurrent !== EXPECTED_VERSION) {
      throw new Error(`expected version ${EXPECTED_VERSION}, got ${finalCurrent}`);
    }
    if (initialStatus.body.updateAvailable && finalLatest && finalCurrent !== finalLatest) {
      throw new Error(`version did not advance to latest (${finalCurrent} vs ${finalLatest})`);
    }
    record('version verification', 'pass', `current=${finalCurrent} latest=${finalLatest || 'unknown'} available=${!!finalStatus.body.updateAvailable}`);

    const healthy = await waitForHealthyContainers(context, 180000);
    record('container health', 'pass', `${healthy.length} sb-* containers running and healthy`);

    await snap(page, 'final-dashboard');
  } catch (err) {
    record('self-update qa', 'fail', err.message);
    await snap(page, 'failure');
    process.exitCode = 1;
  } finally {
    await browser.close().catch(() => {});
    fs.writeFileSync(RESULTS_FILE, JSON.stringify({
      host: HOST_LABEL,
      base: BASE,
      expectedVersion: EXPECTED_VERSION || null,
      initialStatus: initialStatus && initialStatus.body ? initialStatus.body : null,
      finalStatus: finalStatus && finalStatus.body ? finalStatus.body : null,
      results,
    }, null, 2));
    console.log(`\nResults written to ${RESULTS_FILE}\n`);
  }
})();
