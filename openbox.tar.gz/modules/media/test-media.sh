#!/bin/bash
# ============================================================
# SparkBox Media Module — Health Check & Troubleshooting
#
# Run this after starting the media module to verify everything
# is working correctly. It checks each service, tests VPN
# connectivity, and provides specific fixes for any issues.
#
# Usage: bash test-media.sh
# ============================================================

set -o pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

PASS="${GREEN}✓ PASS${NC}"
FAIL="${RED}✗ FAIL${NC}"
WARN="${YELLOW}! WARN${NC}"
TOTAL_PASS=0
TOTAL_FAIL=0
TOTAL_WARN=0

pass() { echo -e "  ${PASS}  $1"; ((TOTAL_PASS++)); }
fail() { echo -e "  ${FAIL}  $1"; ((TOTAL_FAIL++)); }
warn() { echo -e "  ${WARN}  $1"; ((TOTAL_WARN++)); }
header() { echo -e "\n${CYAN}${BOLD}[$1]${NC}"; }
fix() { echo -e "         ${YELLOW}Fix: $1${NC}"; }

# SparkBox paths
SB_ROOT="${SB_ROOT:-/opt/sparkbox}"
MEDIA_ROOT="${MEDIA_ROOT:-/data}"

echo ""
echo "========================================="
echo "  SparkBox Media — Health Check"
echo "========================================="
echo ""

# ============================================================
# TEST 1: Docker running?
# ============================================================
header "Docker"

if docker info > /dev/null 2>&1; then
    pass "Docker is running"
else
    fail "Docker is not running"
    fix "Start Docker: sudo systemctl start docker"
    fix "Or install: curl -fsSL https://get.docker.com | sh"
    echo ""
    echo "Cannot continue without Docker. Exiting."
    exit 1
fi

# ============================================================
# TEST 2: SparkBox .env file has VPN credentials?
# ============================================================
header "Configuration"

ENV_FILE="${SB_ROOT}/.env"

if [ -f "$ENV_FILE" ]; then
    pass ".env file exists ($ENV_FILE)"
else
    # Fall back to checking current directory
    if [ -f .env ]; then
        ENV_FILE=".env"
        pass ".env file exists (current directory)"
    else
        fail ".env file not found"
        fix "Run the SparkBox installer or create ${SB_ROOT}/.env"
    fi
fi

if [ -f "$ENV_FILE" ]; then
    VPN_KEY=$(grep -E "^WIREGUARD_PRIVATE_KEY=" "$ENV_FILE" 2>/dev/null | cut -d= -f2)
    VPN_USER=$(grep -E "^VPN_USER=" "$ENV_FILE" 2>/dev/null | cut -d= -f2)
    VPN_PROVIDER=$(grep -E "^VPN_PROVIDER=" "$ENV_FILE" 2>/dev/null | cut -d= -f2)
    VPN_TYPE=$(grep -E "^VPN_TYPE=" "$ENV_FILE" 2>/dev/null | cut -d= -f2)

    if [ -n "$VPN_KEY" ] && [ "$VPN_KEY" != "" ]; then
        pass "WireGuard private key is set (provider: ${VPN_PROVIDER:-not set})"
    elif [ -n "$VPN_USER" ] && [ "$VPN_USER" != "" ]; then
        pass "VPN credentials are set (provider: ${VPN_PROVIDER:-not set})"
    else
        fail "No VPN credentials found (no WIREGUARD_PRIVATE_KEY or VPN_USER)"
        fix "Edit $ENV_FILE and add your VPN credentials"
        fix "Get credentials from your VPN provider's manual setup page"
    fi
fi

# ============================================================
# TEST 3: Folder structure exists?
# ============================================================
header "Folder Structure"

ALL_FOLDERS_OK=true
for dir in "$MEDIA_ROOT"/torrents/movies "$MEDIA_ROOT"/torrents/tv "$MEDIA_ROOT"/torrents/music "$MEDIA_ROOT"/media/movies "$MEDIA_ROOT"/media/tv "$MEDIA_ROOT"/media/music; do
    if [ -d "$dir" ]; then
        pass "$dir exists"
    else
        fail "$dir missing"
        ALL_FOLDERS_OK=false
    fi
done

if [ "$ALL_FOLDERS_OK" = false ]; then
    fix "Run: sudo bash ${SB_ROOT}/modules/media/setup-folders.sh"
fi

# Check permissions
if [ -d "$MEDIA_ROOT" ]; then
    OWNER=$(stat -c '%u' "$MEDIA_ROOT" 2>/dev/null)
    ENV_PUID=$(grep -E "^PUID=" "$ENV_FILE" 2>/dev/null | cut -d= -f2)
    if [ "$OWNER" = "${ENV_PUID:-1000}" ] || [ "$OWNER" = "$(id -u)" ]; then
        pass "$MEDIA_ROOT ownership matches PUID ($OWNER)"
    else
        warn "$MEDIA_ROOT owned by $OWNER but PUID is ${ENV_PUID:-1000}"
        fix "Run: sudo chown -R ${ENV_PUID:-1000}:${ENV_PUID:-1000} $MEDIA_ROOT"
    fi
fi

# ============================================================
# TEST 4: Container status
# ============================================================
header "Containers"

# Core services (always expected)
CORE_SERVICES="ob-gluetun ob-qbittorrent ob-prowlarr sb-sonarr sb-radarr sb-bazarr sb-jellyfin-media sb-seerr sb-deunhealth"
# Optional services (only check if running)
OPTIONAL_SERVICES="sb-lidarr ob-sabnzbd sb-flaresolverr sb-notifiarr"

check_container() {
    local svc=$1
    local optional=$2
    STATUS=$(docker inspect --format '{{.State.Status}}' "$svc" 2>/dev/null)
    HEALTH=$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}no-healthcheck{{end}}' "$svc" 2>/dev/null)

    if [ -z "$STATUS" ]; then
        if [ "$optional" = "true" ]; then
            return  # Skip optional services that aren't created
        fi
        fail "$svc — not found (not created)"
        fix "Run: sparkbox start media"
    elif [ "$STATUS" = "running" ]; then
        if [ "$HEALTH" = "healthy" ]; then
            pass "$svc — running (healthy)"
        elif [ "$HEALTH" = "unhealthy" ]; then
            fail "$svc — running but UNHEALTHY"
            if [ "$svc" = "ob-gluetun" ]; then
                fix "VPN probably can't connect. Check credentials in .env"
                fix "Check logs: docker logs ob-gluetun | tail -20"
            elif [ "$svc" = "ob-qbittorrent" ]; then
                fix "Usually means VPN dropped. sb-deunhealth should auto-restart it."
                fix "Check: docker logs ob-qbittorrent | tail -20"
            fi
        elif [ "$HEALTH" = "starting" ]; then
            warn "$svc — running (health check starting, wait 30s and rerun)"
        else
            pass "$svc — running"
        fi
    elif [ "$STATUS" = "created" ]; then
        warn "$svc — created but not started"
        if [ "$svc" = "ob-qbittorrent" ] || [ "$svc" = "ob-prowlarr" ] || [ "$svc" = "sb-sonarr" ] || [ "$svc" = "sb-radarr" ]; then
            fix "Waiting for ob-gluetun to be healthy. Check Gluetun status first."
        else
            fix "Try: docker start $svc"
        fi
    elif [ "$STATUS" = "exited" ]; then
        fail "$svc — exited (crashed)"
        fix "Check logs: docker logs $svc | tail -30"
        fix "Try restarting: docker start $svc"
    else
        warn "$svc — status: $STATUS"
    fi
}

for svc in $CORE_SERVICES; do
    check_container "$svc" "false"
done

for svc in $OPTIONAL_SERVICES; do
    check_container "$svc" "true"
done

# ============================================================
# TEST 5: VPN connectivity
# ============================================================
header "VPN Connection"

GLUETUN_STATUS=$(docker inspect --format '{{.State.Status}}' ob-gluetun 2>/dev/null)
GLUETUN_HEALTH=$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{end}}' ob-gluetun 2>/dev/null)

if [ "$GLUETUN_STATUS" = "running" ] && [ "$GLUETUN_HEALTH" = "healthy" ]; then
    # Get VPN IP
    VPN_IP=$(docker exec ob-gluetun wget -qO- --timeout=10 ipinfo.io/ip 2>/dev/null)
    if [ -n "$VPN_IP" ]; then
        pass "Gluetun VPN IP: $VPN_IP"

        # Get VPN location
        VPN_LOCATION=$(docker exec ob-gluetun wget -qO- --timeout=10 "ipinfo.io/${VPN_IP}/city" 2>/dev/null)
        VPN_COUNTRY=$(docker exec ob-gluetun wget -qO- --timeout=10 "ipinfo.io/${VPN_IP}/country" 2>/dev/null)
        if [ -n "$VPN_LOCATION" ]; then
            pass "VPN location: $VPN_LOCATION, $VPN_COUNTRY"
        fi
    else
        fail "Gluetun is healthy but can't reach the internet"
        fix "Check logs: docker logs ob-gluetun | tail -20"
    fi

    # Check if qBittorrent is tunneled
    QBIT_STATUS=$(docker inspect --format '{{.State.Status}}' ob-qbittorrent 2>/dev/null)
    if [ "$QBIT_STATUS" = "running" ]; then
        QBIT_IP=$(docker exec ob-qbittorrent wget -qO- --timeout=10 ipinfo.io/ip 2>/dev/null)
        if [ "$QBIT_IP" = "$VPN_IP" ]; then
            pass "qBittorrent tunneled through VPN ($QBIT_IP)"
        elif [ -n "$QBIT_IP" ]; then
            fail "qBittorrent IP ($QBIT_IP) doesn't match VPN IP ($VPN_IP)!"
            fix "This should not happen. Check network_mode in docker-compose.yml"
        else
            warn "Could not check qBittorrent IP (container may still be starting)"
        fi
    fi

    # Check if Prowlarr is tunneled
    PROWLARR_STATUS=$(docker inspect --format '{{.State.Status}}' ob-prowlarr 2>/dev/null)
    if [ "$PROWLARR_STATUS" = "running" ]; then
        PROWLARR_IP=$(docker exec ob-prowlarr wget -qO- --timeout=10 ipinfo.io/ip 2>/dev/null)
        if [ "$PROWLARR_IP" = "$VPN_IP" ]; then
            pass "Prowlarr tunneled through VPN ($PROWLARR_IP)"
        elif [ -n "$PROWLARR_IP" ]; then
            fail "Prowlarr IP ($PROWLARR_IP) doesn't match VPN IP ($VPN_IP)!"
        fi
    fi

    # Check if SABnzbd is tunneled (if running)
    SAB_STATUS=$(docker inspect --format '{{.State.Status}}' ob-sabnzbd 2>/dev/null)
    if [ "$SAB_STATUS" = "running" ]; then
        SAB_IP=$(docker exec ob-sabnzbd wget -qO- --timeout=10 ipinfo.io/ip 2>/dev/null)
        if [ "$SAB_IP" = "$VPN_IP" ]; then
            pass "SABnzbd tunneled through VPN ($SAB_IP)"
        elif [ -n "$SAB_IP" ]; then
            fail "SABnzbd IP ($SAB_IP) doesn't match VPN IP ($VPN_IP)!"
        fi
    fi

    # Verify your real IP is different
    REAL_IP=$(wget -qO- --timeout=10 ipinfo.io/ip 2>/dev/null)
    if [ -n "$REAL_IP" ] && [ "$REAL_IP" != "$VPN_IP" ]; then
        pass "Real IP ($REAL_IP) differs from VPN IP — VPN is working!"
    elif [ "$REAL_IP" = "$VPN_IP" ]; then
        warn "Real IP matches VPN IP — are you already running a system-wide VPN?"
    fi
else
    if [ "$GLUETUN_HEALTH" = "unhealthy" ]; then
        fail "Gluetun is unhealthy — VPN not connected"
        fix "Check credentials in .env (these are NOT your VPN login email/password)"
        fix "Check logs: docker logs ob-gluetun 2>&1 | tail -30"
    elif [ "$GLUETUN_HEALTH" = "starting" ]; then
        warn "Gluetun health check still starting — wait 30-60 seconds and rerun"
    else
        warn "Gluetun not running — can't test VPN"
        fix "Run: sparkbox start media"
    fi
fi

# ============================================================
# TEST 6: Service web UI accessibility
# ============================================================
header "Web UI Access"

check_http() {
    local name=$1 port=$2
    local code=$(curl -sL -o /dev/null -w "%{http_code}" --max-time 5 "http://localhost:$port" 2>/dev/null)
    if [ "$code" = "200" ] || [ "$code" = "302" ] || [ "$code" = "301" ] || [ "$code" = "307" ]; then
        pass "$name — http://localhost:$port (HTTP $code)"
    elif [ "$code" = "000" ]; then
        local container="sb-${name}"
        local status=$(docker inspect --format '{{.State.Status}}' "$container" 2>/dev/null)
        if [ "$status" = "running" ]; then
            warn "$name — container running but port $port not reachable from host"
            fix "Port may be mapped on Gluetun. Try: http://localhost:$port"
        else
            fail "$name — not reachable (container not running)"
        fi
    else
        warn "$name — http://localhost:$port returned HTTP $code"
    fi
}

check_http qbittorrent 8080
check_http prowlarr 8181
check_http radarr 7878
check_http sonarr 8989
check_http bazarr 6767
check_http jellyfin-media 8096
check_http seerr 5055

# Optional services — only check if running
for svc_port in "lidarr:8686" "sabnzbd:8085" "flaresolverr:8191" "notifiarr:5454"; do
    svc="${svc_port%%:*}"
    port="${svc_port##*:}"
    STATUS=$(docker inspect --format '{{.State.Status}}' "sb-$svc" 2>/dev/null)
    if [ "$STATUS" = "running" ]; then
        check_http "$svc" "$port"
    fi
done

# ============================================================
# TEST 7: Hard link capability
# ============================================================
header "Hard Links"

if [ -d "$MEDIA_ROOT/torrents" ] && [ -d "$MEDIA_ROOT/media" ]; then
    # Check if same filesystem
    FS_TORRENTS=$(df "$MEDIA_ROOT/torrents" --output=source 2>/dev/null | tail -1)
    FS_MEDIA=$(df "$MEDIA_ROOT/media" --output=source 2>/dev/null | tail -1)

    if [ "$FS_TORRENTS" = "$FS_MEDIA" ]; then
        pass "torrents/ and media/ are on the same filesystem ($FS_TORRENTS)"
        pass "Hard links will work correctly"
    else
        fail "torrents/ ($FS_TORRENTS) and media/ ($FS_MEDIA) are on DIFFERENT filesystems!"
        fix "Hard links only work on the same filesystem/drive"
        fix "Move both directories to the same drive"
    fi

    # Quick hard link test
    TEST_FILE="$MEDIA_ROOT/torrents/.hardlink_test_$$"
    TEST_LINK="$MEDIA_ROOT/media/.hardlink_test_$$"
    if touch "$TEST_FILE" 2>/dev/null && ln "$TEST_FILE" "$TEST_LINK" 2>/dev/null; then
        pass "Hard link test succeeded"
        rm -f "$TEST_FILE" "$TEST_LINK" 2>/dev/null
    elif [ -f "$TEST_FILE" ]; then
        fail "Hard link test failed — filesystem may not support hard links"
        fix "Check filesystem type: df -T $MEDIA_ROOT"
        fix "Hard links work on ext4, btrfs, xfs. NOT on exFAT or ntfs-3g"
        rm -f "$TEST_FILE" 2>/dev/null
    else
        warn "Could not write to $MEDIA_ROOT/torrents (permission issue?)"
        fix "Run: sudo chown -R $(id -u):$(id -g) $MEDIA_ROOT"
    fi
else
    warn "Folder structure not found — skipping hard link test"
    fix "Run: sudo bash ${SB_ROOT}/modules/media/setup-folders.sh"
fi

# ============================================================
# SUMMARY
# ============================================================
echo ""
echo "========================================="
echo -e "  ${GREEN}Passed: $TOTAL_PASS${NC}   ${RED}Failed: $TOTAL_FAIL${NC}   ${YELLOW}Warnings: $TOTAL_WARN${NC}"
echo "========================================="

if [ $TOTAL_FAIL -eq 0 ] && [ $TOTAL_WARN -eq 0 ]; then
    echo -e "\n  ${GREEN}${BOLD}All checks passed! Your media stack is ready to go.${NC}\n"
elif [ $TOTAL_FAIL -eq 0 ]; then
    echo -e "\n  ${YELLOW}${BOLD}No failures, but check the warnings above.${NC}\n"
else
    echo -e "\n  ${RED}${BOLD}Some checks failed. Follow the fix instructions above.${NC}"
    echo -e "  ${BOLD}If stuck, check: docker logs <container-name>${NC}\n"
fi
