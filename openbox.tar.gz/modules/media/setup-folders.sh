#!/bin/bash
# ============================================================
# SparkBox Media Module — Folder Structure Setup
#
# Creates the directory structure required for hard links
# to work correctly. Run this ONCE before starting the media module.
#
# Usage: sudo bash setup-folders.sh
# ============================================================

set -e

DATA_DIR="${MEDIA_ROOT:-/data}"

echo ""
echo "=== SparkBox Media — Folder Setup ==="
echo ""
echo "This will create the following structure:"
echo ""
echo "  ${DATA_DIR}/"
echo "  ├── torrents/"
echo "  │   ├── movies/"
echo "  │   ├── tv/"
echo "  │   └── music/"
echo "  ├── usenet/"
echo "  │   ├── movies/"
echo "  │   ├── tv/"
echo "  │   └── music/"
echo "  └── media/"
echo "      ├── movies/"
echo "      ├── tv/"
echo "      └── music/"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "ERROR: This script needs sudo to create directories and set permissions."
    echo "Run: sudo bash setup-folders.sh"
    exit 1
fi

# Get the real user (not root) for ownership
REAL_USER=${SUDO_USER:-$USER}
REAL_UID=$(id -u "$REAL_USER")
REAL_GID=$(id -g "$REAL_USER")

echo "Creating folders..."
mkdir -p "$DATA_DIR"/{torrents/{movies,tv,music},usenet/{movies,tv,music},media/{movies,tv,music}}

echo "Setting ownership to $REAL_USER ($REAL_UID:$REAL_GID)..."
chown -R "$REAL_UID":"$REAL_GID" "$DATA_DIR"

echo "Setting permissions..."
chmod -R 775 "$DATA_DIR"

echo ""
echo "Done! Folder structure:"
if command -v tree &> /dev/null; then
    tree "$DATA_DIR"
else
    find "$DATA_DIR" -type d | head -20
fi

echo ""
echo "Your PUID=$REAL_UID and PGID=$REAL_GID"
echo "Make sure these match your SparkBox .env file."
echo ""
